//
//  FundingDetailView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/10.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import SwiftySegmentedControl

class FundingDetailView: UIView {

    lazy var segmentedBar : SwiftySegmentedControl = {
        () -> SwiftySegmentedControl in
        let tempBar = SwiftySegmentedControl(
            frame: CGRect.zero,
            titles: [],
            index: 0,
            backgroundColor: kGASerperatorLineGrayColor,
            titleColor: kGAFontBlackColor,
            indicatorViewBackgroundColor: UIColor.white,
            selectedTitleColor: kGANavigationBackgroundColor)
        tempBar.autoresizingMask = [.flexibleWidth]
        tempBar.indicatorViewInset = 0
        tempBar.cornerRadius = 0.0
        tempBar.titleFont = UIFont(name: "HelveticaNeue", size: 16.0)!
        tempBar.selectedTitleFont = UIFont(name: "HelveticaNeue", size: 18.0)!
        tempBar.bouncesOnChange = true
        tempBar.panningDisabled = true
        tempBar.indicatorViewLineColor = kGANavigationBackgroundColor
        
        return tempBar
    }()
    
    lazy var collectionView : UICollectionView = {
        () -> UICollectionView in
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        let tempView = UICollectionView.init(frame: CGRect.zero, collectionViewLayout: layout)
        tempView.backgroundColor = .white
        tempView.isPagingEnabled = true
        return tempView
    }()
    
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        self.addSubview(self.segmentedBar)
        self.addSubview(self.collectionView)
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func layoutSubviews() {
        self.segmentedBar.snp.makeConstraints({ (make) in
            make.top.equalTo(self)
            make.left.equalTo(self)
            make.width.equalTo(self)
            make.height.equalTo(55)
        })

        self.collectionView.snp.makeConstraints { (make) in
            make.top.equalTo((self.segmentedBar.snp.bottom))
            make.left.equalTo(self)
            make.width.equalTo(self)
            make.bottom.equalTo(self)
        }
    }

}
