//
//  FundingDetailListAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/13.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class FundingDetailListAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kId = "id"
        static let kDescription = "description"
        static let kCreatedTime = "created_at"
        static let kAmount = "amount"
        static let kIs_income = "is_income"
    }
    
    var page = 1
    let pagesize = 20
    var isRefresh = true
    var dataDictList = NSArray() as! [NSDictionary]
    override init() {
        super.init()
        self.validator = self
    }
}

extension FundingDetailListAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Fund&action=getTransactionList"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        
        if self.isRefresh {self.page = 1}
        resultParams["page"] = self.page
        resultParams["pagesize"] = self.pagesize
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let currentDate = Date()
        var timeInterval = currentDate.timeIntervalSince1970
        //默认查询一年
        timeInterval -= 364 * 24 * 3600
        let beginDate = Date.init(timeIntervalSince1970: timeInterval)
        let beginTime = dateFormatter.string(from: beginDate) + " 00:00:00"
        let endTime = dateFormatter.string(from: currentDate) + " 23:59:59"
        
        resultParams["begin_time"] = beginTime
        resultParams["end_time"] = endTime
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}

extension FundingDetailListAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let dataList = data.object(forKey: "data") as? [NSDictionary] else { return NSArray() }
        
        if self.isRefresh {
            self.dataDictList = dataList
        } else {
            let tempArray = NSMutableArray.init(array: self.dataDictList)
            tempArray.addObjects(from: dataList)
            self.dataDictList = tempArray.copy() as! [NSDictionary]
        }
        if dataList.count > 0 {
            self.page = self.page + 1
        }
        return dataList
    }
}
