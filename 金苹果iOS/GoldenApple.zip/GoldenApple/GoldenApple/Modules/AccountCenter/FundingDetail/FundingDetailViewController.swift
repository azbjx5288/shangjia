//
//  FundingDetailViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/10.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import SwiftySegmentedControl

fileprivate let reuseIdentifier = "FundingDetailCellIdentifier"

class FundingDetailViewController: UIViewController {

    var myView : FundingDetailView?
    let apiManager = FundingDetailTypeAPIManager()
    var typeArray : [NSDictionary]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "资金明细"
        
        self.view = FundingDetailView()
        self.myView = self.view as? FundingDetailView
        
        self.myView?.segmentedBar.addTarget(self, action: #selector(segmentedBarValueChanged(_:)), for: .valueChanged)
        self.myView?.collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        self.myView?.collectionView.delegate = self
        self.myView?.collectionView.dataSource = self
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.loadData()
    }
    override func viewDidDisappear(_ animated: Bool) {
        for controler in self.childViewControllers {
            controler.removeFromParentViewController()
        }
        self.typeArray = nil
        self.apiManager.delegate = nil
        self.apiManager.paramSource = nil
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func segmentedBarValueChanged(_ sender: SwiftySegmentedControl) {
        let indexPath = NSIndexPath.init(row: Int(sender.index), section: 0)
        self.myView?.collectionView.scrollToItem(at: indexPath as IndexPath, at: UICollectionViewScrollPosition.centeredHorizontally, animated: true)
    }

}

extension FundingDetailViewController: UIScrollViewDelegate {
    
    // 当手动改变scrollView的offset，动画结束时调用
    func  scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        let index = self.myView?.segmentedBar.index
        let vc = self.childViewControllers[Int(index!)] as! FundingDetailListViewController
        vc.loadData()
    }
    
    // 当scrollView停止滚动时回调
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let index = scrollView.contentOffset.x / UIScreen.main.bounds.size.width
        do {
            try self.myView?.segmentedBar.setIndex(UInt(index), animated: true)
        } catch {
            print(error)
        }
        let vc = self.childViewControllers[Int(index)] as! FundingDetailListViewController
        vc.loadData()
    }
}

extension FundingDetailViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.typeArray != nil {
            return (self.typeArray?.count)! + 1
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath)
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.frame.size
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
        return UIEdgeInsetsMake(0, 0, 0, 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let vc = self.childViewControllers[indexPath.row] as! FundingDetailListViewController
        cell.contentView.addSubview((vc.view)!)
        vc.view?.snp.makeConstraints { (make) in
            make.edges.equalTo(cell.contentView)
        }
        
        if indexPath.row == 0 && vc.apiManager.dataDictList.count == 0 {
            vc.loadData()
        }
    }

    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        for view in cell.contentView.subviews {
            view.removeFromSuperview()
        }
    }
}
extension FundingDetailViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {

        GAProgressHUD.showLoading(message: "正在加载...")
        return nil
    }
    
}
extension FundingDetailViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        self.typeArray = manager.fetchData(self.apiManager) as? NSArray as? [NSDictionary]
        let titles = NSMutableArray()
    
        titles.add("全部")
        for dict in self.typeArray! {
            titles.add(dict.object(forKey: "description") as! String)
        }
        
        //添加所有子控制器
        for i in (0...titles.count - 1) {
            let vc = FundingDetailListViewController()
            if i != 0 {
                vc.typeId = self.typeArray![i - 1].object(forKey: "id") as? Int
            }
            self.addChildViewController(vc)
        }

        //设置segmentedBar的标题
        self.myView?.segmentedBar.titles = titles as! [String]
        self.myView?.collectionView.reloadData()
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//    }
}
