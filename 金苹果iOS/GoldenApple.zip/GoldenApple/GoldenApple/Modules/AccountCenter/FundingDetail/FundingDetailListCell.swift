//
//  FundingDetailListCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/10.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class FundingDetailListCell: UITableViewCell {

    private var nameLB : UILabel?
    private var timeLB : UILabel?
    private var amountLB : UILabel?
    static func cellWithTableView(tableView : UITableView) -> FundingDetailListCell {
        let cellIdentifier = "FundingDetailListCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? FundingDetailListCell
        if cell == nil {
            cell = FundingDetailListCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.nameLB = UILabel()
        self.nameLB?.text = "类型"
        self.nameLB?.font = UIFont.systemFont(ofSize: 16)
        self.nameLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.nameLB!)
        self.nameLB?.snp.makeConstraints({ (make) in
            make.top.equalTo(self.contentView).offset(20)
            make.left.equalTo(self.contentView).offset(15)
        })
        
        self.timeLB = UILabel()
        self.timeLB?.text = "0000-00-00 00:00:00"
        self.timeLB?.font = UIFont.systemFont(ofSize: 14)
        self.timeLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.timeLB!)
        self.timeLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.nameLB!)
            make.bottom.equalTo(self.contentView).offset(-20)
        })
        
        self.amountLB = UILabel()
        self.amountLB?.text = "00.00"
        self.amountLB?.font = UIFont.systemFont(ofSize: 14)
        self.amountLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.amountLB!)
        self.amountLB?.snp.makeConstraints({ (make) in
            make.right.equalTo(self.contentView).offset(-15)
            make.centerY.equalTo(self.contentView)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
    }
    public func setData(dict : NSDictionary) {
        self.nameLB?.text = dict.object(forKey: FundingDetailListAPIManager.DataKey.kDescription) as? String
        self.timeLB?.text = dict.object(forKey: FundingDetailListAPIManager.DataKey.kCreatedTime) as? String
        let amount = dict.object(forKey: FundingDetailListAPIManager.DataKey.kAmount) as? String
        let is_income = dict.object(forKey: FundingDetailListAPIManager.DataKey.kIs_income) as? Int
        if is_income == 1 {
            self.amountLB?.textColor = kGANavigationBackgroundColor
            self.amountLB?.text = "+" + amount!
        } else {
            self.amountLB?.textColor = kGAFontBlackColor
            self.amountLB?.text = "-" + amount!
        }
    }
}
