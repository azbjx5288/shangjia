//
//  FundingDetailListViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/10.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import MJRefresh

class FundingDetailListViewController: UIViewController {

    var myView : FundingDetailListView?
    var typeId : Int?
    var apiManager = FundingDetailListAPIManager()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view = FundingDetailListView()
        self.myView = self.view as? FundingDetailListView
        
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        
        let header = MJRefreshNormalHeader.init {[weak self] in
            self?.apiManager.isRefresh = true
            self?.apiManager.loadData()
        }
        header?.lastUpdatedTimeLabel.isHidden = true
        
        let footer = MJRefreshAutoNormalFooter.init {[weak self] in
            self?.apiManager.isRefresh = false
            self?.apiManager.loadData()
        }
        
        self.myView?.tableView.mj_header = header
        self.myView?.tableView.mj_footer = footer
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }

    public func loadData() {
        if self.apiManager.dataDictList.count == 0 {
            self.myView?.tableView.mj_header.beginRefreshing()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
extension FundingDetailListViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.apiManager.dataDictList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = FundingDetailListCell.cellWithTableView(tableView: tableView)
        cell.setData(dict: self.apiManager.dataDictList[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
}

extension FundingDetailListViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {

        if (self.typeId != nil) {
            return ["type_id" : self.typeId as Any]
        } else {
            return NSDictionary()
        }
    }
    
}
extension FundingDetailListViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        let array = manager.fetchData(self.apiManager) as? NSArray as? [NSDictionary]
        self.myView?.tableView.reloadData()
        if !self.apiManager.isRefresh && array?.count == 0 {
            let footer = self.myView?.tableView.mj_footer as! MJRefreshAutoNormalFooter
            footer.endRefreshingWithNoMoreData()
        } else {
            self.myView?.tableView.mj_header.endRefreshing()
            self.myView?.tableView.mj_footer.endRefreshing()
        }
        
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        self.myView?.tableView.mj_header.endRefreshing()
        self.myView?.tableView.mj_footer.endRefreshing()
//        self.apiManager.callAPIDidFailed(manager)
    }
}
