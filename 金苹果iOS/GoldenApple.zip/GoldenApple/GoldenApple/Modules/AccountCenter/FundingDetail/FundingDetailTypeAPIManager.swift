//
//  FundingDetailTypeAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/10.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class FundingDetailTypeAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kId = "id"
        static let kDescription = "description"
    }
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension FundingDetailTypeAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Fund&action=getTransactionTypeList"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}

extension FundingDetailTypeAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultArray = data.object(forKey: "data") as? NSArray else { return NSArray() }
        let predicate = NSPredicate.init(format: "id == %d || id == %d || id == %d", 11,1,2)
        let typeArray = resultArray.filtered(using: predicate) as? [NSDictionary]
        return typeArray
    }
}
