//
//  AccountCenterViewController.swift
//  GoldenApple
//
//  Created by User on 16/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import MJRefresh


class AccountCenterViewController: UIViewController {

    var myView : AccountCenterView?
    let apiManager = AccountCenterAPIManager()
    let updateManager = CheckUpdateAPIManager()
    fileprivate var userDict : NSDictionary?
    var redPointView: UIView?
    
    // 方便以后添加新项，及调整每项的顺序
    fileprivate lazy var cellDatas : [NSDictionary] = {
        () -> [NSDictionary] in
        let temp = NSMutableArray()
        let data1 : NSDictionary = ["icon" : "icon_money", "title" : "资金明细","controller" : "FundingDetailViewController","tag" : 1]
        let data9 : NSDictionary = ["icon" : "icon_money", "title" : "用户列表","controller" : "UserListViewController","tag" : 9]
        let data10 : NSDictionary = ["icon" : "icon_money", "title" : "精准开户","controller" : "PreciseOpenAccountViewController","tag" : 10]
        let data11 : NSDictionary = ["icon" : "icon_money", "title" : "链接开户","controller" : "UserListViewController","tag" : 11]
        let data2 : NSDictionary = ["icon" : "icon_key",   "title" : "密码设置","controller" : "SetPasswordViewController","tag" : 2]
        let data3 : NSDictionary = ["icon" : "icon_bank",  "title" : "银行卡管理","controller" : "BankCardManagerViewController","tag" : 3]
        let data7 : NSDictionary = ["icon" : "icon_service","title" : "联系客服","controller" : "CustomerServiceViewController","tag" : 7]
        let data8 : NSDictionary = ["icon" : "icon_service","title" : "站内信","controller" : "MessageCenterViewController","tag" : 8, "check_msg": true]
        let data4 : NSDictionary = ["icon" : "icon_report","title" : "平台公告","controller" : "NoticeListViewController","tag" : 4]
        let data5 : NSDictionary = ["icon" : "icon_update","title" : "版本更新","controller" : "","tag" : 5]
        let data6 : NSDictionary = ["icon" : "icon_exit",  "title" : "安全退出","controller" : "","tag" : 6]
        temp.add(data1)
        temp.add(data9)
        temp.add(data10)
        temp.add(data11)
        temp.add(data2)
        temp.add(data3)
        temp.add(data7)
        temp.add(data8)
        temp.add(data4)
        temp.add(data5)
        temp.add(data6)
        return temp.copy() as! [NSDictionary]
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isTranslucent = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "账号中心"
    
        self.view = AccountCenterView()
        self.myView = self.view as? AccountCenterView

        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        self.updateManager.delegate = self
        self.updateManager.paramSource = self
        let header = MJRefreshNormalHeader.init {[weak self] in
            self?.apiManager.loadData()
        }
        self.myView?.tableView.mj_header = header
    }
    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.loadData()
    }

    @objc func didClickRecharge() {
        let rechargeVC = RechargeViewController()
        rechargeVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(rechargeVC, animated: true)
    }
    @objc func didClickWithdraw() {
        let withdrawVC = WithdrawViewController()
        withdrawVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(withdrawVC, animated: true)
    }
    
    func didClickTransfer() {
        let transferVC = TransferViewController()
        transferVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(transferVC, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension AccountCenterViewController: UITableViewDataSource,UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 1
        case 1:
            return self.cellDatas.count
        default:
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = AccountCenterUserInfoCell.cellWithTableView(tableView: tableView)
            cell.nameLB.text = userDict?.object(forKey: AccountCenterAPIManager.DataKey.kNickname) as? String
            cell.balanceLB.text = userDict?.object(forKey: AccountCenterAPIManager.DataKey.kAbalance) as? String
            return cell
        } else {
            let cellIdentifier = "AccountCenterCellIdentifier"
            var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            if cell == nil {
                cell = UITableViewCell.init(style: .default, reuseIdentifier: cellIdentifier)
                cell?.accessoryType = .disclosureIndicator
                cell?.textLabel?.textColor = .black
                let line = UIView()
                line.backgroundColor = kGASerperatorLineGrayColor
                cell?.contentView.addSubview(line)
                line.snp.makeConstraints { (make) in
                    make.bottom.left.right.equalTo(cell!)
                    make.height.equalTo(1)
                }
            }
            cell?.imageView?.image = UIImage.init(named: self.cellDatas[indexPath.row].object(forKey: "icon") as! String)
            cell?.textLabel?.text = self.cellDatas[indexPath.row].object(forKey: "title") as? String
            if let _ = self.cellDatas[indexPath.row].object(forKey: "check_msg") as? Bool {
                if LotteryHallViewController.is_show_msg {
                    if redPointView == nil {
                        redPointView = UIView()
                    }
                    cell!.imageView!.addSubview(redPointView!)
                    redPointView!.backgroundColor = .red
                    redPointView!.layer.cornerRadius = 4
                    redPointView!.snp.makeConstraints { (make) in
                        make.width.height.equalTo(8)
                        make.right.equalTo(cell!.imageView!)
                        make.top.equalTo(cell!.imageView!)
                    }
                }else{
                    self.redPointView?.removeFromSuperview()
                    let tabbars = self.navigationController?.tabBarController?.tabBar.items
                    let tabbar = tabbars?[3]
                    tabbar?.badgeValue = nil
                }
            }else{
                
            }
            return cell!
        }
       
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 1 {
            let headerView = AccountCenterHeaderView()
            headerView.rechargeBtn.addTarget(self, action: #selector(didClickRecharge), for: .touchUpInside)
            headerView.withdrawBtn.addTarget(self, action: #selector(didClickWithdraw), for: .touchUpInside)
            headerView.transferBtn.addTarget(self, action: #selector(didClickTransfer), for: .touchUpInside)
            return headerView
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 100
        } else {
            return 60
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 55
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//        if indexPath.section == 0 {
//            tableView.bounces = false
//        }
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//        if indexPath.section == 0 {
//            tableView.bounces = true
//        }
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            return
        }
        
        let tag = self.cellDatas[indexPath.row].object(forKey: "tag") as? Int
        
        let pushToVCName = self.cellDatas[indexPath.row].object(forKey: "controller") as? String
        var pushToVC : UIViewController?
        if !(pushToVCName?.isEmpty)! {
            guard  let NameSpace = Bundle.main.infoDictionary!["CFBundleExecutable"] as? String else {
                return  //无法获取到命名空间  后续代码不用执行
            }
            let pushToVCClass = NSClassFromString(NameSpace + "." + pushToVCName!) as? UIViewController.Type
            pushToVC = pushToVCClass?.init()
        }
        
        let fundingPwdSeted = self.userDict?.object(forKey: AccountCenterAPIManager.DataKey.kFund_pwd_seted) as? Int
        switch tag {
        case 2?:
            let vc = pushToVC as! SetPasswordViewController
            vc.selectedIndex = 0
            vc.fundingPwdSeted = fundingPwdSeted
            break
        case 3?:
            if fundingPwdSeted == 0 {
                GAAlertController.showAlert("温馨提示", "您尚未设置资金密码,请前往设置!", "取消", "立即设置", cancelCallBack: {
                }, commitCallBack: {
                    let setPwdVC = SetPasswordViewController()
                    setPwdVC.selectedIndex = 1
                    setPwdVC.hidesBottomBarWhenPushed = true
                    self.navigationController?.pushViewController(setPwdVC, animated: true)
                })
                return
            }
            break
        case 5?:
            self.updateManager.loadData()
            break
        case 6?:
            NotificationCenter.default.post(name: Notification.Name.Logout, object: nil)
            break
        default:
            break
        }
        if pushToVC != nil {
            pushToVC?.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(pushToVC!, animated: true)
        }
        
    }
}
extension AccountCenterViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
    
        GAProgressHUD.showLoading(message: "正在加载...")
        return nil
    }
    
}
extension AccountCenterViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        if manager == self.apiManager {
            self.userDict = manager.fetchData(self.apiManager) as? NSDictionary
            self.myView?.tableView.reloadData()
            self.myView?.tableView.mj_header.endRefreshing()
        } else if manager == self.updateManager {
            guard let updateDict = manager.fetchData(self.updateManager) as? NSDictionary else {
                return
            }
            guard let version = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kVersion) as AnyObject? else {return}
            guard let description = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kDescription) as? String else {return}
            guard let is_force = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kIs_force) as? Int else {return}
            guard let downloadPath = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kFilename) as? String else {return}
            
            let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! NSString
            
            if version.integerValue > currentVersion.integerValue {
                let title = NSString.init(format: "最新版本:%@", version as! CVarArg) as String
                let cancelStr = is_force == 0 ? "取消" : nil
                GAAlertController.showAlert(title, description, cancelStr, "立即更新", cancelCallBack: nil, commitCallBack: {
                    UIApplication.shared.openURL(NSURL.init(string: downloadPath)! as URL)
                    exit(EXIT_SUCCESS);
                })
                
            } else {
                let title = NSString.init(format: "当前版本:%@", currentVersion) as String
                GAAlertController.showAlert(title: title, message: "已是最新版本，无需更新!", delegate: nil,cancelButtonTitle: nil, commitButtonTitle: "确定")
            }
        }
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//
//        if manager == self.apiManager {
//            self.apiManager.callAPIDidFailed(manager)
//        } else if manager == self.updateManager {
//            self.updateManager.callAPIDidFailed(manager)
//        }
//    }
}

