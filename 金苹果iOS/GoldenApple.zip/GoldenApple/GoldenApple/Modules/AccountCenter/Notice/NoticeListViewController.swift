//
//  NoticeListViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit


class NoticeListViewController: UIViewController {

    var myView : NoticeListView?
    let apiManager = NoticeListAPIManager()
    var noticeDictList : [NSDictionary] = NSArray() as! [NSDictionary]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "平台公告"
        self.view = NoticeListView()
        self.myView = self.view as? NoticeListView
        
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.loadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
extension NoticeListViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.noticeDictList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = NoticeListCell.cellWithTableView(tableView: tableView)
        let noticeDict = self.noticeDictList[indexPath.item]
        cell.setData(dict: noticeDict)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = NoticeDetailViewController()
        vc.hidesBottomBarWhenPushed = true
        let detailDict = self.noticeDictList[indexPath.row]
        guard let noticeId = detailDict[NoticeListAPIManager.DataKey.kId] as? Int else { return }
        vc.noticeId = noticeId
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension NoticeListViewController:LYAPIManagerParamSource {
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "正在加载...")
        return nil
    }
    
}
extension NoticeListViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        self.noticeDictList = (manager.fetchData(self.apiManager) as! NSArray) as! [NSDictionary]
        self.myView?.tableView.reloadData()
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//    }
}
