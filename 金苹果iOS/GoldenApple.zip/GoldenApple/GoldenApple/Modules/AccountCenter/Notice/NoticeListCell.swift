//
//  NoticeListCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class NoticeListCell: UITableViewCell {

    private var titleLB : UILabel?
    private var timeLB : UILabel?
    
    static func cellWithTableView(tableView : UITableView) -> NoticeListCell {
        let cellIdentifier = "NoticeListCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? NoticeListCell
        if cell == nil {
            cell = NoticeListCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.titleLB = UILabel()
        self.titleLB?.text = "标题"
        self.titleLB?.font = UIFont.systemFont(ofSize: 16)
        self.titleLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.titleLB!)
        
        self.timeLB = UILabel()
        self.timeLB?.text = "0000-00-00"
        self.timeLB?.font = UIFont.systemFont(ofSize: 14)
        self.timeLB?.textColor = kGAFontGrayColor
        self.timeLB?.textAlignment = .right
        self.contentView.addSubview(self.timeLB!)
        self.timeLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.contentView)
            make.right.equalTo(self.contentView).offset(-15)
        })
        
        self.titleLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.contentView)
            make.left.equalTo(self.contentView).offset(15)
            make.right.equalTo((self.timeLB?.snp.left)!).offset(-20)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
        
    }
    public func setData(dict : NSDictionary) {
        let title = dict.object(forKey: NoticeListAPIManager.DataKey.kTitle) as? String
        self.titleLB?.text = title!
        let time = dict.object(forKey: NoticeListAPIManager.DataKey.kCreated_at) as? String
        let index = time!.index(time!.startIndex, offsetBy: 10)
        self.timeLB?.text = time!.substring(to: index)
    }

}
