//
//  NoticeDetailViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import WebKit

class NoticeDetailViewController: UIViewController {

    var myView : NoticeDetailView?
    let apiManager = NoticeDetailAPIManager()
    var noticeId: Int!
    var noticeDict : NSDictionary?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "公告"
        
        self.view = NoticeDetailView()
        self.myView = self.view as? NoticeDetailView
        
        self.myView?.contentView.navigationDelegate = self
        self.myView?.contentView.uiDelegate = self
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.loadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension NoticeDetailViewController: WKNavigationDelegate,WKUIDelegate {
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        webView.stopLoading()
        UIApplication.shared.openURL(webView.url!)
    }
}

extension NoticeDetailViewController:LYAPIManagerParamSource {
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {

        GAProgressHUD.showLoading(message: "正在加载...")
        
        let params = ["id" : self.noticeId]
        return params as NSDictionary
    }
    
}
extension NoticeDetailViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        self.noticeDict = manager.fetchData(self.apiManager) as? NSDictionary
        self.myView?.setData(dict: self.noticeDict!)
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//    }
}
