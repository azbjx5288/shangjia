//
//  NoticeDetailView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import WebKit
class NoticeDetailView: UIView {

    private var titleLB = UILabel()
    private var timeLB = UILabel()
    public var contentView = WKWebView()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        self.titleLB.text = "标题"
        self.titleLB.font = UIFont.systemFont(ofSize: 18)
        self.titleLB.numberOfLines = 0
        self.titleLB.textAlignment = .center
        self.addSubview(self.titleLB)
        self.titleLB.snp.makeConstraints { (make) in
            make.top.equalTo(self).offset(20)
            make.left.equalTo(self).offset(15)
            make.right.equalTo(self).offset(-15)
        }
        
        self.timeLB.text = "0000-00-00"
        self.timeLB.font = UIFont.systemFont(ofSize: 14)
        self.timeLB.textAlignment = .center
        self.timeLB.textColor = kGAFontGrayColor
        self.addSubview(self.timeLB)
        self.timeLB.snp.makeConstraints { (make) in
            make.top.equalTo(self.titleLB.snp.bottom).offset(5)
            make.centerX.equalTo(self.titleLB)
            make.width.equalTo(self.titleLB)
        }
        

        self.addSubview(self.contentView)
        self.contentView.snp.makeConstraints { (make) in
            make.top.equalTo(self.timeLB.snp.bottom).offset(20)
            make.left.equalTo(self).offset(15)
            make.right.equalTo(self).offset(-15)
            make.bottom.equalTo(self)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func setData(dict : NSDictionary) {
        let title = dict.object(forKey: NoticeDetailAPIManager.DataKey.kTitle) as? String
        self.titleLB.text = title!
        let time = dict.object(forKey: NoticeDetailAPIManager.DataKey.kCreated_at) as? String
        self.timeLB.text = time!
        let content = dict.object(forKey: NoticeDetailAPIManager.DataKey.kContent) as? String
        self.contentView.loadHTMLString(content!, baseURL: nil)
    }
}

