//
//  NoticeDetailAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class NoticeDetailAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kTitle = "title"
        static let kId = "id"
        static let kCreated_at = "created_at"
        static let kContent = "content"
    }
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension NoticeDetailAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Notice&action=getNoticeDetail"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}


extension NoticeDetailAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultDictList = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        return resultDictList
    }
}
