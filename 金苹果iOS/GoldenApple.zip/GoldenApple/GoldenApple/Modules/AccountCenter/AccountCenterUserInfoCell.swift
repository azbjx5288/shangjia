//
//  AccountCenterHeaderCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/16.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AccountCenterUserInfoCell: UITableViewCell {

    public let iconImageView : UIImageView = UIImageView()
    public let nameLB : UILabel = UILabel()
    public let balanceLB : UILabel = UILabel()
   
    static func cellWithTableView(tableView : UITableView) -> AccountCenterUserInfoCell {
        let cellIdentifier = "AccountCenterUserInfoCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AccountCenterUserInfoCell
        if cell == nil {
            cell = AccountCenterUserInfoCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.contentView.backgroundColor = kGANavigationBackgroundColor
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.iconImageView.image = UIImage.init(named: "login_icon")
        self.contentView.addSubview(self.iconImageView)
        self.iconImageView.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.top.equalTo(self.contentView).offset(20)
            make.size.equalTo(CGSize.init(width: 60, height: 60))
        }
        
        self.nameLB.font = UIFont.systemFont(ofSize: 18)
        self.nameLB.textColor = .white
        self.nameLB.text = "用户名"
        self.contentView.addSubview(self.nameLB)
        self.nameLB.snp.makeConstraints { (make) in
            make.top.equalTo(self.iconImageView).offset(5)
            make.left.equalTo(self.iconImageView.snp.right).offset(20)
        }
        
        let balanceIcon = UIImageView()
        balanceIcon.image = UIImage.init(named: "icon_balance")
        self.contentView.addSubview(balanceIcon)
        self.contentView.addSubview(balanceIcon)
        balanceIcon.snp.makeConstraints { (make) in
            make.left.equalTo(self.nameLB)
            make.bottom.equalTo(self.iconImageView).offset(-5)
            make.size.equalTo(CGSize.init(width: 16, height: 16))
        }
        
        let balanceTitle = UILabel()
        balanceTitle.font = UIFont.systemFont(ofSize: 14)
        balanceTitle.textColor = kGAFontLightGrayColor
        balanceTitle.text = "账户余额 :"
        self.contentView.addSubview(balanceTitle)
        balanceTitle.snp.makeConstraints { (make) in
            make.left.equalTo(balanceIcon.snp.right).offset(5)
            make.centerY.equalTo(balanceIcon)
        }
        
        self.balanceLB.font = UIFont.systemFont(ofSize: 16)
        self.balanceLB.textColor = .white
        self.balanceLB.text = "0.00"
        self.contentView.addSubview(self.balanceLB)
        self.balanceLB.snp.makeConstraints { (make) in
            make.centerY.equalTo(balanceTitle)
            make.left.equalTo(balanceTitle.snp.right).offset(5)
        }
        
    }
}
