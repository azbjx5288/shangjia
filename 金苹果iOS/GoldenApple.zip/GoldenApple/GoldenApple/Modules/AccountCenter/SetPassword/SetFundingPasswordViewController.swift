//
//  SetFundingPasswordViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit


class SetFundingPasswordViewController: UIViewController {

    var myView : SetFundingPasswordView?
    let apiManager = SetFundingPasswordAPIManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationItem.title = "设置资金密码"
        self.view = SetFundingPasswordView()
        self.myView = self.view as? SetFundingPasswordView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickSubmit(_ :)), for: .touchUpInside)
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    
    @objc func didClickSubmit(_ sender : UIButton) {
        if self.myView?.pwdTF.text == nil || (self.myView?.pwdTF.text?.isEmpty)!  {
            GAProgressHUD.showWarning(message: "新密码不能为空")
            return
        }
        if self.myView?.pwdTF.text != self.myView?.confirmPwdTF.text {
            GAProgressHUD.showWarning(message: "两次输入的新密码不一致")
            return
        }
        self.apiManager.loadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.myView?.endEditing(true)
    }
}

extension SetFundingPasswordViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        GAProgressHUD.showLoading(message: "正在加载...")
        let params = ["fund_pwd" : self.myView?.pwdTF.text ?? "" ,"confirm_fund_pwd" : self.myView?.confirmPwdTF.text ?? ""]
        return params as NSDictionary
    }
    
}
extension SetFundingPasswordViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        let superView = self.myView?.superview as! SetPasswordView
        superView.setSuccess(title: "资金密码设置成功!")
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//    }
}

