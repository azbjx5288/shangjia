//
//  SetFundingPasswordView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class SetFundingPasswordView: UIView {

    let pwdTF : HaveLeftViewTextField = HaveLeftViewTextField.init(title: "输入资金密码:",showDoneButton:false)
    let confirmPwdTF : HaveLeftViewTextField = HaveLeftViewTextField.init(title: "确认资金密码:",showDoneButton:false)
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("下一步", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        let notifyLB = UILabel()
        notifyLB.text = "为了您的资金安全,充值前请设置资金密码"
        notifyLB.font = UIFont.systemFont(ofSize: 14)
        notifyLB.textColor = kGAFontGrayColor
        notifyLB.textAlignment = .center
        notifyLB.numberOfLines = 0
        self.addSubview(notifyLB)
        notifyLB.snp.makeConstraints { (make) in
            make.top.equalTo(self).offset(20)
            make.left.equalTo(self).offset(15)
            make.right.equalTo(self).offset(-15)
        }
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.left.right.equalTo(self)
            make.top.equalTo(notifyLB.snp.bottom).offset(20)
            make.height.equalTo(1)
        }
        
        self.pwdTF.isSecureTextEntry = true
        self.pwdTF.placeholder = "请输入资金密码"
        self.addSubview(self.pwdTF)
        self.pwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(line.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.confirmPwdTF.isSecureTextEntry = true
        self.confirmPwdTF.placeholder = "请再次输入资金密码"
        self.addSubview(self.confirmPwdTF)
        self.confirmPwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.pwdTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.pwdTF)
        }
        
        let notifyLB1 = UILabel()
        notifyLB1.text = "密码由6-16位数字和字母组成,且必须同时包含数字和字母,且不可与登录密码相同"
        notifyLB1.textColor = kGAFontGrayColor
        notifyLB1.font = UIFont.systemFont(ofSize: 14)
        notifyLB1.numberOfLines = 0
        self.addSubview(notifyLB1)
        notifyLB1.snp.makeConstraints { (make) in
            make.top.equalTo(self.confirmPwdTF.snp.bottom).offset(30)
            make.left.equalTo(self).offset(15)
            make.right.equalTo(self).offset(-15)
        }
        
        let notifyLB2 = UILabel()
        notifyLB2.text = "设置资金密码,2小时后即可发起提现。"
        notifyLB2.textColor = kGANavigationBackgroundColor
        notifyLB2.font = UIFont.systemFont(ofSize: 14)
        notifyLB2.numberOfLines = 0
        self.addSubview(notifyLB2)
        notifyLB2.snp.makeConstraints { (make) in
            make.top.equalTo(notifyLB1.snp.bottom).offset(20)
            make.centerX.equalTo(self)
            make.width.equalTo(notifyLB1)
        }
        
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    

}
