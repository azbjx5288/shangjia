//
//  SetLoginPasswordView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/13.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ChangeLoginPasswordView: UIView {

    let oldPwdTF : HaveLeftViewTextField = HaveLeftViewTextField.init(title: "输入旧登录密码:",showDoneButton:false)
    let newPwdTF : HaveLeftViewTextField = HaveLeftViewTextField.init(title: "输入新登录密码:",showDoneButton:false)
    let confirmPwdTF : HaveLeftViewTextField = HaveLeftViewTextField.init(title: "确认新登录密码:",showDoneButton:false)
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("下一步", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.left.right.equalTo(self)
            make.top.equalTo(self).offset(20)
            make.height.equalTo(1)
        }
        
        self.oldPwdTF.isSecureTextEntry = true
        self.oldPwdTF.placeholder = "请输入旧密码"
        self.addSubview(self.oldPwdTF)
        self.oldPwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(line.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.newPwdTF.isSecureTextEntry = true
        self.newPwdTF.placeholder = "请输入新密码"
        self.addSubview(self.newPwdTF)
        self.newPwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.oldPwdTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.oldPwdTF)
        }
        
        self.confirmPwdTF.isSecureTextEntry = true
        self.confirmPwdTF.placeholder = "请再次输入新密码"
        self.addSubview(self.confirmPwdTF)
        self.confirmPwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.newPwdTF.snp.bottom)
            make.height.equalTo(self.oldPwdTF)
            make.left.right.equalTo(self)
        }
        
        let notifyLB = UILabel()
        notifyLB.text = "密码由6-16位数字和字母组成,且必须同时包含数字和字母"
        notifyLB.textColor = kGAFontGrayColor
        notifyLB.font = UIFont.systemFont(ofSize: 14)
        notifyLB.numberOfLines = 0
        self.addSubview(notifyLB)
        notifyLB.snp.makeConstraints { (make) in
            make.top.equalTo(self.confirmPwdTF.snp.bottom).offset(30)
            make.left.equalTo(self).offset(15)
            make.right.equalTo(self).offset(-15)
        }
        
    
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    

}
