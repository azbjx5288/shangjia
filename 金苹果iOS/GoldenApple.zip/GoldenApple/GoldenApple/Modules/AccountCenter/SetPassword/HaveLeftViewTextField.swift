//
//  HaveLeftViewTextField.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/13.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class HaveLeftViewTextField: UITextField {

    public var titleWidth : CGFloat?

    private let toolBar = GAInputToolBar()
    
    let seperatorLine: UIView = {
        let view = UIView()
        
        view.backgroundColor = kGASerperatorLineGrayColor
        return view
    }()
    
    
    init(title : String, showDoneButton : Bool) {
        super.init(frame: CGRect.zero)
        
        self.font = UIFont.systemFont(ofSize: 16)
        
        let left = UILabel()
        left.text = title
        left.font = UIFont.systemFont(ofSize: 16)
        left.textAlignment = .center
        
        let width = self.widthOfText(text: title, font: left.font) + 30.0
        self.titleWidth = width
        left.frame = CGRect.init(x: 0, y: 0, width: width, height: 200)
    
        self.leftView = left
        self.leftViewMode = .always
        self.clearButtonMode = .whileEditing
    
        self.addSubview(seperatorLine)
        seperatorLine.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(1)
        }
        
        self.toolBar.cancelBtn.action = #selector(cancel)
        self.toolBar.cancelBtn.target = self
        
        
        self.toolBar.setButtonItems(isShowDone: showDoneButton)
        
        self.inputAccessoryView = self.toolBar;
    }
    
    public func setDoneAction(target : AnyObject , action : Selector) {
        self.toolBar.doneBtn.action = action
        self.toolBar.doneBtn.target = target
    }
    
    private func widthOfText(text : String,font : UIFont)->CGFloat {
        let str = text as NSString
        let rect = str.boundingRect(with: CGSize.init(width: CGFloat(MAXFLOAT), height: 30.0), options: [.usesLineFragmentOrigin,.usesFontLeading], attributes: [NSFontAttributeName : font], context: nil)
        return rect.size.width
    }
    
    @objc func cancel() {
        self.endEditing(true)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
