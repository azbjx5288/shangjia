//
//  GAInputToolBar.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/23.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class GAInputToolBar: UIToolbar {
    
    public var cancelBtn : UIBarButtonItem  = UIBarButtonItem.init(title: "退出键盘", style: .plain, target: nil, action: nil)
    public var doneBtn : UIBarButtonItem = UIBarButtonItem.init(title: "确定", style: .plain, target: nil, action: nil)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.barStyle = .blackTranslucent
        self.autoresizingMask = .flexibleHeight
        self.sizeToFit()
        var fr = frame
        fr.size.height = 30
        self.frame = fr
        
        self.doneBtn.tintColor = .white
        self.cancelBtn.tintColor = .white
        self.setButtonItems(isShowDone: false)
    }
    
    public func setButtonItems(isShowDone : Bool) {
        let flexibleSpaceLeft = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        if isShowDone {
            self.items = [self.cancelBtn,flexibleSpaceLeft,self.doneBtn]
        } else {
            self.items = [flexibleSpaceLeft,self.cancelBtn]
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
