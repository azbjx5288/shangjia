//
//  SetPasswordViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/13.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import SwiftySegmentedControl

class SetPasswordViewController: UIViewController {

    private var myView : SetPasswordView?
    public var fundingPwdSeted : Int?
    public var selectedIndex : UInt = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "密码设置"
        
        self.view = SetPasswordView()
        self.myView = self.view as? SetPasswordView
        self.myView?.segmentedBar.addTarget(self, action: #selector(segmentedBarValueChanged(_:)), for: .valueChanged)
        
        self.addChildViewController(ChangeLoginPasswordViewController())
        
        if self.fundingPwdSeted == 1 {
            self.addChildViewController(ChangeFundingPasswordViewController())
        } else {
            self.addChildViewController(SetFundingPasswordViewController())
        }
        
        
        do {
            try self.myView?.segmentedBar.setIndex(selectedIndex, animated: false)
        } catch {
            print(error)
        }
    }
    
    @objc func segmentedBarValueChanged(_ sender: SwiftySegmentedControl) {
        for view in self.view.subviews {
            if view != self.myView?.segmentedBar {
                view.removeFromSuperview()
            }
        }
        let vc = self.childViewControllers[Int(sender.index)]
        self.view.addSubview(vc.view)
        vc.view.snp.makeConstraints { (make) in
            make.top.equalTo((self.myView?.segmentedBar.snp.bottom)!)
            make.left.right.bottom.equalTo(self.view)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}
