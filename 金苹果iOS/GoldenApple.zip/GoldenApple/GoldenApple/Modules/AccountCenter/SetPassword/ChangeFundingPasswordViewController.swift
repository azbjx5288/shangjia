//
//  SetFundingPasswordViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/13.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit


class ChangeFundingPasswordViewController: UIViewController {

    var myView : ChangeFundingPasswordView?
    let apiManager = ChangeFundingPasswordAPIManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isTranslucent = false
        
        self.view = ChangeFundingPasswordView()
        self.myView = self.view as? ChangeFundingPasswordView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickSubmit(_ :)), for: .touchUpInside)
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    
    @objc func didClickSubmit(_ sender : UIButton) {
        if self.myView?.oldPwdTF.text == nil || (self.myView?.oldPwdTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "旧密码不能为空")
            return
        }
        if self.myView?.newPwdTF.text == nil || (self.myView?.newPwdTF.text?.isEmpty)!  {
            GAProgressHUD.showWarning(message: "新密码不能为空")
            return
        }
        if self.myView?.newPwdTF.text != self.myView?.confirmPwdTF.text {
            GAProgressHUD.showWarning(message: "两次输入的新密码不一致")
            return
        }
        self.apiManager.loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.myView?.endEditing(true)
    }
}
extension ChangeFundingPasswordViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
    
        GAProgressHUD.showLoading(message: "正在加载...")
        let params = ["current_password" : self.myView?.oldPwdTF.text ?? "" ,"new_password" : self.myView?.newPwdTF.text ?? ""]
        return params as NSDictionary
    }
    
}
extension ChangeFundingPasswordViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        let superView = self.myView?.superview as! SetPasswordView
        superView.setSuccess(title: "资金密码修改成功!")
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//        
//    }
}
