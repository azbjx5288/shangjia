//
//  SetPasswordView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/13.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import SwiftySegmentedControl

class SetPasswordView: UIView {

    lazy var segmentedBar : SwiftySegmentedControl = {
        () -> SwiftySegmentedControl in
        let tempBar = SwiftySegmentedControl(
            frame: CGRect.zero,
            titles: ["登录密码","资金密码"],
            index: 0,
            backgroundColor: kGASerperatorLineGrayColor,
            titleColor: kGAFontBlackColor,
            indicatorViewBackgroundColor: UIColor.white,
            selectedTitleColor: kGANavigationBackgroundColor)
        tempBar.autoresizingMask = [.flexibleWidth]
        tempBar.indicatorViewInset = 0
        tempBar.cornerRadius = 0.0
        tempBar.titleFont = UIFont(name: "HelveticaNeue", size: 16.0)!
        tempBar.selectedTitleFont = UIFont(name: "HelveticaNeue", size: 18.0)!
        tempBar.bouncesOnChange = true
        tempBar.panningDisabled = true
        tempBar.indicatorViewLineColor = kGANavigationBackgroundColor
        
        return tempBar
    }()
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        self.addSubview(self.segmentedBar)
        self.segmentedBar.snp.makeConstraints({ (make) in
            make.top.equalTo(self)
            make.left.equalTo(self)
            make.width.equalTo(self)
            make.height.equalTo(55)
        })
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func setSuccess(title : String) {
        for view in self.subviews {
            view.removeFromSuperview()
        }
        let successView = GASuccessView.init(title: title)
        self.addSubview(successView)
        successView.snp.makeConstraints({ (make) in
            make.edges.equalTo(self)
        })
    }

}
