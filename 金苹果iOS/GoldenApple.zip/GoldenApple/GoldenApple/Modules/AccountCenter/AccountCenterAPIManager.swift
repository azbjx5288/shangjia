//
//  AccountCenterAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/10.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AccountCenterAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kId = "id"
        static let kUsername = "username"
        static let kIs_tester = "Is_tester"
        static let kIs_agent = "is_agent"
        static let kAccount_id = "account_id"
        static let kPrize_group = "prize_group"
        static let kNickname = "nickname"
        static let kTotalIssues = "total_issues"
        static let kBlocked = "blocked"
        static let kPortrait_code = "portrait_code"
        static let kAbalance = "abalance"
        static let kTime = "bought_at"
        static let kFund_pwd_seted = "fund_pwd_seted"
        static let kWithdrawable = "withdrawable"
        
        /// 登录时间
        static let kSigninAt = "signin_at"
    }
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension AccountCenterAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=User&action=getCurrentUserInfo"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
    
}


extension AccountCenterAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        return resultDict
    }
}

