//
//  MessageInboxView.swift
//  GoldenApple
//
//  Created by User on 2018/7/25.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class MessageInboxView: UIView {

    public lazy var tableView : UITableView = {()-> UITableView in
        let view = UITableView(frame: CGRect(x: 0, y: 0, width: self.width, height: self.height - 64))
        view.separatorStyle = UITableViewCellSeparatorStyle.none
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(tableView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

class MessageInBoxTableViewCell: UITableViewCell {
    
    lazy var label_name = {() -> UILabel in
        let view = UILabel()
        view.text = "ivy001"
        return view
    }()
    
    lazy var label_content = {() -> UILabel in
        let view = UILabel()
        view.font = UIFont.systemFont(ofSize: 14)
        view.text = ""
        view.numberOfLines = 1
        view.textColor = .gray
        return view
    }()
    
    lazy var label_time = {() -> UILabel in
        let view = UILabel()
        view.text = "1999/9/9"
        view.textColor = .gray
        return view
    }()
    
    lazy var label_time_detail = {() -> UILabel in
        let view = UILabel()
        view.text = "14:28:56"
        return view
    }()
    
    lazy var view_seperter = {() -> UIView in
        let view = UIView()
        view.backgroundColor = RGBCOLOR(240, 240, 240)
        return view
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        
        
        let rootView = TGRelativeLayout()
        rootView.tg_padding = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        rootView.tg_width.equal(.fill)
        rootView.tg_height.equal(.fill)
        self.contentView.addSubview(rootView)
        
        rootView.addSubview(label_name)
        rootView.addSubview(label_content)
        rootView.addSubview(label_time)
        rootView.addSubview(label_time_detail)
        
        label_name.tg_width.equal(.wrap)
        label_name.tg_height.equal(.wrap)
        label_content.tg_width.equal(.wrap)
        label_content.tg_height.equal(.wrap)
        label_time.tg_width.equal(.wrap)
        label_time.tg_height.equal(.wrap)
        label_time_detail.tg_width.equal(.wrap)
        label_time_detail.tg_height.equal(.wrap)
        
        label_name.tg_left.equal(0)
        label_name.tg_bottom.equal(rootView.tg_centerY).offset(5)
        label_content.tg_top.equal(rootView.tg_centerY).offset(0)
        label_content.tg_left.equal(label_name)
        label_content.tg_right.equal(label_time.tg_left)
        label_content.tg_bottom.equal(0)
        label_time.tg_right.equal(0)
        label_time.tg_bottom.equal(rootView.tg_centerY)
        label_time_detail.tg_top.equal(rootView.tg_centerY)
        label_time_detail.tg_right.equal(label_time)
        
        self.addSubview(view_seperter)
        view_seperter.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
        self.accessoryType = .disclosureIndicator
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
