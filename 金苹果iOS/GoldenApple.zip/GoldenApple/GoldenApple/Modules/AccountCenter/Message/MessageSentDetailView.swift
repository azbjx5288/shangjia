//
//  MessageSentDetailView.swift
//  GoldenApple
//
//  Created by User on 2018/8/16.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class MessageSentDetailView: UIView {

    private lazy var label_user = {() -> UILabel in
        let view = UILabel()
        view.text = "收件人："
        return view
    }()
    
    lazy var label_user_content = {() -> UILabel in
        let view = UILabel()
        return view
    }()
    
    private lazy var label_title = {() -> UILabel in
        let view = UILabel()
//        view.textAlignment = .left
        view.text = "标题："
        return view
    }()
    
    lazy var label_title_content = {() -> UILabel in
        let view = UILabel()
        return view
    }()
    
    private lazy var label_time = {() -> UILabel in
        let view = UILabel()
        view.text = "发送时间："
        return view
    }()
    
    lazy var label_tiem_content = {() -> UILabel in
        let view = UILabel()
        return view
    }()
    
    lazy var label_content = {() -> UILabel in
        let view = UILabel()
        view.numberOfLines = 0
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let scrollerView = UIScrollView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.height - 64))
        scrollerView.backgroundColor = .white
        label_content.tg_width.equal(.fill).add(-20)
        label_content.tg_height.equal(.wrap)
        label_content.tg_top.equal(15)
        label_content.tg_centerX.equal(0)
        let rootView = TGLinearLayout(.vert)
        
        rootView.tg_width.equal(.fill)
        rootView.tg_height.equal(.wrap)
        
        let info_container = TGRelativeLayout()
        info_container.tg_width.equal(.fill)
        info_container.tg_height.equal(.wrap)
        info_container.tg_padding = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        info_container.tg_bottomBorderline = TGBorderline(color: RGBCOLOR(100, 100, 100))
        
        info_container.addSubview(label_user)
        info_container.addSubview(label_time)
        info_container.addSubview(label_title)
        info_container.addSubview(label_tiem_content)
        info_container.addSubview(label_title_content)
        info_container.addSubview(label_user_content)
        
        label_user.tg_height.equal(.wrap)
        label_time.tg_height.equal(.wrap)
        label_title.tg_height.equal(.wrap)
        label_tiem_content.tg_height.equal(.wrap)
        label_title_content.tg_height.equal(.wrap)
        label_user_content.tg_height.equal(.wrap)
        label_user.tg_width.equal(.wrap)
        label_time.tg_width.equal(.wrap)
        label_title.tg_width.equal(.wrap)
        label_tiem_content.tg_width.equal(.wrap)
        label_tiem_content.tg_width.equal(.wrap)
        label_title_content.tg_width.equal(.fill)
        label_user_content.tg_width.equal(.wrap)
        
        label_user.tg_left.equal(0)
        label_user.tg_top.equal(0)
        label_user_content.tg_left.equal(label_user.tg_right)
        label_user_content.tg_top.equal(0)
        label_title.tg_left.equal(0)
        label_title.tg_top.equal(label_user.tg_bottom).offset(8)
        label_title_content.tg_left.equal(label_title.tg_right)
        label_title_content.tg_top.equal(label_title)
        label_time.tg_left.equal(0)
        label_time.tg_top.equal(label_title_content.tg_bottom).offset(8)
        label_tiem_content.tg_left.equal(label_time.tg_right)
        label_tiem_content.tg_top.equal(label_time)
        
        rootView.addSubview(info_container)
        rootView.addSubview(label_content)
        scrollerView.addSubview(rootView)
        self.addSubview(scrollerView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
