//
//  MessageSentDetailViewController.swift
//  GoldenApple
//
//  Created by User on 2018/8/16.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class MessageSentDetailViewController: UIViewController {

    lazy var myView = {() -> MessageSentDetailView in
        let view = MessageSentDetailView(frame: self.view.frame)
        return view
    }()
    
    let apiManager = MessageSentDetailAPIManager()
    
    var id: Int
    
    init(id: Int) {
        self.id = id
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "发信箱"
        self.view.addSubview(myView)
        self.apiManager.paramSource = self
        self.apiManager.delegate = self
        self.apiManager.loadData()
    }
    

}

extension MessageSentDetailViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
//        GAProgressHUD.showLoading(message: "获取数据,请稍候...")
        
        var params = [:] as [String : Any]
        params["id"] = self.id
        return params as NSDictionary
    }
    
}
extension MessageSentDetailViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
//        GAProgressHUD.showSuccess(message: "获取成功!")
        let data = manager.fetchData(self.apiManager) as! NSDictionary
        self.myView.label_user_content.text = data[MessageSentDetailAPIManager.DataKey.receiver] as? String
        self.myView.label_title_content.text = data[MessageSentDetailAPIManager.DataKey.msg_title] as? String
        self.myView.label_tiem_content.text = data[MessageSentDetailAPIManager.DataKey.created_at] as? String
        self.myView.label_content.text = data[MessageSentDetailAPIManager.DataKey.msg_content] as? String
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        GAProgressHUD.showError(message: "数据获取失败", duration: 1)
//                self.apiManager.callAPIDidFailed(manager)
    }
}

extension MessageSentDetailViewController: GAAlertDelegate {
    func alertCancelButtonClicked() {
        
    }
    
    func alertCommitButtonClicked() {
        self.apiManager.loadData()
    }
    
    
}
