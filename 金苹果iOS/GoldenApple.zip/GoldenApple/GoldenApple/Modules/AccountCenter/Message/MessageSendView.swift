//
//  MessageSendView.swift
//  GoldenApple
//
//  Created by User on 2018/7/25.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit
import DropDown

class MessageSendView: UIView {
    
    let tag_all_xiaji = 123
    let tag_single_xiaji = 456
    let tag_shangji = 789
    
    var delegate: MessageSendViewDelegate?
    var dataSource: MessageSendViewUserDataSource?
    
    //    fileprivate
    lazy var container_user = {() -> UIView in
        let view = UIView(frame: .zero)
        return view
    }()
    
    lazy var label_shoujianren = {() -> UILabel in
        let view = UILabel()
        view.text = "收件人："
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var btn_all_xiaji = {() -> UIButton in
        let view = UIButton()
        view.tag = self.tag_all_xiaji
        view.setTitleColor(.black, for: .normal)
        view.setTitle("所有下级", for: .normal)
        view.titleEdgeInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 0)
        view.setImage(UIImage(named: "opertionS_white"), for: .normal)
        view.setImage(UIImage(named: "optionS_red"), for: .selected)
        view.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        view.isSelected = true
        return view
    }()
    
    lazy var btn_single_xiaji = {() -> UIButton in
        let view = UIButton()
        view.tag = self.tag_single_xiaji
        view.setTitle("单一下级", for: .normal)
        view.titleEdgeInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 0)
        view.setTitleColor(.black, for: .normal)
        view.setImage(UIImage(named: "opertionS_white"), for: .normal)
        view.setImage(UIImage(named: "optionS_red"), for: .selected)
        view.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var btn_shangji = {() -> UIButton in
        let view = UIButton()
        view.tag = self.tag_shangji
        view.setTitleColor(.black, for: .normal)
        view.setTitle("上级", for: .normal)
        view.titleEdgeInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 0)
        view.setImage(UIImage(named: "opertionS_white"), for: .normal)
        view.setImage(UIImage(named: "optionS_red"), for: .selected)
        view.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var btn_xiaji = {() -> UIButton in
        let view = UIButton()
        view.layer.borderColor = RGBCOLOR(240, 240, 240).cgColor
        view.layer.borderWidth = 1
        view.layer.cornerRadius = 5
        view.backgroundColor = .white
        view.setTitle("请选择某一个下级", for: .normal)
        view.setTitleColor(.black, for: .normal)
        return view
    }()
    
    lazy var dropView_xiaji = {() -> DropDown in
        let view = DropDown(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        view.isHidden = true
        return view
    }()
    
    lazy var label_biaoti = {() -> UILabel in
        let view = UILabel()
        view.text = "标题："
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var textField_title = {() -> UITextField in
        let view = UITextField()
        view.borderStyle = UITextBorderStyle.roundedRect
        return view
    }()
    
    lazy var label_content = {() -> UILabel in
        let view = UILabel()
        view.text = "内容："
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var textview_content = {() -> UITextView in
        let view = UITextView()
        view.layer.borderWidth = 1
        view.layer.borderColor = RGBCOLOR(240, 240, 240).cgColor
        return view
    }()
    
    lazy var btn_send = {() -> UIButton in
        let view = UIButton()
        view.setTitle("发送", for: .normal)
        view.setTitleColor(.white, for: .normal)
        view.backgroundColor = kGANavigationBackgroundColor
        return view
    }()
    
    let container_4 = TGLinearLayout(.horz)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let rootView = TGLinearLayout(.vert)
//        rootView.tg_gravity = TGGravity.horz.center
        rootView.tg_padding = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        rootView.backgroundColor = RGBCOLOR(242, 242, 242)
        rootView.tg_width.equal(.fill)
        rootView.tg_height.equal(.fill)
        
        let container_1 = TGLinearLayout(.horz)
        container_1.tg_space = 10
        container_1.tg_width.equal(.fill)
        container_1.tg_height.equal(40)
        
        let container_2 = TGLinearLayout(.horz)
        container_2.tg_width.equal(.fill)
        container_2.tg_height.equal(40)
        
        let container_3 = TGLinearLayout(.horz)
        container_3.tg_width.equal(.fill)
        container_3.tg_height.equal(.wrap)
        
        container_1.addSubview(label_shoujianren)
        container_1.addSubview(btn_all_xiaji)
        container_1.addSubview(btn_single_xiaji)
        container_1.addSubview(btn_shangji)
        container_1.tg_gravity = TGGravity.vert.center
        label_shoujianren.tg_width.equal(.wrap)
        label_shoujianren.tg_height.equal(.wrap)
        btn_all_xiaji.tg_width.equal(.wrap).add(5)
        btn_all_xiaji.tg_height.equal(.wrap)
        btn_single_xiaji.tg_width.equal(.wrap).add(5)
        btn_single_xiaji.tg_height.equal(.wrap)
        btn_shangji.tg_width.equal(.wrap).add(5)
        btn_shangji.tg_height.equal(.wrap)
        
        container_2.tg_top.equal(30)
        container_2.addSubview(label_biaoti)
        container_2.addSubview(textField_title)
        container_2.tg_gravity = TGGravity.vert.center
        //        label_biaoti.tg_centerY.equal(container_2)
        label_biaoti.tg_width.equal(.wrap)
        label_biaoti.tg_height.equal(.wrap)
        textField_title.tg_width.equal(.average)
        textField_title.tg_height.equal(40)
        
        container_3.tg_top.equal(30)
        container_3.addSubview(label_content)
        container_3.addSubview(textview_content)
        //        label_content.tg_centerY.equal(container_3)
        label_content.tg_width.equal(.wrap)
        label_content.tg_height.equal(.wrap)
        textview_content.tg_width.equal(.average)
        textview_content.tg_height.equal(200)
        
        btn_send.tg_width.equal(120)
        btn_send.tg_height.equal(40)
        btn_send.tg_top.equal(30)
        btn_send.tg_centerX.equal(0)
        
        dropView_xiaji.anchorView = btn_xiaji
        dropView_xiaji.tg_width.equal(325)
        dropView_xiaji.tg_height.equal(40)
//        dropView_xiaji.dataSource = self.dataSource?.setXiajiUser() ?? []
        dropView_xiaji.topOffset = CGPoint(x: 0, y:40)
        dropView_xiaji.selectionAction = { [unowned self] (index: Int, item: String) in
            self.btn_xiaji.setTitle(item, for: .normal)
            self.delegate?.onSelectUserChange(item: item)
        }
        
        btn_xiaji.tg_height.equal(40)
        btn_xiaji.tg_width.equal(.fill)
        btn_xiaji.tg_right.equal(0)
        
        container_4.tg_width.equal(.fill)
        container_4.tg_height.equal(40)
        
        let label_zhanwei = UILabel()
        label_zhanwei.text = "标题："
        label_zhanwei.font = UIFont.systemFont(ofSize: 14)
        label_zhanwei.tg_width.equal(.wrap)
        label_zhanwei.tg_height.equal(.wrap)
        label_zhanwei.textColor = RGBCOLOR(242, 242, 242)
        
        container_4.isHidden = true
        container_4.addSubview(label_zhanwei)
        container_4.addSubview(btn_xiaji)
        
        self.addSubview(rootView)
        rootView.addSubview(container_1)
        rootView.addSubview(container_4)
        rootView.addSubview(container_2)
        rootView.addSubview(container_3)
        rootView.addSubview(btn_send)
        
        btn_all_xiaji.addTarget(self, action: #selector(onUserChange(sender:)), for: .touchUpInside)
        btn_single_xiaji.addTarget(self, action: #selector(onUserChange(sender:)), for: .touchUpInside)
        btn_shangji.addTarget(self, action: #selector(onUserChange(sender:)), for: .touchUpInside)
        btn_xiaji.addTarget(self, action: #selector(onDropClick), for: .touchUpInside)
    }
    
    @objc func onUserChange(sender: UIButton){
        btn_all_xiaji.isSelected = false
        btn_single_xiaji.isSelected = false
        btn_shangji.isSelected = false
        switch sender.tag {
        case tag_all_xiaji:
            btn_all_xiaji.isSelected = true
            self.delegate?.onSelectChange(type: 2)
        case tag_single_xiaji:
            btn_single_xiaji.isSelected = true
            self.delegate?.onSelectChange(type: 3)
        case tag_shangji:
            btn_shangji.isSelected = true
            self.delegate?.onSelectChange(type: 1)
        default:
            break
        }
        if self.btn_single_xiaji.isSelected{
            self.container_4.isHidden = false
        }else{
            self.container_4.isHidden = true
        }
    }
    
    @objc func onDropClick(){
        self.dropView_xiaji.show()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

protocol MessageSendViewDelegate {
    func onSelectChange(type: Int)
    func onSelectUserChange(item: String)
}

protocol MessageSendViewUserDataSource {
    func setXiajiUser() -> [NSDictionary]
}

