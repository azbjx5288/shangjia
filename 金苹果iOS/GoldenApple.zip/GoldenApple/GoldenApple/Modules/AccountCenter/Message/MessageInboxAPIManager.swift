//
//  MessageInboxAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/7/25.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import Foundation

class MessageInboxAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let id = "id"
        static let sender = "sender"
        static let created_at = "created_at"
        static let is_readed = "is_readed"
        static let msg_title = "msg_title"
        static let msg_type = "msg_type"
        static let reciver = "reciver"
    }
    
    var page = 1
    let pagesize = 10
    var isRefresh = true
    
    var recordDictList = NSArray() as! [NSDictionary]
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension MessageInboxAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Message&action=GetLettersList"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        
        if self.isRefresh {self.page = 1}
        
        resultParams["page"] = self.page
        resultParams["pagesize"] = self.pagesize
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}


extension MessageInboxAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let recordList = data.object(forKey: "data") as? NSArray else { return NSArray() }
        
        if self.isRefresh {
            self.recordDictList = (recordList as! [NSDictionary])
        } else {
            let tempArray = NSMutableArray.init(array: self.recordDictList)
            tempArray.addObjects(from: recordList as! [NSDictionary])
            self.recordDictList = tempArray.copy() as! [NSDictionary]
        }
        if (recordList as! [NSDictionary]).count > 0 {
            self.page = self.page + 1
        }
        return recordList
    }
}
