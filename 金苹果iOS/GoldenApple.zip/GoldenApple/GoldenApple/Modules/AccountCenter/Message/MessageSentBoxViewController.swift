//
//  MessageSentViewController.swift
//  GoldenApple
//
//  Created by User on 2018/7/25.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit
import MJRefresh

class MessageSentBoxViewController: UIViewController {
    
    var apiManager = MessageSentboxAPIManager()
    
    lazy var myView = {() -> MessageSentBoxView in
        let view = MessageSentBoxView(frame: self.view.frame)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNaviBar()
        self.apiManager.delegate = self
        self.apiManager.loadData()
        // Do any additional setup after loading the view.
    }
    
    
    private func setNaviBar() {
        
        self.navigationItem.title = "发信箱"
        
        self.myView.tableView.delegate = self
        self.myView.tableView.dataSource = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        self.view.addSubview(myView)
        
        
        let header = MJRefreshNormalHeader { [weak self] in
            self?.apiManager.isRefresh = true
            self?.apiManager.page = 1
            self?.apiManager.loadData()
        }
        let footer = MJRefreshAutoNormalFooter { [weak self] in
            self?.apiManager.isRefresh = false
            self?.apiManager.page += 1
            self?.apiManager.loadData()
        }
        header?.lastUpdatedTimeLabel.isHidden = true
        self.myView.tableView.mj_header = header
        self.myView.tableView.mj_footer = footer
    }
}

extension MessageSentBoxViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.apiManager.recordDictList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let data = self.apiManager.recordDictList[indexPath.row]
        let cell = MessageSentBoxTableViewCell(style: .default, reuseIdentifier: "cell")
        cell.label_name.text = data[MessageSentboxAPIManager.DataKey.receiver] as? String
        cell.label_content.text = data[MessageSentboxAPIManager.DataKey.msg_title] as? String
        cell.label_time.text = String((data[MessageSentboxAPIManager.DataKey.created_at] as! String).split(separator: " ")[0])
        cell.label_time_detail.text = String((data[MessageSentboxAPIManager.DataKey.created_at] as! String).split(separator: " ")[1])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = self.apiManager.recordDictList[indexPath.row]
        let id = data[MessageSentboxAPIManager.DataKey.id] as! Int
        let vc = MessageSentDetailViewController(id: id)
        self.navigationController?.pushViewController(vc, animated: true)
        tableView.cellForRow(at: indexPath)?.setSelected(false, animated: true)
    }
}

extension MessageSentBoxViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        //        GAProgressHUD.showLoading(message: "获取数据,请稍候...")
        
        let params = [:] as [String : Any]
        return params as NSDictionary
    }
    
}
extension MessageSentBoxViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        //        GAProgressHUD.showSuccess(message: "获取成功!")
        let recordDictList = manager.fetchData(self.apiManager) as! NSArray
        self.myView.tableView.reloadData()
        if !self.apiManager.isRefresh && recordDictList.count == 0 {
            let footer = self.myView.tableView.mj_footer as! MJRefreshAutoNormalFooter
            footer.endRefreshingWithNoMoreData()
        } else {
            self.myView.tableView.mj_header.endRefreshing()
            self.myView.tableView.mj_footer.endRefreshing()
        }
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        self.myView.tableView.mj_header.endRefreshing()
        self.myView.tableView.mj_footer.endRefreshing()
    }
    
}

extension MessageSentBoxViewController: GAAlertDelegate {
    func alertCancelButtonClicked() {
        
    }
    
    func alertCommitButtonClicked() {
        self.apiManager.loadData()
    }
    
    
}
