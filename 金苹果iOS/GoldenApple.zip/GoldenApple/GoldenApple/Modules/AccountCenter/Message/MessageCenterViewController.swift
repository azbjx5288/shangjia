//
//  MessageCenterViewController.swift
//  GoldenApple
//
//  Created by User on 2018/7/25.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class MessageCenterViewController: UIViewController {
    
    var myView = MessageCenterView()
    
    fileprivate var userDict : NSDictionary?
    var icon_redpoint: UIView?
    
    // 方便以后添加新项，及调整每项的顺序
    fileprivate lazy var cellDatas : [NSDictionary] = {
        () -> [NSDictionary] in
        let temp = NSMutableArray()
        let data1 : NSDictionary = ["icon" : "icon_money", "title" : "收信箱","controller" : "MessageInboxViewController","tag" : 1, "check_msg": true]
        let data2 : NSDictionary = ["icon" : "icon_key",   "title" : "发信箱","controller" : "MessageSentBoxViewController","tag" : 2]
        let data3 : NSDictionary = ["icon" : "icon_bank",  "title" : "发信息","controller" : "MessageSendViewController","tag" : 3]
        temp.add(data1)
        temp.add(data2)
        temp.add(data3)
        return temp.copy() as! [NSDictionary]
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "站内信"
        self.view = self.myView
        self.myView.tableView.delegate = self
        self.myView.tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.myView.tableView.reloadData()
    }

}

extension MessageCenterViewController: UITableViewDataSource,UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.cellDatas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "AccountCenterCellIdentifier"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if cell == nil {
            cell = UITableViewCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.accessoryType = .disclosureIndicator
            cell?.textLabel?.textColor = .black
            let line = UIView()
            line.backgroundColor = kGASerperatorLineGrayColor
            cell?.contentView.addSubview(line)
            line.snp.makeConstraints { (make) in
                make.bottom.left.right.equalTo(cell!)
                make.height.equalTo(1)
            }
        }
        cell?.imageView?.image = UIImage.init(named: self.cellDatas[indexPath.row].object(forKey: "icon") as! String)
        cell?.textLabel?.text = self.cellDatas[indexPath.row].object(forKey: "title") as? String
        if let _ = self.cellDatas[indexPath.row].object(forKey: "check_msg") as? Bool {
            if LotteryHallViewController.is_show_msg{
                if icon_redpoint == nil {
                    icon_redpoint = UIView()
                }
                cell!.imageView!.addSubview(icon_redpoint!)
                icon_redpoint!.backgroundColor = .red
                icon_redpoint!.layer.cornerRadius = 4
                icon_redpoint!.snp.makeConstraints { (make) in
                    make.width.height.equalTo(8)
                    make.right.equalTo(cell!.imageView!)
                    make.top.equalTo(cell!.imageView!)
                }
            }else{
                icon_redpoint?.removeFromSuperview()
            }
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        let tag = self.cellDatas[indexPath.row].object(forKey: "tag") as? Int
        
        let pushToVCName = self.cellDatas[indexPath.row].object(forKey: "controller") as? String
        var pushToVC : UIViewController?
        if !(pushToVCName?.isEmpty)! {
            guard  let NameSpace = Bundle.main.infoDictionary!["CFBundleExecutable"] as? String else {
                return  //无法获取到命名空间  后续代码不用执行
            }
            let pushToVCClass = NSClassFromString(NameSpace + "." + pushToVCName!) as? UIViewController.Type
            pushToVC = pushToVCClass?.init()
        }
        
        switch tag {
        default:
            break
        }
        if pushToVC != nil {
            pushToVC?.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(pushToVC!, animated: true)
        }
        tableView.cellForRow(at: indexPath)?.setSelected(false, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}
