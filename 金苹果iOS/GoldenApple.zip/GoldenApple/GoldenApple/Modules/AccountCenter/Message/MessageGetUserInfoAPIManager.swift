//
//  MessageGetUserInfoAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/8/17.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import Foundation

class MessageGetUserInfoAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        static let user_type = "user_type"
        static let parent = "parent"
        static let child = "child"
        static let is_top_agent = "is_top_agent"
    }
    
}

extension MessageGetUserInfoAPIManager: LYAPIManager {
    
    public func methodName() -> NSString {
        return "service?packet=Message&action=GetUserLetterInfo"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
}

extension MessageGetUserInfoAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        guard let prizeGoupsDict = data.object(forKey: "data") as? NSDictionary else { return nil }
        
        return prizeGoupsDict
    }
    
    
    
}
