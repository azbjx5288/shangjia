//
//  MessageSendViewController.swift
//  GoldenApple
//
//  Created by User on 2018/7/25.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class MessageSendViewController: UIViewController {

    let getUserInfoApiManager = MessageGetUserInfoAPIManager()
    let sendMessageApiManager = MessageSendAPIManager()
    var userList: [NSDictionary] = []
    lazy var myView = {() -> MessageSendView in
        let view = MessageSendView(frame: self.view.frame)
        return view
    }()
    
    var sendUserType = 2
    var xiaji_id = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "发信息"
        self.view.addSubview(self.myView)
        self.myView.delegate = self
        self.getUserInfoApiManager.delegate = self
        self.getUserInfoApiManager.loadData()
        self.sendMessageApiManager.paramSource = self
        self.sendMessageApiManager.delegate = self
        self.myView.btn_send.addTarget(self, action: #selector(onSendClick), for: .touchUpInside)
    }
    
    @objc func onSendClick(){
        let title = self.myView.textField_title.text!
        let content = self.myView.textview_content.text!
        if title.count < 1 {
            GAProgressHUD.showError(message: "请输入标题")
            return
        }
        if content.count < 1 {
            GAProgressHUD.showError(message: "请输入内容")
            return
        }
        if sendUserType == 3 && xiaji_id == -1{
            GAProgressHUD.showError(message: "请指定发送的下级")
            return
        }
        self.sendMessageApiManager.loadData()
    }
}

extension MessageSendViewController: UITextViewDelegate {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.myView.endEditing(true)
    }
    
}

extension MessageSendViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        //        GAProgressHUD.showLoading(message: "获取数据,请稍候...")
        var params = [:] as [String : Any]
        if manager == sendMessageApiManager{
            params["title"] = self.myView.textField_title.text
            params["content"] = self.myView.textview_content.text
            params["user_type"] = sendUserType
            if sendUserType == 3 {
                params["receiver"] = xiaji_id
            }
        }else if manager == getUserInfoApiManager {
            
        }
        return params as NSDictionary
    }
    
}

extension MessageSendViewController:LYAPIManagerCallBackDelegate{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        //        GAProgressHUD.showSuccess(message: "获取成功!")
        if manager == sendMessageApiManager{
            GAAlertController.showAlert("提示", "消息已发送成功", nil, "确定", cancelCallBack: nil, commitCallBack: {
                self.myView.textField_title.text = ""
                self.myView.textview_content.text = ""
            })
        }else if manager == getUserInfoApiManager {
            let hhhhhhh = manager.fetchData(self.getUserInfoApiManager)
            guard let dic = hhhhhhh as? NSDictionary else {
                return
            }
//            let is_top = dic[MessageGetUserInfoAPIManager.DataKey.is_top_agent] as! Bool
            let optionList = dic[MessageGetUserInfoAPIManager.DataKey.user_type] as! NSDictionary
            userList = dic[MessageGetUserInfoAPIManager.DataKey.child] as! [NSDictionary]
            self.myView.btn_shangji.isHidden = !optionList.allKeys.contains(where: { (item) -> Bool in
                return (item as! String) == "1"
            })
            self.myView.btn_all_xiaji.isHidden = !optionList.allKeys.contains(where: { (item) -> Bool in
                return (item as! String) == "2"
            })
            self.myView.btn_single_xiaji.isHidden = !optionList.allKeys.contains(where: { (item) -> Bool in
                return (item as! String) == "3"
            })
            if !optionList.allKeys.contains(where: { (item) -> Bool in
                return (item as! String) == "2"
            }){
                self.myView.btn_shangji.isSelected = true
                self.myView.btn_all_xiaji.isSelected = true
                self.sendUserType = 1
            }
            var list:[String] = []
            for item in userList {
                if let name = item["username"] as? String{
                    list.append(name)
                }
            }
            self.myView.dropView_xiaji.dataSource = list
        }
    }
    
}

extension MessageSendViewController: GAAlertDelegate {
    func alertCancelButtonClicked() {
        
    }
    
    func alertCommitButtonClicked() {
//        self.getUserInfoApiManager.loadData()
    }
    
    
}

extension MessageSendViewController: MessageSendViewDelegate {
     
    func onSelectChange(type: Int){
        self.sendUserType = type
    }
    
    func onSelectUserChange(item: String){
        for user in self.userList {
            if let name = user["username"] as? String{
                if name == item{
                    self.xiaji_id = user["id"] as! Int
                    break
                }
            }
        }
    }

}
