//
//  MessageReadAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/8/17.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import Foundation

import UIKit

class MessageReadAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        static let id = "id"
        static let sender = "sender"
        static let created_at = "created_at"
        static let is_readed = "is_readed"
        static let msg_title = "msg_title"
        static let msg_type = "msg_type"
        static let msg_content = "msg_content"
    }
    
}

extension MessageReadAPIManager: LYAPIManager {
    
    public func methodName() -> NSString {
        return "service?packet=Message&action=GetLetterDetail"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
}
