//
//  CustomerServiceViewController.swift
//  GoldenApple
//
//  Created by User on 06/12/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class CustomerServiceViewController: GAWKWebViewController {
    
    let acountCenterAPIManager = AccountCenterAPIManager()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.acountCenterAPIManager.delegate = self
        
        self.acountCenterAPIManager.loadData()
    }


}

extension CustomerServiceViewController: LYAPIManagerCallBackDelegate {
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        if manager == self.acountCenterAPIManager {
            GAProgressHUD.hidHUD()
            guard let userInfoDict = manager.fetchData(self.acountCenterAPIManager) as? NSDictionary else {return}

            var userName = userInfoDict[AccountCenterAPIManager.DataKey.kUsername] as? String
            if userName == nil || userName!.isEmpty {
                userName = "临时访客"
            }
            let serviceParam = [AccountCenterAPIManager.DataKey.kUsername: userName,
                                AccountCenterAPIManager.DataKey.kId: userInfoDict[AccountCenterAPIManager.DataKey.kId],
                                AccountCenterAPIManager.DataKey.kAbalance: userInfoDict[AccountCenterAPIManager.DataKey.kAbalance],
                                AccountCenterAPIManager.DataKey.kSigninAt: userInfoDict[AccountCenterAPIManager.DataKey.kSigninAt]]
            
            let jsonData = try! JSONSerialization.data(withJSONObject: serviceParam, options: JSONSerialization.WritingOptions.prettyPrinted)
            let urlStr = kGACustomerServiceUrlString + "&token=" + jsonData.base64EncodedString()
            let urlRequest = URLRequest(url: URL(string: urlStr)!)
            self.webView.load(urlRequest)
        }
    }
    
    
}


