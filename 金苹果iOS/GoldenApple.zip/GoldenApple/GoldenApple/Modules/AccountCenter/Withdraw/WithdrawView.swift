//
//  WithdrawView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/27.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class WithdrawView: UIView {
    
    public let withdrawalbleTF = HaveLeftViewTextField.init(title: "可提现余额:",showDoneButton:false)
    public let withdrawTF = HaveLeftViewTextField.init(title: "提现金额:",showDoneButton:false)
    
    public lazy var tableView : UITableView = {
        ()-> UITableView in
        let temp = UITableView()
        temp.separatorStyle = UITableViewCellSeparatorStyle.none
        
        let noticeLB = UILabel()
        noticeLB.text = "该银行卡在2小时内有新增/修改等操作,请在2小时保护时间结束后再提现。"
        noticeLB.numberOfLines = 0
        noticeLB.font = UIFont.systemFont(ofSize: 14)
        noticeLB.textColor = kGANavigationBackgroundColor
        
        //设置行距
        let attributedString = NSMutableAttributedString.init(string: noticeLB.text!, attributes: [NSFontAttributeName : noticeLB.font])
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 5
        attributedString.addAttributes([NSParagraphStyleAttributeName : paragraphStyle], range: NSRange.init(location: 0, length: ((noticeLB.text as NSString?)?.length)!))
        noticeLB.attributedText = attributedString
        
        //宽度
        let width = UIScreen.main.bounds.width - 30
        
        //计算高度
        let size = noticeLB.attributedText?.boundingRect(with: CGSize.init(width: width, height: CGFloat(MAXFLOAT)), options:[.usesLineFragmentOrigin,.usesFontLeading], context: nil).size
        noticeLB.frame = CGRect.init(x: 15, y: 20, width: (size?.width)!, height: (size?.height)!)
        
        let tableFooterView = UIView()
        tableFooterView.frame = CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: (size?.height)! + 40)
        tableFooterView.addSubview(noticeLB)
        
        temp.tableFooterView = tableFooterView
        temp.tableFooterView?.isHidden = true
        
        return temp
    }()
    
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGAFontGrayColor
        temp.setTitle("下一步", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        temp.isEnabled = false
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        self.withdrawalbleTF.isEnabled = false
        self.withdrawalbleTF.text = "00.00元"
        self.withdrawalbleTF.font = UIFont.systemFont(ofSize: 18)
        self.withdrawalbleTF.textColor = kGANavigationBackgroundColor
        self.addSubview(self.withdrawalbleTF)
        self.withdrawalbleTF.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.withdrawTF.placeholder = "请输入提现金额"
        self.withdrawTF.keyboardType = .numbersAndPunctuation
        self.withdrawTF.font = UIFont.systemFont(ofSize: 18)
        self.withdrawTF.textColor = kGANavigationBackgroundColor
        self.addSubview(self.withdrawTF)
        self.withdrawTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.withdrawalbleTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.withdrawalbleTF)
        }
        
        let noticeView = UIView()
        noticeView .backgroundColor = kGASerperatorLineGrayColor
        self.addSubview(noticeView)
        noticeView.snp.makeConstraints { (make) in
            make.top.equalTo(self.withdrawTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.withdrawalbleTF)
        }
        
        let noticeLB = UILabel()
        noticeLB.text = "单笔提现最低100元，最高150000元"
        noticeLB.font = UIFont.systemFont(ofSize: 16)
        noticeLB.textColor = kGAFontGrayColor
        noticeView.addSubview(noticeLB)
        noticeLB.snp.makeConstraints { (make) in
            make.left.equalTo(noticeView).offset(15)
            make.centerY.equalTo(noticeView)
        }
        
        self.setBottomView()
        
        self.addSubview(self.tableView)
        self.tableView.snp.makeConstraints { (make) in
            make.top.equalTo(noticeView.snp.bottom)
            make.bottom.equalTo(self.bottomView.snp.top)
            make.left.right.equalTo(self)
        }
    }
    
    private func setBottomView() {
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
       
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func setSubmitButtonStatus(isEnable : Bool) {
        self.bottomBtn.isEnabled = isEnable
        if isEnable {
            self.bottomBtn.backgroundColor = kGANavigationBackgroundColor
        } else {
            self.bottomBtn.backgroundColor = kGAFontGrayColor
        }
        
    }
    
    
}
