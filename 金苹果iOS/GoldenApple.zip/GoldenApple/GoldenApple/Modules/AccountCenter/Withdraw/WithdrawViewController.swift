//
//  WithdrawViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/27.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class WithdrawViewController: UIViewController {

    var myView : WithdrawView?
    
    var bankCards : [NSDictionary]?
    let getBankApiManager = GetBindedBankCardsAPIManager()
    let userInfoApiManager = AccountCenterAPIManager()
    var withdrawable : Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "提现"
        
        self.view = WithdrawView()
        self.myView = self.view as? WithdrawView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
    
        self.getBankApiManager.delegate = self
        self.getBankApiManager.paramSource = self
        self.userInfoApiManager.delegate = self
        self.userInfoApiManager.paramSource = self

        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.bankCards = nil
        self.myView?.setSubmitButtonStatus(isEnable: false)
        self.getBankApiManager.loadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @objc func didClickBottomBtn() {
        if self.myView?.withdrawTF.text == nil || (self.myView?.withdrawTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "提现金额不能为空!")
            return
        }
        
        let withdraw : NSString = (self.myView?.withdrawTF.text as NSString?)!
    
        if withdraw.doubleValue < 100.00 {
            GAProgressHUD.showWarning(message: "单笔提现最低100元!")
            return
        }
        if withdraw.doubleValue > 150000.00 {
            GAProgressHUD.showWarning(message: "单笔提现最高150000元!")
            return
        }
        
        if self.withdrawable < withdraw.doubleValue {
            GAProgressHUD.showWarning(message: "提现金额不能大于可提现余额!")
            return
        }
        
        let index = self.myView?.tableView.indexPathForSelectedRow?.row
        let bandCard = self.bankCards![index!]
        let withdrawVC1 = WithdrawViewController1()
        withdrawVC1.bandCard = bandCard
        withdrawVC1.withdrawAmount = self.myView?.withdrawTF.text
        self.navigationController?.pushViewController(withdrawVC1, animated: true)
    }
    
    fileprivate func isCanWithdraw(endDateString : String)->Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let endDate = dateFormatter.date(from: endDateString)
        let endDateInterveral = NSDate.init(timeIntervalSinceReferenceDate: (endDate?.timeIntervalSinceReferenceDate)!)
        let timeInterval = endDateInterveral.timeIntervalSinceNow
        if timeInterval <= 0 {
            return true
        } else {
            return false
        }
        
    }
    
}

extension WithdrawViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let count = self.bankCards?.count else {
            return 0
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = BankCardManagerCell.cellWithTableView(tableView: tableView)
        cell.setData(bankDict: self.bankCards![indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let withdrawalTime = self.bankCards![indexPath.row].object(forKey: GetBindedBankCardsAPIManager.DataKey.kIntended_withdrawal_at) as? String
        let canWithdraw = self.isCanWithdraw(endDateString: withdrawalTime!)
        self.myView?.setSubmitButtonStatus(isEnable: canWithdraw)
        tableView.tableFooterView?.isHidden = canWithdraw
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = .white
        let headerLB = UILabel()
        headerLB.text = "请选择收款银行卡"
        headerLB.font = UIFont.systemFont(ofSize: 16)
        headerView.addSubview(headerLB)
        headerLB.snp.makeConstraints { (make) in
            make.left.equalTo(headerView).offset(15)
            make.centerY.equalTo(headerView)
        }
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        headerView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(headerView)
            make.height.equalTo(1)
        }
        return headerView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 55
    }
}

extension WithdrawViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        GAProgressHUD.showLoading(message: "正在加载...")
        
        return NSDictionary()
    }
    
}
extension WithdrawViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        if manager == self.getBankApiManager {
            let dataArray = manager.fetchData(self.getBankApiManager) as? [NSDictionary]
            if dataArray == nil || dataArray?.count == 0 {
                GAAlertController.showAlert("温馨提示", "您尚未添加收款银行卡,请前往银行卡管理添加!", "取消", "添加银行卡", cancelCallBack: {
//                    self.navigationController?.popViewController(animated: true)
                }, commitCallBack: {
                    let bankManagerVC = BankCardManagerViewController()
                    bankManagerVC.hidesBottomBarWhenPushed = true
                    self.navigationController?.pushViewController(bankManagerVC, animated: true)
                    let controllers = self.navigationController?.viewControllers
                    let mControllers = NSMutableArray.init(array: controllers!)
                    mControllers.removeObject(at: (controllers?.count)! - 2)
                    self.navigationController?.viewControllers = mControllers.copy() as! [UIViewController]
                })
                return
            }
            self.bankCards = dataArray
            self.myView?.tableView.reloadData()
            self.userInfoApiManager.loadData()
            
        } else if manager == self.userInfoApiManager {
            guard let dict = manager.fetchData(self.userInfoApiManager) as? NSDictionary  else {return}
            guard var withdrawable = dict.object(forKey: AccountCenterAPIManager.DataKey.kWithdrawable) as? NSString  else {return}
            self.myView?.withdrawalbleTF.text = (withdrawable as String) + "元"
            withdrawable = withdrawable.replacingOccurrences(of: ",", with: "") as NSString
            self.withdrawable = (withdrawable as NSString).doubleValue
            
        }
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.getBankApiManager.callAPIDidFailed(manager)
//    }
}

