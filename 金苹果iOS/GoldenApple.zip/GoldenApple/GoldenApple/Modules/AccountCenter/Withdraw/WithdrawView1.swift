//
//  WithdrawView1.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/27.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class WithdrawView1: UIView {
    public let userNameTF = HaveLeftViewTextField.init(title: "用户人名",showDoneButton:false)
    public let withdrawTF = HaveLeftViewTextField.init(title: "提现金额",showDoneButton:false)
    public let bankNameTF = HaveLeftViewTextField.init(title: "提现银行",showDoneButton:false)
    public let bankNumTF = HaveLeftViewTextField.init(title: "提现账号",showDoneButton:false)
    public let accountNameTF = HaveLeftViewTextField.init(title: "开户人名",showDoneButton:false)
    public let pwdTF = HaveLeftViewTextField.init(title: "",showDoneButton:false)
    
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("确认提现", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_ : )), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_ : )), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        self.userNameTF.font = UIFont.systemFont(ofSize: 16)
        self.userNameTF.isUserInteractionEnabled = false
        self.addSubview(self.userNameTF)
        self.userNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.withdrawTF.font = UIFont.systemFont(ofSize: 16)
        self.withdrawTF.isUserInteractionEnabled = false
        self.addSubview(self.withdrawTF)
        self.withdrawTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.userNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.userNameTF)
        }
        
        self.bankNameTF.font = UIFont.systemFont(ofSize: 16)
        self.bankNameTF.isUserInteractionEnabled = false
        self.addSubview(self.bankNameTF)
        self.bankNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.withdrawTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.userNameTF)
        }
        
        self.bankNumTF.font = UIFont.systemFont(ofSize: 16)
        self.bankNumTF.isUserInteractionEnabled = false
        self.addSubview(self.bankNumTF)
        self.bankNumTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.bankNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.userNameTF)
        }
        
        self.accountNameTF.font = UIFont.systemFont(ofSize: 16)
        self.accountNameTF.isUserInteractionEnabled = false
        self.addSubview(self.accountNameTF)
        self.accountNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.bankNumTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.userNameTF)
        }
        
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
        
        let pwdView = UIView()
        pwdView.backgroundColor = kGASerperatorLineGrayColor
        self.addSubview(pwdView)
        pwdView.snp.makeConstraints { (make) in
            make.top.equalTo(self.accountNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.bottom.equalTo(self.bottomView.snp.top)
        }
        
        let noticeLB = UILabel()
        noticeLB.text = "为了确保你的资金安全,请输入资金密码"
        noticeLB.numberOfLines = 0
        noticeLB.textColor = kGANavigationBackgroundColor
        noticeLB.font = UIFont.systemFont(ofSize: 16)
        pwdView.addSubview(noticeLB)
        noticeLB.snp.makeConstraints { (make) in
            make.top.equalTo(pwdView).offset(20)
            make.centerX.equalTo(pwdView)
        }
        
        self.pwdTF.font = UIFont.systemFont(ofSize: 16)
        self.pwdTF.leftView = nil
        self.pwdTF.clearButtonMode = .whileEditing
        self.pwdTF.placeholder = "请输入资金密码"
        self.pwdTF.isSecureTextEntry = true
        self.pwdTF.textAlignment = .center
        self.pwdTF.backgroundColor = .white
        pwdView.addSubview(self.pwdTF)
        self.pwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(noticeLB.snp.bottom).offset(10)
            make.left.right.equalTo(self)
            make.height.equalTo(self.userNameTF)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    //处理键盘遮挡
    @objc func keyboardWillShow(_ notification : Notification) {
        
        if !self.pwdTF.isFirstResponder {
            return
        }
        
        let keyboardFrame = notification.userInfo!["UIKeyboardFrameEndUserInfoKey"] as? CGRect
        let keyBoardHeight = keyboardFrame?.size.height  //键盘高度
        let duration = notification.userInfo!["UIKeyboardAnimationDurationUserInfoKey"] //动画时长
        
        self.screenY = nil
        self.getViewScreenY(view: self.pwdTF)
    
        let pwdTFMaxY = self.screenY!   //pwdTF相对屏幕的maxY
        let screenH = UIScreen.main.bounds.size.height
        let offset = keyBoardHeight! - (screenH - pwdTFMaxY)   //myView需要移动的y值
        
        if offset > 0.0 {
            UIView.animate(withDuration: duration as! TimeInterval) {
                self.transform = CGAffineTransform(translationX: 0, y: -offset);//xy移动距离
            }
        }
    }
    
    
    /// 获取控件相对屏幕的Y值
    var screenY : CGFloat?
    private func getViewScreenY(view : UIView?){
        if screenY == nil {
            view?.layoutIfNeeded()
            screenY = view?.frame.maxY
            self.getViewScreenY(view: view?.superview!)
        } else {
            if view != nil {
                view?.layoutIfNeeded()
                screenY = screenY! + (view?.frame.origin.y)!
                self.getViewScreenY(view: view?.superview)
            }
        }
    }
    
    
    @objc func keyboardWillHide(_ notification : Notification) {
        
        if !self.pwdTF.isFirstResponder {
            return
        }
        
        let duration = notification.userInfo!["UIKeyboardAnimationDurationUserInfoKey"]
        UIView.animate(withDuration: duration as! TimeInterval) {
            self.transform = CGAffineTransform(translationX: 0, y: 0);//xy移动距离
        }
    }

    
    public func withdrawSuccess() {
        for view in self.subviews {
            view.removeFromSuperview()
        }
        let successView = GASuccessView.init(title: "提现成功!")
        self.addSubview(successView)
        successView.snp.makeConstraints({ (make) in
            make.edges.equalTo(self)
        })
    }
}
