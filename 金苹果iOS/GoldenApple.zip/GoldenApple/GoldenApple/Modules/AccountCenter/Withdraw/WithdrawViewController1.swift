//
//  WithdrawViewController1.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/27.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class WithdrawViewController1: UIViewController {

    var myView : WithdrawView1?
    var bandCard : NSDictionary?
    var withdrawAmount : String?
    
    var withdrawApiManager : WithdrawAPIManager? =  WithdrawAPIManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "提现确认"
        self.myView = WithdrawView1()
        self.view.addSubview(self.myView!)
        self.myView?.snp.makeConstraints({ (make) in
            make.top.bottom.right.left.equalTo(self.view)
        })

        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
        self.myView?.userNameTF.text = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kUsername] as? String
        self.myView?.withdrawTF.text = self.withdrawAmount! + "元"
        self.myView?.bankNameTF.text = self.bandCard?.object(forKey: GetBindedBankCardsAPIManager.DataKey.kName) as? String
        let bankNumber = self.bandCard?.object(forKey: GetBindedBankCardsAPIManager.DataKey.kAccount) as? NSString
        self.myView?.bankNumTF.text = "************" + (bankNumber?.substring(with: NSRange.init(location: (bankNumber?.length)! - 4, length: 4)))!
        let accountName = self.bandCard?.object(forKey: GetBindedBankCardsAPIManager.DataKey.kAccountName) as? NSString
        self.myView?.accountNameTF.text = "**" + (accountName?.substring(with: NSRange.init(location: (accountName?.length)! - 1, length: 1)))!
        
        self.withdrawApiManager?.delegate = self
        self.withdrawApiManager?.paramSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
    
    @objc func didClickBottomBtn() {
        if self.myView?.pwdTF.text == nil || (self.myView?.pwdTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "资金密码不能为空")
            return
        }
        self.withdrawApiManager?.loadData()
    }
    
    
}

extension WithdrawViewController1:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        GAProgressHUD.showLoading(message: "正在提现...")
        let params = NSMutableDictionary()
        let cardId = self.bandCard?.object(forKey: GetBindedBankCardsAPIManager.DataKey.kId)
        
        params["bankcard_id"] = cardId
        params["amount"] = self.withdrawAmount
        
        let fund_password = self.myView?.pwdTF.text
//        var username = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kUsername] as! String
//        username = username.lowercased()
//        fund_password = username + fund_password!
//        fund_password = ((fund_password?.md5())?.md5())?.md5()
     
        params["fund_password"] = fund_password
        
        return params
    }
    
}
extension WithdrawViewController1:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        self.myView?.withdrawSuccess()
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.withdrawApiManager?.callAPIDidFailed(manager)
//    }
}
