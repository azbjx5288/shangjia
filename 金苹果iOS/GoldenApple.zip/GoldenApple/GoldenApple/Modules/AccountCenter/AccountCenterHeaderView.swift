//
//  AccountCenterHeaderView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/12/1.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AccountCenterHeaderView: UIView {
    
    fileprivate let topLine: UIView = {
        let view = UIView()
        view.backgroundColor = kGASerperatorLineGrayColor
        
        return view
    }()

    let rechargeBtn : UIButton = {
        let button = UIButton()
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.setTitle("充值", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.setTitleColor(.gray, for: .highlighted)
        button.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0)
        button.setImage(UIImage.init(named: "icon_deposit"), for: .normal)
        
        return button
    }()
    
    fileprivate let seperatorLine1: UIView = {
        let view = UIView()
        view.backgroundColor = kGASerperatorLineGrayColor
        
        return view
    }()
    
    let withdrawBtn : UIButton = {
        let button = UIButton()
        
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.setTitle("提现", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.setTitleColor(.gray, for: .highlighted)
        button.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0)
        button.setImage(UIImage.init(named: "icon_withdraw"), for: .normal)
        
        return button
    }()
    let seperatorLine2: UIView = {
        let view = UIView()
        view.backgroundColor = kGASerperatorLineGrayColor
        
        return view
    }()
    let transferBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.setTitle("转账", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.setTitleColor(.gray, for: .highlighted)
        button.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0)
        button.setImage(UIImage.init(named: "icon_withdraw"), for: .normal)
        
        return button
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = kGANavigationBackgroundColor
        
        self.addSubview(self.topLine)
        self.addSubview(self.rechargeBtn)
        self.addSubview(self.seperatorLine1)
        self.addSubview(self.withdrawBtn)
        self.addSubview(self.seperatorLine2)
        self.addSubview(self.transferBtn)
        
        self.topLine.snp.makeConstraints { (make) in
            make.left.right.equalTo(self)
            make.top.equalTo(self)
            make.height.equalTo(1)
        }
        self.rechargeBtn.snp.makeConstraints { (make) in
            make.top.equalTo(topLine.snp.bottom)
            make.left.equalTo(self)
            make.width.equalTo(topLine).multipliedBy(0.33).offset(0.5)
            make.height.equalTo(55)
        }
        self.seperatorLine1.snp.makeConstraints { (make) in
            make.left.equalTo(self.rechargeBtn.snp.right)
            make.top.bottom.equalTo(self.rechargeBtn)
            make.width.equalTo(1)
        }
        self.withdrawBtn.snp.makeConstraints { (make) in
            make.top.bottom.width.equalTo(self.rechargeBtn)
            make.left.equalTo(self.seperatorLine1.snp.right)
        }
        self.seperatorLine2.snp.makeConstraints { (make) in
            make.left.equalTo(self.withdrawBtn.snp.right)
            make.top.bottom.equalTo(self.withdrawBtn)
            make.width.equalTo(1)
        }
        self.transferBtn.snp.makeConstraints { (make) in
            make.top.bottom.width.equalTo(self.rechargeBtn)
            make.left.equalTo(self.seperatorLine2.snp.right)
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
