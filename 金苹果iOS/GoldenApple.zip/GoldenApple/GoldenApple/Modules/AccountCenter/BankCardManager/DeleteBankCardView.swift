//
//  DeleteBankCardView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/24.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class DeleteBankCardView: UIView {

    public let cardLB = UILabel()
    public let accountNameTF = HaveLeftViewTextField.init(title: "开户人名",showDoneButton:false)
    public let bankNumTF = HaveLeftViewTextField.init(title: "银行卡号",showDoneButton:false)
    public let pwdTF : HaveLeftViewTextField = HaveLeftViewTextField.init(title: "资金密码:",showDoneButton:false)
    
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("确认删除", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        self.cardLB.font = UIFont.systemFont(ofSize: 18)
        self.cardLB.textAlignment = .center
        self.addSubview(self.cardLB)
        self.cardLB.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.top.equalTo(self.cardLB.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(10)
        }
        
        self.accountNameTF.placeholder = "请输入开户人姓名"
        self.addSubview(self.accountNameTF)
        self.accountNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(line.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.cardLB)
        }
        
        self.bankNumTF.placeholder = "请输入银行卡号"
        self.bankNumTF.keyboardType = .numberPad
        self.addSubview(self.bankNumTF)
        self.bankNumTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.accountNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.cardLB)
        }
        
        self.pwdTF.placeholder = "请输入资金密码"
        self.pwdTF.isSecureTextEntry = true
        self.addSubview(self.pwdTF)
        self.pwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.bankNumTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.cardLB)
        }
        
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func deleteSuccess() {
        for view in self.subviews {
            view.removeFromSuperview()
        }
        let successView = GASuccessView.init(title: "删除成功!")
        self.addSubview(successView)
        successView.snp.makeConstraints({ (make) in
            make.edges.equalTo(self)
        })
    }
    
}
