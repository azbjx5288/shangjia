//
//  DeleteBankCardViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/24.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class DeleteBankCardViewController: UIViewController {

    var bankDict : NSDictionary?
    var myView : DeleteBankCardView?
    let checkApiManager = CheckBankCardAPIManager()
    let deleteApiManager = DeleteBankCardAPIManager()
    var checkToken : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "删除银行卡"
        self.view = DeleteBankCardView()
        self.myView = self.view as? DeleteBankCardView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
        let bankName = self.bankDict?.value(forKey: GetBindedBankCardsAPIManager.DataKey.kName) as? String
        let bankNumber = self.bankDict?.object(forKey: GetBindedBankCardsAPIManager.DataKey.kAccount) as? NSString
        
        self.myView?.cardLB.text = bankName! + "  ************" + (bankNumber?.substring(with: NSRange.init(location: (bankNumber?.length)! - 4, length: 4)))!
       
        self.checkApiManager.delegate = self
        self.checkApiManager.paramSource = self
        self.deleteApiManager.delegate = self
        self.deleteApiManager.paramSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func didClickBottomBtn() {
        if self.myView?.accountNameTF.text == nil || (self.myView?.accountNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)!  {
            GAProgressHUD.showWarning(message: "开户人名不能为空")
            return
        }
        if self.myView?.bankNumTF.text == nil || (self.myView?.bankNumTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "银行卡号不能为空")
            return
        }
        
        let bankNumLength = (self.myView?.bankNumTF.text as NSString?)?.length
        if bankNumLength != 16 && bankNumLength != 18 && bankNumLength != 19 {
            GAProgressHUD.showWarning(message: "银行卡号为16、18或19位数字组成")
            return
        }
        
        if self.myView?.pwdTF.text == nil || (self.myView?.pwdTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "资金密码不能为空")
            return
        }
        self.checkApiManager.loadData()
    }

}

extension DeleteBankCardViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        let cardId = self.bankDict?.value(forKey: GetBindedBankCardsAPIManager.DataKey.kId) as? Int
        let params = NSMutableDictionary()
        params["card_id"] = cardId
        
        if manager == self.checkApiManager {
            GAProgressHUD.showLoading(message: "正在校验银行卡信息...")
            self.checkToken = nil
            params["fund_pwd"] = self.myView?.pwdTF.text
            params["account_name"] = self.myView?.accountNameTF.text
            params["account"] = self.myView?.bankNumTF.text
            params["type"] = 3
            return params
        } else if manager == self.deleteApiManager {
            GAProgressHUD.showLoading(message: "正在删除...")
            params["checked_token"] = self.checkToken
        }
        return params
    }
    
}
extension DeleteBankCardViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        if manager == self.checkApiManager { //校验银行卡信息成功
            GAProgressHUD.showSuccess(message: "校验成功!")
            guard let tokenDict = manager.fetchData(self.checkApiManager) as? NSDictionary  else {return}
            self.checkToken = tokenDict.value(forKey: CheckBankCardAPIManager.DataKey.kToken) as? String
            self.deleteApiManager.loadData()
        } else if manager == self.deleteApiManager {  //删除银行卡成功
            GAProgressHUD.hidHUD()
            self.myView?.deleteSuccess()
        }
        
        
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.checkApiManager.callAPIDidFailed(manager)
//    }
}
