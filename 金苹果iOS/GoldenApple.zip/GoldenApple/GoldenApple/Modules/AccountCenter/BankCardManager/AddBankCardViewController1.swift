//
//  AddBankCardViewController1.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/29.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AddBankCardViewController1: UIViewController {

    let addApiManager = AddBankCardAPIManager()
    var checkToken : String?
    var provinceDict  : NSDictionary?
    var cityDict : NSDictionary?
    var bankDict : NSDictionary?
    var branch : String?
    var accountName : String?
    var bankCardNum : String?
    /// 判断添加成功银行卡
    fileprivate var isAddedSuccess = false
    
    var myView : AddBankCardView1?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "添加银行卡"
        self.navigationItem.setNavigationBackTarget(self, action: #selector(didClickBack))
        self.myView = AddBankCardView1()
        self.view.addSubview(self.myView!)
        self.myView?.snp.makeConstraints({ (make) in
            make.edges.equalTo(self.view)
        })
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickSubmit(_ :)), for: .touchUpInside)
        self.myView?.bankNameTF.text = self.bankDict?.object(forKey: "name") as? String
        self.myView?.addressTF.text = (self.provinceDict?.value(forKey: "areaName") as? String)! + "   " + (self.cityDict?.value(forKey: "areaName") as? String)!
        self.myView?.branchTF.text = self.branch
        self.myView?.accountNameTF.text = self.accountName
        self.myView?.bankNumTF.text = self.bankCardNum
        self.addApiManager.delegate = self
        self.addApiManager.paramSource = self
        
    }
    
    @objc func didClickBack() {
        if self.isAddedSuccess {
            var managerVC : UIViewController?
            for vc in (self.navigationController?.childViewControllers)! {
                if vc.isKind(of: BankCardManagerViewController.self) {
                    managerVC = vc
                }
            }
            self.navigationController?.popToViewController(managerVC!, animated: true)
        } else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    @objc func didClickSubmit(_ sender : UIButton) {
        self.addApiManager.loadData()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
extension AddBankCardViewController1:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "正在处理...")
        let params = NSMutableDictionary()
        let bankId = Int((self.bankDict?.value(forKey: "id") as? String)!)
        let provinceId = self.provinceDict?.value(forKey: "areaId") as? Int
        let cityId = self.cityDict?.value(forKey: "areaId") as? Int
        
        params["bank_id"] = bankId
        params["province_id"] = provinceId
        params["city_id"] = cityId
        params["account_name"] = self.myView?.accountNameTF.text
        params["account"] = self.myView?.bankNumTF.text
        params["branch"] = self.myView?.branchTF.text
        
        if self.checkToken != nil {
            params["checked_token"] = self.checkToken!
        }
        
        return params
    }
    
}
extension AddBankCardViewController1:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        self.myView?.addSuccess()
        self.isAddedSuccess = true
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.addApiManager.callAPIDidFailed(manager)
//    }
}
