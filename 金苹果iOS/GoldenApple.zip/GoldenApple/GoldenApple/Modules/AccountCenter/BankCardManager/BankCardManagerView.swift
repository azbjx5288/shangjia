//
//  BankCardManagerView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/21.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BankCardManagerView: UIView {
    
    var timer = Timer()
    fileprivate var countdown_seconds = 0
    public lazy var tableView : UITableView = {
        ()-> UITableView in
        let temp = UITableView()
        temp.separatorStyle = UITableViewCellSeparatorStyle.none
        
        //tableFooterView
        let noticeLB = UILabel()
        noticeLB.text = "同一账号最多绑定4张银行卡\n为了您的账户资金安全,银行卡\"新增\"和\"修改\"将在操作完成2小时后，才能向平台发起提现。\n\n银行卡信息发生变更,1小时后将自动锁定,锁定银行卡后,将不能对银行卡进行增加/修改/删除操作。如需解除银行卡请联系在线客服。"
        noticeLB.numberOfLines = 0
        noticeLB.font = UIFont.systemFont(ofSize: 14)
        noticeLB.textColor = kGAFontGrayColor
        
        //设置行距
        let attributedString = NSMutableAttributedString.init(string: noticeLB.text!, attributes: [NSFontAttributeName : noticeLB.font])
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 5
        attributedString.addAttributes([NSParagraphStyleAttributeName : paragraphStyle], range: NSRange.init(location: 0, length: ((noticeLB.text as NSString?)?.length)!))
        noticeLB.attributedText = attributedString
        
        //宽度
        let width = UIScreen.main.bounds.width - 30
      
        //计算高度
        let size = noticeLB.attributedText?.boundingRect(with: CGSize.init(width: width, height: CGFloat(MAXFLOAT)), options:[.usesLineFragmentOrigin,.usesFontLeading], context: nil).size
        noticeLB.frame = CGRect.init(x: 15, y: 20, width: (size?.width)!, height: (size?.height)!)
        
        let tableFooterView = UIView()
        tableFooterView.frame = CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: (size?.height)! + 40)
        tableFooterView.addSubview(noticeLB)
        
        temp.tableFooterView = tableFooterView
        
        return temp
    }()
    
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.titleLabel?.textAlignment = .center
        temp.backgroundColor = kGAFontGrayColor
        temp.isUserInteractionEnabled = false
        let title = "锁定银行卡"
        temp.titleLabel?.numberOfLines = 0
        temp.setTitle(title, for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        self.setBottomView()
        self.addSubview(self.tableView)
        self.tableView.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self)
            make.bottom.equalTo(self.bottomView.snp.top)
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    private func setBottomView() {
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
        self.bottomView.isHidden = true
    }
    
    public func setLockStatus(isLocked : Bool,lockTime : String?) {
        
        self.bottomView.isHidden = false
        
        if isLocked {
            self.setLockBttomBtnTitle()
        } else {
            if lockTime == nil || (lockTime?.isEmpty)! {
                self.bottomView.isHidden = true
                return
            }
            
            self.bottomBtn.backgroundColor = kGANavigationBackgroundColor
            self.bottomBtn.isUserInteractionEnabled = true
            
            self.timeManager(endDateString:lockTime!)
            
            // 初始化 timer ,并设置时间间隔1秒，以及处理事件的方法
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerStartCountDown), userInfo: nil, repeats: true)
            // 开始
            timer.fire()
        
        }
    }
    private func timeManager(endDateString : String) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let endDate = dateFormatter.date(from: endDateString)
        let endDateInterveral = NSDate.init(timeIntervalSinceReferenceDate: (endDate?.timeIntervalSinceReferenceDate)!)
        let timeInterval = endDateInterveral.timeIntervalSinceNow
        self.countdown_seconds = Int(timeInterval)
        
    }
    private func timeFromat() -> String {
        var interval = self.countdown_seconds
        var hour = 0
        var minute = 0
        var second = 0
        if interval / 3600 >= 1 {
            hour = interval / 3600
        }
        interval = interval - hour * 3600
        
        if interval / 60 >= 1 {
            minute = interval / 60
        }
        second = interval - minute * 60
        
        return NSString.init(format: "%02d:%02d:%02d", hour,minute,second) as String
    }
    
    @objc func timerStartCountDown() {
        
        guard self.countdown_seconds > 0 else {
            // 停止
            timer.invalidate()

            let attrTitle = NSMutableAttributedString.init(string: "锁定银行卡")
            self.bottomBtn.setAttributedTitle(attrTitle, for: .normal)
            return
        }
        
        self.countdown_seconds = self.countdown_seconds - 1
        let timeStr = self.timeFromat()
        self.setUnlockBttomBtnTitle(timeString: timeStr)
    }
    
    private func setLockBttomBtnTitle() {
        self.bottomBtn.backgroundColor = kGAFontGrayColor
        self.bottomBtn.isUserInteractionEnabled = false
        let attrTitle = NSMutableAttributedString.init(string: "已锁定")
        self.bottomBtn.setAttributedTitle(attrTitle, for: .normal)
    }
    
    private func setUnlockBttomBtnTitle(timeString : String) {
        
        let title = "锁定银行卡\n"
        let titleLength = (title as NSString).length
        let timeLength = (timeString as NSString).length
        
        let attrTitle = NSMutableAttributedString.init(string: title + timeString )
        attrTitle.addAttributes([NSFontAttributeName : UIFont.systemFont(ofSize: 14)], range: NSRange.init(location: titleLength, length: timeLength))
        self.bottomBtn.setAttributedTitle(attrTitle, for: .normal)
    }
    
}
