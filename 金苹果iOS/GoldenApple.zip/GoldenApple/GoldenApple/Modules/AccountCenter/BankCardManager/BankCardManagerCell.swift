//
//  BankCardManagerCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/21.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BankCardManagerCell: UITableViewCell {

    public let selectImg : UIButton = UIButton()
    private let bankNumLB : UILabel = UILabel()
    private let iconView : UIImageView = UIImageView()
    static func cellWithTableView(tableView : UITableView) -> BankCardManagerCell {
        let cellIdentifier = "BankCardManagerCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? BankCardManagerCell
        if cell == nil {
            cell = BankCardManagerCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.iconView.image = UIImage.init(named: "jpgcz")
        self.contentView.addSubview(self.iconView)
        self.iconView.snp.makeConstraints { (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.centerY.equalTo(self.contentView)
            make.width.height.equalTo(35)
        }
        
        self.selectImg.isUserInteractionEnabled = false
        self.selectImg.setImage(UIImage.init(named: "opertionS_white"), for: .normal)
        self.selectImg.setImage(UIImage.init(named: "optionS_red"), for: .selected)
        self.contentView.addSubview(self.selectImg)
        self.selectImg.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView).offset(-15)
            make.centerY.equalTo(self.contentView)
            make.width.height.equalTo(22.5)
        }
        
        self.bankNumLB.text = "************1234"
        self.bankNumLB.textAlignment = .center
        self.bankNumLB.font = UIFont.systemFont(ofSize: 16)
        self.contentView.addSubview(self.bankNumLB)
        self.bankNumLB.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.contentView)
            make.left.equalTo(self.iconView.snp.right).offset(5)
            make.right.equalTo(self.selectImg.snp.left).offset(-5)
        }
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.selectImg.isSelected = selected
    }
    
     public func setData(bankDict : NSDictionary) {
        let bankNumber = bankDict.object(forKey: GetBindedBankCardsAPIManager.DataKey.kAccount) as? NSString
        self.bankNumLB.text = "************" + (bankNumber?.substring(with: NSRange.init(location: (bankNumber?.length)! - 4, length: 4)))!
        let bankId = bankDict.object(forKey: GetBindedBankCardsAPIManager.DataKey.kBank_id) as? Int
        self.iconView.image = UIImage.init(named: GACacheManager.default.getBankIcon(bankId: bankId!)!)
    }
}
