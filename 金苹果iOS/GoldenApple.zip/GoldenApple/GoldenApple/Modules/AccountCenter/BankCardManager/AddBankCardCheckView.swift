//
//  AddBankCardCheckView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/12/15.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AddBankCardCheckView: UIView {
    
    public let checkBankView = HasLetfViewPickerTextField.init(title: "",showDoneButton:true)
    public let checkBankTF = UITextField()
    public let accountNameTF = HaveLeftViewTextField.init(title: "开户人名",showDoneButton:false)
    public let bankNumTF = HaveLeftViewTextField.init(title: "银行卡号",showDoneButton:false)
    public let pwdTF = HaveLeftViewTextField.init(title: "资金密码",showDoneButton:false)
    
    private let pullDownTextFieldHeight = 35
    
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("下一步", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
    
        self.checkBankView.clearButtonMode = .never
        self.checkBankView.delegate = self
        self.addSubview(self.checkBankView)
        self.checkBankView.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.checkBankTF.placeholder = "请选择一张银行卡用于校验"
        self.checkBankTF.font = UIFont.systemFont(ofSize: 16)
        self.setPullDownTextField(textField: self.checkBankTF)
        self.checkBankView.addSubview(self.checkBankTF)
        self.checkBankTF.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.checkBankView)
            make.left.equalTo(self.checkBankView).offset(self.checkBankView.titleWidth!)
            make.right.equalTo(self.checkBankView).offset(-15)
            make.height.equalTo(self.pullDownTextFieldHeight)
        }
        
        self.accountNameTF.placeholder = "请输入开户人姓名"
        self.addSubview(self.accountNameTF)
        self.accountNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.checkBankView.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.checkBankView)
        }
        
        self.bankNumTF.placeholder = "请输入校验银行卡号"
        self.bankNumTF.keyboardType = .numberPad
        self.addSubview(self.bankNumTF)
        self.bankNumTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.accountNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.checkBankView)
        }
    
        self.pwdTF.placeholder = "请输入资金密码"
        self.pwdTF.isSecureTextEntry = true
        self.addSubview(self.pwdTF)
        self.pwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.bankNumTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.checkBankView)
        }
        
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
        
    }
    
    private func setPullDownTextField(textField : UITextField) {
        textField.tintColor = .clear
        textField.isUserInteractionEnabled = false
        textField.layer.borderWidth = 1
        let leftView = UIView()
        leftView.frame = CGRect.init(x: 0, y: 0, width: 10, height: 1)
        textField.leftView = leftView
        textField.leftViewMode = .always
        let rightView = UIButton()
        rightView.setImage(UIImage.init(named: "allow_down"), for: .normal)
        rightView.backgroundColor = kGAFontGrayColor
        rightView.frame = CGRect.init(x: 0, y: 0, width: pullDownTextFieldHeight, height: pullDownTextFieldHeight)
        textField.rightView = rightView
        textField.rightViewMode = .always
        textField.layer.borderColor = (kGASerperatorLineGrayColor).cgColor
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
extension AddBankCardCheckView : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.checkBankView {
            let imageView = (self.checkBankTF.rightView as! UIButton).imageView
            self.transformImageView(imageView: imageView!, rotationAngle: Double.pi)
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.checkBankView {
            let imageView = (self.checkBankTF.rightView as! UIButton).imageView
            self.transformImageView(imageView: imageView!, rotationAngle: Double.pi * 2)
        }
    }
    
    private func transformImageView(imageView : UIImageView ,rotationAngle : Double) {
        let transform = CGAffineTransform(rotationAngle: CGFloat(rotationAngle))
        UIView.animate(withDuration: 0.3) {
            imageView.transform = transform
        }
    }
}

