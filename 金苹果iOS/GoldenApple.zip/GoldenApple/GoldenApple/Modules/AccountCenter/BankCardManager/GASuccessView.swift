//
//  GASuccessView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/27.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class GASuccessView: UIView {

    let iconView = UIImageView.init(image: UIImage.init(named: "icon_success"))
    let titleLB = UILabel()
    
    init(title : String) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        self.addSubview(self.iconView)
        self.iconView.snp.makeConstraints { (make) in
            make.centerY.equalTo(self).offset(-20)
            make.centerX.equalTo(self)
            make.width.height.equalTo(80)
        }
        
        self.titleLB.text = title
        self.titleLB.textColor = kGANavigationBackgroundColor
        self.titleLB.font = UIFont.systemFont(ofSize: 20)
        self.addSubview(self.titleLB)
        self.titleLB.snp.makeConstraints { (make) in
            make.top.equalTo(self.iconView.snp.bottom).offset(30)
            make.centerX.equalTo(self)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
