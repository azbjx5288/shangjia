//
//  LockBankCardViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/24.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class LockBankCardViewController: UIViewController {

    var myView : LockBankCardView?
    let apiManager = LockBankCardAPIManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "锁定银行卡"
        self.view = LockBankCardView()
        self.myView = self.view as? LockBankCardView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @objc func didClickBottomBtn() {
        if self.myView?.pwdTF.text == nil || (self.myView?.pwdTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "资金密码不能为空")
            return
        }
        self.apiManager.loadData()
    }
    
}

extension LockBankCardViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        GAProgressHUD.showLoading(message: "正在处理...")
        let params = NSMutableDictionary()
        params["fund_pwd"] = self.myView?.pwdTF.text
        return params
    }
    
}
extension LockBankCardViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        self.myView?.lockSuccess()
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//    }
}
