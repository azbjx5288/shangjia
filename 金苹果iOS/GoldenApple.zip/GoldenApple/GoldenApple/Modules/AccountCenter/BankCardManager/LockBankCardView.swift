//
//  LockBankCardView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/24.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class LockBankCardView: UIView {

    let pwdTF : HaveLeftViewTextField = HaveLeftViewTextField.init(title: "资金密码:",showDoneButton:false)
    
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("提交", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
      
        self.pwdTF.placeholder = "请输入资金密码"
        self.pwdTF.isSecureTextEntry = true
        self.addSubview(self.pwdTF)
        self.pwdTF.snp.makeConstraints { (make) in
            make.top.equalTo(self).offset(50)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func lockSuccess() {
        for view in self.subviews {
            view.removeFromSuperview()
        }
        let successView = GASuccessView.init(title: "锁定成功!")
        self.addSubview(successView)
        successView.snp.makeConstraints({ (make) in
            make.edges.equalTo(self)
        })
    }

}
