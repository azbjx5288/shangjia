//
//  AddBankCardView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/21.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AddBankCardView: UIView {

    public let bankNameView = HasLetfViewPickerTextField.init(title: "银行名称",showDoneButton:true)
    public let bankNameTF = UITextField()
    public let accountNameTF = HaveLeftViewTextField.init(title: "开户人名",showDoneButton:false)
    public let bankNumTF = HaveLeftViewTextField.init(title: "银行卡号",showDoneButton:false)
    public let addressTF = HasLetfViewPickerTextField.init(title: "开户地址",showDoneButton:true)
    public let provinceTF = UITextField()
    public let cityTF = UITextField()
    public let branchTF = HaveLeftViewTextField.init(title: "开户支行",showDoneButton:false)
    
    private let pullDownTextFieldHeight = 35
    
    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("下一步", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
    
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_ : )), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_ : )), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        self.bankNameView.clearButtonMode = .never
        self.bankNameView.delegate = self
        self.addSubview(self.bankNameView)
        self.bankNameView.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.bankNameTF.placeholder = "请选择银行"
        self.bankNameTF.font = UIFont.systemFont(ofSize: 16)
        self.setPullDownTextField(textField: self.bankNameTF)
        self.bankNameView.addSubview(self.bankNameTF)
        self.bankNameTF.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bankNameView)
            make.left.equalTo(self.bankNameView).offset(self.bankNameView.titleWidth!)
            make.right.equalTo(self.bankNameView).offset(-15)
            make.height.equalTo(self.pullDownTextFieldHeight)
        }
        
        self.accountNameTF.placeholder = "请输入开户人姓名"
        self.addSubview(self.accountNameTF)
        self.accountNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.bankNameView.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.bankNameView)
        }
        
        self.bankNumTF.placeholder = "由16、18或19位数字组成"
        self.bankNumTF.keyboardType = .numberPad
        self.addSubview(self.bankNumTF)
        self.bankNumTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.accountNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.bankNameView)
        }
        
        self.addressTF.clearButtonMode = .never
        self.addressTF.delegate = self
        self.addSubview(self.addressTF)
        self.addressTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.bankNumTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.bankNameView)
        }
        
        self.provinceTF.placeholder = "省份"
        self.provinceTF.font = UIFont.systemFont(ofSize: 14)
        self.setPullDownTextField(textField: self.provinceTF)
        self.addressTF.addSubview(self.provinceTF)
        self.provinceTF.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.addressTF)
            make.left.equalTo(self.addressTF).offset(self.addressTF.titleWidth!)
            make.width.equalTo(90)
            make.height.equalTo(self.pullDownTextFieldHeight)
        }
        
        self.cityTF.placeholder = "城市"
        self.cityTF.font = UIFont.systemFont(ofSize: 14)
        self.setPullDownTextField(textField: self.cityTF)
        self.addressTF.addSubview(self.cityTF)
        self.cityTF.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.addressTF)
            make.left.equalTo(self.provinceTF.snp.right).offset(10)
            make.width.equalTo(110)
            make.height.equalTo(self.provinceTF)
        }
        
        self.branchTF.placeholder = "请输入开户支行"
        self.addSubview(self.branchTF)
        self.branchTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.addressTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.bankNameView)
        }
        
        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
        
    }
    
    private func setPullDownTextField(textField : UITextField) {
        textField.tintColor = .clear
        textField.isUserInteractionEnabled = false
        textField.layer.borderWidth = 1
        let leftView = UIView()
        leftView.frame = CGRect.init(x: 0, y: 0, width: 10, height: 1)
        textField.leftView = leftView
        textField.leftViewMode = .always
        let rightView = UIButton()
        rightView.setImage(UIImage.init(named: "allow_down"), for: .normal)
        rightView.backgroundColor = kGAFontGrayColor
        rightView.frame = CGRect.init(x: 0, y: 0, width: pullDownTextFieldHeight, height: pullDownTextFieldHeight)
        textField.rightView = rightView
        textField.rightViewMode = .always
        textField.layer.borderColor = (kGASerperatorLineGrayColor).cgColor
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    //处理键盘遮挡
    @objc func keyboardWillShow(_ notification : Notification) {
        
        if !(self.branchTF.isFirstResponder) {
            return
        }
        
        let keyboardFrame = notification.userInfo!["UIKeyboardFrameEndUserInfoKey"] as? CGRect
        let keyBoardHeight = keyboardFrame?.size.height  //键盘高度
        let duration = notification.userInfo!["UIKeyboardAnimationDurationUserInfoKey"] //动画时长
        
        self.screenY = nil
        if self.branchTF.isFirstResponder {
            self.getViewScreenY(view: self.branchTF)
        }
        
        let textFieldMaxY = self.screenY!   //pwdTF相对屏幕的maxY
        let screenH = UIScreen.main.bounds.size.height
        let offset = keyBoardHeight! - (screenH - textFieldMaxY)   //myView需要移动的y值
        
        if offset > 0.0 {
            UIView.animate(withDuration: duration as! TimeInterval) {
                self.transform = CGAffineTransform(translationX: 0, y: -offset);//xy移动距离
            }
        }
    }
    
    
    /// 获取控件相对屏幕的Y值
    var screenY : CGFloat?
    private func getViewScreenY(view : UIView?){
        if screenY == nil {
            view?.layoutIfNeeded()
            screenY = view?.frame.maxY
            self.getViewScreenY(view: view?.superview!)
        } else {
            if view != nil {
                view?.layoutIfNeeded()
                screenY = screenY! + (view?.frame.origin.y)!
                self.getViewScreenY(view: view?.superview)
            }
        }
    }
    
    
    @objc func keyboardWillHide(_ notification : Notification) {
        if !(self.branchTF.isFirstResponder) {
            return
        }
        let duration = notification.userInfo!["UIKeyboardAnimationDurationUserInfoKey"]
        UIView.animate(withDuration: duration as! TimeInterval) {
            self.transform = CGAffineTransform(translationX: 0, y: 0);//xy移动距离
        }
    }
    
}

extension AddBankCardView : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.bankNameView {
            let imageView = (self.bankNameTF.rightView as! UIButton).imageView
            self.transformImageView(imageView: imageView!, rotationAngle: Double.pi)
        } else if textField == self.addressTF {
            let imageView1 = (self.provinceTF.rightView as! UIButton).imageView
            let imageView2 = (self.cityTF.rightView as! UIButton).imageView
            self.transformImageView(imageView: imageView1!, rotationAngle: Double.pi)
            self.transformImageView(imageView: imageView2!, rotationAngle: Double.pi)
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.bankNameView {
            let imageView = (self.bankNameTF.rightView as! UIButton).imageView
            self.transformImageView(imageView: imageView!, rotationAngle: Double.pi * 2)
        } else if textField == self.addressTF {
            let imageView1 = (self.provinceTF.rightView as! UIButton).imageView
            let imageView2 = (self.cityTF.rightView as! UIButton).imageView
            self.transformImageView(imageView: imageView1!, rotationAngle: Double.pi * 2)
            self.transformImageView(imageView: imageView2!, rotationAngle: Double.pi * 2)
        }
    }
    
    private func transformImageView(imageView : UIImageView ,rotationAngle : Double) {
        let transform = CGAffineTransform(rotationAngle: CGFloat(rotationAngle))
        UIView.animate(withDuration: 0.3) {
            imageView.transform = transform
        }
    }
}

