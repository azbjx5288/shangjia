//
//  AddBankCardViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/21.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit


class AddBankCardViewController: UIViewController {

    var myView : AddBankCardView?
    let getBanksAPIManager = GetAllBanksAPIManager()
    var allBankList : [NSDictionary]?
//    let addApiManager = AddBankCardAPIManager()
    var checkToken : String?
    
    var citysList : [NSDictionary] = {
        let path = Bundle.main.path(forResource: "city", ofType: "json")
        let data = NSData.init(contentsOfFile: path!)
        let citys = try? JSONSerialization.jsonObject(with: data! as Data, options: JSONSerialization.ReadingOptions.mutableContainers)
        return (citys as? [NSDictionary])!
    }()
    var subCityList : [NSDictionary]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "添加银行卡"
        
        self.subCityList = self.citysList[0].value(forKey: "cities") as? [NSDictionary]
            
        self.myView = AddBankCardView()
        self.view.addSubview(self.myView!)
        self.myView?.snp.makeConstraints({ (make) in
            make.edges.equalTo(self.view)
        })
        
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickSubmit(_ :)), for: .touchUpInside)
        self.myView?.bankNameView.pickerView.delegate = self
        self.myView?.bankNameView.pickerView.dataSource = self
        
        self.myView?.bankNameView.setDoneAction(target: self, action: #selector(didClickDone(_:)))

        self.myView?.addressTF.pickerView.delegate = self
        self.myView?.addressTF.pickerView.dataSource = self
        
        self.myView?.addressTF.setDoneAction(target: self, action: #selector(didClickDone1(_:)))

        self.getBanksAPIManager.paramSource = self
        self.getBanksAPIManager.delegate = self
//        self.addApiManager.delegate = self
//        self.addApiManager.paramSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.getBanksAPIManager.loadData()
        
    }

    @objc func didClickSubmit(_ sender : UIButton) {
        if self.myView?.bankNameTF.text == nil || (self.myView?.bankNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "银行名不能为空")
            return
        }
        if self.myView?.accountNameTF.text == nil || (self.myView?.accountNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)!  {
            GAProgressHUD.showWarning(message: "开户人名不能为空")
            return
        }
        if self.myView?.bankNumTF.text == nil || (self.myView?.bankNumTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "银行卡号不能为空")
            return
        }
        
        let bankNumLength = (self.myView?.bankNumTF.text as NSString?)?.length
        if bankNumLength != 16 && bankNumLength != 18 && bankNumLength != 19 {
            GAProgressHUD.showWarning(message: "银行卡号为16、18或19位数字组成")
            return
        }
        if self.myView?.provinceTF.text == nil || (self.myView?.provinceTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "开户地址不能为空")
            return
        }
        if self.myView?.branchTF.text == nil || (self.myView?.branchTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "开户支行不能为空")
            return
        }

        self.pushAddViewController1()
    }
    
    public func pushAddViewController1() {
        let addVC1 = AddBankCardViewController1()
        let bankIndex = self.myView?.bankNameView.pickerView.selectedRow(inComponent: 0)
        let bankDict = self.allBankList?[bankIndex!]
        addVC1.bankDict = bankDict
        let provinceIndex = self.myView?.addressTF.pickerView.selectedRow(inComponent: 0)
        let provinceDict = self.citysList[provinceIndex!]
        addVC1.provinceDict = provinceDict
        let cityIndex = self.myView?.addressTF.pickerView.selectedRow(inComponent: 1)
        let cityDict = self.subCityList![cityIndex!]
        addVC1.cityDict = cityDict
        addVC1.checkToken = self.checkToken
        addVC1.branch = self.myView?.branchTF.text
        addVC1.accountName = self.myView?.accountNameTF.text
        addVC1.bankCardNum = self.myView?.bankNumTF.text
        self.navigationController?.pushViewController(addVC1, animated: true)
    }
        
    @objc func didClickDone(_ sender : UIBarButtonItem) {
        self.myView?.bankNameView.endEditing(true)
        let index = self.myView?.bankNameView.pickerView.selectedRow(inComponent: 0)
        self.myView?.bankNameTF.text = self.allBankList?[index!].object(forKey: "name") as? String
    }
    @objc func didClickDone1(_ sender : UIBarButtonItem) {
        self.myView?.addressTF.endEditing(true)
        let index = self.myView?.addressTF.pickerView.selectedRow(inComponent: 0)
        self.myView?.provinceTF.text = self.citysList[index!].value(forKey: "areaName") as? String
        let subIndex = self.myView?.addressTF.pickerView.selectedRow(inComponent: 1)
        self.myView?.cityTF.text = self.subCityList![subIndex!].value(forKey: "areaName") as? String
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

}

extension AddBankCardViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "正在加载...")
        return NSDictionary()
    }
    
}
extension AddBankCardViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
       GAProgressHUD.hidHUD()
        guard let bankDict = manager.fetchData(self.getBanksAPIManager) as? NSDictionary  else {return}
        let tempArray = NSMutableArray()
        for key in bankDict.allKeys {
            let dict = ["id" : key, "name" : bankDict[key]]
            tempArray.add(dict)
        }
        self.allBankList = tempArray.copy() as? [NSDictionary]
        
    }
    
}

extension AddBankCardViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if pickerView == self.myView?.bankNameView.pickerView {
            return 1
        } else if pickerView == self.myView?.addressTF.pickerView {
            return 2
        }
        return 0
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == self.myView?.bankNameView.pickerView {
            guard let count = self.allBankList?.count else {return 0}
            return count
        } else if pickerView == self.myView?.addressTF.pickerView {
            if component == 0 {
                return self.citysList.count
            } else if component == 1 {
                return (self.subCityList?.count)!
            }
        }
        return 0
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == self.myView?.bankNameView.pickerView {
            return self.allBankList?[row].object(forKey: "name") as? String
        } else if pickerView == self.myView?.addressTF.pickerView {
            if component == 0 {
                return self.citysList[row].value(forKey: "areaName") as? String
            } else if component == 1 {
                return self.subCityList?[row].value(forKey: "areaName") as? String
            }
        }
        return ""
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == self.myView?.addressTF.pickerView {
            if component == 0 {
                self.subCityList = self.citysList[row].value(forKey: "cities") as? [NSDictionary]
                pickerView.reloadComponent(1)
            }
        }
    }
}
