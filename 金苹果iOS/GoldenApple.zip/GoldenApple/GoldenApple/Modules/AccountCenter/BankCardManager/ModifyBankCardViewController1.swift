//
//  ModifyBankCardViewController1.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/27.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ModifyBankCardViewController1: UIViewController {

    var myView : ModifyBankCardView1?
    
    var checkToken : String?
    
    var cardId : Int?
    
    var citysList : [NSDictionary] = {
        let path = Bundle.main.path(forResource: "city", ofType: "json")
        let data = NSData.init(contentsOfFile: path!)
        let citys = try? JSONSerialization.jsonObject(with: data! as Data, options: JSONSerialization.ReadingOptions.mutableContainers)
        return (citys as? [NSDictionary])!
    }()
    
    var subCityList : [NSDictionary]?
    
    var allBankList : [NSDictionary]?
    
    let getBanksAPIManager = GetAllBanksAPIManager()
    let modifyApiManager = ModifyBankCardAPIManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "修改银行卡"
        self.navigationItem.setNavigationBackTarget(self, action: #selector(didClickLeftItem(_ :)))
  
        self.subCityList = self.citysList[0].value(forKey: "cities") as? [NSDictionary]
        
        self.myView = ModifyBankCardView1()
        self.view.addSubview(self.myView!)
        self.myView?.snp.makeConstraints({ (make) in
            make.edges.equalTo(self.view)
        })
       
        
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickSubmit(_ :)), for: .touchUpInside)
        self.myView?.bankNameView.pickerView.delegate = self
        self.myView?.bankNameView.pickerView.dataSource = self
        
        self.myView?.bankNameView.setDoneAction(target: self, action: #selector(didClickDone(_:)))
        
        self.myView?.addressTF.pickerView.delegate = self
        self.myView?.addressTF.pickerView.dataSource = self
        
        self.myView?.addressTF.setDoneAction(target: self, action: #selector(didClickDone1(_:)))
        
        self.getBanksAPIManager.paramSource = self
        self.getBanksAPIManager.delegate = self
        self.modifyApiManager.paramSource = self
        self.modifyApiManager.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.getBanksAPIManager.loadData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func didClickLeftItem(_ sender : UIButton) {
        var managerVC : UIViewController?
        for vc in (self.navigationController?.childViewControllers)! {
            if vc.isKind(of: BankCardManagerViewController.self) {
                managerVC = vc
            }
        }
        self.navigationController?.popToViewController(managerVC!, animated: true)
    }
    
    @objc func didClickSubmit(_ sender : UIButton) {
        if self.myView?.bankNameTF.text == nil || (self.myView?.bankNameTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "银行名不能为空")
            return
        }
        if self.myView?.accountNameTF.text == nil || (self.myView?.accountNameTF.text?.isEmpty)!  {
            GAProgressHUD.showWarning(message: "开户人名不能为空")
            return
        }
        if self.myView?.bankNumTF.text == nil || (self.myView?.bankNumTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "银行卡号不能为空")
            return
        }
        let bankNumLength = (self.myView?.bankNumTF.text as NSString?)?.length
        if bankNumLength != 16 && bankNumLength != 18 && bankNumLength != 19 {
            GAProgressHUD.showWarning(message: "银行卡号为16、18或19位数字组成")
            return
        }
        if self.myView?.bankNumTF.text != self.myView?.verifyBankNumTF.text {
            GAProgressHUD.showWarning(message: "两次输入的银行卡号不一致")
            return
        }
        if self.myView?.provinceTF.text == nil || (self.myView?.provinceTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "开户地址不能为空")
            return
        }
        if self.myView?.branchTF.text == nil || (self.myView?.branchTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "开户支行不能为空")
            return
        }

        self.modifyApiManager.loadData()
    }
    
    @objc func didClickDone(_ sender : UIBarButtonItem) {
        self.myView?.bankNameView.endEditing(true)
        let index = self.myView?.bankNameView.pickerView.selectedRow(inComponent: 0)
        self.myView?.bankNameTF.text = self.allBankList?[index!].object(forKey: "name") as? String
    }
    @objc func didClickDone1(_ sender : UIBarButtonItem) {
        self.myView?.addressTF.endEditing(true)
        let index = self.myView?.addressTF.pickerView.selectedRow(inComponent: 0)
        self.myView?.provinceTF.text = self.citysList[index!].value(forKey: "areaName") as? String
        let subIndex = self.myView?.addressTF.pickerView.selectedRow(inComponent: 1)
        self.myView?.cityTF.text = self.subCityList![subIndex!].value(forKey: "areaName") as? String
    }
    
}

extension ModifyBankCardViewController1:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        if manager == self.getBanksAPIManager {
            GAProgressHUD.showLoading(message: "正在加载...")
            return NSDictionary()
        }  else if manager == self.modifyApiManager {
            let params = NSMutableDictionary()
            let bankIndex = self.myView?.bankNameView.pickerView.selectedRow(inComponent: 0)
            let bankId = Int((self.allBankList?[bankIndex!].value(forKey: "id") as? String)!)
            let provinceIndex = self.myView?.addressTF.pickerView.selectedRow(inComponent: 0)
            let provinceId = self.citysList[provinceIndex!].value(forKey: "areaId") as? Int
            let cityIndex = self.myView?.addressTF.pickerView.selectedRow(inComponent: 1)
            let cityId = self.subCityList![cityIndex!].value(forKey: "areaId") as? Int
            
            params["card_id"] = self.cardId
            params["bank_id"] = bankId
            params["province_id"] = provinceId
            params["city_id"] = cityId
            params["account_name"] = self.myView?.accountNameTF.text
            params["account"] = self.myView?.bankNumTF.text
            params["branch"] = self.myView?.branchTF.text
            params["checked_token"] = self.checkToken
            
            return params
        }
        
        
        return NSDictionary()
    }
    
}
extension ModifyBankCardViewController1:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        if manager == self.getBanksAPIManager {  // 获取所有银行卡成功
            guard let bankDict = manager.fetchData(self.getBanksAPIManager) as? NSDictionary  else {return}
            let tempArray = NSMutableArray()
            for key in bankDict.allKeys {
                let dict = ["id" : key, "name" : bankDict[key]]
                tempArray.add(dict)
            }
            self.allBankList = tempArray.copy() as? [NSDictionary]
        } else if manager == self.modifyApiManager { // 银行卡修改成功
            self.myView?.modifySuccess()
        }
        
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.getBanksAPIManager.callAPIDidFailed(manager)
//    }
}

extension ModifyBankCardViewController1: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if pickerView == self.myView?.bankNameView.pickerView {
            return 1
        } else if pickerView == self.myView?.addressTF.pickerView {
            return 2
        }
        return 0
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == self.myView?.bankNameView.pickerView {
            guard let count = self.allBankList?.count else {return 0}
            return count
        } else if pickerView == self.myView?.addressTF.pickerView {
            if component == 0 {
                return self.citysList.count
            } else if component == 1 {
                return (self.subCityList?.count)!
            }
        }
        return 0
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == self.myView?.bankNameView.pickerView {
            return self.allBankList?[row].object(forKey: "name") as? String
        } else if pickerView == self.myView?.addressTF.pickerView {
            if component == 0 {
                return self.citysList[row].value(forKey: "areaName") as? String
            } else if component == 1 {
                return self.subCityList?[row].value(forKey: "areaName") as? String
            }
        }
        return ""
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == self.myView?.addressTF.pickerView {
            if component == 0 {
                self.subCityList = self.citysList[row].value(forKey: "cities") as? [NSDictionary]
                pickerView.reloadComponent(1)
            }
        }
    }
}
