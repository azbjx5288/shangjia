//
//  BankCardManagerViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/21.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit


class BankCardManagerViewController: UIViewController {

    var myView : BankCardManagerView?
    let addButton = UIButton.init(type: .custom)
    var bankCards : [NSDictionary]?
    let apiManager = GetBindedBankCardsAPIManager()
    var isLocked : Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNaviBar()
        
        self.view = BankCardManagerView()
        self.myView = self.view as? BankCardManagerView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
        
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(enterForeground), name: NSNotification.Name.UIApplicationWillEnterForeground, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(enterBackground), name: NSNotification.Name.UIApplicationDidEnterBackground, object: nil)
    }
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func enterForeground() {
        self.apiManager.loadData()
    }
    
    @objc func enterBackground() {
        self.myView?.timer.invalidate()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.bankCards = nil
        self.apiManager.loadData()
    }
    override func viewDidDisappear(_ animated: Bool) {
        self.myView?.timer.invalidate()
    }
    
    private func setNaviBar() {
        
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationItem.title = "银行卡管理"
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        
        self.addButton.setImage(UIImage.init(named: "blus_button"), for: .normal)
        self.addButton.frame = CGRect.init(x: 0, y: 0, width: 30, height: 30)
        self.addButton.addTarget(self, action: #selector(didClickAddBtn(_ :)), for: .touchUpInside)
        let rightItem : UIBarButtonItem = UIBarButtonItem.init(customView: self.addButton)
        self.navigationItem.rightBarButtonItem = rightItem;
        self.addButton.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func didClickBottomBtn() {
        self.navigationController?.pushViewController(LockBankCardViewController(), animated: true)
    }
    
    @objc func didClickAddBtn(_ sender : UIButton) {
        if self.bankCards != nil && (self.bankCards?.count)! > 0 {
            let checkVC = AddBankCardCheckViewController()
            checkVC.bindedBanks = self.bankCards
            self.navigationController?.pushViewController(checkVC, animated: true)
        } else {
            let addVC = AddBankCardViewController()
            self.navigationController?.pushViewController(addVC, animated: true)
        }
    }
    
    @objc func didClickDeleteBtn(_ sender : UIButton) {
        let deleteVC = DeleteBankCardViewController()
        let indexPath = self.myView?.tableView.indexPathForSelectedRow
        deleteVC.bankDict = self.bankCards?[(indexPath?.row)!]
        self.navigationController?.pushViewController(deleteVC, animated: true)
    }
    @objc func didClickEditBtn(_ sender : UIButton) {
        let modifyVC = ModifyBankCardViewController()
        let indexPath = self.myView?.tableView.indexPathForSelectedRow
        modifyVC.bankDict = self.bankCards?[(indexPath?.row)!]
        self.navigationController?.pushViewController(modifyVC, animated: true)
    }
    
}

extension BankCardManagerViewController: UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let count = self.bankCards?.count else {
            return 0
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = BankCardManagerCell.cellWithTableView(tableView: tableView)
        cell.setData(bankDict: self.bankCards![indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        guard let count = self.bankCards?.count else {
            return nil
        }
    
        if count > 0 && !self.isLocked {
            let footer = BankCardManagerFooterView()
            footer.deleteBtn.addTarget(self, action: #selector(didClickDeleteBtn(_ :)), for: .touchUpInside)
            footer.editBtn.addTarget(self, action: #selector(didClickEditBtn(_ :)), for: .touchUpInside)
            return footer
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 50
    }
}

extension BankCardManagerViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
    
        GAProgressHUD.showLoading(message: "正在加载...")
        return NSDictionary()
    }
    
}
extension BankCardManagerViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        guard let dataArray = manager.fetchData(self.apiManager) as? [NSDictionary]  else {return}
        self.bankCards = dataArray
        var lockTime : String?
        if dataArray.count > 0 {
            self.isLocked = self.bankCards![0].object(forKey: GetBindedBankCardsAPIManager.DataKey.kLocked) as! Bool
            lockTime = self.bankCards![0].object(forKey: GetBindedBankCardsAPIManager.DataKey.kIntended_lock_at) as? String
            self.myView?.tableView.reloadData()
            self.myView?.tableView.selectRow(at: NSIndexPath.init(row: 0, section: 0) as IndexPath, animated: false, scrollPosition: UITableViewScrollPosition.top)
        } else {
            self.isLocked = false
            self.myView?.tableView.reloadData()
        }
        
        if dataArray.count >= 4 || self.isLocked {
            self.addButton.isHidden = true
        } else {
            self.addButton.isHidden = false
        }
    
        self.myView?.setLockStatus(isLocked: self.isLocked,lockTime: lockTime)
    }

}


