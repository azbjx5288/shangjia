//
//  ModifyBankCardViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/27.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ModifyBankCardViewController: UIViewController {

    var bankDict : NSDictionary?
    let checkApiManager = CheckBankCardAPIManager()
    var myView : ModifyBankCardView?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "修改银行卡"
        self.view = ModifyBankCardView()
        self.myView = self.view as? ModifyBankCardView
        
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
        let bankName = self.bankDict?.value(forKey: GetBindedBankCardsAPIManager.DataKey.kName) as? String
        let bankNumber = self.bankDict?.object(forKey: GetBindedBankCardsAPIManager.DataKey.kAccount) as? NSString
        
        self.myView?.cardLB.text = bankName! + "  ************" + (bankNumber?.substring(with: NSRange.init(location: (bankNumber?.length)! - 4, length: 4)))!
        
        self.checkApiManager.delegate = self
        self.checkApiManager.paramSource = self
  
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func didClickBottomBtn() {
        if self.myView?.accountNameTF.text == nil || (self.myView?.accountNameTF.text?.isEmpty)!  {
            GAProgressHUD.showWarning(message: "开户人名不能为空")
            return
        }
        if self.myView?.bankNumTF.text == nil || (self.myView?.bankNumTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "银行卡号不能为空")
            return
        }
        
        let bankNumLength = (self.myView?.bankNumTF.text as NSString?)?.length
        if bankNumLength != 16 && bankNumLength != 18 && bankNumLength != 19 {
            GAProgressHUD.showWarning(message: "银行卡号为16、18或19位数字组成")
            return
        }
        
        if self.myView?.pwdTF.text == nil || (self.myView?.pwdTF.text?.isEmpty)! {
            GAProgressHUD.showWarning(message: "资金密码不能为空")
            return
        }
        self.checkApiManager.loadData()
    }
}

extension ModifyBankCardViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        let cardId = self.bankDict?.value(forKey: GetBindedBankCardsAPIManager.DataKey.kId) as? Int
        let params = NSMutableDictionary()
        params["card_id"] = cardId
        
        GAProgressHUD.showLoading(message: "正在校验银行卡信息...")
        params["fund_pwd"] = self.myView?.pwdTF.text
        params["account_name"] = self.myView?.accountNameTF.text
        params["account"] = self.myView?.bankNumTF.text
        params["type"] = 2
        return params

    }
    
}
extension ModifyBankCardViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        //验证成功
        guard let tokenDict = manager.fetchData(self.checkApiManager) as? NSDictionary  else {return}
        let checkToken = tokenDict.value(forKey: CheckBankCardAPIManager.DataKey.kToken) as? String
        let modifyVC1 = ModifyBankCardViewController1()
        let cardId = self.bankDict?.value(forKey: GetBindedBankCardsAPIManager.DataKey.kId) as? Int
        modifyVC1.cardId = cardId
        modifyVC1.checkToken = checkToken
        self.navigationController?.pushViewController(modifyVC1, animated: true)
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.checkApiManager.callAPIDidFailed(manager)
//    }
}
