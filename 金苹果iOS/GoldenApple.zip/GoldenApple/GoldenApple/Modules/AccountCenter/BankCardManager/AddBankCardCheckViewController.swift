//
//  AddBankCardCheckViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/12/15.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AddBankCardCheckViewController: UIViewController {

    var myView : AddBankCardCheckView?
    
    var bindedBanks : [NSDictionary]?
    let checkApiManager = CheckBankCardAPIManager()
    var checkToken : String?
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "校验银行卡"
        
        self.myView = AddBankCardCheckView()
        self.view.addSubview(self.myView!)
        self.myView?.snp.makeConstraints({ (make) in
            make.edges.equalTo(self.view)
        })
        
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickSubmit(_ :)), for: .touchUpInside)
        self.myView?.checkBankView.pickerView.delegate = self
        self.myView?.checkBankView.pickerView.dataSource = self
        
        self.myView?.checkBankView.setDoneAction(target: self, action: #selector(didClickDone(_:)))
        
        self.checkApiManager.delegate = self
        self.checkApiManager.paramSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func didClickSubmit(_ sender : UIButton) {
        if self.myView?.checkBankTF.text == nil || (self.myView?.checkBankTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "校验银行卡不能为空")
            return
        }
        if self.myView?.accountNameTF.text == nil || (self.myView?.accountNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)!  {
            GAProgressHUD.showWarning(message: "开户人名不能为空")
            return
        }
        if self.myView?.bankNumTF.text == nil || (self.myView?.bankNumTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! {
            GAProgressHUD.showWarning(message: "银行卡号不能为空")
            return
        }
        
        let bankNumLength = (self.myView?.bankNumTF.text as NSString?)?.length
        if bankNumLength != 16 && bankNumLength != 18 && bankNumLength != 19 {
            GAProgressHUD.showWarning(message: "银行卡号为16、18或19位数字组成")
            return
        }

        if self.myView?.pwdTF.text == nil || (self.myView?.pwdTF.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)! && !(self.myView?.pwdTF.isHidden)! {
            GAProgressHUD.showWarning(message: "资金密码不能为空")
            return
        }
        
        self.checkApiManager.loadData()
    }
    
    @objc func didClickDone(_ sender : UIBarButtonItem) {
        self.myView?.checkBankView.endEditing(true)
        let index = self.myView?.checkBankView.pickerView.selectedRow(inComponent: 0)
        let bankNumber = self.bindedBanks?[index!].object(forKey: GetBindedBankCardsAPIManager.DataKey.kAccount) as? NSString
        self.myView?.checkBankTF.text = "************" + (bankNumber?.substring(with: NSRange.init(location: (bankNumber?.length)! - 4, length: 4)))!
        
    }
}

extension AddBankCardCheckViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "正在校验银行卡信息...")
        self.checkToken = nil
        let index = self.myView?.checkBankView.pickerView.selectedRow(inComponent: 0)
        let params = NSMutableDictionary()
        let cardId = self.bindedBanks![index!].object(forKey: GetBindedBankCardsAPIManager.DataKey.kId)
        let name = self.myView?.accountNameTF.text
        let account = self.myView?.bankNumTF.text
        params["card_id"] = cardId
        params["fund_pwd"] = self.myView?.pwdTF.text
        params["account_name"] = name
        params["account"] = account
        params["type"] = 1
        return params
    }
    
}

extension AddBankCardCheckViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        guard let tokenDict = manager.fetchData(self.checkApiManager) as? NSDictionary  else {return}
        self.checkToken = tokenDict.value(forKey: CheckBankCardAPIManager.DataKey.kToken) as? String
        let addBankCardVC = AddBankCardViewController()
        addBankCardVC.checkToken = self.checkToken
        self.navigationController?.pushViewController(addBankCardVC, animated: true)
    }
}

extension AddBankCardCheckViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        guard let count = self.bindedBanks?.count else {return 0}
        return count
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let bankNumber = self.bindedBanks?[row].object(forKey: GetBindedBankCardsAPIManager.DataKey.kAccount) as? NSString
        return "************" + (bankNumber?.substring(with: NSRange.init(location: (bankNumber?.length)! - 4, length: 4)))!
    }
}
