//
//  AddBankCardView1.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/29.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class AddBankCardView1: UIView {
    public let bankNameTF = HaveLeftViewTextField.init(title: "开户银行",showDoneButton:true)
    public let addressTF = HaveLeftViewTextField.init(title: "银行区域",showDoneButton:true)
    public let branchTF = HaveLeftViewTextField.init(title: "开户支行",showDoneButton:false)
    public let accountNameTF = HaveLeftViewTextField.init(title: "开户人名",showDoneButton:false)
    public let bankNumTF = HaveLeftViewTextField.init(title: "银行卡号",showDoneButton:false)

    public lazy var bottomBtn : UIButton = {
        ()-> UIButton in
        let temp = UIButton()
        temp.backgroundColor = kGANavigationBackgroundColor
        temp.setTitle("确认提交", for: .normal)
        temp.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        temp.setTitleColor(.white, for: .normal)
        temp.setTitleColor(.gray, for: .highlighted)
        return temp
    }()
    
    private lazy var bottomView : UIView = {
        ()-> UIView in
        let temp = UIView()
        return temp
    }()
    
    init() {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        self.bankNameTF.isUserInteractionEnabled = false
        self.addSubview(self.bankNameTF)
        self.bankNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.addressTF.isUserInteractionEnabled = false
        self.addSubview(self.addressTF)
        self.addressTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.bankNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.bankNameTF)
        }
    
        self.branchTF.isUserInteractionEnabled = false
        self.addSubview(self.branchTF)
        self.branchTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.addressTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.addressTF)
        }
        
        self.accountNameTF.isUserInteractionEnabled = false
        self.addSubview(self.accountNameTF)
        self.accountNameTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.branchTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.branchTF)
        }
        
        self.bankNumTF.isUserInteractionEnabled = false
        self.addSubview(self.bankNumTF)
        self.bankNumTF.snp.makeConstraints { (make) in
            make.top.equalTo(self.accountNameTF.snp.bottom)
            make.left.right.equalTo(self)
            make.height.equalTo(self.accountNameTF)
        }
        

        self.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = kGASerperatorLineGrayColor
        self.bottomView.addSubview(bottomLine)
        bottomLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.bottomView.addSubview(self.bottomBtn)
        self.bottomBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
        
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func addSuccess() {
        for view in self.subviews {
            view.removeFromSuperview()
        }
        let successView = GASuccessView.init(title: "添加成功!")
        self.addSubview(successView)
        successView.snp.makeConstraints({ (make) in
            make.edges.equalTo(self)
        })
        
        let noticeLB = UILabel()
        noticeLB.text = "新的银行卡将在2小时后可以发起\"平台提现\""
        noticeLB.numberOfLines = 0
        noticeLB.textAlignment = .center
        noticeLB.font = UIFont.systemFont(ofSize: 14)
        noticeLB.textColor = kGAFontGrayColor
        successView.addSubview(noticeLB)
        noticeLB.snp.makeConstraints { (make) in
            make.top.equalTo(successView.titleLB.snp.bottom).offset(30)
            make.left.equalTo(successView).offset(15)
            make.right.equalTo(successView).offset(-15)
        }
    }
}
