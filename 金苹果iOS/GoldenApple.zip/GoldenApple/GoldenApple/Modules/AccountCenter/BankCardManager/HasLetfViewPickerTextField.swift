//
//  HasLeftViewPickerTextField.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/22.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class HasLetfViewPickerTextField: HaveLeftViewTextField {

    public let pickerView = UIPickerView()

    override init(title: String,showDoneButton:Bool) {
        super.init(title: title,showDoneButton:showDoneButton)
        self.tintColor = .clear
        self.inputView = self.pickerView;
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // 禁止粘贴、选择等事件
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return false
    }

}

