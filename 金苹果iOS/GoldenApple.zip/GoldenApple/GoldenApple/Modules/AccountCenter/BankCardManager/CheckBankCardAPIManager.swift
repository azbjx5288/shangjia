//
//  CheckBankCardAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/24.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class CheckBankCardAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kToken = "checked_token"
    }
    
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension CheckBankCardAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=User&action=checkBankCard"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .post
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}

extension CheckBankCardAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let token = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        return token
    }
}

