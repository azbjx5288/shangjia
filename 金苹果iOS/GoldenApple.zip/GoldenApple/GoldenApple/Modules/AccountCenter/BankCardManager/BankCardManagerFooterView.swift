//
//  BankCardManagerFooterView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/21.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BankCardManagerFooterView: UIView {

    let editBtn : UIButton = UIButton()
    let deleteBtn : UIButton = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        let canceColor = kGANavigationBackgroundColor
        self.deleteBtn.setTitle("删除", for: .normal)
        self.deleteBtn.setTitleColor(canceColor, for: .normal)
        self.deleteBtn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        self.deleteBtn.layer.borderWidth = 1
        self.deleteBtn.layer.borderColor = canceColor.cgColor
        self.deleteBtn.layer.cornerRadius = 3
        self.addSubview(self.deleteBtn)
        self.deleteBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self)
            make.right.equalTo(self).offset(-15)
            make.width.equalTo(50)
            make.height.equalTo(30)
        }
        
        let editColor = kGAFontGrayColor
        self.editBtn.setTitle("修改", for: .normal)
        self.editBtn.setTitleColor(editColor, for: .normal)
        self.editBtn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        self.editBtn.layer.borderWidth = 1
        self.editBtn.layer.borderColor = editColor.cgColor
        self.editBtn.layer.cornerRadius = 3
        self.addSubview(self.editBtn)
        self.editBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self)
            make.right.equalTo(self.deleteBtn.snp.left).offset(-15)
            make.width.equalTo(self.deleteBtn)
            make.height.equalTo(self.deleteBtn)
        }
        
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
