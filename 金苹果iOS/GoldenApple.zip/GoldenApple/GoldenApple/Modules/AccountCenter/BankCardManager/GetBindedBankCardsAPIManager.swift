//
//  BankCardManagerAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/21.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class GetBindedBankCardsAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kName = "bank"
        static let kAccountName = "account_name"
        static let kId = "id"
        static let kBank_id = "bank_id"
        static let kAccount = "account"
        static let kLocked = "locked"
        static let kIntended_lock_at = "intended_lock_at" //预期锁卡时间
        static let kIntended_withdrawal_at = "intended_withdrawal_at"  //预期提现时间
    }
    
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension GetBindedBankCardsAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=User&action=getBankCardList"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}


extension GetBindedBankCardsAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let dataArray = data.object(forKey: "data") as? NSArray else { return NSArray() }
        return dataArray
    }
}
