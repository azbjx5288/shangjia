//
//  ChangePrizeAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/9/4.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import Foundation

class ChangePrizeAPIManager: GAAPIBaseManager {
    struct DataKey {
    }
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension ChangePrizeAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=User&action=ChangePrizeGroup"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .post
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
    
}


extension ChangePrizeAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        return resultDict
    }
}

