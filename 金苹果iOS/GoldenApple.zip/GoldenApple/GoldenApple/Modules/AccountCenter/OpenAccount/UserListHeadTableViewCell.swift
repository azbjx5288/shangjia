//
//  UserListHeadTableViewCell.swift
//  GoldenApple
//
//  Created by User on 2018/8/29.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class UserListHeadTableViewCell: UIView {

    lazy var label_name = {() -> UILabel in
        let view = UILabel()
        view.text = "用户名"
        return view
    }()
    
    lazy var label_num = {() -> UILabel in
        let view = UILabel()
        view.text = "下级人数"
        return view
    }()
    
    lazy var label_time = {() -> UILabel in
        let view = UILabel()
        view.text = "注册时间"
        return view
    }()
    
    lazy var label_yue = {() -> UILabel in
        let view = UILabel()
        view.text = "团队余额"
        return view
    }()
    
    lazy var container = {() -> TGLinearLayout in
        let view = TGLinearLayout(.horz)
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        container.tg_width.equal(.fill)
        container.tg_height.equal(48)
        container.tg_rightPadding = 40
        container.tg_boundBorderline = TGBorderline(color: kGASerperatorLineGrayColor)
    
        container.addSubview(label_name)
        container.addSubview(label_num)
        container.addSubview(label_time)
        container.addSubview(label_yue)
        
        label_name.tg_width.equal(.average)
        label_name.tg_height.equal(.fill)
        label_name.textAlignment = .center
        
        label_num.tg_width.equal(.average)
        label_num.tg_height.equal(.fill)
        label_num.textAlignment = .center
        
        label_time.tg_width.equal(.average)
        label_time.tg_height.equal(.fill)
        label_time.textAlignment = .center
        
        label_yue.tg_width.equal(.average)
        label_yue.tg_height.equal(.fill)
        label_yue.textAlignment = .center
        self.addSubview(container)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
