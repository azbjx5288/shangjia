//
//  ModifyAwardViewController.swift
//  GoldenApple
//
//  Created by User on 2018/8/30.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import RxSwift
import RxCocoa

class ModifyAwardViewController: UIViewController {

    let disposeBag = DisposeBag()
    lazy var myView = {() -> ModifyAwardView in
        let view = ModifyAwardView(frame: self.view.frame)
        return view
    }()
    
    let apiManager = GetChildInfoAPIManager()
    let changePrizeAPIManager =  ChangePrizeAPIManager()
    
    var data: NSDictionary?
    var agent_prize_set_quota: String?
    var userSetQuota: NSDictionary?
    var prize: NSMutableDictionary = [:]
    var currentUserPrizeGroup: String?
    var iMaxPrizeGroup: String?
    var parentSingle: Double?
    var parentMulti: Double?
    var parentAG: Double?
    var parentGA: Double?
    
    var userSingle: Double?
    var userMulti: Double?
    var userAG: Double?
    var userGA: Double?
    var id: Int
    
    init(_ id: Int) {
        self.id = id
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "调整奖金组"
        self.view.addSubview(myView)
        self.apiManager.paramSource = self
        self.apiManager.delegate = self
        self.changePrizeAPIManager.delegate = self
        self.changePrizeAPIManager.paramSource = self
        self.apiManager.loadData()
        
        self.myView.btn_save.addTarget(self, action: #selector(save), for: .touchUpInside)
        
        self.myView.textfield_shuzicai.rx.text.orEmpty.asObservable()
            .distinctUntilChanged()
            .throttle(0.5, scheduler: MainScheduler.instance)
            .filter{ [weak self] in
                if Double($0) != nil && Double($0)! > 1950 {
                    if self?.userSetQuota?[$0] == nil || (self?.userSetQuota![$0] as! Int) == 0 {
                        let msg = """
                        \($0)奖金组已无配额。
                        目前可选配额为：
                        \(self?.userSetQuota!.filter { (key, value) -> Bool in
                        return (value as! Int) > 0
                        }.map { (key, value) -> String in
                        return "\(key)"
                        }.sorted().joined(separator: ",") ?? "")
                        """
                        let vc = MessageDialogViewController("提示", msg)
                        let dialog = CustomerDialogBuilder(customerVc: vc)
                            .build()
                        self?.present(dialog, animated: true, completion: nil)
                    }
                }
                return self?.prize[$0] != nil
            }
            .subscribe(onNext: { [weak self] in
                let rebate = self?.prize[$0] as! String
                self?.myView.label_szc_dyfd.text = String(format: "对应返点%.2lf%%", Double(rebate)! * 100)
            })
            .disposed(by: disposeBag)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        IQKeyboardManager.shared.enable = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        IQKeyboardManager.shared.enable = false
    }
    
    func setViewData(_ data: NSDictionary){
        let username = (data[GetChildInfoAPIManager.DataKey.userPrizeSet] as! NSDictionary)["username"] as! String
        self.currentUserPrizeGroup = (data[GetChildInfoAPIManager.DataKey.currentUserPrizeGroup] as! String)
        self.iMaxPrizeGroup = (data[GetChildInfoAPIManager.DataKey.iMaxPrizeGroup] as! String)
        self.parentSingle = data[GetChildInfoAPIManager.DataKey.parentSingle] as! Double
        self.parentMulti = data[GetChildInfoAPIManager.DataKey.parentMulti] as! Double
        self.parentAG = data[GetChildInfoAPIManager.DataKey.parentAG] as! Double
        self.parentGA = data[GetChildInfoAPIManager.DataKey.parentGA] as! Double
        self.userSingle = data[GetChildInfoAPIManager.DataKey.userSingle] as! Double
        self.userMulti = data[GetChildInfoAPIManager.DataKey.userMulti] as! Double
        self.userAG = data[GetChildInfoAPIManager.DataKey.userAG] as! Double
        self.userGA = data[GetChildInfoAPIManager.DataKey.userGA] as! Double
        self.userSetQuota = data[GetChildInfoAPIManager.DataKey.userSetQuota] as! NSDictionary
        
        self.myView.label_username.text = "用户名：\(username)"
        self.myView.textfield_shuzicai.text = currentUserPrizeGroup
        self.myView.label_szc_max.text = "最高可设置\(iMaxPrizeGroup!)"
        self.myView.label_dgfd_tips.text = "%（一共有\(String(format:"%.1f", parentSingle!))%可以分配）"
        self.myView.label_hhgg_tips.text = "%（一共有\(String(format:"%.1f", parentMulti!))%可以分配）"
        self.myView.label_ag_tips.text = "%（一共有\(String(format:"%.1f", parentAG!))%可以分配）"
        self.myView.label_ga_tips.text = "%（一共有\(String(format:"%.1f", parentGA!))%可以分配）"
        
        self.myView.textfield_dgfd.text = String(format:"%.1f", userSingle!)
        self.myView.textfield_hhgh.text = String(format:"%.1f", userMulti!)
        self.myView.textfield_ag.text = String(format:"%.1f", userAG!)
        self.myView.textfield_ga.text = String(format:"%.1f", userGA!)
    }
    
    func save(){
        changePrizeAPIManager.loadData()
    }
    
    func priceGroupSliderChange() {
        let rebate = prize[self.myView.textfield_shuzicai.text!] as! String
        self.myView.label_szc_dyfd.text = String(format: "对应返点%.2lf%%", Double(rebate)! * 100)
    }
    
}

extension ModifyAwardViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        if manager.isKind(of: GetChildInfoAPIManager.self) {
            let params = ["id": self.id] as [String : Any]
            return params as NSDictionary
        }else {
            let jsonData = try? JSONSerialization.data(withJSONObject: ["1": self.myView.textfield_shuzicai.text!], options: .prettyPrinted)
            let json = String(bytes: jsonData!, encoding: String.Encoding.utf8)
            let jsonData1 = try? JSONSerialization.data(withJSONObject: self.userSetQuota!, options: .prettyPrinted)
            let json1 = String(bytes: jsonData1!, encoding: String.Encoding.utf8)
            let params = ["id": id,
                "fb_single": self.myView.textfield_dgfd.text!,
                "fb_all": self.myView.textfield_hhgh.text!,
                "ag_percent": self.myView.textfield_ag.text!,
                "ga_percent": self.myView.textfield_ga.text!,
                "series_prize_group_json": json,
                "agent_prize_set_quota": json1]  as [String : Any]
            return params as NSDictionary
        }
    }
    
}
extension ModifyAwardViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        //        GAProgressHUD.showSuccess(message: "获取成功!")
        if manager.isKind(of: GetChildInfoAPIManager.self) {
            let data = manager.fetchData(self.apiManager) as! NSDictionary
            let data1 = data[GetChildInfoAPIManager.DataKey.allPossiblePrizeGroup] as! String
            let data3 = try? JSONSerialization.jsonObject(with: data1.data(using: .utf8)!, options: .mutableContainers) as! [NSDictionary]
            data3?.forEach { (item) in
                let key = item["name"]
                let value = item["water"]
                prize[key] = value
            }
            self.data = data
            self.setViewData(data)
            priceGroupSliderChange()
        }else {
            let msg = """
                    用户 \(self.myView.label_username.text!.replacingOccurrences(of: "用户名：", with: "")) 的奖金组设置成功，新的奖金组是
                    数字彩奖金组: \(self.myView.textfield_shuzicai.text!)
                    竞彩单关：\(self.myView.textfield_dgfd.text!)%
                    竞彩混关：\(self.myView.textfield_hhgh.text!)%
                    AG游戏：\(self.myView.textfield_ag.text!)%
                    GA游戏：\(self.myView.textfield_ga.text!)%
                    """
            let vc = MessageDialogViewController("提示", msg);
            vc.label_message.textAlignment = .center
            let dialog = CustomerDialogBuilder(customerVc: vc)
                .isGestureDismissal(false)
                .hasNagativeTap(false, "", nagative: {})
                .hasPositiveTap {
                    self.navigationController?.popViewController(animated: true)
                }
                .build()
            present(dialog, animated: true, completion: nil)
        }
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        if manager.isKind(of: GetChildInfoAPIManager.self) {
            let dialog = SimpleDialogBuilder()
                .message("数据获取失败，请重试")
                .isGestureDismissal(false)
                .hasPositiveTap {self.apiManager.loadData()}
                .hasNagativeTap {self.dismiss(animated: true, completion: nil)}
                .build()
            self.present(dialog, animated: true, completion: nil)
        }
    }
}
