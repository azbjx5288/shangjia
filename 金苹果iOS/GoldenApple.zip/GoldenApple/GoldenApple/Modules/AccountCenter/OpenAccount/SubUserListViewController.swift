//
//  SubUserListViewController.swift
//  GoldenApple
//
//  Created by User on 2018/8/31.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import MJRefresh

class SubUserListViewController: UIViewController {
    
    lazy var myView = {() -> UserListView in
        let view = UserListView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - 64))
        return view
    }()
    
    let userListApiManager = SubUserAPIManager()
    
    var subuserId: Int
    
    init(_ subuserId: Int) {
        self.subuserId = subuserId
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "用户列表"
        self.view.addSubview(self.myView)
        self.myView.tableView.dataSource = self
        self.myView.tableView.delegate = self
        userListApiManager.paramSource = self
        userListApiManager.delegate = self
        
        let header = MJRefreshNormalHeader { [weak self] in
            self?.userListApiManager.isRefresh = true
            self?.userListApiManager.page = 1
            self?.userListApiManager.loadData()
        }
        let footer = MJRefreshAutoNormalFooter { [weak self] in
            self?.userListApiManager.isRefresh = false
            self?.userListApiManager.page += 1
            self?.userListApiManager.loadData()
        }
        header?.lastUpdatedTimeLabel.isHidden = true
        self.myView.tableView.mj_header = header
        self.myView.tableView.mj_footer = footer
        
        self.myView.btn_search.addTarget(self, action: #selector(search), for: .touchUpInside)
        self.userListApiManager.loadData()
    }
    
    func subuser(sender: UIButton) {
        let data = self.userListApiManager.recordDictList[sender.tag]
        let id = data[UserListAPIManager.DataKey.id] as! Int
        let children_num = data[UserListAPIManager.DataKey.children_num] as! Int
        if children_num > 0 {
            self.navigationController?.pushViewController(SubUserListViewController(id), animated: true)
        }
    }
    
    func search(){
        self.userListApiManager.username = self.myView.textfield_search.text ?? ""
        self.userListApiManager.isRefresh = true
        self.userListApiManager.page = 1
        self.userListApiManager.loadData()
    }
}

extension SubUserListViewController: UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.userListApiManager.recordDictList.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let data = self.userListApiManager.recordDictList[indexPath.row]
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell") as? UserListTableViewCell
        if cell == nil {
            cell = UserListTableViewCell.init(style: .default, reuseIdentifier: "cell") as UserListTableViewCell
            cell?.btn_edit.isHidden = true
        }
        if (data[UserListAPIManager.DataKey.children_num] as! Int) > 0 {
            let attrStr = NSAttributedString(string: data[UserListAPIManager.DataKey.username] as! String, attributes: [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
            cell?.label_name.setAttributedTitle(attrStr, for: .normal)
        }else {
            let attrStr = NSAttributedString(string: data[UserListAPIManager.DataKey.username] as! String, attributes: [:])
            cell?.label_name.setAttributedTitle(attrStr, for: .normal)
        }
        cell?.label_num.text = "\(data[UserListAPIManager.DataKey.children_num] as! Int)"
        cell?.label_time.text = data[UserListAPIManager.DataKey.register_at] as? String
        cell?.label_yue.text = data[UserListAPIManager.DataKey.group_account_sum] as? String
        cell?.btn_edit.tag = indexPath.row
        cell?.label_name.tag = indexPath.row
        cell?.label_name.addTarget(self, action: #selector(self.subuser(sender:)), for: .touchUpInside)
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 48
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.cellForRow(at: indexPath)?.setSelected(false, animated: true)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UserListHeadTableViewCell(frame: .zero)
        headerView.container.tg_rightPadding = 0
        return headerView
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 48
    }
}

extension SubUserListViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        //        GAProgressHUD.showLoading(message: "获取数据,请稍候...")
        
        var params = [:] as [String : Any]
        if self.userListApiManager.username != ""{
            params["username"] = self.userListApiManager.username
        }
        params["pid"] = self.subuserId
        return params as NSDictionary
    }
    
}

extension SubUserListViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        //        GAProgressHUD.showSuccess(message: "获取成功!")
        let recordDictList = manager.fetchData(self.userListApiManager) as! NSArray
        self.myView.tableView.reloadData()
        if !self.userListApiManager.isRefresh && recordDictList.count == 0 {
            let footer = self.myView.tableView.mj_footer as! MJRefreshAutoNormalFooter
            footer.endRefreshingWithNoMoreData()
        } else {
            self.myView.tableView.mj_header.endRefreshing()
            self.myView.tableView.mj_footer.endRefreshing()
        }
    }
    
}
