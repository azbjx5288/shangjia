//
//  UserListView.swift
//  GoldenApple
//
//  Created by User on 2018/8/28.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class UserListView: UIView {
    
    lazy var textfield_search = {() -> UITextField in
        let view = UITextField()
        view.borderStyle = .roundedRect
        view.placeholder = "请输入下级用户名"
        return view
    }()
    
    lazy var btn_search = {() -> UIButton in
        let view = UIButton()
        view.setTitle("搜索", for: .normal)
        view.setTitleColor(.black, for: .normal)
        view.layer.borderColor = RGBCOLOR(222, 222, 222).cgColor
        view.layer.borderWidth = 0.5
        return view
    }()
    
    lazy var tableView = {() -> UITableView in
        let view = UITableView()
        return view
    }()
    
    private lazy var container = {() -> TGLinearLayout in
        let view = TGLinearLayout(.vert)
        return view
    }()
    
    private lazy var container_header = {() -> TGLinearLayout in
        let view = TGLinearLayout(.horz)
        view.tg_padding = UIEdgeInsets(top: 10, left: 20, bottom: 10, right: 20)
        view.tg_space = 20
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        container_header.tg_width.equal(.fill)
        container_header.tg_height.equal(.wrap)
        
        container.tg_width.equal(.fill)
        container.tg_height.equal(.fill)
        
        container_header.addSubview(textfield_search)
        container_header.addSubview(btn_search)
        
        container.addSubview(container_header)
        container.addSubview(tableView)
        
        tableView.tg_width.equal(.fill)
        tableView.tg_height.equal(.fill)
        textfield_search.tg_width.equal(.fill)
        textfield_search.tg_height.equal(40)
        btn_search.tg_height.equal(40)
        btn_search.tg_width.equal(60)
        
        self.addSubview(container)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
