//
//  ModifyAwardView.swift
//  GoldenApple
//
//  Created by User on 2018/8/30.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class ModifyAwardView: UIView {

    lazy var label_tips = {() -> UILabel in
        let view = UILabel()
        view.numberOfLines = 0
        view.textColor = .red
        view.text = "特别提示：调整用户奖金组，一旦调高并保存后，不允许恢复或调低，请谨慎操作！"
        return view
    }()
    
    lazy var label_username = {() -> UILabel in
        let view = UILabel()
        view.text = "用户名：ZBadmin"
        return view
    }()
    
    lazy var label_award_title = {() -> UILabel in
        let view = UILabel()
        view.text = "奖金组："
        return view
    }()
    
    lazy var label_shuzicai_title = {() -> UILabel in
        let view = UILabel()
        view.text = "数字彩："
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var textfield_shuzicai = {() -> UITextField in
        let view = UITextField()
        view.keyboardType = .numberPad
        view.borderStyle = .roundedRect
        return view
    }()
    
    lazy var label_szc_dyfd = {() -> UILabel in
        let view = UILabel()
        view.text = "对应返点23%"
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_szc_max = {() -> UILabel in
        let view = UILabel()
        view.text = "最高可设置1960"
        view.font = UIFont.systemFont(ofSize: 12)
        view.textColor = kGAFontGrayColor
        return view
    }()
    
    lazy var label_game_award_title = {() -> UILabel in
        let view = UILabel()
        view.text = "游戏返点："
        return view
    }()
    
    lazy var label_jczq_title = {() -> UILabel in
        let view = UILabel()
        view.text = "竞彩足球："
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_dgfd_title = {() -> UILabel in
        let view = UILabel()
        view.text = "单关返点："
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var textfield_dgfd = {() -> UITextField in
        let view = UITextField()
        view.keyboardType = .decimalPad
        view.borderStyle = .roundedRect
        return view
    }()
    
    lazy var label_dgfd_tips = {() -> UILabel in
        let view = UILabel()
        view.text = "%（一共有6%可以分配）"
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_hhgg_title = {() -> UILabel in
        let view = UILabel()
        view.text = "混合过关："
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var textfield_hhgh = {() -> UITextField in
        let view = UITextField()
        view.keyboardType = .decimalPad
        view.borderStyle = .roundedRect
        return view
    }()
    
    lazy var label_hhgg_tips = {() -> UILabel in
        let view = UILabel()
        view.text = "%（一共有6%可以分配）"
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_ag_title = {() -> UILabel in
        let view = UILabel()
        view.text = "AG游戏："
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var textfield_ag = {() -> UITextField in
        let view = UITextField()
        view.keyboardType = .decimalPad
        view.borderStyle = .roundedRect
        return view
    }()
    
    lazy var label_ag_tips = {() -> UILabel in
        let view = UILabel()
        view.text = "%（一共有6%可以分配）"
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_ga_title = {() -> UILabel in
        let view = UILabel()
        view.text = "GA游戏："
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var textfield_ga = {() -> UITextField in
        let view = UITextField()
        view.keyboardType = .decimalPad
        view.borderStyle = .roundedRect
        return view
    }()
    
    lazy var label_ga_tips = {() -> UILabel in
        let view = UILabel()
        view.text = "%（一共有6%可以分配）"
        view.textColor = kGAFontBlackColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var btn_save = {() -> UIButton in
        let view = UIButton()
        view.setTitle("保存", for: .normal)
        view.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        view.layer.borderWidth = 1
        view.layer.cornerRadius = 5
        view.backgroundColor = kGATabbarBackgroundColor
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        let scrollView = UIScrollView(frame: frame)
        let rootView = TGLinearLayout(.vert)
        rootView.tg_space = 15
        rootView.tg_padding = UIEdgeInsets(top: 10, left: 15, bottom: 10, right: 15)
        rootView.backgroundColor = .white
        rootView.tg_width.equal(.fill)
        rootView.tg_height.equal(.fill)
        
        let container_1 = TGRelativeLayout()
        let container_2 = TGLinearLayout(.horz)
        container_2.tg_gravity = TGGravity.vert.center
        let container_3 = TGLinearLayout(.horz)
        container_3.tg_gravity = TGGravity.vert.center
        let container_4 = TGLinearLayout(.horz)
        container_4.tg_gravity = TGGravity.vert.center
        let container_5 = TGLinearLayout(.horz)
        container_5.tg_gravity = TGGravity.vert.center
        container_1.tg_width.equal(.fill)
        container_1.tg_height.equal(.wrap)
        container_2.tg_width.equal(.fill)
        container_2.tg_height.equal(.wrap)
        container_3.tg_width.equal(.fill)
        container_3.tg_height.equal(.wrap)
        container_4.tg_width.equal(.fill)
        container_4.tg_height.equal(.wrap)
        container_5.tg_width.equal(.fill)
        container_5.tg_height.equal(.wrap)
        
        label_tips.tg_width.equal(.fill)
        label_tips.tg_height.equal(.wrap)
        label_username.tg_width.equal(.wrap)
        label_username.tg_height.equal(.wrap)
        label_award_title.tg_width.equal(.wrap)
        label_award_title.tg_height.equal(.wrap)
        
        
        label_shuzicai_title.tg_width.equal(.wrap)
        label_shuzicai_title.tg_height.equal(.wrap)
        label_shuzicai_title.tg_left.equal(0)
        label_shuzicai_title.tg_centerY.equal(textfield_shuzicai)
        textfield_shuzicai.tg_width.equal(90)
        textfield_shuzicai.tg_height.equal(.wrap)
        textfield_shuzicai.tg_left.equal(label_shuzicai_title.tg_right)
        label_szc_dyfd.tg_width.equal(.wrap)
        label_szc_dyfd.tg_height.equal(.wrap)
        label_szc_dyfd.tg_left.equal(textfield_shuzicai.tg_right).offset(5)
        label_szc_dyfd.tg_centerY.equal(textfield_shuzicai)
        label_szc_max.tg_width.equal(.wrap)
        label_szc_max.tg_height.equal(.wrap)
        label_szc_max.tg_left.equal(textfield_shuzicai)
        label_szc_max.tg_top.equal(textfield_shuzicai.tg_bottom)
        
        label_game_award_title.tg_width.equal(.wrap)
        label_game_award_title.tg_height.equal(.wrap)
        label_jczq_title.tg_width.equal(.wrap)
        label_jczq_title.tg_height.equal(.wrap)
        label_dgfd_title.tg_width.equal(.wrap)
        label_dgfd_title.tg_height.equal(.wrap)
        textfield_dgfd.tg_width.equal(70)
        textfield_dgfd.tg_height.equal(.wrap)
        label_dgfd_tips.tg_width.equal(.wrap)
        label_dgfd_tips.tg_height.equal(.wrap)
        label_hhgg_title.tg_width.equal(.wrap)
        label_hhgg_title.tg_height.equal(.wrap)
        textfield_hhgh.tg_width.equal(70)
        textfield_hhgh.tg_height.equal(.wrap)
        label_hhgg_tips.tg_width.equal(.wrap)
        label_hhgg_tips.tg_height.equal(.wrap)
        label_ag_title.tg_width.equal(.wrap)
        label_ag_title.tg_height.equal(.wrap)
        textfield_ag.tg_width.equal(70)
        textfield_ag.tg_height.equal(.wrap)
        label_ag_tips.tg_width.equal(.wrap)
        label_ag_tips.tg_height.equal(.wrap)
        label_ga_title.tg_width.equal(.wrap)
        label_ga_title.tg_height.equal(.wrap)
        textfield_ga.tg_width.equal(70)
        textfield_ga.tg_height.equal(.wrap)
        label_ga_tips.tg_width.equal(.wrap)
        label_ga_tips.tg_height.equal(.wrap)
        btn_save.tg_width.equal(160)
        btn_save.tg_height.equal(40)
        btn_save.tg_centerX.equal(0)
        
        container_1.addSubview(label_shuzicai_title)
        container_1.addSubview(textfield_shuzicai)
        container_1.addSubview(label_szc_dyfd)
        container_1.addSubview(label_szc_max)
        
        container_2.addSubview(label_dgfd_title)
        container_2.addSubview(textfield_dgfd)
        container_2.addSubview(label_dgfd_tips)
        
        container_3.addSubview(label_hhgg_title)
        container_3.addSubview(textfield_hhgh)
        container_3.addSubview(label_hhgg_tips)
        
        container_4.addSubview(label_ag_title)
        container_4.addSubview(textfield_ag)
        container_4.addSubview(label_ag_tips)
        
        container_5.addSubview(label_ga_title)
        container_5.addSubview(textfield_ga)
        container_5.addSubview(label_ga_tips)
        
        rootView.addSubview(label_tips)
        rootView.addSubview(label_username)
        rootView.addSubview(label_award_title)
        rootView.addSubview(container_1)
        rootView.addSubview(label_game_award_title)
        rootView.addSubview(label_jczq_title)
        rootView.addSubview(container_2)
        rootView.addSubview(container_3)
        rootView.addSubview(container_4)
        rootView.addSubview(container_5)
        rootView.addSubview(btn_save)

        scrollView.addSubview(rootView)
        self.addSubview(scrollView)
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
