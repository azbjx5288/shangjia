//
//  GetChildInfoAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/8/30.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import Foundation

import UIKit

class GetChildInfoAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let userPrizeSet = "userPrizeSet"
        static let currentUserPrizeGroup = "currentUserPrizeGroup"
        static let userSetQuota = "userSetQuota"
        static let allPossiblePrizeGroup = "allPossiblePrizeGroup"
        static let selfSetQuota = "selfSetQuota"
        static let userSingle = "userSingle"
        static let userMulti = "userMulti"
        static let userAG = "userAg"
        static let userGA = "userGa"
        static let is_agent = "is_agent"
        static let iMinPrizeGroup = "iMinPrizeGroup"
        static let iMaxPrizeGroup = "iMaxPrizeGroup"
        static let parentSingle = "parentSingle"
        static let parentMulti = "parentMulti"
        static let parentAG = "parentAg"
        static let parentGA = "parentGa"
    }
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension GetChildInfoAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=User&action=getChildInfo"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
    
}


extension GetChildInfoAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        return resultDict
    }
}

