//
//  PreciseOpenAccountViewController.swift
//  GoldenApple
//
//  Created by User on 2018/8/31.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import RxSwift
import RxCocoa

class PreciseOpenAccountViewController: UIViewController {
    
    let disposeBag = DisposeBag()
    lazy var myView = {() -> PreciseOpenAccountView in
        let view = PreciseOpenAccountView(frame: self.view.frame)
        return view
    }()
    
    let getUserAccurateInfoAPIManage = GetUserAccurateInfoAPIManage()
    let accurateUserAPIManager = AccurateUserAPIManager()
    
    var user_type = 1
    
    var userAllPrizeSetQuota: NSDictionary!
    var playerMinPrizeGroup: String!
    var agentMinPrizeGroup: String!
    var userAG: Double!
    var userGA: Double!
    var userMulti: Int!
    var userSingle: Int!
    var possiblePlayerPrizeGroup: Int!
    var possibleAgentPrizeGroup: Int!
    var aPlayers: NSDictionary!
    var aAgents: NSDictionary!
    
    var quota: NSMutableDictionary = [:]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "精准开户"
        self.view.addSubview(myView)
        self.myView.label_szc_max.isHidden = true
        self.getUserAccurateInfoAPIManage.delegate = self
        self.accurateUserAPIManager.delegate = self
        self.accurateUserAPIManager.paramSource = self
//        self.getUserAccurateInfoAPIManage.paramSource = self
        self.myView.btn_save.addTarget(self, action: #selector(self.saveData), for: .touchUpInside)
        self.myView.btn_type_agent.tag = 1
        self.myView.btn_type_user.tag = 0
        self.myView.btn_type_agent.addTarget(self, action: #selector(self.userTypeChange(sender:)), for: .touchUpInside)
        self.myView.btn_type_user.addTarget(self, action: #selector(self.userTypeChange(sender:)), for: .touchUpInside)
        
        self.myView.textfield_shuzicai.rx.text.orEmpty.asObservable()
            .distinctUntilChanged()
            .filter{ [weak self] in
                if self?.user_type == 1 {
                    return self?.aAgents?[$0] != nil
                }else {
                    return self?.aPlayers?[$0] != nil
                }
            }
            .subscribe(onNext: { [weak self] in
                if self?.user_type == 1 {
                    let rebate = self?.aAgents[$0] as! Double
                    self?.myView.label_szc_dyfd.text = String(format: "对应返点%.2lf%%", rebate * 100)
                    if Int($0) ?? 0 >= 1950 {
                        let vc = SetQuotaViewController(self?.userAllPrizeSetQuota ?? [:], self?.quota ?? [:])
                        vc.title = "设置开户配额"
                        let dialog = CustomerDialogBuilder(customerVc: vc)
                            .hasPositiveTap {
                                for view in vc.views {
                                    self?.quota[view.label_key.text!] = view.textfield_value.text!
                                }
                                let filtered = self?.quota.filter({ (tupleArgument) -> Bool in
                                    return (tupleArgument.value as? String) != nil && Int(tupleArgument.value as! String)! > 0
                                })
                                self?.quota.removeAllObjects()
                                for result in filtered! {
                                    self?.quota[result.0] = result.1
                                }
                            }
                            .build()
                        self?.present(dialog, animated: true, completion: nil)
                    }
                }else {
                    let rebate = self?.aPlayers[$0] as! Double
                    self?.myView.label_szc_dyfd.text = String(format: "对应返点%.2lf%%", rebate * 100)
                }
            })
            .disposed(by: disposeBag)
        self.getUserAccurateInfoAPIManage.loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        IQKeyboardManager.shared.enable = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        IQKeyboardManager.shared.enable = false
    }
    
    func setView(){
        self.myView.label_dgfd_tips.text = "%（一共有\(String(format:"%d", userSingle!))%可以分配）"
        self.myView.label_hhgg_tips.text = "%（一共有\(String(format:"%d", userMulti!))%可以分配）"
        self.myView.label_ag_tips.text = "%（一共有\(String(format:"%.1f", userAG!))%可以分配）"
        self.myView.label_ga_tips.text = "%（一共有\(String(format:"%.1f", userAG!))%可以分配）"
    }
    
    func userTypeChange(sender: UIButton) {
        self.myView.btn_type_agent.isSelected = false
        self.myView.btn_type_user.isSelected = false
        sender.isSelected = true
        let tag = sender.tag
        self.user_type = tag
    }
    
    func saveData() {
        let vc = AccurateConfirmViewController()
        vc.kvView_type.label_value.text = self.user_type == 1 ? "代理" : "玩家"
        vc.kvView_username.label_value.text = self.myView.textfield_setusername.text
        vc.kvView_pwd.label_value.text = self.myView.textfield_setpwd.text
        vc.kvView_szc.label_value.text = self.myView.textfield_shuzicai.text
        vc.kvView_jjdg.label_value.text = self.myView.textfield_dgfd.text
        vc.kvView_jjhg.label_value.text = self.myView.textfield_hhgh.text
        vc.kvView_ag.label_value.text = self.myView.textfield_ag.text
        vc.kvView_ga.label_value.text = self.myView.textfield_ga.text
        let dialog = CustomerDialogBuilder(customerVc: vc)
            .isGestureDismissal(false)
            .hasPositiveTap {
                self.accurateUserAPIManager.loadData()
            }
            .build()
        self.present(dialog, animated: true, completion: nil)
    }

}

extension PreciseOpenAccountViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        if manager.isKind(of: AccurateUserAPIManager.self) {
            let jsonData = try? JSONSerialization.data(withJSONObject: self.quota, options: .prettyPrinted)
            let json = String(bytes: jsonData!, encoding: String.Encoding.utf8)
            let params = ["fb_single": self.myView.textfield_dgfd.text!,
                "fb_all": self.myView.textfield_dgfd.text!,
                "ag_percent": self.myView.textfield_ag.text!,
                "ga_percent": self.myView.textfield_ga.text!,
                "is_agent": self.user_type,
                "username": self.myView.textfield_setusername.text!,
                "password": self.myView.textfield_setpwd.text!,
                "nickname": self.myView.textfield_setnickname.text!,
                "series_prize_group_json": "{\"1\":\"\(self.myView.textfield_shuzicai.text!)\"}",
                "agent_prize_set_quota": json
                ] as [String : Any]
            return params as NSDictionary
        }else {
          let params = ["id": ""] as [String : Any]
            return params as NSDictionary
        }
    }
    
}
extension PreciseOpenAccountViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        //        GAProgressHUD.showSuccess(message: "获取成功!")
        if manager.isKind(of: GetUserAccurateInfoAPIManage.self) {
            let data = manager.fetchData(self.getUserAccurateInfoAPIManage) as! NSDictionary
            self.userAllPrizeSetQuota = data[GetUserAccurateInfoAPIManage.DataKey.userAllPrizeSetQuota] as? NSDictionary
            self.playerMinPrizeGroup = data[GetUserAccurateInfoAPIManage.DataKey.playerMinPrizeGroup] as? String
            self.agentMinPrizeGroup = data[GetUserAccurateInfoAPIManage.DataKey.agentMinPrizeGroup] as? String
            self.userAG = data[GetUserAccurateInfoAPIManage.DataKey.userAG] as? Double
            self.userGA = data[GetUserAccurateInfoAPIManage.DataKey.userGA] as? Double
            self.userMulti = data[GetUserAccurateInfoAPIManage.DataKey.userMulti] as? Int
            self.userSingle = data[GetUserAccurateInfoAPIManage.DataKey.userSingle] as? Int
            self.possiblePlayerPrizeGroup = data[GetUserAccurateInfoAPIManage.DataKey.possiblePlayerPrizeGroup] as? Int
            self.possibleAgentPrizeGroup = data[GetUserAccurateInfoAPIManage.DataKey.possibleAgentPrizeGroup] as? Int
            self.aPlayers = data[GetUserAccurateInfoAPIManage.DataKey.aPlayers] as? NSDictionary
            self.aAgents = data[GetUserAccurateInfoAPIManage.DataKey.aAgents] as? NSDictionary
            self.setView()
        }else {
            let dialog = SimpleDialogBuilder()
                .message("恭喜您，注册成功!")
                .isGestureDismissal(false)
                .hasPositiveTap {self.dismiss(animated: true, completion: nil)}
                .hasNagativeTap(false, "", nagative: {})
                .build()
            self.present(dialog, animated: true, completion: nil)
        }
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        if manager.isKind(of: GetUserAccurateInfoAPIManage.self) {
            let dialog = SimpleDialogBuilder()
                .message("数据获取失败，请重试")
                .isGestureDismissal(false)
                .hasPositiveTap {self.getUserAccurateInfoAPIManage.loadData()}
                .hasNagativeTap {self.dismiss(animated: true, completion: nil)}
                .build()
            self.present(dialog, animated: true, completion: nil)
        }
    }
}
