//
//  UserListTableViewCell.swift
//  GoldenApple
//
//  Created by User on 2018/8/29.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class UserListTableViewCell: UITableViewCell {

    lazy var label_name = {() -> UIButton in
        let view = UIButton()
        view.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        return view
    }()
    
    lazy var label_num = {() -> UILabel in
        let view = UILabel()
        return view
    }()
    
    lazy var label_time = {() -> UILabel in
        let view = UILabel()
        view.numberOfLines = 0
        view.font = UIFont.systemFont(ofSize: 12)
        return view
    }()
    
    lazy var label_yue = {() -> UILabel in
        let view = UILabel()
        view.font = UIFont.systemFont(ofSize: 12)
        return view
    }()
    
    lazy var btn_edit = {() -> UIButton in
        let view = UIButton()
        view.setImage(UIImage(named: "trendred"), for: .normal)
        return view
    }()
    
    lazy var container = {() -> TGLinearLayout in
        let view = TGLinearLayout(.horz)
        return view
    }()

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        container.tg_width.equal(.fill)
        container.tg_height.equal(48)
        container.tg_gravity = TGGravity.vert.center
        container.tg_bottomBorderline = TGBorderline(color: kGASerperatorLineGrayColor)
        
        container.addSubview(label_name)
        container.addSubview(label_num)
        container.addSubview(label_time)
        container.addSubview(label_yue)
        container.addSubview(btn_edit)
        
        label_name.tg_width.equal(.average)
        label_name.tg_height.equal(.fill)
        label_name.titleLabel?.textAlignment = .center
        
        label_num.tg_width.equal(.average)
        label_num.tg_height.equal(.fill)
        label_num.textAlignment = .center
        
        label_time.tg_width.equal(.average)
        label_time.tg_height.equal(.fill)
        label_time.textAlignment = .center
        
        label_yue.tg_width.equal(.average)
        label_yue.tg_height.equal(.fill)
        label_yue.textAlignment = .center
        
        btn_edit.tg_width.equal(40)
        btn_edit.tg_height.equal(40)
        self.addSubview(container)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
