//
//  AccurateUserAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/9/5.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import Foundation

class AccurateUserAPIManager: GAAPIBaseManager {
    struct DataKey {
    }
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension AccurateUserAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=User&action=AccurateUser"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .post
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
    
}


extension AccurateUserAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        return resultDict
    }
}
