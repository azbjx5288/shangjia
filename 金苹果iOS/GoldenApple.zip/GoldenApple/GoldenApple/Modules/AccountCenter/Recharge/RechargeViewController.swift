//
//  RechargeViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/29.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import WebKit
import SDWebImage
import Photos

class RechargeViewController: UIViewController {

    lazy var webVC : GDWebViewController = {
        ()->GDWebViewController in
        let temp = GDWebViewController()
        return temp
    }()
    
    let apiManager = GetDepositUrlAPIManager()
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "充值"
        webVC.delegate = self
        webVC.toolbar.toolbarTintColor = UIColor.white
        webVC.toolbar.toolbarBackgroundColor = UIColor.black
        webVC.allowsBackForwardNavigationGestures = true
        webVC.toolbar.toolbarTranslucent = false
        webVC.webView.configuration.userContentController.add(self, name: "goBack")
        webVC.webView.configuration.userContentController.add(self, name: "downloadQr")
        self.addChildViewController(webVC)
        
        self.view.addSubview(webVC.view)
        webVC.view.snp.makeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
        
        let closeBtn = UIButton()
        closeBtn.setTitle("关闭", for: .normal)
        closeBtn.setTitleColor(.white, for: .normal)
        closeBtn.addTarget(self, action: #selector(close), for: .touchUpInside)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: {
            self.webVC.showToolbar(true, animated: false)
            self.webVC.toolbar.addSubview(closeBtn)
            closeBtn.snp.makeConstraints { (make) in
                make.center.height.equalTo(self.webVC.toolbar)
                make.width.equalTo(50)
            }
        })
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    
    open override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    override func viewDidAppear(_ animated: Bool) {
        self.setNeedsStatusBarAppearanceUpdate()
        self.apiManager.loadData()
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
        self.webVC.webView.configuration.userContentController.removeScriptMessageHandler(forName: "goBack")
        self.webVC.webView.configuration.userContentController.removeScriptMessageHandler(forName: "downloadQr")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
 
    }
    
    @objc func close() {
        self.navigationController?.popViewController(animated: true)
    }
    


}
extension RechargeViewController:GDWebViewControllerDelegate {
    func webViewController(_ webViewController: GDWebViewController, didChangeTitle newTitle: NSString?) {
        self.navigationItem.title = newTitle as String?
    }
    
    func webViewController(_ webViewController: GDWebViewController, didFinishLoading loadedURL: URL?) {
 
    }
}

extension RechargeViewController:LYAPIManagerParamSource {
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "正在加载...")
        return NSDictionary()
    }
    
}
extension RechargeViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        guard let dict = manager.fetchData(self.apiManager) as? NSDictionary else {
            return
        }
        let url = dict.value(forKey: "url") as! String
        webVC.loadURLWithString(url)
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//    }
}

extension RechargeViewController: WKScriptMessageHandler {
    
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "goBack" {
            self.navigationController?.popViewController(animated: true)
        } else if message.name == "downloadQr" {
            print("111111111,%@",message.body)
            let url = "http://img2.zol.com.cn/product/127_940x705/290/ceG0eUP5XeDg.jpg"
            self.saveImage(urlString: url)
        }
    }
    
    func saveImage(urlString : String) {
        let url = NSURL.init(string: urlString) as URL?
        GAProgressHUD.showLoading(message: "下载中...")
        SDWebImageDownloader.shared().downloadImage(with: url, options: SDWebImageDownloaderOptions.useNSURLCache, progress: nil, completed: { (image, data, error, completed) in
            if image == nil {
                DispatchQueue.main.async {
                    GAProgressHUD.showWarning(message: "图片下载失败!")
                }
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAsset(from: image!)
            }) { (isSuccess: Bool, error: Error?) in
                DispatchQueue.main.async {
                    if isSuccess {
                        GAProgressHUD.showSuccess(message: "保存成功!")
                    } else{
                        GAProgressHUD.showWarning(message: "图片保存失败!")
                    }
                }
                
            }
        })
    }
    

}
