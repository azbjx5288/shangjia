//
//  PlatTransferAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/5/31.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class PlatTransferAPIManager: GAAPIBaseManager {

    struct DataKey {
        static let kTransferType = "transfer_type"
        static let kPlatId = "plat_id"
        static let kAmount = "amount"
    }
    
    override init() {
        super.init()
        
        self.validator = self
    }
}

extension PlatTransferAPIManager: LYAPIManager {
    func methodName() -> NSString {
        return "service?packet=Fund&action=PlatTransfer"
    }
    
    func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    func requestType() -> LYAPIManagerRequestType {
        return .post
    }
    
    func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
}

extension PlatTransferAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let dataArray = data.object(forKey: "data") else { return NSArray() }
        return dataArray
    }
    
    
}
