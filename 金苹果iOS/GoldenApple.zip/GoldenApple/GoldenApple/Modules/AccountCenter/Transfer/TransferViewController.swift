//
//  TransferViewController.swift
//  GoldenApple
//
//  Created by User on 2018/5/23.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class TransferViewController: UIViewController {
    
    enum eTransferType: UInt {
        case PTOutput = 0 //平台转出
        case PDInput = 1   //频道转入
    }
    
    fileprivate let contentView = TransferView()
    
    fileprivate let getThirdPlatBalanceAPIManager = GetThirdPlatBalanceAPIManager()
    
    fileprivate let platTransferAPIManager = PlatTransferAPIManager()
    
    fileprivate var thirdPlatBalanceDict: NSDictionary?
    
    fileprivate var transferTypeStr: String?
    fileprivate var platIdStr: String?
    
    fileprivate let platforDict: NSDictionary = [eTransferPlatform.eGoldApple: "主钱包", eTransferPlatform.eGAGame: "GA游戏"]
    

    override func loadView() {
        super.loadView()
        
        self.view = self.contentView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.title = "转账"
        self.view.backgroundColor = UIColor.white
        
        self.getThirdPlatBalanceAPIManager.delegate = self
        self.getThirdPlatBalanceAPIManager.paramSource = self
        self.platTransferAPIManager.delegate = self
        self.platTransferAPIManager.paramSource = self
        
        self.contentView.fromTypeFiled.dataArray = platforDict.allValues as NSArray
        self.contentView.toTypeFiled.dataArray = platforDict.allValues as NSArray
        self.contentView.fromTypeFiled.delegate = self
        self.contentView.toTypeFiled.delegate = self
        self.contentView.submitBtn.addTarget(self, action: #selector(submitBtnClick), for: .touchUpInside)
        
        self.getThirdPlatBalanceAPIManager.loadData()
    }

    @objc fileprivate func submitBtnClick() {
        
        if (self.contentView.fromTypeFiled.text?.isEmpty)! || (self.contentView.toTypeFiled.text?.isEmpty)! {
            GAProgressHUD.showError(message: "请选择转移平台")
            return
        }
        
        if self.contentView.fromTypeFiled.text == self.contentView.toTypeFiled.text {
            GAProgressHUD.showError(message: "转移平台选择错误")
            return
        }
        
        if (self.contentView.amountInputFiled.text?.isEmpty)! {
            GAProgressHUD.showError(message: "请输入金额")
            return
        }
        
        self.platTransferAPIManager.loadData()
    }

    fileprivate func getBalance(_ textField: UITextField) -> String? {
        
        if textField.text == nil {
            return nil
        }
        
        
        for (key, value) in platforDict {
            if textField.text! == (value as! String) {
                //目前只有GA游戏转移所以platId只能是GA游戏.
                self.platIdStr = String(eTransferPlatform.eGAGame.rawValue)
                if textField == self.contentView.fromTypeFiled {
                    self.transferTypeStr = String(eTransferType.PDInput.rawValue)
                } else {
                    self.transferTypeStr = String(eTransferType.PTOutput.rawValue)
                }
                
                switch (key as! eTransferPlatform) {
                case .eGAGame:
                    return thirdPlatBalanceDict?.object(forKey: GetThirdPlatBalanceAPIManager.DataKey.kBalance) as? String
                case .eGoldApple:
                    if textField == self.contentView.fromTypeFiled {
                        self.transferTypeStr = String(eTransferType.PTOutput.rawValue)
                    } else {
                        self.transferTypeStr = String(eTransferType.PDInput.rawValue)
                    }
                    return thirdPlatBalanceDict?.object(forKey: GetThirdPlatBalanceAPIManager.DataKey.kPlatAvailable) as? String
                default:
                    break
                }
                
                
            }
        }
        
        
        return nil
    }

}

extension TransferViewController: LYAPIManagerParamSource {
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "正在加载...")
        
        if manager == self.getThirdPlatBalanceAPIManager {
            return [GetThirdPlatBalanceAPIManager.DataKey.kPlatId: eTransferPlatform.eGAGame.rawValue]
        } else if manager == self.platTransferAPIManager {
            
            guard let amountStr = self.contentView.amountInputFiled.text else { return nil}
            
            let paramsDict = [PlatTransferAPIManager.DataKey.kTransferType: self.transferTypeStr,
                              PlatTransferAPIManager.DataKey.kPlatId: self.platIdStr,
                              PlatTransferAPIManager.DataKey.kAmount: amountStr]
            
            return paramsDict as NSDictionary
        }
        
        return nil
    }
    
    
}

extension TransferViewController: LYAPIManagerCallBackDelegate {
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        if manager == self.getThirdPlatBalanceAPIManager {
            thirdPlatBalanceDict = manager.fetchData(self.getThirdPlatBalanceAPIManager) as? NSDictionary
            
        } else if manager == self.platTransferAPIManager {
            
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    
}

extension TransferViewController: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.contentView.fromTypeFiled {
            
            self.contentView.fromBalanceLabel.text = self.getBalance(textField)
        } else if textField == self.contentView.toTypeFiled {
            
            self.contentView.toBalanceLabel.text = self.getBalance(textField)
        }
    }
}

