//
//  TransferView.swift
//  GoldenApple
//
//  Created by User on 2018/5/23.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class TransferView: UIView {
    
    fileprivate let contentView: UIView = {
        let view = UIView()
        
        return view
    }()
    
    fileprivate let transferTipsLabel: UILabel = {
        let label = UILabel()
        label.text = "转移:"
        return label
    }()
    
    fileprivate let fromTipsLabel: UILabel = {
        let label = UILabel()
        
        label.text = "从"
        return label
    }()
    
    let fromTypeFiled: LYPickerViewOfTextField = {
        let filed = LYPickerViewOfTextField()
        filed.borderStyle = UITextBorderStyle.roundedRect
        filed.font = UIFont.systemFont(ofSize: 14)
        let rightView = UIButton()
        rightView.setImage(UIImage.init(named: "allow_down"), for: .normal)
        rightView.backgroundColor = kGAFontGrayColor
        rightView.frame = CGRect.init(x: 0, y: 0, width: 35, height: 35)
        filed.rightView = rightView
        filed.rightViewMode = .always
        return filed
    }()
    
    fileprivate let toTipsLabel: UILabel = {
        let label = UILabel()
        
        label.text = "到"
        return label
    }()
    
    let toTypeFiled: LYPickerViewOfTextField = {
        let filed = LYPickerViewOfTextField()
        filed.borderStyle = UITextBorderStyle.roundedRect
        filed.font = UIFont.systemFont(ofSize: 14)
        let rightView = UIButton()
        rightView.setImage(UIImage.init(named: "allow_down"), for: .normal)
        rightView.backgroundColor = kGAFontGrayColor
        rightView.frame = CGRect.init(x: 0, y: 0, width: 35, height: 35)
        filed.rightView = rightView
        filed.rightViewMode = .always
        
        return filed
    }()
    

    
    fileprivate let balanceTipsLabel: UILabel = {
        let label = UILabel()
        
        label.text = "余额:"
        return label
    }()
    
    let fromBalanceLabel: UILabel = {
        let label = UILabel()
        
        label.text = "000"
        label.textColor = kGAFontRedColor
        label.font = UIFont.boldSystemFont(ofSize: 14)
        return label
    }()
    
    let toBalanceLabel: UILabel = {
        let label = UILabel()
        
        label.text = "000"
        label.textColor = kGAFontRedColor
        label.font = UIFont.boldSystemFont(ofSize: 14)
        return label
    }()
    
    fileprivate let amountTipsLabel: UILabel = {
        let label = UILabel()
        label.text = "转入金额:"
        
        return label
    }()
    
    let amountInputFiled: UITextField = {
        let field = UITextField()
        field.placeholder = "请输入转账金额"
        field.borderStyle = UITextBorderStyle.roundedRect
        field.keyboardType = .numberPad
        field.clearButtonMode = .whileEditing
    
        return field
    }()
    
    let inputAccessoryTool: UIToolbar? = {
        if UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.pad {
            return nil
        }
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.blackTranslucent
        toolBar.autoresizingMask = UIViewAutoresizing.flexibleHeight
        toolBar.sizeToFit()
        var frame = toolBar.frame
        frame.size.height = 30
        toolBar.frame = frame
        
        return toolBar
    }()
    
    fileprivate let bottomView: UIView = {
        let view = UIView()
        
        return view
    }()
    
    fileprivate let seperatorLine: UIView = {
        let view = UIView()
        
        view.backgroundColor = kGASerperatorLineGrayColor
        
        return view
    }()
    
    let submitBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        
        button.setTitle("转移", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.backgroundColor = kGAFontRedColor
        button.setTitleColor(UIColor.white, for: UIControlState.normal)

        return button
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.contentView)
        self.contentView.addSubview(self.transferTipsLabel)
        self.contentView.addSubview(self.fromTipsLabel)
        self.contentView.addSubview(self.fromTypeFiled)
        self.contentView.addSubview(self.toTipsLabel)
        self.contentView.addSubview(self.toTypeFiled)
        
        self.contentView.addSubview(self.balanceTipsLabel)
        self.contentView.addSubview(self.fromBalanceLabel)
        self.contentView.addSubview(self.toBalanceLabel)
        
        self.contentView.addSubview(self.amountTipsLabel)
        self.contentView.addSubview(self.amountInputFiled)
        
        self.addSubview(self.bottomView)
        self.bottomView.addSubview(self.seperatorLine)
        self.bottomView.addSubview(self.submitBtn)
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action: #selector(doneBtnClick))
        let flexibleSpaceLeft = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        self.inputAccessoryTool?.setItems([flexibleSpaceLeft, doneBtn], animated: true)
        self.amountInputFiled.inputAccessoryView = self.inputAccessoryTool
        
//        self.contentView.backgroundColor = UIColor.lightGray
        self.makeConstraintsForSubviews()
    }
    
    fileprivate func makeConstraintsForSubviews() {
        self.contentView.snp.makeConstraints { (make) in
            make.top.equalTo(25)
            make.centerX.equalToSuperview()
            make.width.equalTo(300)
            make.height.equalTo(250)
        }
        self.transferTipsLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.fromTypeFiled)
            make.left.equalToSuperview()
            make.height.equalTo(21)
        }
        self.fromTipsLabel.snp.makeConstraints { (make) in
            make.top.equalTo(self.transferTipsLabel)
            make.left.equalTo(self.transferTipsLabel.snp.right).offset(5)
            make.height.equalTo(self.transferTipsLabel)
        }
        self.fromTypeFiled.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalTo(self.fromTipsLabel.snp.right).offset(5)
            make.height.equalTo(40)
            make.width.equalTo(100)
        }
        self.toTipsLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.toTypeFiled)
            make.left.equalTo(self.fromTypeFiled.snp.right).offset(5)
        }
        self.toTypeFiled.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalTo(self.toTipsLabel.snp.right).offset(5)
            make.width.height.equalTo(self.fromTypeFiled)
        }
        
        self.balanceTipsLabel.snp.makeConstraints { (make) in
            make.top.equalTo(self.fromTypeFiled.snp.bottom).offset(20)
            make.left.equalTo(self.transferTipsLabel)
        }
        self.fromBalanceLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.fromTypeFiled)
            make.centerY.equalTo(self.balanceTipsLabel)
        }
        self.toBalanceLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.toTypeFiled)
            make.centerY.equalTo(self.balanceTipsLabel)
        }
        
        self.amountTipsLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.balanceTipsLabel)
            make.centerY.equalTo(self.amountInputFiled)
        }
        self.amountInputFiled.snp.makeConstraints { (make) in
            make.top.equalTo(self.balanceTipsLabel.snp.bottom).offset(20)
            make.left.equalTo(self.amountTipsLabel.snp.right).offset(10)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        self.bottomView.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        self.seperatorLine.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self.bottomView)
            make.height.equalTo(1)
        }
        
        self.submitBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bottomView)
            make.height.equalTo(60)
            make.left.equalTo(self.bottomView).offset(15)
            make.right.equalTo(self.bottomView).offset(-15)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func doneBtnClick() {
        self.endEditing(true)
    }
    
}
