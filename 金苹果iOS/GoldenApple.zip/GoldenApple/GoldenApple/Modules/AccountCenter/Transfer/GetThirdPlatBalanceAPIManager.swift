//
//  GetThirdPlatBalanceAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/5/30.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class GetThirdPlatBalanceAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        static let kPlatId = "plat_id"
        static let kId = "id"
        static let kName = "name"
        static let kBalance = "balance"
        static let kPlatAvailable = "platAvailable"
    }
    
    override init() {
        super.init()
        
        self.validator = self
    }

}

extension GetThirdPlatBalanceAPIManager: LYAPIManager {
    func methodName() -> NSString {
        return "service?packet=Fund&action=GetThirdPlatBalance"
    }
    
    func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
}

extension GetThirdPlatBalanceAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        let keyStr = String(eTransferPlatform.eGAGame.rawValue)
        
        return resultDict.object(forKey:keyStr)
    }
    
    
}
