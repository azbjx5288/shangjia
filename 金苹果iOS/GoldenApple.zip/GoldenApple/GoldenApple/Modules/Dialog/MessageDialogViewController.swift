//
//  MessageDialogViewController.swift
//  GoldenApple
//
//  Created by User on 2018/9/3.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class MessageDialogViewController: BaseCustomDialogViewController {

    var title_str: String
    var msg_str: String
    
    lazy var label_message = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.font = UIFont.systemFont(ofSize: 16, weight: 2)
        view.textColor = kGAFontRedColor
        return view
    }()
    
    init(_ title: String, _ message: String) {
        self.title_str = title
        self.msg_str = message
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 6
        paragraphStyle.alignment = .left
        // 4.行间距
        let nameStr : NSMutableAttributedString = NSMutableAttributedString(string:self.msg_str)
        nameStr.addAttribute(NSParagraphStyleAttributeName, value: paragraphStyle, range: NSMakeRange(0, self.msg_str.count))
        label_message.attributedText = nameStr
//        label_message.text = self.msg_str
        label_title.text = self.title_str
        
        self.container_content.addSubview(label_message)
    }

}
