//
//  BaseCustomDialogViewController.swift
//  GoldenApple
//
//  Created by User on 2018/8/31.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class BaseCustomDialogViewController: UIViewController {

    lazy var rootView = {() -> TGLinearLayout in
        let view = TGLinearLayout(.vert)
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var container_head = {() -> TGRelativeLayout in
        let view = TGRelativeLayout()
        view.tg_width.equal(.fill)
        view.tg_height.equal(40)
        view.tg_boundBorderline = TGBorderline(color: kGASerperatorLineGrayColor)
        view.backgroundColor = kGABackgroundColor
        return view
    }()
    
    lazy var container_content = {() -> TGLinearLayout in
        let view = TGLinearLayout(.vert)
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.tg_padding = UIEdgeInsets(top: 10, left: 15, bottom: 10, right: 15)
        return view
    }()
    
    lazy var label_title = {() -> UILabel in
        let view = UILabel()
        view.text = "提示"
        view.tg_width.equal(.wrap)
        view.tg_height.equal(.wrap)
        view.tg_centerX.equal(0)
        view.tg_centerY.equal(0)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        container_head.addSubview(label_title)
        rootView.addSubview(container_head)
        rootView.addSubview(container_content)
        self.view.addSubview(rootView)
        container_content.tg_endLayoutDo {
            let widthConstraint:NSLayoutConstraint = NSLayoutConstraint(item: self.view, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: self.rootView.width)
            
            let heightConstraint:NSLayoutConstraint = NSLayoutConstraint(item: self.view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 40 + self.container_content.height)
            
            self.view.addConstraints([widthConstraint, heightConstraint])
            self.updateFocusIfNeeded()
        }
    }
    
}
