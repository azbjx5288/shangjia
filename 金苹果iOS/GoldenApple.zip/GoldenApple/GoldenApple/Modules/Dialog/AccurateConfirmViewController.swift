//
//  AccurateConfirmViewController.swift
//  GoldenApple
//
//  Created by User on 2018/9/6.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class AccurateConfirmViewController: BaseCustomDialogViewController {
    
    lazy var kvView_type = {() -> KeyValueView in
        let view = KeyValueView(.label, "用户类型：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_username = {() -> KeyValueView in
        let view = KeyValueView(.label, "登录账号：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_pwd = {() -> KeyValueView in
        let view = KeyValueView(.label, "登录密码:：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_nickname = {() -> KeyValueView in
        let view = KeyValueView(.label, "用户昵称：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_szc = {() -> KeyValueView in
        let view = KeyValueView(.label, "数字彩奖金组：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var temp_1 = {() -> UIView in
        let view = UIView()
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_jjdg = {() -> KeyValueView in
        let view = KeyValueView(.label, "竞彩单关：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_jjhg = {() -> KeyValueView in
        let view = KeyValueView(.label, "竞彩混关：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_ag = {() -> KeyValueView in
        let view = KeyValueView(.label, "AG游戏：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_ga = {() -> KeyValueView in
        let view = KeyValueView(.label, "GA游戏：", "代理")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_peie = {() -> KeyValueView in
        let view = KeyValueView(.label, "配额数：", "")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var temp_2 = {() -> UIView in
        let view = UIView()
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_peie_1950 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1950奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1951 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1951奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1952 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1952奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1953 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1953奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1954 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1954奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1955 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1955奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1956 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1956奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1957 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1957奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1958 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1958奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1959 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1959奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    lazy var kvView_peie_1960 = {() -> KeyValueView in
        let view = KeyValueView(.label, "1960奖金组：", "0")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        let container = TGFlowLayout(.vert, arrangedCount: 2)
        container.tg_vspace = 10
        container.tg_width.equal(.fill)
        container.tg_height.equal(320)
        container.addSubview(kvView_type)
        container.addSubview(kvView_username)
        container.addSubview(kvView_pwd)
        container.addSubview(kvView_nickname)
        container.addSubview(kvView_szc)
        container.addSubview(temp_1)
        container.addSubview(kvView_jjdg)
        container.addSubview(kvView_jjhg)
        container.addSubview(kvView_ag)
        container.addSubview(kvView_ga)
        container.addSubview(kvView_peie)
        container.addSubview(temp_2)
        container.addSubview(kvView_peie_1950)
        container.addSubview(kvView_peie_1951)
        container.addSubview(kvView_peie_1952)
        container.addSubview(kvView_peie_1953)
        container.addSubview(kvView_peie_1954)
        container.addSubview(kvView_peie_1955)
        container.addSubview(kvView_peie_1956)
        container.addSubview(kvView_peie_1957)
        container.addSubview(kvView_peie_1958)
        container.addSubview(kvView_peie_1959)
        container.addSubview(kvView_peie_1960)
        
        self.container_content.addSubview(container)
    }


}

class KeyValueView: TGLinearLayout {
    
    enum TYPE {
        case label
        case input(CGSize)
    }
    
    lazy var label_key = {() -> UILabel in
        let view = UILabel()
        view.font = UIFont.systemFont(ofSize: 14)
        view.tg_width.equal(.wrap)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var label_value = {() -> UILabel in
        let view = UILabel()
        view.font = UIFont.systemFont(ofSize: 14)
        view.tg_width.equal(.wrap)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var textfield_value = {() -> UITextField in
        let view = UITextField()
        view.font = UIFont.systemFont(ofSize: 14)
        view.borderStyle = .roundedRect
//        view.tg_width.equal(60)
//        view.tg_height.equal(40)
        return view
    }()
    
    lazy var label_tips = {() -> UILabel in
        let view = UILabel()
        view.font = UIFont.systemFont(ofSize: 13)
        view.tg_width.equal(.wrap)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    init(_ type: TYPE,_ key: String, _ value: String,_ tips: String = "") {
        super.init(frame: .zero, orientation: .horz)
        self.tg_gravity = TGGravity.vert.center
        label_key.text = key
        self.addSubview(self.label_key)
        switch type {
        case .input(let size):
            textfield_value.tg_height.equal(size.height)
            textfield_value.tg_width.equal(size.width)
            self.addSubview(textfield_value)
            textfield_value.text = value
        default:
            self.addSubview(label_value)
            label_value.text = value
        }
        if tips != "" {
            self.addSubview(label_tips)
            label_tips.text = tips
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
