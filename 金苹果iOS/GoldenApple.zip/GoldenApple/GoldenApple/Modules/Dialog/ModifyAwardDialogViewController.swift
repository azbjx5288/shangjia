//
//  ModifyAwardDialogViewController.swift
//  GoldenApple
//
//  Created by User on 2018/8/31.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class ModifyAwardDialogViewController: BaseCustomDialogViewController {

    lazy var label_tips = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "用户 ZBadmin 的奖金组设置成功，新的奖金组是"
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_szc = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "数字彩奖金组: 1561"
        view.tg_left.equal(10)
        view.textColor = kGAFontGrayColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()

    lazy var label_jcdg = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "竞彩单关：5%"
        view.tg_left.equal(10)
        view.textColor = kGAFontGrayColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_jchg = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "竞彩混关：5%"
        view.tg_left.equal(10)
        view.textColor = kGAFontGrayColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_AG = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "AG游戏：0.5%"
        view.tg_left.equal(10)
        view.textColor = kGAFontGrayColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_GA = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "GA游戏：0.6%"
        view.tg_left.equal(10)
        view.textColor = kGAFontGrayColor
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.container_content.tg_space = 10
        self.container_content.addSubview(label_tips)
        self.container_content.addSubview(label_szc)
        self.container_content.addSubview(label_jcdg)
        self.container_content.addSubview(label_jchg)
        self.container_content.addSubview(label_AG)
        self.container_content.addSubview(label_GA)
    }
    
}
