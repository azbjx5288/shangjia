//
//  SetQuotaViewController.swift
//  GoldenApple
//
//  Created by User on 2018/9/6.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit
import TangramKit

class SetQuotaViewController: BaseCustomDialogViewController {
    
    var tipsData: NSDictionary
    var userSetData: NSDictionary
    var views = Array<KeyValueView>()

    lazy var kvView_1950 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1950", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1951 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1951", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1952 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1953", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1953 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1954", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1954 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1954", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1955 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1955", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1956 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1956", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1957 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1957", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1958 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1958", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1959 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1959", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    lazy var kvView_1960 = {() -> KeyValueView in
        let view = KeyValueView(.input(CGSize(width: 35, height: 35)), "1960", "0", "(最大允许0)")
        view.tg_width.equal(50%)
        view.tg_height.equal(.wrap)
        return view
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let container = TGFlowLayout(.vert, arrangedCount: 2)
        container.tg_vspace = 15
        container.tg_width.equal(.fill)
        container.tg_height.equal(320)
        container.addSubview(kvView_1950)
        container.addSubview(kvView_1951)
        container.addSubview(kvView_1952)
        container.addSubview(kvView_1953)
        container.addSubview(kvView_1954)
        container.addSubview(kvView_1955)
        container.addSubview(kvView_1956)
        container.addSubview(kvView_1957)
        container.addSubview(kvView_1958)
        container.addSubview(kvView_1959)
        container.addSubview(kvView_1960)
        views.append(kvView_1950)
        views.append(kvView_1951)
        views.append(kvView_1952)
        views.append(kvView_1953)
        views.append(kvView_1954)
        views.append(kvView_1955)
        views.append(kvView_1956)
        views.append(kvView_1957)
        views.append(kvView_1958)
        views.append(kvView_1959)
        views.append(kvView_1960)
        self.container_content.addSubview(container)
        
        for view in views {
            if let value = self.tipsData[view.label_key.text!] as? Int {
                view.label_tips.text = "(最大允许\(value))"
            }
            if let value = self.userSetData[view.label_key.text!] as? String {
                view.textfield_value.text = "\(value)"
            }
        }
    }
    
    init(_ tipsData: NSDictionary, _ userSetData: NSDictionary) {
        self.tipsData = tipsData
        self.userSetData = userSetData
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
