//
//  ModifyWarningdialogViewController.swift
//  GoldenApple
//
//  Created by User on 2018/8/31.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class ModifyWarningdialogViewController: BaseCustomDialogViewController {

    lazy var label_tips = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "1958奖金组已无配额。"
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_avaliable_title = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "目前可选配额为："
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    lazy var label_avaliable = {() -> UILabel in
        let view = UILabel()
        view.tg_width.equal(.fill)
        view.tg_height.equal(.wrap)
        view.text = "1951、1952、1953、1959"
        view.font = UIFont.systemFont(ofSize: 14)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.container_content.tg_space = 20
        self.container_content.addSubview(label_tips)
        self.container_content.addSubview(label_avaliable_title)
        self.container_content.addSubview(label_avaliable)
    }
    

}
