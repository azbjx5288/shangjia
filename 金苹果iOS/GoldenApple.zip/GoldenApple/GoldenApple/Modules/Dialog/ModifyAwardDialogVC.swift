//
//  ModifyAwardDialogVC.swift
//  GoldenApple
//
//  Created by User on 2018/8/31.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class ModifyAwardDialogVC: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
