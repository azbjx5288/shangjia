//
//  GANavigationController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/22.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit



class GANavigationController: UINavigationController {
    
    var replaceTarget : Bool = false
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    override init(rootViewController: UIViewController) {
        super.init(rootViewController: rootViewController)
        self.navigationBar.isTranslucent = false
        self.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
    }
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        super.pushViewController(viewController, animated: animated)
        
        let backItem = UIBarButtonItem.init(image: UIImage.init(named: "allow_left"), style: .plain, target: self, action: #selector(didClickBackBtn))
        backItem.tintColor = .white
        backItem.width = 40
        if self.viewControllers.count > 1 {
//            let fixedItem = UIBarButtonItem.init(barButtonSystemItem: .fixedSpace, target: nil, action: nil)
//            fixedItem.width = 0
            viewController.navigationItem.leftBarButtonItem = backItem
        }

        viewController.navigationItem.hidesBackButton = true;
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func didClickBackBtn() {
        self.popViewController(animated: true)
    }

}

extension UINavigationItem {
    
    /// 可以在UINavigationItem中重写返回方法
    func setNavigationBackTarget(_ target: AnyObject?, action: Selector) {
        self.leftBarButtonItem?.target = target
        self.leftBarButtonItem?.action = action
    }
}

