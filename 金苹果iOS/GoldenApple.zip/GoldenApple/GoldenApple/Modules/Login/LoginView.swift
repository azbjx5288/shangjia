//
//  LoginView.swift
//  GoldenApple
//
//  Created by User on 28/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import SnapKit

class LoginView: UIView {

    fileprivate let iconImage: UIImageView = {
        let icon = UIImageView(image: UIImage(named: "login_icon"))
        return icon
    }()
    
    fileprivate let middleView: UIView = {
        let view = UIView()
        
        return view
    }()
    
    fileprivate let userBgView: UIView = {
        let view = UIView()
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.lightGray.cgColor
        
        return view
    }()
    
    fileprivate let userIcon: UIImageView = {
        let image = UIImageView(image: UIImage(named: "admini"))
        
        return image
    }()
    
    let userField: UITextField = {
        let field = UITextField()
        field.placeholder = "请输入用户名"
        field.returnKeyType = .next
        field.clearButtonMode = UITextFieldViewMode.whileEditing
        field.textColor = UIColor.white
        
        return field
    }()
    
    fileprivate let passwordIcon: UIImageView = {
        let image = UIImageView(image: UIImage(named: "password"))

        return image
    }()
    
    let passwordBgView: UIView = {
        let view = UIView()
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.lightGray.cgColor
        
        return view
    }()
    
    let passwordField: UITextField = {
        let field = UITextField()
        field.placeholder = "请输入密码"
        field.returnKeyType = UIReturnKeyType.done
        field.isSecureTextEntry = true
        field.clearButtonMode = UITextFieldViewMode.whileEditing
        field.textColor = UIColor.white
        
        return field
    }()
    
//    let inputAccessoryTool: UIToolbar = {
//        let toolbar = UIToolbar()
//        toolbar.barStyle = UIBarStyle.blackTranslucent
//        toolbar.autoresizingMask = UIViewAutoresizing.flexibleHeight
//        var frame = toolbar.frame
//        frame.size.height = 30.0
//        toolbar.frame = frame
//
//        return toolbar
//    }()
    
    let loginButton: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("登录", for: UIControlState.normal)

        button.backgroundColor = UIColor.white
        button.setTitleColor(kGAFontRedColor, for: UIControlState.normal)
        return button
    }()
    
    let versionLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 14)
        
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor(patternImage: UIImage(named: "Optimus-G2-Wallpaper-15")!)
        self.addSubview(self.iconImage)
        
        self.addSubview(self.middleView)
        self.middleView.addSubview(self.userBgView)
        self.userBgView.addSubview(self.userIcon)
        self.userBgView.addSubview(self.userField)
        self.middleView.addSubview(self.passwordBgView)
        self.passwordBgView.addSubview(self.passwordIcon)
        self.passwordBgView.addSubview(self.passwordField)
        self.addSubview(self.loginButton)
        self.addSubview(self.versionLabel)
        
        let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
        self.versionLabel.text = "版本号:" + currentVersion
        
        self.makeConstraintsForSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate func makeConstraintsForSubviews() -> Void {

        
        self.iconImage.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(60)
            make.centerX.equalTo(self)
            make.height.width.equalTo(115)
        }
        
        self.middleView.snp.makeConstraints { (make) in
            make.top.equalTo(self.iconImage.snp.bottom).offset(30)
            make.left.right.equalTo(self)
            make.height.equalTo(150)
        }
        
        self.userBgView.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
            make.height.equalTo(65)
            make.width.equalTo(300)
        }
        self.userIcon.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(20)
        }
        self.userField.snp.makeConstraints { (make) in
            make.left.equalTo(self.userIcon.snp.right).offset(20)
            make.top.right.bottom.equalToSuperview()
        }
        
        self.passwordBgView.snp.makeConstraints { (make) in
            make.top.equalTo(self.userBgView.snp.bottom).offset(15)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(self.userBgView)
        }
        self.passwordIcon.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(20)
        }
        self.passwordField.snp.makeConstraints { (make) in
            make.left.equalTo(self.passwordIcon.snp.right).offset(20)
            make.top.right.bottom.equalToSuperview()
        }
        
        
        self.loginButton.snp.makeConstraints { (make) in
            make.top.equalTo(self.middleView.snp.bottom).offset(40)
            make.centerX.equalTo(self)
            make.width.height.equalTo(self.userBgView)
        }
        
        self.versionLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-30)
        }
    }
    
}

