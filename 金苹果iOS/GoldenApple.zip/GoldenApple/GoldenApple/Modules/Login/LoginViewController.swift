//
//  LoginViewController.swift
//  GoldenApple
//
//  Created by User on 27/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import CryptoSwift

class LoginViewController: UIViewController {
    
    let loginApiManager = LoginAPIManager()
    let logoutApiManager = LogoutAPIManager()
    let checkUpdateApiManager = CheckUpdateAPIManager()
    
    fileprivate let contentView: LoginView = {
        return LoginView()
    }()
    
    override func loadView() {
        super.loadView()
        self.view = self.contentView
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.contentView.userField.delegate = self
        self.contentView.passwordField.delegate = self
        self.contentView.loginButton.addTarget(self, action: #selector(loginButtonClick), for: UIControlEvents.touchUpInside)
        
        self.loginApiManager.delegate = self
        self.loginApiManager.paramSource = self
        self.logoutApiManager.delegate = self
        self.logoutApiManager.paramSource = self
        self.checkUpdateApiManager.delegate = self
        self.checkUpdateApiManager.paramSource = self
    
        NotificationCenter.default.addObserver(self, selector: #selector(logout(notice:)), name: Notification.Name.Logout, object: nil)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let user = UserDefaults.standard.value(forKey: LoginAPIManager.kLoginUserParam) as? String
        if user != nil {
            self.contentView.userField.text = user!
        }
        let password = UserDefaults.standard.value(forKey: LoginAPIManager.kLoginPasswordParam) as? String
        if password != nil {
            self.contentView.passwordField.text = password!
        }
        
        self.checkUpdateApiManager.loadData()
    }
    
    @objc fileprivate func loginButtonClick() -> Void {
        
//        self.mainTabBarController()
        
        let account = self.contentView.userField.text
        let password = self.contentView.passwordField.text
        if account == nil || account!.isEmpty {
            GAProgressHUD.showWarning(message: "请输入用户名")
            return
        } else if password == nil || password!.isEmpty {
            GAProgressHUD.showWarning(message: "请输入密码")
            return
        }
        
        self.loginApiManager.loadData()
        GAProgressHUD.showLoading(message: "登录中...")
    }
    
    func logout(notice: Notification) -> Void {
        
        let errorNumber = notice.object as? Int
        if errorNumber != nil && errorNumber! == GAError.ServiceError.forcedExit.rawValue {
            GAAlertController.showAlert("提示", "请登录后访问", nil, "重新登录", cancelCallBack: nil) {
                self.navigationController?.popToViewController(self, animated: true)
            }
        } else {
            GAProgressHUD.showSuccess(message: "成功退出!")
            self.navigationController?.popToViewController(self, animated: true)
            self.logoutApiManager.loadData()
        }
        
        LYCache.default.clean()
        
    }

}

extension LoginViewController: LYAPIManagerCallBackDelegate {
    
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        
        GAProgressHUD.hidHUD()
        
        if manager == self.loginApiManager {
            manager.fetchData(self.loginApiManager)

            UserDefaults.standard.setValue(self.contentView.userField.text!, forKey: LoginAPIManager.kLoginUserParam)
            UserDefaults.standard.setValue(self.contentView.passwordField.text!, forKey: LoginAPIManager.kLoginPasswordParam)
            
            self.mainTabBarController()
        } else if manager == self.logoutApiManager {
            self.navigationController?.popViewController(animated: true)
        } else if manager == self.checkUpdateApiManager {
            guard let updateDict = manager.fetchData(self.checkUpdateApiManager) as? NSDictionary else {
                return
            }
            guard let version = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kVersion) as? Int else {return}
            guard let description = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kDescription) as? String else {return}
            guard let is_force = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kIs_force) as? Int else {return}
            guard let downloadPath = updateDict.value(forKey: CheckUpdateAPIManager.DataKey.kFilename) as? String else {return}
            
            let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! NSString
            if version > currentVersion.integerValue {
                let title = NSString.init(format: "最新版本:%d", version) as String
                let cancelStr = is_force == 0 ? "取消" : nil
                GAAlertController.showAlert(title, description, cancelStr, "立即更新", cancelCallBack: nil, commitCallBack: {
                    let urlStr = "itms-services://?action=download-manifest&url=" + downloadPath
                    guard let url = URL(string: urlStr) else { return }
                    UIApplication.shared.openURL(url)
                    print("update version: ---- \(downloadPath)")
                    exit(EXIT_SUCCESS)
                })
            }
        }
    }
    
}

extension LoginViewController: LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        let userString = self.contentView.userField.text
        let passwordString = self.contentView.passwordField.text
        let passwordParam = (userString!.lowercased() + passwordString!).md5().md5().md5()
        
        if self.loginApiManager == manager {
            let params = [ LoginAPIManager.kLoginUserParam : userString,
                           LoginAPIManager.kLoginPasswordParam : passwordParam]
            return params as NSDictionary
        } else if manager == self.logoutApiManager {
            return [GASessionManager.UserInfoKey.kToken : GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken] as! String]
        }
        
        return nil
    }
    
    
}

extension LoginViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == self.contentView.userField {
            self.contentView.passwordField.becomeFirstResponder()
        } else if textField == self.contentView.passwordField {
            self.contentView.passwordField.resignFirstResponder()
            self.loginButtonClick()
        }
        
        return true
    }
    
}

// MARK: - fileprivte methods
extension LoginViewController {
    
    func mainTabBarController() -> Void {
        
        let lotteryHall = LotteryHallViewController()
        let lotteryHallNavi = GANavigationController(rootViewController: lotteryHall)
        lotteryHallNavi.navigationBar.barTintColor = kGANavigationBackgroundColor
        lotteryHallNavi.tabBarItem = UITabBarItem(title: "购彩大厅", image: UIImage(named: "tap_gcdt"), selectedImage: nil)
        
        let lotteryTrend = LotteryTrendViewController()
        let lotteryTrendNavi = GANavigationController(rootViewController: lotteryTrend)
        lotteryTrendNavi.navigationBar.barTintColor = kGANavigationBackgroundColor
        lotteryTrendNavi.tabBarItem = UITabBarItem(title: "开奖走势", image: UIImage(named: "tap_kjzs"), selectedImage: nil)
        
        let gameRecord = GameRecordViewController()
        let gameRecordNavi = GANavigationController(rootViewController: gameRecord)
        gameRecordNavi.navigationBar.barTintColor = kGANavigationBackgroundColor
        gameRecordNavi.tabBarItem = UITabBarItem(title: "游戏记录", image: UIImage(named: "tap_yxjl"), selectedImage: nil)
        
        let accountCenter = AccountCenterViewController()
        let accountCenterNavi = GANavigationController(rootViewController: accountCenter)
        accountCenterNavi.navigationBar.barTintColor = kGANavigationBackgroundColor
        accountCenterNavi.tabBarItem = UITabBarItem(title: "账号中心", image: UIImage(named: "tap_zhzx"), selectedImage: nil)
        
        let mainTabBarController = UITabBarController()
        mainTabBarController.tabBar.barTintColor = kGATabbarBackgroundColor
        mainTabBarController.tabBar.tintColor = UIColor.white
        mainTabBarController.tabBar.isTranslucent = false
        let selectedImage = UIImage(named: "menu-press-background")
        mainTabBarController.tabBar.selectionIndicatorImage = selectedImage!.resizableImage(withCapInsets: UIEdgeInsetsMake(selectedImage!.size.height/2, selectedImage!.size.height/2, selectedImage!.size.width/2, selectedImage!.size.width/2))
        if #available(iOS 10.0, *) {
            mainTabBarController.tabBar.unselectedItemTintColor = kGATabbarUnSelectedFontColor
        } else {
            // Fallback on earlier versions
        }
        mainTabBarController.viewControllers = [lotteryHallNavi, lotteryTrendNavi, gameRecordNavi, accountCenterNavi];
//        UIApplication.shared.keyWindow?.rootViewController = mainTabBarController
        self.navigationController?.pushViewController(mainTabBarController, animated: true)
//        self.present(mainTabBarController, animated: true, completion: nil)
    }
}

