//
//  LoginAPIManager.swift
//  GoldenApple
//
//  Created by User on 27/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LoginAPIManager: GAAPIBaseManager {
    
    static let kLoginUserParam = "username"
    static let kLoginPasswordParam = "password"
    
}

extension LoginAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=User&action=login"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
//        resultParams["terminal_id"] = "2" //android
        resultParams["terminal_id"] = "6"   //ios
        
        return resultParams as NSDictionary
    }
    
}

extension LoginAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        if let dict = data.object(forKey: "data") as? NSDictionary {
            GASessionManager.default.userinformation = dict
            return dict
        }
        
        return nil
    }
}
