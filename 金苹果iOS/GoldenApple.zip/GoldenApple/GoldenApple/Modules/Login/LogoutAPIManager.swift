//
//  LogoutAPIManager.swift
//  GoldenApple
//
//  Created by User on 17/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LogoutAPIManager: GAAPIBaseManager {
    
    override init() {
        super.init()
    }
}

extension LogoutAPIManager: LYAPIManager {
    
    func methodName() -> NSString {
        return "service?packet=User&action=logout"
    }
    
    func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}

extension LogoutAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        guard let resultDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        
        return resultDict
    }
}
