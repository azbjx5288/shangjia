//
//  GameRecordViewController.swift
//  GoldenApple
//
//  Created by User on 16/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class GameRecordViewController: UIViewController {
    
    var myView : GameRecordView?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setMyView()
        self.setChildControllers()
    }
    override func viewDidAppear(_ animated: Bool) {
        let index = self.myView?.segmentedView.index
        self.reloadData(index: index!)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isTranslucent = false
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    
    private func setMyView() {
        self.view = GameRecordView()
        self.myView = self.view as? GameRecordView
        self.myView?.segmentedView.delegate = self
        self.myView?.scrollView.delegate = self
    }
    
    private func setChildControllers() {
        let bettingVC = BettingRecordViewController()
        let zhuihaoVC = ZhuiHaoRecordViewController()
        self.addChildViewController(bettingVC)
        self.addChildViewController(zhuihaoVC)
        for i in 0...self.childViewControllers.count - 1 {
            self.myView?.contentView.addSubview(self.childViewControllers[i].view)
            let left = CGFloat(i) * UIScreen.main.bounds.size.width
            self.childViewControllers[i].view.snp.makeConstraints({ (make) in
                make.top.height.equalTo((self.myView?.contentView)!)
                make.width.equalTo((self.myView?.scrollView)!)
                make.left.equalTo((self.myView?.contentView)!).offset(left)
            })
        }
        self.myView?.contentView.snp.makeConstraints({ (make) in
            make.right.equalTo(zhuihaoVC.view)
        })
    }
    
    fileprivate func reloadData(index : Int) {
        let vc = self.childViewControllers[index]
        if vc.isKind(of: BettingRecordViewController.self) {
            let bettingVC = vc as! BettingRecordViewController
            bettingVC.reloadData()
        } else if vc.isKind(of: ZhuiHaoRecordViewController.self) {
            let zhuiHaoVC = vc as! ZhuiHaoRecordViewController
            zhuiHaoVC.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}

extension GameRecordViewController : GameRecordSegmentedViewDelegate {
    func selectedItem(index: Int) {
        let offsetX = CGFloat(index) * UIScreen.main.bounds.size.width
        self.myView?.scrollView.setContentOffset(CGPoint.init(x: offsetX , y: 0), animated: true)
    }
}
extension GameRecordViewController : UIScrollViewDelegate {
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        let index = scrollView.contentOffset.x / UIScreen.main.bounds.size.width
        self.reloadData(index: Int(index))
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let index = scrollView.contentOffset.x / UIScreen.main.bounds.size.width
        self.myView?.segmentedView.index = Int(index)
        self.reloadData(index: Int(index))
    }
    
}
