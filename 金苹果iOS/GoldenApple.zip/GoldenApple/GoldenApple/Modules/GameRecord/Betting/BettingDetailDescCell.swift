//
//  BettingDetailDescCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/6.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingDetailDescCell: UITableViewCell {

    private var timeLB : UILabel?
    private var numberLB : UILabel?
    private var prizeGroupLB: UILabel?
    private var modeLB: UILabel?
    private var amountLB : UILabel?
    
    static func cellWithTableView(tableView : UITableView) -> BettingDetailDescCell {
        let cellIdentifier = "BettingDetailDescCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? BettingDetailDescCell
        if cell == nil {
            cell = BettingDetailDescCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    private func setSubViews() {
        
        let timeTitleLB = UILabel()
        timeTitleLB.text = "投注时间: "
        timeTitleLB.font = UIFont.systemFont(ofSize: 16)
        timeTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(timeTitleLB)
        let timeTitleSize = timeTitleLB.sizeThatFits(CGSize.init(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude))
        timeTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.top.equalTo(self.contentView).offset(20)
            make.width.equalTo(timeTitleSize.width)
        })
        
        self.timeLB = UILabel()
        self.timeLB?.text = "0000"
        self.timeLB?.font = UIFont.systemFont(ofSize: 16)
        self.timeLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.timeLB!)
        self.timeLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB.snp.right)
            make.centerY.equalTo(timeTitleLB)
        })
        
        let prizeGroupTitleLB = UILabel()
        prizeGroupTitleLB.text = "奖  金  组: "
        prizeGroupTitleLB.font = UIFont.systemFont(ofSize: 16)
        prizeGroupTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(prizeGroupTitleLB)
        let prizeGroupTitleSize = timeTitleLB.sizeThatFits(CGSize.init(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude))
        prizeGroupTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB)
            make.top.equalTo(timeTitleLB.snp.bottom).offset(10)
            make.width.equalTo(prizeGroupTitleSize.width)
        })
        
        self.prizeGroupLB = UILabel()
        self.prizeGroupLB?.text = "元"
        self.prizeGroupLB?.numberOfLines = 0
        self.prizeGroupLB?.font = UIFont.systemFont(ofSize: 16)
        self.prizeGroupLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.prizeGroupLB!)
        self.prizeGroupLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(prizeGroupTitleLB.snp.right)
            make.right.equalTo(self.contentView).offset(-15)
            make.top.equalTo((self.timeLB?.snp.bottom)!).offset(10)
        })
        
        let modeTitleLB = UILabel()
        modeTitleLB.text = "投注模式: "
        modeTitleLB.font = UIFont.systemFont(ofSize: 16)
        modeTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(modeTitleLB)
        let modeTitleSize = timeTitleLB.sizeThatFits(CGSize.init(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude))
        modeTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB)
            make.top.equalTo(prizeGroupTitleLB.snp.bottom).offset(10)
            make.width.equalTo(modeTitleSize.width)
        })
        
        self.modeLB = UILabel()
        self.modeLB?.text = "0000"
        self.modeLB?.numberOfLines = 0
        self.modeLB?.font = UIFont.systemFont(ofSize: 16)
        self.modeLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.modeLB!)
        self.modeLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(modeTitleLB.snp.right)
            make.right.equalTo(self.contentView).offset(-15)
            make.centerY.equalTo(modeTitleLB)
        })
        
        let numberTitleLB = UILabel()
        numberTitleLB.text = "注单编号: "
        numberTitleLB.font = UIFont.systemFont(ofSize: 16)
        numberTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(numberTitleLB)
        let numberTitleSize = numberTitleLB.sizeThatFits(CGSize.init(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude))
        numberTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB)
            make.top.equalTo(modeTitleLB.snp.bottom).offset(10)
            make.width.equalTo(numberTitleSize.width)
        })
        
        self.numberLB = UILabel()
        self.numberLB?.text = "0000"
        self.numberLB?.numberOfLines = 0
        self.numberLB?.font = UIFont.systemFont(ofSize: 16)
        self.numberLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.numberLB!)
        self.numberLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(numberTitleLB.snp.right)
            make.right.equalTo(self.contentView).offset(-15)
            make.centerY.equalTo(numberTitleLB)
        })
        
        let amountTitleLB = UILabel()
        amountTitleLB.text = "投注金额: "
        amountTitleLB.font = UIFont.systemFont(ofSize: 16)
        amountTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(amountTitleLB)
        let amountTitleSize = timeTitleLB.sizeThatFits(CGSize.init(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude))
        amountTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB)
            make.top.equalTo((self.numberLB?.snp.bottom)!).offset(10)
            make.width.equalTo(amountTitleSize.width)
        })
        
        self.amountLB = UILabel()
        self.amountLB?.font = UIFont.systemFont(ofSize: 16)
        self.amountLB?.textColor = kGAFontRedColor
        self.contentView.addSubview(self.amountLB!)
        self.amountLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(amountTitleLB.snp.right)
            make.centerY.equalTo(amountTitleLB)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
            make.top.equalTo((self.amountLB?.snp.bottom)!).offset(20)
        }
    }
    
    public func setData(dict : NSDictionary) {
        let time = dict.object(forKey: BettingDetailAPIManager.DataKey.kTime) as? String
        self.timeLB?.text = time!
        
        let prizeGroup = dict.object(forKey: BettingDetailAPIManager.DataKey.kPrizeGroup) as? String
        self.prizeGroupLB?.text = prizeGroup!
        
        var coefficient = dict.object(forKey: BettingDetailAPIManager.DataKey.kCoefficient) as? String
        coefficient = self.covertCoefficient(coefficient: coefficient!)
        self.modeLB?.text = coefficient
        
        let serialNumber = dict.object(forKey: BettingDetailAPIManager.DataKey.kSerialNumber) as? String
        self.numberLB?.text = serialNumber!
    
        let amount = dict.object(forKey: BettingDetailAPIManager.DataKey.kAmount) as? String
        self.amountLB?.text = amount! + "元"
    }
    
    private func covertCoefficient(coefficient : String)-> String {
        switch coefficient {
            case "1.000":
                return "2元"
            case "0.500":
                return "1元"
            case "0.100":
                return "2角"
            case "0.050":
                return "1角"
            case "0.010":
                return "2分"
            case "0.005":
                return "1分"
            case "0.001":
                return "2厘"
            default:
                return "2元"
        }
    }
}


