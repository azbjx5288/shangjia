//
//  BettingDetailViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/6.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingDetailViewController: UIViewController {
    var myView : BettingDetailView?
    var detailDict : NSDictionary?
    let apiManager = BettingDetailAPIManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNaviBar()
        
        self.view = BettingDetailView()
        self.myView = self.view as? BettingDetailView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
    
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.apiType = .getDetail
        self.apiManager.loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func setNaviBar() {
        
        self.navigationItem.title = "投注详情"
        
        let status = self.detailDict?.object(forKey: BettingRecordAPIManager.DataKey.kStatus) as? Int
        
        if status == 0 {
            let cancelBtn : UIButton = UIButton.init(type: .custom)
            cancelBtn.titleLabel?.font = UIFont.systemFont(ofSize: 18)
            cancelBtn.setTitle("撤单", for: .normal)
            cancelBtn.setTitleColor(.white, for: .normal)
            cancelBtn.setTitleColor(.gray, for: .highlighted)
            cancelBtn.frame = CGRect.init(x: 0, y: 0, width: 50, height: 30)
            cancelBtn.addTarget(self, action: #selector(didClickCancel), for: .touchUpInside)
            let rightItem : UIBarButtonItem = UIBarButtonItem.init(customView: cancelBtn)
            self.navigationItem.rightBarButtonItem = rightItem;
        }
    }
    
    @objc func didClickBottomBtn() {
        let lotteryId = self.detailDict?.object(forKey: BettingDetailAPIManager.DataKey.kLottery_id) as? Int
        guard let lottery = GACacheManager.default.getLotteryDictionary(lotteryId: lotteryId!) else {return}
        let name = lottery.object(forKey: "name") as? String
        if name == nil {
            GAAlertController .showAlert(title: "温馨提示", message: "苹果手机端APP暂未开放该彩种!", delegate: nil, cancelButtonTitle: nil, commitButtonTitle: "确定");
            return
        }
        let lotteryPlaying = LotteryPlayingViewController(lotteryDict: lottery)
        lotteryPlaying.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(lotteryPlaying, animated: true)
    }
    
    @objc func didClickCancel() {
        GAAlertController.showAlert(title: "撤单确认", message: "您确定要撤单吗?", delegate: self, cancelButtonTitle: "取消", commitButtonTitle: "确定")
    }
}

extension BettingDetailViewController: UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = BettingDetailHeaderCell.cellWithTableView(tableView: tableView)
            if self.apiManager.detailDict != nil {cell.setData(dict: self.detailDict!)}
            return cell
        case 1:
            let cell = BettingDetailDescCell.cellWithTableView(tableView: tableView)
            if self.apiManager.detailDict != nil {cell.setData(dict: self.detailDict!)}
            return cell
        case 2:
            let cell = BettingDetailWinCell.cellWithTableView(tableView: tableView)
            if self.apiManager.detailDict != nil {cell.setData(dict: self.detailDict!)}
            return cell
        case 3:
            let cell = BettingDetailNumberCell.cellWithTableView(tableView: tableView)
            if self.apiManager.detailDict != nil {cell.setData(dict: self.detailDict!,dict1 : self.apiManager.detailDict!)}
            return cell
        default:
            return UITableViewCell()
        }
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 3 {
            let headerView = UIView()
            headerView.backgroundColor = .white
            let titleLB = UILabel()
            titleLB.text = "投注号码"
            titleLB.font = UIFont.systemFont(ofSize: 16)
            titleLB.textColor = kGAFontBlackColor
            headerView.addSubview(titleLB)
            titleLB.snp.makeConstraints({ (make) in
                make.left.equalTo(headerView).offset(15)
                make.centerY.equalTo(headerView)
            })
            
            let line = UIView()
            line.backgroundColor = kGASerperatorLineGrayColor
            headerView.addSubview(line)
            line.snp.makeConstraints { (make) in
                make.bottom.left.right.equalTo(headerView)
                make.height.equalTo(1)
            }
            return headerView
        } else { return nil }
    }
    
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        switch indexPath.section {
//        case 0:
//            return 90
//        case 1:
//            return 140
//        case 2:
//            return 100
//        case 3:
//            if tableView.cellForRow(at: indexPath) != nil {
//                let cell : BettingDetailNumberCell = (tableView.cellForRow(at: indexPath) as? BettingDetailNumberCell)!
//                return cell.cellHeight
//            } else {
//                return 150
//            }
////            guard let cell : BettingDetailNumberCell = tableView.cellForRow(at: indexPath) as? BettingDetailNumberCell else {return 150}
//            
//        default:
//            return 44
//        }
//    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 3 {
            return 60
        } else { return 0 }
    }
}

extension BettingDetailViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        var message : String = ""
        switch self.apiManager.apiType {
        case .getDetail:
            message = "正在加载..."
        case .cancel:
            message = "正在撤单,请稍候..."
        }
        GAProgressHUD.showLoading(message: message)
    
        let bettingID = self.detailDict?.object(forKey: BettingRecordAPIManager.DataKey.kId) as? Int
        let params = ["id" : bettingID]
        return params as NSDictionary
    }
    
}
extension BettingDetailViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        manager.fetchData(self.apiManager)
        
        switch self.apiManager.apiType {
        case .getDetail:
            self.myView?.tableView.reloadData()
        case .cancel:
            GAProgressHUD.showSuccess(message: "撤单成功!")
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {

        GAProgressHUD.hidHUD()
        switch self.apiManager.apiType {
        case .getDetail:
            self.myView?.tableView.reloadData()
            break
        case .cancel:
            break
        }
    }
}

extension BettingDetailViewController: GAAlertDelegate {
    func alertCancelButtonClicked() {
        
    }
    
    func alertCommitButtonClicked() {
        self.apiManager.apiType = .cancel
        self.apiManager.loadData()
    }
}
