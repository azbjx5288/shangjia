//
//  BettingDetailWinCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/6.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingDetailWinCell: UITableViewCell {

    private var issusLB : UILabel?
    private var winNumberView: UIView?
    fileprivate var lotteryId: Int?
    
    static func cellWithTableView(tableView : UITableView) -> BettingDetailWinCell {
        let cellIdentifier = "BettingDetailWinCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? BettingDetailWinCell
        if cell == nil {
            cell = BettingDetailWinCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    private func setSubViews() {
        let titleLB = UILabel()
        titleLB.text = "开奖号码"
        titleLB.font = UIFont.systemFont(ofSize: 16)
        titleLB.textColor = kGAFontBlackColor
        self.contentView.addSubview(titleLB)
        titleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.top.equalTo(self.contentView).offset(20)
        })
        
        self.issusLB = UILabel()
        self.issusLB?.text = "奖期"
        self.issusLB?.font = UIFont.systemFont(ofSize: 14)
        self.issusLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.issusLB!)
        self.issusLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(titleLB.snp.right).offset(20)
            make.centerY.equalTo(titleLB)
        })
        
        self.winNumberView = UIView()
        self.contentView.addSubview(self.winNumberView!)
        self.winNumberView?.snp.makeConstraints({ (make) in
            make.top.equalTo(titleLB.snp.bottom).offset(10)
            make.left.equalTo(titleLB)
            make.bottom.equalTo(self.contentView).offset(-20)
            make.right.equalTo(self.contentView).offset(-15)
            make.height.equalTo(40)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(5)
        }
        
    }
    
    public func setData(dict : NSDictionary) {
        let issus = dict.object(forKey: BettingDetailAPIManager.DataKey.kIssue) as? String
        self.issusLB?.text = issus! + "期"
        let winNumber = dict.object(forKey: BettingDetailAPIManager.DataKey.kWinningNumber) as? String
        self.lotteryId = dict.object(forKey: BettingDetailAPIManager.DataKey.kLottery_id) as? Int;
        
        if winNumber != nil && !((winNumber?.isEmpty)!) {
            var numberArray : NSArray?
            numberArray = winNumber?.components(separatedBy: " ") as NSArray?
            //如果是单号
            if (numberArray?.count)! < 2 {
                numberArray =  winNumber?.characters
                    .map{String($0)}
                    .filter{ $0 != nil } as NSArray?
            }
            self.setNumberView(numbers: numberArray! as NSArray,isOpen: true)
        } else {
            let numberArray = ["-","-","-","-","-",]
            self.setNumberView(numbers: numberArray as NSArray,isOpen: false)
        }
    }
    
    private func setNumberView(numbers : NSArray,isOpen : Bool) {
        
        guard let lottery = GACacheManager.default.getLotteryDictionary(lotteryId: self.self.lotteryId!) else {return}
        let series_id = lottery.object(forKey: "series_id") as? UInt
        //如果是快三，则显示骰子
        if (series_id == eLotterySeriesType.eK3.rawValue) {
            let k3SpecialView : K3LastWinNumberView = K3LastWinNumberView.init(frame: CGRect.zero)
            self.winNumberView?.addSubview(k3SpecialView)
            k3SpecialView.setSubviewsConstrain(leftView: self.winNumberView!,centerYView: self.winNumberView!)
            k3SpecialView.setTitles(numbers: numbers)
        } else if eLotterySeriesType.eKL.rawValue == series_id {
            let mutiNumberView = MutiLastWinNumberView(numberArray: numbers as! [NSString], maxViewWidth: Double(self.width))
            self.winNumberView?.addSubview(mutiNumberView)
            let viewHeight = mutiNumberView.setSubviewsConstrain()
            self.winNumberView?.snp.updateConstraints({ (make) in
                make.height.equalTo(viewHeight)
            })
        } else {
            let normalNumberView : NormalLastWinNumberView = NormalLastWinNumberView.init(frame: CGRect.zero, numberArray: numbers as! [NSString])
            self.winNumberView?.addSubview(normalNumberView)
            normalNumberView.setSubviewsConstrain()
        }
        
    }

}
