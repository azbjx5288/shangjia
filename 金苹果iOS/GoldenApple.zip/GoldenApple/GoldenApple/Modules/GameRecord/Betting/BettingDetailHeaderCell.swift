//
//  BettingDetailHeaderCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/6.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingDetailHeaderCell: UITableViewCell {

    private var iconView : UIImageView?
    private var nameLB : UILabel?
    private var issusLB : UILabel?
    private var statusLB : UILabel?
    
    static func cellWithTableView(tableView : UITableView) -> BettingDetailHeaderCell {
        let cellIdentifier = "BettingDetailHeaderCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? BettingDetailHeaderCell
        if cell == nil {
            cell = BettingDetailHeaderCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.iconView = UIImageView()
        self.iconView?.image = UIImage.init(named: "jpgcz")
        self.contentView.addSubview(self.iconView!)
        self.iconView?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.top.equalTo(self.contentView).offset(20)
            make.bottom.equalTo(self.contentView).offset(-20)
            make.width.height.equalTo(60)
        })
        
        self.nameLB = UILabel()
        self.nameLB?.numberOfLines = 0
        self.nameLB?.text = "彩种名称"
        self.nameLB?.font = UIFont.systemFont(ofSize: 19)
        self.nameLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.nameLB!)
        self.nameLB?.snp.makeConstraints({ (make) in
            make.left.equalTo((self.iconView?.snp.right)!).offset(20)
            make.top.equalTo((self.iconView)!).offset(5)
        })
        
        self.issusLB = UILabel()
        self.issusLB?.numberOfLines = 0
        self.issusLB?.text = "奖期"
        self.issusLB?.font = UIFont.systemFont(ofSize: 16)
        self.issusLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.issusLB!)
        self.issusLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.nameLB!)
            make.bottom.equalTo((self.iconView)!).offset(-5)
            make.width.equalTo(50)
        })
        
        self.statusLB = UILabel()
        self.statusLB?.numberOfLines = 0
        self.statusLB?.textAlignment = .right
        self.statusLB?.text = "状态"
        self.statusLB?.font = UIFont.systemFont(ofSize: 16)
        self.statusLB?.textColor = kGAFontRedColor
        self.contentView.addSubview(self.statusLB!)
        self.statusLB?.snp.makeConstraints({ (make) in
            make.right.equalTo(self.contentView).offset(-15)
            make.left.equalTo((self.issusLB?.snp.right)!).offset(10)
            make.centerY.equalTo(self.contentView)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
    }
    public func setData(dict : NSDictionary) {
        
        let lotteryId = dict.object(forKey: BettingDetailAPIManager.DataKey.kLottery_id) as? Int
        
        let icon = GACacheManager.default.getLotteryIcon(lotteryId:lotteryId!)
        self.iconView?.image = UIImage.init(named: icon!)
        
        let name = dict.object(forKey: BettingDetailAPIManager.DataKey.kName) as? String
        (name != nil) ? (self.nameLB?.text = name) : (self.nameLB?.text = ("彩种名称" as String))
        
        let issus = dict.object(forKey: BettingDetailAPIManager.DataKey.kIssue) as? String
        self.issusLB?.text = issus! + "期"
        let issusSize = self.issusLB?.sizeThatFits(CGSize.init(width: CGFloat.greatestFiniteMagnitude, height: CGFloat.greatestFiniteMagnitude))
        self.issusLB?.snp.updateConstraints({ (make) in
            make.width.equalTo((issusSize?.width)!)
        })
        
        let prize = dict.object(forKey: BettingDetailAPIManager.DataKey.kPrize) as? String
        let status = dict.object(forKey: BettingDetailAPIManager.DataKey.kStatus) as? Int
        
        if prize != nil {
            self.statusLB?.text = "中奖金额" + prize! + "元"
        } else {
            self.statusLB?.text = self.getStatusCname(status: status!)
        }
    }
    
    private func getStatusCname(status : Int)-> String {
        var statusStr = ""
        switch status {
        case 0:
            statusStr = "待开奖"
            break
        case 1:
            statusStr = "已撤销"
            break
        case 2:
            statusStr = "未中奖"
            break
        case 3:
            statusStr = "已中奖"
            break
        case 4:
            statusStr = "已派奖"
            break
        case 5:
            statusStr = "系统撤销"
            break
        default:
            statusStr = "未知"
        }
        return statusStr
    }

}
