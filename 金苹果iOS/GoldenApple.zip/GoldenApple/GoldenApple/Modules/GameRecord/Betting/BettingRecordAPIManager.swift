//
//  BettingRecordAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/3.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingRecordAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        static let kIssue = "issue"
        static let kId = "id"
        static let kLotteryid = "lottery_id"
        static let kTraceid = "trace_id"
        static let kAmount = "amount"
        static let kPrize = "prize"
        static let kName = "lottery_name"
        static let kStatus = "status"
    }
    
    var page = 1
    let pagesize = 10
    var lottery_id = "-1"
    var time = "今天"
    var status = "-1"
    var isRefresh = true
    
    var recordDictList = NSArray() as! [NSDictionary]
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension BettingRecordAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Game&action=getProjectList"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        
        if self.isRefresh {self.page = 1}
            
        resultParams["page"] = self.page
        resultParams["pagesize"] = self.pagesize
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        var currentDate = Date()
        var timeIntervalNow = currentDate.timeIntervalSince1970
        //默认当天
        switch time {
        case "今天":
            timeIntervalNow -= 24 * 3600
            break
        case "昨天":
            timeIntervalNow -= 24 * 3600 * 2
            currentDate = currentDate.addingTimeInterval(-24 * 3600)
            break
        case "近7天":
            timeIntervalNow -= 24 * 3600 * 7
            break
        case "当月":
            timeIntervalNow = TimeUtils.startOfCurrentMonth().timeIntervalSince1970
            break
        default:
            timeIntervalNow -= 24 * 3600
            break
        }
        
        let beginDate = Date.init(timeIntervalSince1970: timeIntervalNow)
        let start_time = dateFormatter.string(from: beginDate) + " 00:00:00"
        let end_time = dateFormatter.string(from: currentDate) + " 23:59:59"
        
        resultParams["lottery_id"] = lottery_id
        resultParams["status"] = status
        resultParams["start_time"] = start_time
        resultParams["end_time"] = end_time
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}



extension BettingRecordAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {

        guard let recordList = data.object(forKey: "data") as? NSArray else { return NSArray() }
        
        if self.isRefresh {
            self.recordDictList = (recordList as! [NSDictionary])
        } else {
            let tempArray = NSMutableArray.init(array: self.recordDictList)
            tempArray.addObjects(from: recordList as! [NSDictionary])
            self.recordDictList = tempArray.copy() as! [NSDictionary]
        }
        if (recordList as! [NSDictionary]).count > 0 {
            self.page = self.page + 1
        }
        return recordList

    }
}
