//
//  BettingDetailAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/6.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingDetailAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kLottery_id = "lottery_id"
        static let kName = "lottery_name"
        static let kIssue = "issue"
        static let kWay = "way"
        static let kSerialNumber = "serial_number"
        static let kMultiple = "multiple"
        static let kWinningNumber = "winning_number"
        static let kBetNumber = "bet_number"
        static let kAmount = "amount"
        static let kPrize = "prize"
        static let kPrizeGroup = "prize_group"
        static let kTime = "bought_at"
        static let kStatus = "status"
        static let kCoefficient = "coefficient"
    }
    
    enum BettindDetailAPIType {
        case getDetail
        case cancel
    }
    
    var detailDict : NSDictionary?
    var apiType : BettindDetailAPIType = .getDetail
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension BettingDetailAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        switch self.apiType {
        case .getDetail:
            return "service?packet=Game&action=getProjectDetail"
        case.cancel:
            return "service?packet=Game&action=dropProject"
        }
        
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        switch self.apiType {
        case .getDetail:
            return .get
        case.cancel:
            return .post
        }
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}

extension BettingDetailAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        switch self.apiType {
        case .getDetail:
            guard let detailDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
            self.detailDict = detailDict
            return detailDict
        case .cancel:
            self.detailDict = nil
            return data
        }
        
        
    }
}

