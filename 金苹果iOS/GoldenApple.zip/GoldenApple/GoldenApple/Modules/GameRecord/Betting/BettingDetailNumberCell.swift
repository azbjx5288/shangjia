//
//  BettingDetailNumberCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/6.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingDetailNumberCell: UITableViewCell {

    private var wayLB : UILabel?
    private var multipleLB : UILabel?
    private var betNumberLB : UITextView?
    private var amountLB : UILabel?
 
    static func cellWithTableView(tableView : UITableView) -> BettingDetailNumberCell {
        let cellIdentifier = "BettingDetailWinCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? BettingDetailNumberCell
        if cell == nil {
            cell = BettingDetailNumberCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    private func setSubViews() {
        self.wayLB = UILabel()
        self.wayLB?.numberOfLines = 0
        self.wayLB?.text = "投注方式"
        self.wayLB?.font = UIFont.systemFont(ofSize: 16)
        self.wayLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.wayLB!)
        self.wayLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.top.equalTo(self.contentView).offset(20)
            make.width.equalTo(self.contentView).multipliedBy(0.3);
        })
        
        self.amountLB = UILabel()
        self.amountLB?.numberOfLines = 0
        self.amountLB?.text = "投注金额"
        self.amountLB?.font = UIFont.systemFont(ofSize: 16)
        self.amountLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.amountLB!)
        
        self.multipleLB = UILabel()
        self.multipleLB?.numberOfLines = 0
        self.multipleLB?.text = "1倍"
        self.multipleLB?.font = UIFont.systemFont(ofSize: 16)
        self.multipleLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.multipleLB!)
        self.multipleLB?.snp.makeConstraints({ (make) in
            make.right.equalTo(self.contentView).offset(-15)
            make.left.equalTo((self.amountLB?.snp.right)!).offset(10)
            make.centerY.equalTo(self.wayLB!)
        })
        
        self.amountLB?.snp.makeConstraints({ (make) in
            make.left.equalTo((self.wayLB?.snp.right)!).offset(10)
            make.width.equalTo(self.contentView).multipliedBy(0.4)
            make.centerY.equalTo(self.wayLB!)
        })
        
        self.betNumberLB = UITextView()
        self.betNumberLB?.isUserInteractionEnabled = false
        self.betNumberLB?.text = "投注号码"
        self.betNumberLB?.font = UIFont.systemFont(ofSize: 16)
        self.betNumberLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.betNumberLB!)
        self.betNumberLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.wayLB!)
            make.top.equalTo((self.amountLB?.snp.bottom)!).offset(20)
            make.width.equalTo(UIScreen.main.bounds.size.width - 30)
            make.height.equalTo(0)
            make.bottom.equalTo(self.contentView).offset(-20)
        })
        
    }
    
    public func setData(dict : NSDictionary,dict1 : NSDictionary) {
        let way = dict1.object(forKey: BettingDetailAPIManager.DataKey.kWay) as? String
        self.wayLB?.text = way
        
        let multiple = dict1.object(forKey: BettingDetailAPIManager.DataKey.kMultiple) as? Int
        self.multipleLB?.text = "\(multiple ?? 1)" + "倍"
        
        let coefficient = dict.object(forKey: BettingDetailAPIManager.DataKey.kCoefficient) as? String
        let amount = dict1.object(forKey: BettingDetailAPIManager.DataKey.kAmount) as? String
        let count = NSString.init(format: "%0.lf", Double(amount!)! / (Double(coefficient!)! * 2))
        self.amountLB?.text = String(count) + "注  " + amount! + "元"
        
        let betNumber = dict1.object(forKey: BettingDetailAPIManager.DataKey.kBetNumber) as? String
        self.betNumberLB?.text = betNumber
        let size = self.betNumberLB?.sizeThatFits(CGSize.init(width: UIScreen.main.bounds.size.width - 30, height: CGFloat.greatestFiniteMagnitude))
        self.betNumberLB?.snp.updateConstraints({ (make) in
            make.height.equalTo(((size?.height)! + 5))
        })
    }
}
