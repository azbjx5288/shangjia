//
//  BettingRecordCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/3.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class BettingRecordCell: UITableViewCell {

    private var nameLB : UILabel?
    private var issusLB : UILabel?
    private var amountLB : UILabel?
    private var statusLB : UILabel?
    
    static func cellWithTableView(tableView : UITableView) -> BettingRecordCell {
        let cellIdentifier = "BettingRecordCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? BettingRecordCell
        if cell == nil {
            cell = BettingRecordCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.nameLB = UILabel()
        self.nameLB?.font = UIFont.systemFont(ofSize: 16)
        self.nameLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.nameLB!)
        self.nameLB?.snp.makeConstraints({ (make) in
            make.top.equalTo(self.contentView).offset(20)
            make.left.equalTo(self.contentView).offset(15)
        })
        
        self.issusLB = UILabel()
        self.issusLB?.font = UIFont.systemFont(ofSize: 14)
        self.issusLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.issusLB!)
        self.issusLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.nameLB!)
            make.left.equalTo((self.nameLB?.snp.right)!).offset(10)
        })
        
        self.amountLB = UILabel()
        self.amountLB?.font = UIFont.systemFont(ofSize: 14)
        self.amountLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.amountLB!)
        self.amountLB?.snp.makeConstraints({ (make) in
            make.left.equalTo((self.nameLB)!)
            make.bottom.equalTo(self.contentView).offset(-20)
        })
        
        let indicatorView = UIImageView()
        indicatorView.image = UIImage.init(named: "arrowright")
        indicatorView.contentMode = .center
        self.contentView.addSubview(indicatorView)
        indicatorView.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView).offset(-15)
            make.centerY.equalTo(self.amountLB!)
            make.height.equalTo(30)
            make.width.equalTo(15)
        }
        
        self.statusLB = UILabel()
        self.statusLB?.font = UIFont.systemFont(ofSize: 16)
        self.statusLB?.textColor = kGAFontRedColor
        self.contentView.addSubview(self.statusLB!)
        self.statusLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.amountLB!)
            make.right.equalTo(indicatorView.snp.left).offset(-10)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
    }
    
    public func setData(dict : NSDictionary) {
        let name = dict.object(forKey: BettingRecordAPIManager.DataKey.kName) as? String
        (name != nil) ? (self.nameLB?.text = name) : (self.nameLB?.text = ("彩种名称" as String))
        
        let issus = dict.object(forKey: BettingRecordAPIManager.DataKey.kIssue) as? String
        self.issusLB?.text = issus! + "期"
        
        let amount = dict.object(forKey: BettingRecordAPIManager.DataKey.kAmount) as? String
        self.amountLB?.text = amount! + "元"
        
        let prize = dict.object(forKey: BettingRecordAPIManager.DataKey.kPrize) as? String
        let status = dict.object(forKey: BettingRecordAPIManager.DataKey.kStatus) as? Int
        
        if prize != nil {
            self.statusLB?.text = prize! + "元"
        } else {
            self.statusLB?.text = self.getStatusCname(status: status!)
        }
    }
    
    private func getStatusCname(status : Int)-> String {
        var statusStr = ""
        switch status {
        case 0:
            statusStr = "待开奖"
            break
        case 1:
            statusStr = "已撤销"
            break
        case 2:
            statusStr = "未中奖"
            break
        case 3:
            statusStr = "已中奖"
            break
        case 4:
            statusStr = "已派奖"
            break
        case 5:
            statusStr = "系统撤销"
            break
        default:
            statusStr = "未知"
        }
        return statusStr
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}


