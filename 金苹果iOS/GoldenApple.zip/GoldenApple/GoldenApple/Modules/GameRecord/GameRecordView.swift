//
//  GameRecordView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/2.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class GameRecordView: UIView {

    public lazy var scrollView : UIScrollView = {
        ()-> UIScrollView in
        let temp = UIScrollView()
        temp.isPagingEnabled = true
        return temp
    }()
    
    public lazy var contentView : UIView = {
        ()-> UIView in
        return UIView()
    }()
    
    public lazy var segmentedView : GameRecordSegmentedView = {
        ()-> GameRecordSegmentedView in
        let temp = GameRecordSegmentedView.init(titles: ["投注记录","追号记录"])
        temp.backgroundColor = kGANavigationBackgroundColor
        return temp
    }()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        self.addSubview(self.segmentedView)
        self.addSubview(self.scrollView)
        self.scrollView.addSubview(self.contentView)
        self.setConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    public func setConstraints() {
        
        self.segmentedView.snp.makeConstraints { (make) in
            make.top.width.left.equalTo(self)
            make.height.equalTo(70)
        }
        
        self.scrollView.snp.makeConstraints { (make) in
            make.top.equalTo(self.segmentedView.snp.bottom)
            make.left.right.bottom.equalTo(self)
        }
        self.contentView.snp.makeConstraints { (make) in
            make.edges.equalTo(self.scrollView)
            make.height.equalTo(self.scrollView)
        }
    }
}
