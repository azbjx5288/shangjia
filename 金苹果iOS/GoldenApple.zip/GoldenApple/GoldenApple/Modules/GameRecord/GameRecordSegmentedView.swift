//
//  GameRecordSegmentedView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/2.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

protocol GameRecordSegmentedViewDelegate {
    func selectedItem(index : Int)
}

class GameRecordSegmentedView: UIView {

    var indicatorView : UIImageView = UIImageView()
    var titles : NSArray?
    fileprivate var buttons : NSMutableArray = NSMutableArray()
    
    private var _index = 0
    var index : Int {
        set {
            _index = newValue
            self.indexChanged()
        }
        get {
            return _index
        }
    }
    var lastSelectItem : UIButton?
    var delegate : GameRecordSegmentedViewDelegate?

    init(titles: NSArray) {
        super.init(frame: CGRect.zero)
        self.titles = titles
        self.indicatorView.image = UIImage.init(named: "Smalltrianglewhite")
        self.contentMode = .center
        self.addSubview(self.indicatorView)
        
        let norColor = kGABallGrayColor
        for i in 0...titles.count - 1 {
            let btn = UIButton()
            btn.index = i
            btn.setTitle(titles[i] as? String, for: .normal)
            btn.setTitleColor(norColor, for: .normal)
            btn.setTitleColor(.white, for: .selected)
            if #available(iOS 8.2, *) {
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: 300)
            } else {
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 18)
            }
            btn.addTarget(self, action: #selector(selectedItem(_ :)), for: .touchUpInside)
            self.addSubview(btn)
            self.buttons.add(btn)
        }
        
        self.lastSelectItem =  (self.buttons.firstObject as! UIButton)
        self.lastSelectItem?.isSelected = true
       
        self.setConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setConstraints(){
        let width = UIScreen.main.bounds.size.width / CGFloat(self.buttons.count)
        for i in 0...self.buttons.count - 1 {
            let btn = self.buttons[i] as! UIButton
            btn.snp.makeConstraints({ (make) in
                make.width.equalTo(width)
                make.left.equalTo(self).offset(CGFloat(i) * width);
                make.top.equalTo(self).offset(20)
                make.bottom.equalTo(self)
            })
        }
        self.indicatorView.snp.makeConstraints { (make) in
            make.bottom.equalTo(self)
            make.width.equalTo(20)
            make.height.equalTo(10)
            make.centerX.equalTo(self.buttons.firstObject as! UIButton).offset(0)
        }
    }

    private func indexChanged() {
        self.lastSelectItem?.isSelected = false
        let selectItem = self.buttons[self.index] as! UIButton
        self.lastSelectItem = selectItem
        selectItem.isSelected = true
        
        let width = UIScreen.main.bounds.size.width / CGFloat(self.buttons.count)
        self.indicatorView.snp.updateConstraints { (make) in
            make.centerX.equalTo(self.buttons.firstObject as! UIButton).offset(CGFloat(self.index) * width)
        }
        UIView.animate(withDuration: 0.3) {
            self.indicatorView.superview?.layoutIfNeeded()
        }
        
        if self.delegate != nil {
            self.delegate?.selectedItem(index: self.index)
        }
    }
    @objc func selectedItem(_ sender : UIButton){
        if self.index != sender.index {
            self.index = sender.index
        }
        
    }
    
}

//给扩展类加属性
private var indexKey: UInt8 = 0
extension UIButton {
    var index : Int {
        set {
            objc_setAssociatedObject(self, &indexKey, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
        get {
            return (objc_getAssociatedObject(self, &indexKey) as? Int)!
        }
    }
}
