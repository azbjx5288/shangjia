//
//  ZhuiHaoRecordView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/2.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ZhuiHaoRecordView: UIView {
    
    public lazy var setting = {
        ()-> WOWDropMenuSetting in
        var setting = WOWDropMenuSetting()
        setting.columnTitles = ["全部彩种","今天","全部状态"]
        setting.rowTitles =  [
            kGAlotteryNameDatas,
            KGAQueryTimeList,
            KGAQueryChasingStatusNames
        ]
        setting.maxShowCellNumber = 9
        setting.columnEqualWidth = true
        setting.cellTextLabelSelectColoror = UIColor.red
        setting.showDuration = 0.2
        return setting
    }()

    public lazy var tableView : UITableView = {
        ()-> UITableView in
        let temp = UITableView()
        temp.separatorStyle = UITableViewCellSeparatorStyle.none
        return temp
    }()
    
    var dropMenuView: WOWDropMenuView!
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        self.dropMenuView = WOWDropMenuView(frame: .zero, setting: self.setting)
        self.addSubview(self.dropMenuView)
        self.addSubview(self.tableView)
        self.dropMenuView.snp.makeConstraints { (make) in
            make.left.right.top.equalTo(self)
            make.height.equalTo(40)
        }
        self.tableView.snp.makeConstraints { (make) in
            make.top.equalTo(self.dropMenuView.snp.bottom)
            make.left.right.bottom.equalTo(self)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
