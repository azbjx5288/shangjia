//
//  ZhuiHaoDetailViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/8.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import MBProgressHUD

class ZhuiHaoDetailViewController: UIViewController {

    var myView : ZhuiHaoDetailView?
    var detailDict : NSDictionary?
    let apiManager = ZhuiHaoDetailAPIManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNaviBar()
        
        self.view = ZhuiHaoDetailView()
        self.myView = self.view as? ZhuiHaoDetailView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
        
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.loadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func setNaviBar() {
        
        self.navigationItem.title = "追号详情"
        
        let status = self.detailDict?.object(forKey: BettingRecordAPIManager.DataKey.kStatus) as? Int
        
        if status == 0 {
            let cancelBtn : UIButton = UIButton.init(type: .custom)
            cancelBtn.titleLabel?.font = UIFont.systemFont(ofSize: 18)
            cancelBtn.setTitle("撤单", for: .normal)
            cancelBtn.setTitleColor(.white, for: .normal)
            cancelBtn.setTitleColor(.gray, for: .highlighted)
            cancelBtn.frame = CGRect.init(x: 0, y: 0, width: 50, height: 30)
            cancelBtn.addTarget(self, action: #selector(didClickCancel(_ :)), for: .touchUpInside)
            let rightItem : UIBarButtonItem = UIBarButtonItem.init(customView: cancelBtn)
            self.navigationItem.rightBarButtonItem = rightItem;
        }
    }
    
    @objc func didClickBottomBtn() {
        let lotteryId = self.detailDict?.object(forKey: BettingDetailAPIManager.DataKey.kLottery_id) as? Int
        guard let lottery = GACacheManager.default.getLotteryDictionary(lotteryId: lotteryId!) else {return}
        let name = lottery.object(forKey: "name") as? String
        if name == nil {
            GAAlertController .showAlert(title: "温馨提示", message: "苹果手机端APP暂未开放该彩种!", delegate: nil, cancelButtonTitle: nil, commitButtonTitle: "确定");
            return
        }
        let lotteryPlaying = LotteryPlayingViewController(lotteryDict: lottery)
        lotteryPlaying.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(lotteryPlaying, animated: true)
    }
    
    @objc func didClickCancel(_ sender : UIButton) {
        let cancelVC = ZhuiHaoCancelViewController()
        cancelVC.detailDict = self.apiManager.detailDict
        self.navigationController?.pushViewController(cancelVC, animated: true)
    }

}
extension ZhuiHaoDetailViewController: UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 2:
            if self.apiManager.detailDict != nil {
                let issuesArray = self.apiManager.detailDict!.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kIssues) as? [NSDictionary]
                if issuesArray != nil {return (issuesArray?.count)!} else {return 0}
            }
        default:
            return 1
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            let cell = ZhuiHaoDetailHeaderCell.cellWithTableView(tableView: tableView)
            if self.apiManager.detailDict != nil {cell.setData(dict: self.detailDict!)}
            return cell
        case 1:
            let cell = ZhuiHaoDetailDescCell.cellWithTableView(tableView: tableView)
            if self.apiManager.detailDict != nil {
                let basicDict = self.apiManager.detailDict!.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kBasic) as? NSDictionary
                if basicDict != nil {cell.setData(dict: basicDict!)}
            }
            return cell
        case 2:
            let cell = ZhuiHaoDetailBettingCell.cellWithTableView(tableView: tableView)
            if self.apiManager.detailDict != nil {
                let issuesArray = self.apiManager.detailDict!.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kIssues) as? [NSDictionary]
                if issuesArray != nil {cell.setData(dict: issuesArray![indexPath.row])}
            }
   
            return cell
        default:
            return UITableViewCell()
        }
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 2 {
            let headerView = UIView()
            headerView.backgroundColor = .white
            
            let indicatorView = UIImageView()
            indicatorView.image = UIImage.init(named: "arrowright")
            indicatorView.contentMode = .center
            headerView.addSubview(indicatorView)
            indicatorView.snp.makeConstraints { (make) in
                make.right.equalTo(headerView).offset(-15)
                make.centerY.equalTo(headerView)
                make.height.equalTo(30)
                make.width.equalTo(15)
            }
            
            let titleLB = UILabel()
            titleLB.text = "查看追号方案"
            titleLB.font = UIFont.systemFont(ofSize: 16)
            titleLB.textColor = kGAFontBlackColor
            headerView.addSubview(titleLB)
            titleLB.snp.makeConstraints({ (make) in
                make.right.equalTo(indicatorView.snp.left).offset(-10)
                make.centerY.equalTo(headerView)
            })
            
            let line = UIView()
            line.backgroundColor = kGASerperatorLineGrayColor
            headerView.addSubview(line)
            line.snp.makeConstraints { (make) in
                make.bottom.left.right.equalTo(headerView)
                make.height.equalTo(1)
            }
            
            let gesture = UITapGestureRecognizer.init(target: self, action: #selector(didClickedHeaderView))
            headerView.isUserInteractionEnabled = true
            headerView.addGestureRecognizer(gesture)
            return headerView
        } else { return nil }
    }
    
    @objc func didClickedHeaderView() {
        let planVC = ZHuiHaoPlanViewController()
        planVC.basicDict = self.apiManager.detailDict!.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kBasic) as? NSDictionary
        let issuesArray = self.apiManager.detailDict!.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kIssues) as? [NSDictionary]
        planVC.issueDict = issuesArray?.first
        let bet_number = planVC.basicDict?.object(forKey: "bet_number") as? String
        if planVC.issueDict != nil {
            let tempDict = NSMutableDictionary(dictionary: planVC.issueDict!)
            tempDict.setValue(bet_number, forKey: "bet_number")
            planVC.issueDict! = tempDict as NSDictionary
        }
        self.navigationController?.pushViewController(planVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return 90
        case 1:
            return 140
        case 2:
            return 90
        default:
            return 44
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 2 {
            return 60
        } else { return 0 }
    }
}

extension ZhuiHaoDetailViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {

        GAProgressHUD.showLoading(message: "正在加载...")
        
        let zhuiHaoID = self.detailDict?.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kId) as? Int
        let params = ["id" : zhuiHaoID]
        return params as NSDictionary
    }
    
}
extension ZhuiHaoDetailViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        manager.fetchData(self.apiManager)
        
        self.myView?.tableView.reloadData()

    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//
//        self.apiManager.callAPIDidFailed(manager)
//        
//    }
}
