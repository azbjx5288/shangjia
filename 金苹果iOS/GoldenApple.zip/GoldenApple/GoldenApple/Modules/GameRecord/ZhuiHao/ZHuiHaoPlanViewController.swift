//
//  ZHuiHaoPlanViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/17.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ZHuiHaoPlanViewController: UIViewController {

    var myView : ZhuiHaoPlanView?
    public var basicDict : NSDictionary?
    public var issueDict : NSDictionary?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "追号方案"
        
        self.view = ZhuiHaoPlanView()
        self.myView = self.view as? ZhuiHaoPlanView
        self.myView?.bottomBtn.addTarget(self, action: #selector(didClickBottomBtn), for: .touchUpInside)
        
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.myView?.tableView.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func didClickBottomBtn() {
        
    }
}

extension ZHuiHaoPlanViewController: UITableViewDataSource,UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.basicDict != nil {
            return 1
        } else {
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = BettingDetailNumberCell.cellWithTableView(tableView: tableView)
        cell.setData(dict: self.basicDict!,dict1 : self.issueDict!)
        return cell
    }
    

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
}
