//
//  ZhuiHaoDetailHeaderCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/8.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ZhuiHaoDetailHeaderCell: UITableViewCell {

    private var iconView : UIImageView?
    private var nameLB : UILabel?
    private var wayLB : UILabel?
    private var statusLB : UILabel?
    private var progressLB : UILabel?
    
    static func cellWithTableView(tableView : UITableView) -> ZhuiHaoDetailHeaderCell {
        let cellIdentifier = "ZhuiHaoDetailHeaderCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? ZhuiHaoDetailHeaderCell
        if cell == nil {
            cell = ZhuiHaoDetailHeaderCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.iconView = UIImageView()
        self.iconView?.image = UIImage.init(named: "jpgcz")
        self.contentView.addSubview(self.iconView!)
        self.iconView?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.centerY.equalTo(self.contentView)
            make.width.height.equalTo(60)
        })
        
        self.nameLB = UILabel()
        self.nameLB?.numberOfLines = 0
        self.nameLB?.text = "彩种名称"
        self.nameLB?.font = UIFont.systemFont(ofSize: 19)
        self.nameLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.nameLB!)
        self.nameLB?.snp.makeConstraints({ (make) in
            make.left.equalTo((self.iconView?.snp.right)!).offset(20)
            make.top.equalTo((self.iconView)!).offset(5)
        })
        
        self.wayLB = UILabel()
        self.wayLB?.numberOfLines = 0
        self.wayLB?.text = "方式"
        self.wayLB?.font = UIFont.systemFont(ofSize: 16)
        self.wayLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.wayLB!)
        self.wayLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.nameLB!)
            make.bottom.equalTo((self.iconView)!).offset(-5)
        })
        
        self.statusLB = UILabel()
        self.statusLB?.numberOfLines = 0
        self.statusLB?.text = "状态"
        self.statusLB?.font = UIFont.systemFont(ofSize: 16)
        self.statusLB?.textColor = kGAFontRedColor
        self.contentView.addSubview(self.statusLB!)
        self.statusLB?.snp.makeConstraints({ (make) in
            make.right.equalTo(self.contentView).offset(-15)
            make.centerY.equalTo(self.contentView)
        })
        
        self.progressLB = UILabel()
        self.progressLB?.numberOfLines = 0
        self.progressLB?.text = "0/0"
        self.progressLB?.font = UIFont.systemFont(ofSize: 14)
        self.progressLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.progressLB!)
        self.progressLB?.snp.makeConstraints({ (make) in
            make.right.equalTo((self.statusLB?.snp.left)!).offset(-5)
            make.centerY.equalTo(self.statusLB!)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
    }
    
    public func setData(dict : NSDictionary) {
        let lotteryId = dict.object(forKey: BettingDetailAPIManager.DataKey.kLottery_id) as? Int
        
        let icon = GACacheManager.default.getLotteryIcon(lotteryId:lotteryId!)
        self.iconView?.image = UIImage.init(named: icon!)
        
        let name = dict.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kName) as? String
        (name != nil) ? (self.nameLB?.text = name) : (self.nameLB?.text = ("彩种名称" as String))
                
        let way = dict.object(forKey: BettingDetailAPIManager.DataKey.kWay) as? String
        self.wayLB?.text = way!
        
        let total_issues = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kTotalIssues) as? Int
        let finished_issues = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kFinishedIssues) as? Int
        
        self.progressLB?.text = NSString.init(format: "%d/%d",finished_issues!, total_issues!) as String
        
        let status = dict.object(forKey: BettingDetailAPIManager.DataKey.kStatus) as? Int
        
        self.statusLB?.text = self.getStatusCname(status: status!)
    }
    
    private func getStatusCname(status : Int)-> String {
        var statusStr = ""
        switch status {
        case 0:
            statusStr = "进行中"
            break
        case 1:
            statusStr = "已完成"
            break
        case 2:
            statusStr = "用户终止"
            break
        case 3:
            statusStr = "管理员终止"
            break
        case 4:
            statusStr = "系统终止"
            break
        default:
            statusStr = "未知"
        }
        return statusStr
    }

}
