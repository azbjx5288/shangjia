//
//  ZhuiHaoDetailAPIManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/8.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ZhuiHaoDetailAPIManager: GAAPIBaseManager {
    struct DataKey {
        static let kBasic = "basic"
        static let kIssues = "issues"
        static let kId = "id"
        static let kLottery_id = "lottery_id"
        static let kName = "lottery_name"
        static let kWay = "way"
        static let kSerialNumber = "serial_number"
        static let kMultiple = "multiple"
        static let kWinningNumber = "winning_number"
        static let kTotalIssues = "total_issues"
        static let kBetNumber = "bet_number"
        static let kAmount = "amount"
        static let kPrize = "prize"
        static let kTime = "bought_at"
        static let kStatus = "status"
        static let kCoefficient = "coefficient"
        static let kStopOnWon = "stop_on_won"
    }
    

    var detailDict : NSDictionary?
    
    override init() {
        super.init()
        self.validator = self
    }
}

extension ZhuiHaoDetailAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Game&action=getTraceDetail"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    public func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        let metodStr = self.methodName().substring(from: self.methodName().range(of: "?").upperBound)
        let signStr = metodStr + (resultParams.urlParamsString(false) as String) + (try! LYServiceFactory.default.service(self.serviceType()).publicKey as String)
        resultParams["sign"] = signStr.md5()
        
        return resultParams as NSDictionary
    }
    
}


extension ZhuiHaoDetailAPIManager: LYAPIManagerDataReformer {
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let detailDict = data.object(forKey: "data") as? NSDictionary else { return NSDictionary() }
        self.detailDict = detailDict
        return detailDict
        
    }
}
