//
//  ZhuiHaoRecordCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/6.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ZhuiHaoRecordCell: UITableViewCell {
    
    private var nameLB : UILabel?
    private var issusLB : UILabel?
    private var amountLB : UILabel?
    private var prizeLB : UILabel?
    private var statusLB : UILabel?
    
    static func cellWithTableView(tableView : UITableView) -> ZhuiHaoRecordCell {
        let cellIdentifier = "ZhuiHaoRecordCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? ZhuiHaoRecordCell
        if cell == nil {
            cell = ZhuiHaoRecordCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.nameLB = UILabel()
        self.nameLB?.font = UIFont.systemFont(ofSize: 16)
        self.nameLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.nameLB!)
        self.nameLB?.snp.makeConstraints({ (make) in
            make.top.equalTo(self.contentView).offset(20)
            make.left.equalTo(self.contentView).offset(15)
        })
        
        self.issusLB = UILabel()
        self.issusLB?.font = UIFont.systemFont(ofSize: 14)
        self.issusLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.issusLB!)
        self.issusLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.nameLB!)
            make.left.equalTo((self.nameLB?.snp.right)!).offset(10)
        })
        
        self.amountLB = UILabel()
        self.amountLB?.font = UIFont.systemFont(ofSize: 14)
        self.amountLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.amountLB!)
        self.amountLB?.snp.makeConstraints({ (make) in
            make.left.equalTo((self.nameLB)!)
            make.bottom.equalTo(self.contentView).offset(-20)
        })
        
        let indicatorView = UIImageView()
        indicatorView.image = UIImage.init(named: "arrowright")
        indicatorView.contentMode = .center
        self.contentView.addSubview(indicatorView)
        indicatorView.snp.makeConstraints { (make) in
            make.right.equalTo(self.contentView).offset(-15)
            make.centerY.equalTo(self.amountLB!)
            make.height.equalTo(30)
            make.width.equalTo(15)
        }
        
        self.prizeLB = UILabel()
        self.prizeLB?.font = UIFont.systemFont(ofSize: 16)
        self.prizeLB?.textColor = kGAFontRedColor
        self.contentView.addSubview(self.prizeLB!)
        self.prizeLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.amountLB!)
            make.right.equalTo(indicatorView.snp.left).offset(-10)
        })
        
        self.statusLB = UILabel()
        self.statusLB?.font = UIFont.systemFont(ofSize: 14)
        self.statusLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.statusLB!)
        self.statusLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.issusLB!)
            make.right.equalTo(self.prizeLB!)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
    }
    
    public func setData(dict : NSDictionary) {
        let name = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kName) as? String
        (name != nil) ? (self.nameLB?.text = name) : (self.nameLB?.text = ("彩种名称" as String))
        
        let issus = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kStartIssue) as? String
        self.issusLB?.text = issus! + "期"
        
        let amount = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kAmount) as? String
        self.amountLB?.text = amount! + "元"
        
        let prize = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kPrize) as? String
        let status = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kStatus) as? Int
        let total_issues = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kTotalIssues) as? Int
        let finished_issues = dict.object(forKey: ZhuiHaoRecordAPIManager.DataKey.kFinishedIssues) as? Int
        
        if prize != nil {
            self.prizeLB?.text = prize! + "元"
        } else {
            self.prizeLB?.text = "0元"
        }
    
        self.statusLB?.text = self.getStatusCname(status: status!, finishedIssues: finished_issues!, totalIssues: total_issues!)
    }
    
    private func getStatusCname(status : Int,finishedIssues : Int, totalIssues : Int)-> String {
        var statusStr = ""
        switch status {
   
        case 0,1: //进行中、已完成
            statusStr = NSString.init(format: "%d/%d", finishedIssues,totalIssues) as String
            break
        case 2:
            statusStr = "用户终止"
            break
        case 3:
            statusStr = "管理员终止"
            break
        case 4:
            statusStr = "系统终止"
            break
        default:
            statusStr = "未知"
        }
        return statusStr
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
