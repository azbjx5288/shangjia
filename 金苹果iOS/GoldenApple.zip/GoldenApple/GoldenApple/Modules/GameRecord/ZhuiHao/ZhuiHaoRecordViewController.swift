//
//  ZhuiHaoRecordViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/2.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import MJRefresh

class ZhuiHaoRecordViewController: UIViewController {
    
    var myView : ZhuiHaoRecordView?
    var needReloadData : Bool = true
    let apiManager = ZhuiHaoRecordAPIManager()
    init() {
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view = ZhuiHaoRecordView()
        self.myView = self.view as? ZhuiHaoRecordView
        
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        self.myView?.dropMenuView.delegate = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        
        let header = MJRefreshNormalHeader.init {[weak self] in
            self?.apiManager.isRefresh = true
            self?.apiManager.loadData()
        }
        header?.lastUpdatedTimeLabel.isHidden = true
        let footer = MJRefreshAutoNormalFooter.init {[weak self] in
            self?.apiManager.isRefresh = false
            self?.apiManager.loadData()
        }
        self.myView?.tableView.mj_header = header
        self.myView?.tableView.mj_footer = footer
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.needReloadData = true
    }
    
    public func reloadData() {
        if self.needReloadData {
            self.myView?.tableView.mj_header.beginRefreshing()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

extension ZhuiHaoRecordViewController: DropMenuViewDelegate{
    func dropMenuClick(column: Int, row: Int) {
        switch column {
        case 0:
            self.apiManager.recordDictList = []
            self.apiManager.lottery_id = kGAlotteryIdDatas[kGAlotteryNameDatas[row]]!
            self.apiManager.page = 1
            self.apiManager.loadData()
            break
        case 1:
            self.apiManager.recordDictList = []
            self.apiManager.time = KGAQueryTimeList[row]
            self.apiManager.page = 1
            self.apiManager.loadData()
            break
        case 2:
            self.apiManager.recordDictList = []
            self.apiManager.status = KGAQueryChasingStatusList[KGAQueryChasingStatusNames[row]]!
            self.apiManager.page = 1
            self.apiManager.loadData()
            break
        default:
            break
        }
    }
}

extension ZhuiHaoRecordViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.apiManager.recordDictList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = ZhuiHaoRecordCell.cellWithTableView(tableView: tableView)
        let recordDict = self.apiManager.recordDictList[indexPath.item]
        cell.setData(dict: recordDict)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = ZhuiHaoDetailViewController()
        vc.hidesBottomBarWhenPushed = true
        let detailDict = self.apiManager.recordDictList[indexPath.row] as NSDictionary
        vc.detailDict = detailDict
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ZhuiHaoRecordViewController:LYAPIManagerParamSource {
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        let params = NSDictionary()
        return params as NSDictionary
    }
    
}
extension ZhuiHaoRecordViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        
        self.needReloadData = false
        
        let recordDictList = manager.fetchData(self.apiManager) as! NSArray
        self.myView?.tableView.reloadData()
        if recordDictList.count == 0 {
            GAProgressHUD.showError(message: "按您查询的条件，暂无追号记录。", duration: 1)
        }
        if !self.apiManager.isRefresh && recordDictList.count == 0 {
            let footer = self.myView?.tableView.mj_footer as! MJRefreshAutoNormalFooter
            footer.endRefreshingWithNoMoreData()
        } else {
            self.myView?.tableView.mj_header.endRefreshing()
            self.myView?.tableView.mj_footer.endRefreshing()
        }
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        self.myView?.tableView.mj_header.endRefreshing()
        self.myView?.tableView.mj_footer.endRefreshing()

//        self.apiManager.callAPIDidFailed(manager)
    }
}
