//
//  ZhuiHaoDetailDescCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/8.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ZhuiHaoDetailDescCell: UITableViewCell {

    private var timeLB : UILabel?
    private var numberLB : UILabel?
    private var stopLB : UILabel?
    
    static func cellWithTableView(tableView : UITableView) -> ZhuiHaoDetailDescCell {
        let cellIdentifier = "BettingDetailDescCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? ZhuiHaoDetailDescCell
        if cell == nil {
            cell = ZhuiHaoDetailDescCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    private func setSubViews() {
        
        let timeTitleLB = UILabel()
        timeTitleLB.text = "投注时间:"
        timeTitleLB.font = UIFont.systemFont(ofSize: 16)
        timeTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(timeTitleLB)
        timeTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(self.contentView).offset(15)
            make.top.equalTo(self.contentView).offset(20)
            make.width.equalTo(75)
        })
        
        self.timeLB = UILabel()
        self.timeLB?.text = "0000"
        self.timeLB?.font = UIFont.systemFont(ofSize: 16)
        self.timeLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.timeLB!)
        self.timeLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB.snp.right).offset(5)
            make.centerY.equalTo(timeTitleLB)
        })
        
        let numberTitleLB = UILabel()
        numberTitleLB.text = "注单编号:"
        numberTitleLB.font = UIFont.systemFont(ofSize: 16)
        numberTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(numberTitleLB)
        numberTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB)
            make.top.equalTo(timeTitleLB.snp.bottom).offset(10)
        })
        
        self.numberLB = UILabel()
        self.numberLB?.text = "0000"
        self.numberLB?.numberOfLines = 0
        self.numberLB?.font = UIFont.systemFont(ofSize: 16)
        self.numberLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.numberLB!)
        self.numberLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.timeLB!)
            make.right.equalTo(self.contentView).offset(-15)
            make.top.equalTo((self.timeLB?.snp.bottom)!).offset(10)
        })
        
        let stopTitleLB = UILabel()
        stopTitleLB.text = "追中即停: "
        stopTitleLB.font = UIFont.systemFont(ofSize: 16)
        stopTitleLB.textColor = kGAFontGrayColor
        self.contentView.addSubview(stopTitleLB)
        stopTitleLB.snp.makeConstraints({ (make) in
            make.left.equalTo(timeTitleLB)
            make.top.equalTo((self.numberLB?.snp.bottom)!).offset(10)
        })
        
        self.stopLB = UILabel()
        self.stopLB?.font = UIFont.systemFont(ofSize: 16)
        self.stopLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.stopLB!)
        self.stopLB?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.timeLB!)
            make.centerY.equalTo(stopTitleLB)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(5)
        }
    }
    
    public func setData(dict : NSDictionary) {
        let time = dict.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kTime) as? String
        self.timeLB?.text = time!
        
        let serialNumber = dict.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kSerialNumber) as? String
        self.numberLB?.text = serialNumber!
        
        let stop = dict.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kStopOnWon) as? Int
        if stop == 0 {
            self.stopLB?.text = "否"
        } else if (stop == 1) {
            self.stopLB?.text = "是"
        }
        
    }

}
