//
//  ZhuiHaoCancelView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/9.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class ZhuiHaoCancelView: UIView {

    public lazy var tableView : UITableView = {
        ()-> UITableView in
        let temp = UITableView()
        temp.separatorStyle = UITableViewCellSeparatorStyle.none
        temp.allowsSelection = false
        temp.allowsMultipleSelection = false
        return temp
    }()
    
    private let menuView : UIView = UIView()
    
    public let issueCountLB : UILabel = UILabel()
    
    public let cancelBtn : UIButton = UIButton()
    
    public let selectAllBtn : UIButton = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .white
        
        self.menuView.backgroundColor = kGANavigationBackgroundColor
        self.addSubview(self.menuView)
        self.menuView.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self)
            make.height.equalTo(55)
        }
        
        self.issueCountLB.textColor = .white
        self.issueCountLB.text = "共0期"
        if #available(iOS 8.2, *) {
            self.issueCountLB.font = UIFont.systemFont(ofSize: 16, weight: 300)
        } else {
            self.issueCountLB.font = UIFont.systemFont(ofSize: 16)
        }
        self.menuView.addSubview(self.issueCountLB)
        self.issueCountLB.snp.makeConstraints { (make) in
            make.center.equalTo(self.menuView)
        }
        
        
        self.cancelBtn.setTitle("取消", for: .normal)
        self.cancelBtn.setTitleColor(.white, for: .normal)
        self.cancelBtn.setTitleColor(.gray, for: .highlighted)
        self.cancelBtn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        self.cancelBtn.layer.borderColor = UIColor.white.cgColor
        self.cancelBtn.layer.borderWidth = 1
        self.cancelBtn.layer.cornerRadius = 3
        self.menuView.addSubview(self.cancelBtn)
        self.cancelBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self.menuView).offset(15)
            make.centerY.equalTo(self.menuView)
            make.size.equalTo(CGSize.init(width: 50, height: 30))
        }
        self.cancelBtn.isHidden = true
        
        self.selectAllBtn.backgroundColor = .white
        self.selectAllBtn.setTitle("全选", for: .normal)
        self.selectAllBtn.setTitleColor(self.menuView.backgroundColor, for: .normal)
        self.selectAllBtn.setTitleColor(.gray, for: .highlighted)
        self.selectAllBtn.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        self.selectAllBtn.layer.cornerRadius = 3
        self.menuView.addSubview(self.selectAllBtn)
        self.selectAllBtn.snp.makeConstraints { (make) in
            make.right.equalTo(self.menuView).offset(-15)
            make.centerY.equalTo(self.menuView)
            make.size.equalTo(self.cancelBtn)
        }
        self.selectAllBtn.isHidden = true
        
        self.addSubview(self.tableView)
        self.tableView.snp.makeConstraints { (make) in
            make.top.equalTo(self.menuView.snp.bottom)
            make.left.right.bottom.equalTo(self)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
