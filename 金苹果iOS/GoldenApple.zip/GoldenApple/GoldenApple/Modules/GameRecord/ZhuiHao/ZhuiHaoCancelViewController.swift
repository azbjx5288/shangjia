//
//  ZhuiHaoCancelViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/9.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import MBProgressHUD

class ZhuiHaoCancelViewController: UIViewController {

    var myView : ZhuiHaoCancelView?
    var detailDict : NSDictionary?
    var basicDict : NSDictionary?
    var issuesArray : [NSDictionary]?
    var editBtn : UIButton?
    
    let apiManager = ZhuiHaoCancelAPIManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNaviBar()
        self.view = ZhuiHaoCancelView()
        self.myView = self.view as? ZhuiHaoCancelView

        self.basicDict = self.detailDict!.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kBasic) as? NSDictionary
        self.issuesArray = self.detailDict!.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kIssues) as? [NSDictionary]
        
        let totalIssues = basicDict?.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kTotalIssues) as! Int
        self.myView?.issueCountLB.text = "共" + "\(totalIssues)" + "期"
        self.myView?.cancelBtn.addTarget(self, action: #selector(didClickCancelBtn(_ :)), for: .touchUpInside)
        self.myView?.selectAllBtn.addTarget(self, action: #selector(didClickAllBtn(_ :)), for: .touchUpInside)
        
        self.myView?.tableView.delegate = self
        self.myView?.tableView.dataSource = self
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        
    }
    
    private func setNaviBar() {
        
        self.navigationItem.title = "追号撤单"
        
        self.editBtn = UIButton.init(type: .custom)
        self.editBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        self.editBtn?.setTitle("编辑", for: .normal)
        self.editBtn?.setTitle("提交", for: .selected)
        self.editBtn?.setTitleColor(.white, for: .normal)
        self.editBtn?.setTitleColor(.gray, for: .highlighted)
        self.editBtn?.frame = CGRect.init(x: 0, y: 0, width: 50, height: 30)
        self.editBtn?.addTarget(self, action: #selector(didClickEditBtn(_ :)), for: .touchUpInside)
        let rightItem : UIBarButtonItem = UIBarButtonItem.init(customView: self.editBtn!)
        self.navigationItem.rightBarButtonItem = rightItem;
    }

    @objc func didClickEditBtn(_ sender : UIButton) {
        if sender.isSelected {
            GAAlertController.showAlert(title: "撤单确认", message: "您确定要撤单吗?", delegate: self, cancelButtonTitle: "取消", commitButtonTitle: "确定")
        } else {
            sender.isSelected = !sender.isSelected
            self.myView?.tableView.allowsMultipleSelection = sender.isSelected
            self.myView?.cancelBtn.isHidden = !sender.isSelected
            self.myView?.selectAllBtn.isHidden = !sender.isSelected
            self.myView?.tableView.reloadData()
        }
    }
    
    @objc func didClickCancelBtn(_ sender : UIButton) {
        for i in 0...((self.issuesArray?.count)! - 1) {
            let indexPath : NSIndexPath = NSIndexPath.init(row: i, section: 0)
            self.myView?.tableView.scrollToRow(at: indexPath as IndexPath, at: .bottom, animated: false)
            self.myView?.tableView.deselectRow(at: indexPath as IndexPath, animated: false)
            let cell : ZhuiHaoCancelCell = self.myView?.tableView.cellForRow(at: indexPath as IndexPath)! as! ZhuiHaoCancelCell
            cell.selectImg.isSelected = false
        }
        self.myView?.tableView.scrollToRow(at: NSIndexPath.init(row: 0, section: 0) as IndexPath, at: .top, animated: false)
    }
    @objc func didClickAllBtn(_ sender : UIButton) {
        for i in 0...((self.issuesArray?.count)! - 1) {
            let stauts = self.issuesArray![i].object(forKey: ZhuiHaoDetailAPIManager.DataKey.kStatus) as! Int
            if stauts == 0 {
                let indexPath : NSIndexPath = NSIndexPath.init(row: i, section: 0)
                self.myView?.tableView.selectRow(at: indexPath as IndexPath, animated: false, scrollPosition: .bottom)
                let cell : ZhuiHaoCancelCell = self.myView?.tableView.cellForRow(at: indexPath as IndexPath)! as! ZhuiHaoCancelCell
                cell.selectImg.isSelected = true
            }
        }
        self.myView?.tableView.scrollToRow(at: NSIndexPath.init(row: 0, section: 0) as IndexPath, at: .top, animated: false)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
extension ZhuiHaoCancelViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.issuesArray?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = ZhuiHaoCancelCell.cellWithTableView(tableView: tableView)
        cell.setData(dict: self.issuesArray![indexPath.row])
        cell.setEditStatus(isEditing: (self.editBtn?.isSelected)!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let stauts = self.issuesArray![indexPath.row].object(forKey: ZhuiHaoDetailAPIManager.DataKey.kStatus) as! Int
        let cell : ZhuiHaoCancelCell = tableView.cellForRow(at: indexPath)! as! ZhuiHaoCancelCell
        if stauts == 0 {
            cell.selectImg.isSelected = true
        } else {
            GAProgressHUD.showWarning(message: "不能撤销该注单!")
            self.myView?.tableView.deselectRow(at: indexPath, animated: false)
        }
        
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell : ZhuiHaoCancelCell = tableView.cellForRow(at: indexPath)! as! ZhuiHaoCancelCell
        cell.selectImg.isSelected = false
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let cell1 = cell as! ZhuiHaoCancelCell
        cell1.selectImg.isSelected = cell.isSelected
    }
}

extension ZhuiHaoCancelViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        GAProgressHUD.showLoading(message: "正在撤单,请稍候...")
        
        let zhuiHaoID = self.basicDict?.object(forKey: ZhuiHaoDetailAPIManager.DataKey.kId) as? Int
        let indexPaths = self.myView?.tableView.indexPathsForSelectedRows
        var ids = ""
        if indexPaths != nil {
            for indexPath in indexPaths! {
                let id = self.issuesArray![indexPath.row].object(forKey: ZhuiHaoDetailAPIManager.DataKey.kId) as? Int
                ids = ids + "\(id ?? 0)"
                if indexPath != indexPaths?.last {
                    ids = ids + ","
                }
            }
        }
        ids = "[" + ids + "]"
        
        let params = ["trace_id" : zhuiHaoID ?? 0,"ids" : ids] as [String : Any]
        return params as NSDictionary
    }
    
}
extension ZhuiHaoCancelViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.showSuccess(message: "撤单成功!")
        manager.fetchData(self.apiManager)
        self.navigationController?.popViewController(animated: true)
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        
//        self.apiManager.callAPIDidFailed(manager)
//    }
}
extension ZhuiHaoCancelViewController: GAAlertDelegate {
    func alertCancelButtonClicked() {
     
    }
    
    func alertCommitButtonClicked() {
        self.apiManager.loadData()
    }
    
    
}
