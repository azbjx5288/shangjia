//
//  LotteryTrendDetailViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/17.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import MJRefresh

class LotteryTrendDetailViewController: UIViewController {

    fileprivate let myView : LotteryTrendDetailView = {
        return LotteryTrendDetailView()
    }()
    fileprivate let apiManager = WinNumListAPIManager()
    var lotteryId : Int?
    fileprivate var dataArray : [NSDictionary]?
    
    fileprivate static let flagCount = 10
    fileprivate static var iPage = 1
    /// 开奖号码记录数,输入接口
    fileprivate var recodCount = LotteryTrendDetailViewController.flagCount
    
    override func loadView() {
        super.loadView()
        
        self.view = self.myView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "开奖走势"
        
        let header = MJRefreshNormalHeader { [weak self] in
            self?.recodCount = LotteryTrendDetailViewController.flagCount
            self?.apiManager.loadData()
        }
        let footer = MJRefreshAutoNormalFooter { [weak self] in
            self?.recodCount = LotteryTrendDetailViewController.flagCount * LotteryTrendDetailViewController.iPage
            LotteryTrendDetailViewController.iPage += 1
            self?.apiManager.loadData()
        }
        header?.lastUpdatedTimeLabel.isHidden = true
        self.myView.tableView.mj_header = header
        self.myView.tableView.mj_footer = footer
        
        self.myView.tableView.delegate = self
        self.myView.tableView.dataSource = self
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        
    }

    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.loadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

extension LotteryTrendDetailViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.dataArray != nil {
            return (self.dataArray?.count)!
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = LotteryTrendDetailCell.cellWithTableView(tableView: tableView)
        cell.lotterId = self.lotteryId
        let dataDict = self.dataArray![indexPath.row]
        cell.setData(dataDict: dataDict)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}

extension LotteryTrendDetailViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "正在加载...")
        
        let params = ["lottery_id" : self.lotteryId,
                      "count" : self.recodCount]
        return params as NSDictionary
    }
    
}
extension LotteryTrendDetailViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        guard let dataArray = manager.fetchData(self.apiManager) as? [NSDictionary]  else {return}
        self.dataArray = dataArray
        self.myView.tableView.reloadData()
        
        if self.myView.tableView.mj_header.isRefreshing {
            self.myView.tableView.mj_header.endRefreshing()
        } else if self.myView.tableView.mj_footer.isRefreshing {
            self.myView.tableView.mj_footer.endRefreshing()
        }
    }
    
//    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
//        self.apiManager.callAPIDidFailed(manager)
//    }
}
