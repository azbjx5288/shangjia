//
//  LotteryTrendViewController.swift
//  GoldenApple
//
//  Created by User on 16/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import MJRefresh

class LotteryTrendViewController: UIViewController {

    fileprivate let myView : LotteryTrendView = {
        return LotteryTrendView()
    }()
    let apiManager = LotteryTrendAPIManager()
    var dataArray : NSArray?
    
    override func loadView() {
        super.loadView()
        
        self.view = self.myView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "开奖走势"
        
        self.myView.tableView.delegate = self
        self.myView.tableView.dataSource = self
        
        let header = MJRefreshNormalHeader.init {[weak self] in
            self?.apiManager.loadData()
        }
        header?.lastUpdatedTimeLabel.isHidden = true
        self.myView.tableView.mj_header = header
        
        self.apiManager.delegate = self
        self.apiManager.paramSource = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.apiManager.loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension LotteryTrendViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.dataArray != nil {
            return (self.dataArray?.count)!
        } else {
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = LotteryTrendCell.cellWithTableView(tableView: tableView)
        cell.bettingBtn.tag = indexPath.row + 564728
        cell.bettingBtn.addTarget(self, action: #selector(didClickBettingBtn(_ :)), for: .touchUpInside)
        
        cell.trendBtn.tag = indexPath.row + 264728
        cell.trendBtn.addTarget(self, action: #selector(didClickTrendBtn(_ :)), for: .touchUpInside)
        guard let data : NSDictionary = self.dataArray?[indexPath.row] as? NSDictionary else {return cell}
        cell.setData(data : data)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
        if self.dataArray != nil && self.dataArray!.count > indexPath.row {
            let data = self.dataArray![indexPath.row] as? NSDictionary
            let lotteryId = data?.object(forKey: LotteryTrendAPIManager.DataKey.kSeriesId) as? UInt
            if lotteryId != nil && lotteryId! == eLotterySeriesType.eKL.rawValue {
                return 180
            }
        }
        
        
        return 165
    }
    
    @objc func didClickBettingBtn(_ sender : UIButton) {
        let row = sender.tag - 564728
        guard let data : NSDictionary = self.dataArray?[row] as? NSDictionary else {return}
        guard let lotteryId = data.object(forKey: LotteryTrendAPIManager.DataKey.kLottery_id) as? Int else {return}
        guard let lottery = GACacheManager.default.getLotteryDictionary(lotteryId: lotteryId) else {return}
        let lotteryPlaying = LotteryPlayingViewController(lotteryDict: lottery)
        lotteryPlaying.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(lotteryPlaying, animated: true)
    }
    @objc func didClickTrendBtn(_ sender : UIButton) {
        let row = sender.tag - 264728
        guard let data : NSDictionary = self.dataArray?[row] as? NSDictionary else {return}
        guard let lotteryId = data.object(forKey: LotteryTrendAPIManager.DataKey.kLottery_id) as? Int else {return}
        let detailVC = LotteryTrendDetailViewController()
        detailVC.lotteryId = lotteryId
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
}

extension LotteryTrendViewController:LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        GAProgressHUD.showLoading(message: "加载中...")
        return NSDictionary()
    }
    
}
extension LotteryTrendViewController:LYAPIManagerCallBackDelegate
{
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        guard let dataArray = manager.fetchData(self.apiManager) as? NSArray  else {return}
        self.dataArray = dataArray
        self.myView.tableView.reloadData()
        if self.myView.tableView.mj_header.isRefreshing {
            self.myView.tableView.mj_header.endRefreshing()
        }
    }
    
}
