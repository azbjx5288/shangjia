//
//  LotteryTrendDetailCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/17.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class LotteryTrendDetailCell: UITableViewCell {

    public var lotterId : Int?
    private var issusLB : UILabel?
    private var winNumberView: UIView?
    private var k3SpecialView: K3LastWinNumberView?
    
    static func cellWithTableView(tableView : UITableView) -> LotteryTrendDetailCell {
        let cellIdentifier = "LotteryTrendDetailCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? LotteryTrendDetailCell
        if cell == nil {
            cell = LotteryTrendDetailCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    private func setSubViews() {
        self.issusLB = UILabel()
        self.issusLB?.text = "xxxxxxx期"
        self.issusLB?.font = UIFont.systemFont(ofSize: 16)
        self.issusLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.issusLB!)
        self.issusLB?.snp.makeConstraints({ (make) in
            make.top.equalTo(self.contentView).offset(20)
            make.left.equalTo(self.contentView).offset(15)
        })
        
        self.winNumberView = UIView()
        self.contentView.addSubview(self.winNumberView!)
        self.winNumberView?.snp.makeConstraints({ (make) in
            make.top.equalTo((self.issusLB?.snp.bottom)!).offset(10)
            make.left.equalTo(self.contentView).offset(15)
            make.height.equalTo(30)
            make.right.equalTo(self.contentView).offset(-15)
        })
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(1)
        }
    }
    
    public func setData(dataDict : NSDictionary) {
        
        for view in (self.winNumberView?.subviews)! {
            view.removeFromSuperview()
        }
        
        let issus = dataDict.object(forKey: WinNumListAPIManager.DataKey.kIssue) as? String
        self.issusLB?.text = issus! + "期"
        let winNumber = dataDict.object(forKey: LotteryTrendAPIManager.DataKey.kWn_number) as? String
        
        if winNumber != nil && !((winNumber?.isEmpty)!) {
            var numberArray : NSArray?
            numberArray = winNumber?.components(separatedBy: " ") as NSArray?
            //如果是单号
            if (numberArray?.count)! < 2 {
                numberArray =  winNumber!.map{String($0)} as NSArray
            }
            self.setNumberView(numbers: numberArray! as NSArray,isOpen: true)
        } else {
            let numberArray = ["-","-","-","-","-",]
            self.setNumberView(numbers: numberArray as NSArray,isOpen: false)
        }
        
    }
    
    private func setNumberView(numbers : NSArray,isOpen : Bool) {
        guard let lottery = GACacheManager.default.getLotteryDictionary(lotteryId: self.lotterId!) else {return}
        let series_id = lottery.object(forKey: "series_id") as? UInt
        //如果是快三，则显示骰子
        if (series_id == eLotterySeriesType.eK3.rawValue) {
            let k3SpecialView : K3LastWinNumberView = K3LastWinNumberView.init(frame: CGRect.zero)
            self.winNumberView?.addSubview(k3SpecialView)
            k3SpecialView.setSubviewsConstrain(leftView: self.winNumberView!,centerYView: self.winNumberView!)
            k3SpecialView.setTitles(numbers: numbers)
        } else if eLotterySeriesType.eKL.rawValue == series_id {
            let mutiNumberView = MutiLastWinNumberView(numberArray: numbers as! [NSString], maxViewWidth: Double(self.width))
            self.winNumberView?.addSubview(mutiNumberView)
            mutiNumberView.setSubviewsConstrain()
            
        } else {
            
            let normalNumberView : NormalLastWinNumberView = NormalLastWinNumberView.init(frame: CGRect.zero, numberArray: numbers as! [NSString])
            self.winNumberView?.addSubview(normalNumberView)
            normalNumberView.setSubviewsConstrain()
        }
        
    }
    
}
