//
//  LotteryTrendCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/16.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class LotteryTrendCell: UITableViewCell {
    private var nameLB : UILabel?
    private var issusLB : UILabel?
    
    public  let bettingBtn : UIButton = UIButton()
    
    private var winNumberView: UIView?
    
    private var issusLB1 : UILabel?
    private var numberLB1: UILabel?
    
    private var issusLB2 : UILabel?
    private var numberLB2: UILabel?
    
    private var k3SpecialView1: K3LastWinNumberView = K3LastWinNumberView.init(frame: CGRect.zero)
    private var k3SpecialView2: K3LastWinNumberView = K3LastWinNumberView.init(frame: CGRect.zero)
    
    public  let trendBtn : UIButton = UIButton()
   
    
    static func cellWithTableView(tableView : UITableView) -> LotteryTrendCell {
        let cellIdentifier = "LotteryTrendCellId"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? LotteryTrendCell
        if cell == nil {
            cell = LotteryTrendCell.init(style: .default, reuseIdentifier: cellIdentifier)
            cell?.selectionStyle = .none
            cell?.setSubViews()
        }
        return cell!
    }
    
    private func setSubViews() {
        self.nameLB = UILabel()
        self.nameLB?.text = "彩种"
        self.nameLB?.font = UIFont.systemFont(ofSize: 16)
        self.nameLB?.textColor = kGAFontBlackColor
        self.contentView.addSubview(self.nameLB!)
        self.nameLB?.snp.makeConstraints({ (make) in
            make.top.equalTo(self.contentView).offset(20)
            make.left.equalTo(self.contentView).offset(15)
        })
        
        self.issusLB = UILabel()
        self.issusLB?.text = "xxxxxxx期"
        self.issusLB?.font = UIFont.systemFont(ofSize: 14)
        self.issusLB?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.issusLB!)
        self.issusLB?.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self.nameLB!)
            make.left.equalTo((self.nameLB?.snp.right)!).offset(5)
        })
        
        self.bettingBtn.setTitle("立即投注", for: .normal)
        self.bettingBtn.setTitleColor(.white, for: .normal)
        self.bettingBtn.setTitleColor(.gray, for: .highlighted)
        self.bettingBtn.setTitleColor(.white, for: .disabled)
        self.bettingBtn.layer.cornerRadius = 3
        self.bettingBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        self.bettingBtn.backgroundColor = kGANavigationBackgroundColor
        self.contentView.addSubview(self.bettingBtn)
        self.bettingBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.issusLB!)
            make.right.equalTo(self.contentView).offset(-10)
            make.width.equalTo(70)
            make.height.equalTo(30)
        }
        
        self.winNumberView = UIView()
        self.contentView.addSubview(self.winNumberView!)
        self.winNumberView?.snp.makeConstraints({ (make) in
            make.top.equalTo((nameLB?.snp.bottom)!).offset(10)
            make.left.equalTo(nameLB!)
            make.height.equalTo(30)
            make.right.equalTo(self.contentView).offset(-15)
        })
        
        self.issusLB1 = UILabel()
        self.issusLB1?.text = "xxxxxxx期"
        self.issusLB1?.font = UIFont.systemFont(ofSize: 14)
        self.issusLB1?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.issusLB1!)
        
        let issusLB1Size = self.getTextSize(text: (self.issusLB1?.text)!, font: (self.issusLB1?.font)!)
        let issusLB1Width = ceil(issusLB1Size.width)
        
        self.issusLB1?.snp.makeConstraints({ (make) in
            make.top.equalTo((self.winNumberView?.snp.bottom)!)
            make.width.equalTo(issusLB1Width)
            make.left.equalTo(self.nameLB!)
            make.height.equalTo(30.0)
        })
        
        self.trendBtn.isEnabled = false
        self.trendBtn.setImage(UIImage.init(named: "trendred"), for: .normal)
        self.trendBtn.setImage(UIImage.init(named: "trendgray"), for: .disabled)
        self.contentView.addSubview(self.trendBtn)
        self.trendBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.winNumberView!)
            make.right.equalTo(self.contentView)
            make.width.height.equalTo(54)
        }
        
        self.numberLB1 = UILabel()
        self.numberLB1?.numberOfLines = 0
        self.numberLB1?.text = "- - - - -"
        self.numberLB1?.font = UIFont.systemFont(ofSize: 14)
        self.numberLB1?.textColor = kGAFontRedColor
        self.contentView.addSubview(self.numberLB1!)
        self.numberLB1?.snp.makeConstraints({ (make) in
            make.left.equalTo((self.issusLB1?.snp.right)!).offset(10)
            make.centerY.equalTo(self.issusLB1!)
            make.height.equalTo(self.issusLB1!)
        })
        self.contentView.addSubview(self.k3SpecialView1)
        self.k3SpecialView1.setSubviewsConstrain(leftView: self.numberLB1!,centerYView: self.numberLB1!)
        self.k3SpecialView1.isHidden = true
        
        self.issusLB2 = UILabel()
        self.issusLB2?.text = "xxxxxxx期"
        self.issusLB2?.font = UIFont.systemFont(ofSize: 14)
        self.issusLB2?.textColor = kGAFontGrayColor
        self.contentView.addSubview(self.issusLB2!)
        
        let issusLB2Size = self.getTextSize(text: (self.issusLB2?.text)!, font: (self.issusLB2?.font)!)
        let issusLB2Width = ceil(issusLB2Size.width)
        
        self.issusLB2?.snp.makeConstraints({ (make) in
            make.top.equalTo((self.issusLB1?.snp.bottom)!)
            make.width.equalTo(issusLB2Width)
            make.left.equalTo(self.issusLB1!)
            make.height.equalTo(self.issusLB1!)
        })
        
        self.numberLB2 = UILabel()
        self.numberLB2?.numberOfLines = 0
        self.numberLB2?.text = "- - - - -"
        self.numberLB2?.font = UIFont.systemFont(ofSize: 14)
        self.numberLB2?.textColor = kGAFontRedColor
        self.contentView.addSubview(self.numberLB2!)
        self.numberLB2?.snp.makeConstraints({ (make) in
            make.left.equalTo(self.numberLB1!)
            make.centerY.equalTo(self.issusLB2!)
            make.height.equalTo(self.issusLB1!)
        })
        self.contentView.addSubview(self.k3SpecialView2)
        self.k3SpecialView2.setSubviewsConstrain(leftView: self.numberLB2!,centerYView: self.numberLB2!)
        self.k3SpecialView2.isHidden = true
        
        let line = UIView()
        line.backgroundColor = kGASerperatorLineGrayColor
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.bottom.left.right.equalTo(self.contentView)
            make.height.equalTo(5)
        }
    }
    
    private func getTextSize(text : String,font : UIFont) -> CGSize {
        let string = text as NSString
        let size = string.boundingRect(with: CGSize.init(width: Double(MAXFLOAT), height: Double(MAXFLOAT)), options:[.usesLineFragmentOrigin,.usesFontLeading], attributes: [NSFontAttributeName : font], context: nil).size
        return size
    }
    
    private func setOtherIssus(issuesArray : NSArray,lottery : NSDictionary) {
        
        self.numberLB1?.textColor = kGAFontRedColor
        self.numberLB2?.textColor = kGAFontRedColor
        
        let series_id = lottery.object(forKey: "series_id") as? Int
        
        if issuesArray.count > 1 {
            let dict1 = issuesArray[1] as? NSDictionary
            let issus1 = (dict1?.object(forKey: LotteryTrendAPIManager.DataKey.kIssue) as? String)! + "期"
            let winNumber1 = dict1?.object(forKey: LotteryTrendAPIManager.DataKey.kWn_number) as? String
            self.issusLB1?.text = issus1
            self.numberLB1?.text = winNumber1!
            if (series_id == 4) {
                self.numberLB1?.textColor = .clear
                var winNumberArray1 : NSArray? = self.convertWinNumber(numberStr: winNumber1!)
                if winNumberArray1 == nil || winNumberArray1?.count == 0 {
                    winNumberArray1 = ["-","-","-","-","-",]
                }
                self.k3SpecialView1.setTitles(numbers: winNumberArray1!)
                self.k3SpecialView1.isHidden = false
            }
        }
        
        if issuesArray.count > 2 {
            let dict2 = issuesArray[2] as? NSDictionary
            let issus2 = (dict2?.object(forKey: LotteryTrendAPIManager.DataKey.kIssue) as? String)! + "期"
            let winNumber2 = dict2?.object(forKey: LotteryTrendAPIManager.DataKey.kWn_number) as? String
            self.issusLB2?.text = issus2
            self.numberLB2?.text = winNumber2!
            if (series_id == 4) {
                self.numberLB2?.textColor = .clear
                var winNumberArray2 : NSArray? = self.convertWinNumber(numberStr: winNumber2!)
                if winNumberArray2 == nil || winNumberArray2?.count == 0 {
                    winNumberArray2 = ["-","-","-","-","-",]
                }
                self.k3SpecialView2.setTitles(numbers: winNumberArray2!)
                self.k3SpecialView2.isHidden = false
            }
        }
        self.setIssusLBConstraints()
    
    }
    
    //将连续字符串转为数组
    private func convertWinNumber(numberStr : String)-> NSArray {
        let numberArray : NSArray = numberStr.map{String($0)} as NSArray 
        return numberArray
    }
    
    private func setIssusLBConstraints() {
        let issusLB1Size = self.getTextSize(text: (self.issusLB1?.text)!, font: (self.issusLB1?.font)!)
        let issusLB1Width = ceil(issusLB1Size.width)
        self.issusLB1?.snp.updateConstraints({ (make) in
            make.width.equalTo(issusLB1Width)
        })
        
        let issusLB2Size = self.getTextSize(text: (self.issusLB2?.text)!, font: (self.issusLB2?.font)!)
        let issusLB2Width = ceil(issusLB2Size.width)
        self.issusLB2?.snp.updateConstraints({ (make) in
            make.width.equalTo(issusLB2Width)
        })
    }
    
    public func setData(data : NSDictionary) {
    
        self.nameLB?.text = "彩种"
        self.issusLB?.text = "xxxxxxx期"
        self.issusLB1?.text = "xxxxxxx期"
        self.numberLB1?.text = "- - - - -"
        self.issusLB2?.text = "xxxxxxx期"
        self.numberLB2?.text = "- - - - -"
        self.k3SpecialView1.isHidden = true
        self.k3SpecialView2.isHidden = true
        
        self.setIssusLBConstraints()
        
        for view in (self.winNumberView?.subviews)! {
            view.removeFromSuperview()
        }
        
        guard let name = data.object(forKey: LotteryTrendAPIManager.DataKey.kName) as? String else {return}
        self.nameLB?.text = name
        guard let issuesArray = data.object(forKey: LotteryTrendAPIManager.DataKey.kIssues) as? [NSDictionary] else {return}
        guard let lotteryId = data.object(forKey: LotteryTrendAPIManager.DataKey.kLottery_id) as? Int else {return}
        guard let lottery = GACacheManager.default.getLotteryDictionary(lotteryId: lotteryId) else {return}
        if issuesArray.count == 0 {
            self.trendBtn.isEnabled = false
            self.bettingBtn.isEnabled = false
            self.bettingBtn.backgroundColor = kGAViewGrayBackgoundColor
            let numberArray = ["-","-","-","-","-",]
            self.setNumberView(numbers: numberArray as NSArray,lottery: lottery,isOpen: false)
            return
        }
        self.trendBtn.isEnabled = true
        self.bettingBtn.isEnabled = true
        self.bettingBtn.backgroundColor = kGANavigationBackgroundColor
        let firstDict = issuesArray[0]
        let issus = firstDict.object(forKey: LotteryTrendAPIManager.DataKey.kIssue) as? String
        self.issusLB?.text = issus! + "期"
        let winNumber = firstDict.object(forKey: LotteryTrendAPIManager.DataKey.kWn_number) as? String
        
        if winNumber != nil && !((winNumber?.isEmpty)!){
            var numberArray : NSArray?
            numberArray = winNumber?.components(separatedBy: " ") as NSArray?
            //如果是单号
            if (numberArray?.count)! < 2 {
                numberArray =  self.convertWinNumber(numberStr: winNumber!)
            }
            self.setNumberView(numbers: numberArray! as NSArray,lottery: lottery,isOpen: true)
        } else {
            let numberArray = ["-","-","-","-","-",]
            self.setNumberView(numbers: numberArray as NSArray,lottery: lottery,isOpen: false)
        }
        
        self.setOtherIssus(issuesArray: issuesArray as NSArray,lottery : lottery)
    }
    
    private func setNumberView(numbers : NSArray,lottery : NSDictionary,isOpen : Bool) {

        let series_id = lottery.object(forKey: "series_id") as? UInt
        
        //如果是快三，则显示骰子
        if (series_id == eLotterySeriesType.eK3.rawValue) {
            let k3SpecialView : K3LastWinNumberView = K3LastWinNumberView.init(frame: CGRect.zero)
            self.winNumberView?.addSubview(k3SpecialView)
            k3SpecialView.setSubviewsConstrain(leftView: self.winNumberView!,centerYView: self.winNumberView!)
            k3SpecialView.setTitles(numbers: numbers)
        } else if series_id == eLotterySeriesType.eKL.rawValue {
            let mutiNumberView = MutiLastWinNumberView(numberArray: numbers as! [NSString], maxViewWidth: Double(self.winNumberView!.width))
            self.winNumberView?.addSubview(mutiNumberView)
            let viewW = mutiNumberView.setSubviewsConstrain()
            self.winNumberView?.snp.updateConstraints({ (make) in
                make.height.equalTo(viewW)
            })
        } else {
            let normalNumberView : NormalLastWinNumberView = NormalLastWinNumberView.init(frame: CGRect.zero, numberArray: numbers as! [NSString])
            self.winNumberView?.addSubview(normalNumberView)
            normalNumberView.setSubviewsConstrain()
        }
       
    }

}
