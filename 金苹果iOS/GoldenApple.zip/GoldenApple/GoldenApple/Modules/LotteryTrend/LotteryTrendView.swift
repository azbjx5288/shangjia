//
//  LotteryTrendView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/16.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class LotteryTrendView: UIView {

    public lazy var tableView : UITableView = {
        ()-> UITableView in
        let temp = UITableView()
        temp.separatorStyle = UITableViewCellSeparatorStyle.none
        return temp
    }()
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = .black
        self.addSubview(self.tableView)
        self.tableView.snp.makeConstraints { (make) in
            make.edges.equalTo(self)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

}
