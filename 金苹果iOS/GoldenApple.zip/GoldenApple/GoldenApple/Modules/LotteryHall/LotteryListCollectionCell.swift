//
//  LotteryListCollectionCell.swift
//  GoldenApple
//
//  Created by User on 26/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryListCollectionCell: UICollectionViewCell {
    
    lazy var iconImage: UIImageView = {
        let icon = UIImageView()
        return icon
    }()
    
    lazy var titleLabel: UILabel = {
        let title = UILabel()
        title.font = UIFont.boldSystemFont(ofSize: 11)
        title.textColor = UIColor.darkGray
        title.numberOfLines = 0
        title.textAlignment = .center
        
        return title
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.layer.borderColor = UIColor.lightGray.cgColor
        
        self.addSubview(self.iconImage)
        self.addSubview(self.titleLabel)
        
        self.iconImage.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
            make.height.width.equalTo(70)
        }
        
        self.titleLabel.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(self)
            make.height.equalTo(30)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setLotteryDict(_ lotteryDict: NSDictionary) {
        let lotteryName = lotteryDict.object(forKey: LotteryListAPIManager.DataKey.kName) as! String
        self.titleLabel.text = lotteryName
        let lotteryId = lotteryDict.object(forKey: LotteryListAPIManager.DataKey.kId) as! Int
        guard let iconName = GACacheManager.default.getLotteryIcon(lotteryId:lotteryId) else {return}
        self.iconImage.image = UIImage(named: iconName)
    }
    
}
