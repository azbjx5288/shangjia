//
//  LotteryMenuCollectionViewCell.swift
//  GoldenApple
//
//  Created by El Capitan on 2018/3/7.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class LotteryMenuCollectionViewCell: UICollectionViewCell {
    static let childMenuFontSize: CGFloat = 14.0
    let categoryLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: LotteryMethodCell.methodFontSize)
        label.textColor = kGAFontGrayColor
        label.text = "时时彩"
        label.layer.borderWidth = 1.0
        label.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        label.layer.cornerRadius = 5
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.categoryLabel)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.categoryLabel.frame = self.bounds
    }
    
    override var isSelected: Bool {
        didSet {
            if isSelected {
                self.categoryLabel.textColor = kGAFontRedColor
                self.categoryLabel.layer.borderColor = kGAFontRedColor.cgColor
            } else {
                self.categoryLabel.textColor = kGAFontGrayColor
                self.categoryLabel.layer.borderColor = kGASerperatorLineGrayColor.cgColor
            }
        }
    }
}
