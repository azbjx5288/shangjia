//
//  LotteryRulesOfPlay.swift
//  GoldenApple
//
//  Created by User on 09/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import JavaScriptCore
import MBProgressHUD

class LotteryRulesOfPlay: NSObject {
    
    static let kSeperactorCode = "|"
    
    fileprivate(set) var methodType: eLotteryMethodType?
    
    fileprivate(set) var lotteryType: eLotterySeriesType?
    
    /// 彩票信息dictionary，LotteryListAPIManager
    fileprivate var lotteryDict: NSDictionary?
    
    /// 玩法详细信息dictionary, MethodListAPIManager--MethodDetailKey
    fileprivate(set) var lotteryMethodDict: NSDictionary?
    
    fileprivate var mainGroupName: String!
    
    fileprivate let webView: UIWebView = {
        let web = UIWebView()
        
        return web
    }()
    
    fileprivate var jsContext: JSContext!
    
    fileprivate let iosJS: LotteryCalculateBettingCountByJS = {
        let js = LotteryCalculateBettingCountByJS.default
        
        return js
    }()
    
    static let `default` = LotteryRulesOfPlay()
    
    private override init() {
        super.init()
        
        let basePath = NSString(format: "%@/web", Bundle.main.bundlePath) as String
        let baseUrl = URL.init(fileURLWithPath: basePath, isDirectory: true)
        let htmlPath = NSString(format: "%@/game.html", basePath) as String
        let htmlString = try! NSString(contentsOfFile: htmlPath, encoding: String.Encoding.utf8.rawValue) as String
        self.webView.delegate = self
        self.webView.loadHTMLString(htmlString, baseURL: baseUrl)
        
        
    }
    
    
}

extension LotteryRulesOfPlay: UIWebViewDelegate {
    
    //    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
    //        MBProgressHUD.showAdded(to: self.webView, animated: true)
    //
    //    }
    //
    //    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
    //        MBProgressHUD.hide(for: self.webView, animated: true)
    //
    //        self.jsContext = webView.value(forKeyPath: "documentView.webView.mainFrame.javaScriptContext") as? JSContext
    //        self.jsContext!.exceptionHandler = { context, value in
    //            NSLog("web JS: %@", value!)
    //        }
    //    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        MBProgressHUD.showAdded(to: UIApplication.shared.keyWindow!, animated: true).label.text = "正在加载..."
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        MBProgressHUD.hide(for: UIApplication.shared.keyWindow!, animated: true)
        
        self.jsContext = webView.value(forKeyPath: "documentView.webView.mainFrame.javaScriptContext") as? JSContext
        
        self.jsContext.setObject(self.iosJS, forKeyedSubscript: "iOSJs" as NSCopying & NSObjectProtocol)
        
        self.jsContext.evaluateScript("calculate()")
        
        self.jsContext.exceptionHandler = { (context, exception) in
            print("exception：", exception as Any)
        }
    }
    
    
}

// MARK: - Public methods

extension LotteryRulesOfPlay {
    
    func clearAllData() {
        self.methodType = nil
        self.lotteryMethodDict = nil
        self.lotteryType = nil
        self.lotteryDict = nil
    }
    
    /// 设置每个彩系的默认玩法
    func setLotteryDict(dict: NSDictionary) {
        self.lotteryDict = dict
        
        let type = dict.object(forKey: LotteryListAPIManager.DataKey.kSeriesId) as! NSNumber
        self.lotteryType = eLotterySeriesType(rawValue: type.uintValue)
        switch self.lotteryType {
        case .eTime?:
            self.methodType = .yxdwd
        case .e11X5?:
            self.methodType = .rxyzyfs
        case .e3D?:
            self.methodType = .zxfs3d
        case .eK3?:
            self.methodType = .k3hz
        case .ePk10?:
            self.methodType = .cmc
        case .eKL?:
            self.methodType = .hzdskl
        case .eKL12?:
            self.methodType = .rx5
        case .eKL10?:
            self.methodType = .qszuxfskl10
        case .eGaGame?: break
        case .eOften?: break
        case .eAll?: break
            
        case .none:
            break
        }
    }
    
    func setLotteryMethodDict(dict: NSDictionary, mainGroupName: String) {
        
        self.lotteryMethodDict = dict
        self.mainGroupName = mainGroupName
        let type = dict.object(forKey: MethodListAPIManager.DataKey.MethodDetailKey.kSeriesWayId) as! NSNumber
        
        self.methodType = eLotteryMethodType(rawValue: type.uintValue)
        
    }
    
    func titleName() -> String? {
        
        let methodName = self.lotteryMethodDict?.object(forKey: MethodListAPIManager.DataKey.kNameCn) as? String
        if methodName != nil {
            //            return self.mainGroupName + "-" + methodName!
            return methodName!
        }
        
        return nil
    }
    
    func groupMethodName() -> String? {
        let methodName = self.lotteryMethodDict?.object(forKey: MethodListAPIManager.DataKey.kNameCn) as? String
        if methodName != nil {
            return self.mainGroupName + "-" + methodName!
        }
        
        return nil
    }
    
    func numberOfSections() -> Int {
        
        if self.methodType == nil {
            return 0
        }
        
        var section = 0
        switch self.methodType! {
        case .wxzx120, .qsanzxhz, .qsanzxkd, .qsanz3, .qsanz6, .qsanzuxhz, .zsanzxhz, .zsanzxkd, .zsanz3, .zsanz6, .zsanzuxhz, .hsanzxhz, .hsanzxkd, .hsanz3, .hsanz6, .hsanzuxhz, .hsanbd, .exhehz, .exhekd, .exqehz, .exqekd, .bdwhsanymbdw, .bdwhsanembdw, .bdwqsanymbdw, .bdwqsanembdw, .bdwsixymbdw, .bdwsixembdw, .dxdswxhzdxds, .lhhwq, .lhhwb, .lhhws, .lhhwg, .lhhqb, .lhhqs, .lhhqg, .lhhbs, .lhhbg, .lhhsg, .qsanzuxfs3m, .qsanzuxds3m, .qezuxfs2m, .qezuxds2m, .bdwqsanbdw, .ddsqwx, .czwqwx, .rxyzyfs, .rxyzyds, .rxezefs, .rxezeds, .rxszsfs, .rxszsds, .rxsizsifs, .rxsizsids, .rxwzwfs, .rxwzwds, .rxlzwfs, .rxlzwds, .rxqzwfs, .rxqzwds, .rxbzwfs, .rxbzwds, .c1bc, .c2bc, .c3bc, .c4bc, .c5bc, .k3hz, .sthdx, .sthtx, .ethfx, .sbth, .ebth, .slhtx, .k3dx, .k3ds, .k3cbc, .k3c1bc, .k3c2bc, .k3c3bc, .k3qhong, .k3qhei, .gyhhz, .gyhdxds, .zxhz3d, .zuxz33d, .zuxz63d, .zuxhz3d, .zuxz3ds3d, .zuxz6ds3d, .ymbdw3d, .ermbdw3d, .lhhbs3d, .lhhbg3d, .lhhsg3d, .cbc13d, .cbc23d, .cbc33d, .cbc43d, .cbc53d, .zuxherzux3d, .zuxqerzux3d, .rx1, .rx2, .rx3, .rx4, .rx5, .rx6, .rx7, .rx8, .rx2ds, .rx3ds, .rx4ds, .rx5ds, .rx6ds, .rx7ds, .rx8ds, .qerzuxfs, .qerzuxds, .qszuxfskl12, .qszuxdskl12, .rx2kl10, .rx3kl10, .rx4kl10, .rx5kl10, .rx6kl10, .rx7kl10, .rx2dskl10, .rx3dskl10, .rx4dskl10, .rx5dskl10, .rx6dskl10, .rx7dskl10, .qerzuxfskl10, .qerzuxdskl10, .qszuxfskl10, .qszuxdskl10, .hzdskl, .hzdx810kl, .hzwxkl, .johkl, .szxkl, .qsanhzws, .zsanhzws, .hsanhzws, .qsantshm, .zsantshm, .hsantshm, .bdwwuxembdw, .bdwwuxsmbdw, .yffs, .hscs, .sanxbx, .sijfc, .c1bcssc, .c2bcssc, .c3bcssc, .c4bcssc, .c5bcssc, .qsanz3ds, .qsanz6ds, .zsanz3ds, .zsanz6ds, .hsanz3ds, .hsanz6ds, .qsizux24, .qsizux6, .hsizux24, .hsizux6, .qsanbd, .qsanbz, .qsansz, .qsandz, .zsanbd, .zsanbz, .zsansz, .zsandz, .hsanbz, .hsansz, .hsandz, .exherbd, .exqerbd, .wxzxhz, .rerzhixuanhezhi, .rsanzhixuanhezhi, .rerzhixuankuadu, .rsanzhixuankuadu, .rerzuxuanfushi, .rerzuxuanhezhi, .rsanzuxuanhezhi, .rsanzu3fushi, .rsanzu6fushi, .rsizuxuan24, .rsizuxuan6:
            section = 1
            break
        case .wxzx60, .wxzx30, .wxzx20, .wxzx10, .wxzx5, .exhefs, .exheds, .exqefs, .exqeds, .dxdshedxds, .dxdsqedxds, .qsanzuxdt3m, .qezxfs2m, .qezxds2m, .qezuxdt2m, .rxezedt, .rxszsdt, .rxsizsidt, .rxwzwdt, .rxlzwdt, .rxqzwdt, .rxbzwdt, .ethdx, .jqqeds, .jqqefs, .jqheds, .jqhefs, .zxherzx3d, .zxherzxds3d, .zxqerzx3d, .zxqerds3d, .zuxherds3d, .zuxqerds3d, .rx2dt, .rx3dt, .rx4dt, .rx5dt, .rx6dt, .rx7dt, .rx8dt, .qerzxfs, .qerzxds, .qerzuxdt, .qszuxdtkl12, .rx2dtkl10, .rx3dtkl10, .rx4dtkl10, .rx5dtkl10, .rx6dtkl10, .rx7dtkl10, .qerzxfskl10, .qerzxdskl10, .qerzuxdtkl10, .qszuxdtkl10, .rx1fskl, .rx2fskl, .rx3fskl, .rx4fskl, .rx5fskl, .rx6fskl, .rx7fskl, .qsizux12, .qsizux4, .hsizux12, .hsizux4, .rsizuxuan12, .rsizuxuan4:
            section = 2
            break
        case .qsanzxfs, .qsanzxds, .zsanzxfs, .zsanzxds, .hsanzxfs, .hsanzxds, .dxdshsandxds, .dxdsqsandxds, .qsanzxfs3m, .qsanzxds3m, .jqqsands, .jqqsanfs, .jqhsands, .jqhsanfs, .zxfs3d, .zxds3d, .yxdwd3d, .qszxfskl12, .qszxdskl12, .qszxfskl10, .qszxdskl10, .hsanqwerx, .hsanqjerx, .qsanqwerx, .qsanqjerx, .qsanhhzux, .zsanhhzx, .hsanhhzux:
            section = 3
            break
        case .qsizxfs, .qsizxds, .hsizxfs, .hsizxds, .jqqsids, .jqqsifs, .jqhsids, .jqhsifs, .simqwsanx, .simqjsanx:
            section = 4
            break
        case .wxzxfs, .wxzxds, .yxdwd, .dwd11x5, .lh, .jqqwuds, .jqqwufs, .jqhwuds, .jqhwufs, .dwdkl12, .wmqwsanx, .wmqjsanx,. rerzhixuanfushi, .rsanzhixuanfushi, .rsizhixuanfushi, .rerzhixuandanshi:
            section = 5
            break
        case .cmc:
            section = 10
        default:
            section = 0
        }
        
        return section
    }
    
    func numberOfItemsInSection(section: Int) -> Int {
        
        if self.methodType == nil {
            return 0
        }
        
        var nItems = 0
        switch self.methodType! {
        case .sthtx, .slhtx, .k3qhong, .k3qhei, .qsanbz, .qsansz, .qsandz, .zsanbz, .zsansz, .zsandz, .hsanbz, .hsansz, .hsandz:
            nItems = 1
        case .k3dx, .k3ds, .lh, .hzdskl:
            nItems = 2
        case .lhhwq, .lhhwb, .lhhws, .lhhwg, .lhhqb, .lhhqs, .lhhqg, .lhhbs, .lhhbg, .lhhsg, .lhhbs3d, .lhhbg3d, .lhhsg3d, .hzdx810kl, .johkl, .szxkl, .qsantshm, .zsantshm, .hsantshm:
            nItems = 3
        case .dxdshedxds, .dxdshsandxds, .dxdsqedxds, .dxdsqsandxds, .dxdswxhzdxds, .gyhdxds:
            nItems = 4
        case .hzwxkl:
            nItems = 5
        case .ddsqwx, .sthdx, .ethdx, .ethfx, .sbth, .ebth, .k3cbc, .k3c1bc, .k3c2bc, .k3c3bc:
            nItems = 6
        case .czwqwx:
            nItems = 7
        case .wxzxfs, .wxzxds, .wxzx120, .wxzx60, .wxzx30, .wxzx20, .wxzx10, .wxzx5, .qsizxfs, .qsizxds, .hsizxfs, .hsizxds, .qsanzxfs, .qsanzxds, .qsanzxkd, .qsanz3, .qsanz6, .zsanzxfs, .zsanzxds, .zsanzxkd, .zsanz3, .zsanz6, .hsanzxfs, .hsanzxds, .hsanzxkd, .hsanz3, .hsanz6, .hsanbd, .exhefs, .exheds, .exhekd, .exqefs, .exqeds, .exqekd, .yxdwd, .bdwhsanymbdw, .bdwhsanembdw, .bdwqsanymbdw, .bdwqsanembdw, .bdwsixymbdw, .bdwsixembdw, .cmc, .jqqefs, .jqqeds, .jqhefs, .jqheds, .jqqsanfs, .jqqsands, .jqhsanfs, .jqhsands, .jqqsifs, .jqqsids, .jqhsifs, .jqhsids, .jqqwufs, .jqqwuds, .jqhwufs, .jqhwuds, .zxfs3d, .zxds3d, .zuxz33d, .zuxz63d, .zuxz3ds3d, .zuxz6ds3d, .zxherzx3d, .zxherzxds3d, .zxqerzx3d, .zxqerds3d, .zuxherzux3d, .zuxherds3d, .zuxqerzux3d, .zuxqerds3d, .yxdwd3d, .ymbdw3d, .ermbdw3d, .cbc13d, .cbc23d, .cbc33d, .cbc43d, .cbc53d, .qsanhzws, .zsanhzws, .hsanhzws, .bdwwuxembdw, .bdwwuxsmbdw, .yffs, .hscs, .sanxbx, .sijfc, .c1bcssc, .c2bcssc, .c3bcssc, .c4bcssc, .c5bcssc, .qsanhhzux, .zsanhhzx, .hsanhhzux, .qsanz3ds, .qsanz6ds, .zsanz3ds, .zsanz6ds, .hsanz3ds, .hsanz6ds, .qsizux24, .qsizux12, .qsizux6, .qsizux4, .hsizux24, .hsizux12, .hsizux6, .hsizux4, .qsanbd, .zsanbd, .exqerbd, .exherbd, .rerzhixuanfushi, .rsanzhixuanfushi, .rsizhixuanfushi, .rerzhixuankuadu, .rsanzhixuankuadu, .rerzuxuanfushi, .rsanzu3fushi, .rsanzu6fushi, .rsizuxuan24, .rsizuxuan12, .rsizuxuan6, .rsizuxuan4, .rerzhixuandanshi:
            nItems = 10
        case .qsanzxfs3m, .qsanzxds3m, .qsanzuxfs3m, .qsanzuxds3m, .qsanzuxdt3m, .qezxfs2m, .qezxds2m, .qezuxfs2m, .qezuxds2m, .qezuxdt2m, .bdwqsanbdw, .dwd11x5, .rxyzyfs, .rxyzyds, .rxezefs, .rxezeds, .rxszsfs, .rxszsds, .rxsizsifs, .rxsizsids, .rxwzwfs, .rxwzwds, .rxlzwfs, .rxlzwds, .rxqzwfs, .rxqzwds, .rxbzwfs, .rxbzwds, .rxezedt, .rxszsdt, .rxsizsidt, .rxwzwdt, .rxlzwdt, .rxqzwdt, .rxbzwdt, .c1bc, .c2bc, .c3bc, .c4bc, .c5bc:
            nItems = 11
        case .rx1, .rx2, .rx3, .rx4, .rx5, .rx6, .rx7, .rx8, .rx2ds, .rx3ds, .rx4ds, .rx5ds, .rx6ds, .rx7ds, .rx8ds, .rx2dt, .rx3dt, .rx4dt, .rx5dt, .rx6dt, .rx7dt, .rx8dt, .dwdkl12, .qerzxfs, .qerzxds, .qerzuxfs, .qerzuxds, .qerzuxdt, .qszxfskl12, .qszxdskl12, .qszuxfskl12, .qszuxdskl12, .qszuxdtkl12:
            nItems = 12
        case .k3hz:
            nItems = 16
        case .gyhhz, .rerzuxuanhezhi:
            nItems = 17
        case .exhehz, .exqehz, .rerzhixuanhezhi:
            nItems = 19
        case .rx2kl10, .rx3kl10, .rx4kl10, .rx5kl10, .rx6kl10, .rx7kl10, .rx2dskl10, .rx3dskl10, .rx4dskl10, .rx5dskl10, .rx6dskl10, .rx7dskl10, .rx2dtkl10, .rx3dtkl10, .rx4dtkl10, .rx5dtkl10, .rx6dtkl10, .rx7dtkl10, .qerzxfskl10, .qerzxdskl10, .qerzuxfskl10, .qerzuxdskl10, .qerzuxdtkl10, .qszxfskl10, .qszxdskl10, .qszuxfskl10, .qszuxdskl10, .qszuxdtkl10:
            nItems = 20
        case .qsanzuxhz, .zsanzuxhz, .hsanzuxhz, .zuxhz3d, .rsanzuxuanhezhi:
            nItems = 26
        case .qsanzxhz, .zsanzxhz, .hsanzxhz, .zxhz3d, .rsanzhixuanhezhi:
            nItems = 28
        case .rx1fskl, .rx2fskl, .rx3fskl, .rx4fskl, .rx5fskl, .rx6fskl, .rx7fskl:
            nItems = 40
        case .wxzxhz:
            nItems = 46
        case .wmqwsanx:
            if section < 2 {
                nItems = 2
            } else {
                nItems = 10
            }
        case .simqwsanx, .hsanqwerx, .qsanqwerx:
            if section == 0 {
                nItems = 2
            } else {
                nItems = 10
            }
        case .wmqjsanx:
            if section < 2 {
                nItems = 5
            } else {
                nItems = 10
            }
        case .simqjsanx, .hsanqjerx, .qsanqjerx:
            if section == 0 {
                nItems = 5
            } else {
                nItems = 10
            }
        default:
            nItems = 0
        }
        
        return nItems
    }
    
    //MARK: 是否有位数选择
    func hasDigit() -> [String]? {
        if self.methodType == nil {
            return nil
        }
        
        switch self.methodType! {
        case .rerzhixuanhezhi, .rerzhixuankuadu, .rerzuxuanfushi, .rerzuxuanhezhi, .rerzhixuandanshi, .rerzuxuandanshi:
            return ["十", "个"]
        case .rsanzhixuanhezhi, .rsanzhixuankuadu, .rsanzuxuanhezhi, .rsanzu3fushi, .rsanzu6fushi, .rsanzhixuandanshi, .rsanhunhezuxuan, .rsanzu3danshi, .rsanzu6danshi:
            return ["百", "十", "个"]
        case .rsizhixuandanshi, .rsizuxuan24, .rsizuxuan12, .rsizuxuan6, .rsizuxuan4:
            return ["千", "百", "十", "个"]
        default:
            return nil
        }
    }
    
    func renxuanNumbers() -> Int? {
        if self.methodType == nil {
            return nil
        }
        
        switch self.methodType! {
        case .rerzhixuanfushi, .rerzhixuanhezhi, .rerzhixuankuadu, .rerzuxuanfushi, .rerzuxuanhezhi, .rerzhixuandanshi, .rerzuxuandanshi:
            return 2
        case .rsanzhixuanhezhi, .rsanzhixuankuadu, .rsanzuxuanhezhi, .rsanzu3fushi, .rsanzu6fushi, .rsanzhixuandanshi, .rsanhunhezuxuan, .rsanzu3danshi, .rsanzu6danshi:
            return 3
        case .rsizhixuanfushi, .rsizhixuandanshi, .rsizuxuan24, .rsizuxuan12, .rsizuxuan6, .rsizuxuan4:
            return 4
        default:
            return nil
        }
    }
    
    func sectionsName() -> [String]? {
        if self.methodType == nil {
            return nil
        }
        
        let names: [String]?
        switch self.methodType! {
        case .wxzxfs, .yxdwd, .wmqwsanx, .wmqjsanx, .rerzhixuanfushi, .rsanzhixuanfushi, .rsizhixuanfushi:
            names = ["万位", "千位", "百位", "十位", "个位"]
        case .wxzx60, .wxzx30, .qsizux12, .hsizux12:
            names = ["二重号", "单号"]
        case .wxzx20, .qsizux4, .hsizux4:
            names = ["三重号", "单号"]
        case .wxzx10:
            names = ["三重号", "二重号"]
        case .wxzx5:
            names = ["四重号", "单号"]
        case .qsizux6, .hsizux6:
            names = ["二重号"]
        case .wxzx120:
            names = ["组选120"]
        case .zuxherzux3d, .zuxqerzux3d, .qsizux24, .hsizux24:
            names = ["组选"]
        case .qsizxfs:
            names = ["万位", "千位", "百位", "十位"]
        case .hsizxfs, .simqwsanx, .simqjsanx:
            names = ["千位", "百位", "十位", "个位"]
        case .qsanzxfs, .dxdsqsandxds, .qsanqwerx, .qsanqjerx:
            names = ["万位", "千位", "百位"]
        case .qsanz3, .zsanz3, .hsanz3, .zuxz33d:
            names = ["组三"]
        case .qsanz6, .zsanz6, .hsanz6, .zuxz63d:
            names = ["组六"]
        case .qsanzxhz, .zsanzxhz, .hsanzxhz:
            names = ["直选和值"]
        case .qsanzxkd, .zsanzxkd, .hsanzxkd:
            names = ["直选跨度"]
        case .qsanzuxhz, .zsanzuxhz, .hsanzuxhz:
            names = ["组选和值"]
        case .zsanzxfs:
            names = ["千位", "百位", "十位"]
        case .hsanzxfs, .dxdshsandxds, .zxfs3d, .yxdwd3d, .hsanqwerx, .hsanqjerx:
            names = ["百位", "十位", "个位"]
        case .hsanbd:
            names = ["包胆"]
        case .exhefs, .dxdshedxds, .zxherzx3d:
            names = ["十位", "个位"]
        case .exhehz:
            names = ["后二和值"]
        case .exhekd:
            names = ["后二跨度"]
        case .exqefs, .dxdsqedxds, .zxqerzx3d:
            names = ["万位", "千位"]
        case .exqehz:
            names = ["前二和值"]
        case .exqekd:
            names = ["前二跨度"]
        case .bdwhsanymbdw, .bdwhsanembdw, .bdwqsanymbdw, .bdwqsanembdw, .bdwsixymbdw, .bdwsixembdw, .ymbdw3d, .ermbdw3d, .bdwwuxembdw, .bdwwuxsmbdw:
            names = ["不定位"]
        case .dxdswxhzdxds, .wxzxhz:
            names = ["五星和值"]
        case .lhhwq:
            names = ["万:千"]
        case .lhhwb:
            names = ["万:百"]
        case .lhhws:
            names = ["万:十"]
        case .lhhwg:
            names = ["万:个"]
        case .lhhqb:
            names = ["千:百"]
        case .lhhqs:
            names = ["千:十"]
        case .lhhqg:
            names = ["千:个"]
        case .lhhbs, .lhhbs3d:
            names = ["百:十"]
        case .lhhbg, .lhhbg3d:
            names = ["百:个"]
        case .lhhsg, .lhhsg3d:
            names = ["十:个"]
        case .qsanzxfs3m, .qszxfskl12, .qszxfskl10:
            names = ["一位", "二位", "三位"]
        case .qsanzuxfs3m, .bdwqsanbdw, .qszuxfskl12, .qszuxfskl10:
            names = ["前三"]
        case .qsanzuxdt3m, .qezuxdt2m, .rxezedt, .rxszsdt, .rxsizsidt, .rxwzwdt, .rxlzwdt, .rxqzwdt, .rxbzwdt, .rx2dt, .rx3dt, .rx4dt, .rx5dt, .rx6dt, .rx7dt, .rx8dt, .qerzuxdt, .qszuxdtkl12, .rx2dtkl10, .rx3dtkl10, .rx4dtkl10, .rx5dtkl10, .rx6dtkl10, .rx7dtkl10, .qerzuxdtkl10, .qszuxdtkl10:
            names = ["胆码", "拖码"]
        case .qezxfs2m, .qerzxfs, .qerzxfskl10:
            names = ["一位", "二位"]
        case .qezuxfs2m, .qerzuxfs, .qerzuxfskl10:
            names = ["前二"]
        case .czwqwx:
            names = ["猜中位"]
        case .dwd11x5, .dwdkl12:
            names = ["一位", "二位", "三位", "四位", "五位"]
        case .rxyzyfs, .rx1:
            names = ["选1中1"]
        case .rxezefs, .rx2:
            names = ["选2中2"]
        case .rxszsfs, .rx3:
            names = ["选3中3"]
        case .rxsizsifs, .rx4:
            names = ["选4中4"]
        case .rxwzwfs, .rx5:
            names = ["选5中5"]
        case .rxlzwfs, .rx6:
            names = ["选6中5"]
        case .rxqzwfs, .rx7:
            names = ["选7中5"]
        case .rxbzwfs, .rx8:
            names = ["选8中5"]
        case .rx2kl10:
            names = ["任选二"]
        case .rx3kl10:
            names = ["任选三"]
        case .rx4kl10:
            names = ["任选四"]
        case .rx5kl10:
            names = ["任选五"]
        case .rx6kl10:
            names = ["任选六"]
        case .rx7kl10:
            names = ["任选七"]
        case .c1bc, .cbc13d, .c1bcssc:
            names = ["一个号"]
        case .c2bc, .cbc23d, .c2bcssc:
            names = ["二个号"]
        case .c3bc, .cbc33d, .c3bcssc:
            names = ["三个号"]
        case .c4bc, .cbc43d, .c4bcssc:
            names = ["四个号"]
        case .c5bc, .cbc53d, .c5bcssc:
            names = ["五个号"]
        case .gyhhz:
            names = ["冠亚和"]
        case .k3hz, .gyhdxds:
            names = ["和值"]
        case .qsanhzws, .zsanhzws, .hsanhzws:
            names = ["和值尾数"]
        case .sthdx:
            names = ["三同号单选"]
        case .sthtx:
            names = ["三同号通选"]
        case .ethdx:
            names = ["同号","不同号"]
        case .ethfx:
            names = ["二同号复选"]
        case .sbth:
            names = ["三不同号"]
        case .ebth:
            names = ["二不同号"]
        case .slhtx:
            names = ["三连号通选"]
        case .k3dx:
            names = ["大小"]
        case .k3ds:
            names = ["单双"]
        case .k3cbc:
            names = ["猜必出"]
        case .k3c1bc:
            names = ["猜1不出"]
        case .k3c2bc:
            names = ["猜2不出"]
        case .k3c3bc:
            names = ["猜3不出"]
        case .k3qhong:
            names = ["全红"]
        case .k3qhei:
            names = ["全黑"]
        case .cmc:
            names = ["冠军", "亚军", "季军", "第四名", "第五名", "第六名", "第七名", "第八名", "第九名", "第十名"]
        case .lh:
            names = ["1V10", "2V9", "3V8", "4V7", "5V6"]
        case .jqqefs:
            names = ["冠军", "亚军"]
        case .jqhefs:
            names = ["第九名", "第十名"]
        case .jqqsanfs:
            names = ["冠军", "亚军", "季军"]
        case .jqhsanfs:
            names = ["第八名", "第九名", "第十名"]
        case .jqqsifs:
            names = ["冠军", "亚军", "季军", "第四名"]
        case .jqhsifs:
            names = ["第七名", "第八名", "第九名", "第十名"]
        case .jqqwufs:
            names = ["冠军", "亚军", "季军", "第四名", "第五名"]
        case .jqhwufs:
            names = ["第六名", "第七名", "第八名", "第九名", "第十名"]
        case .rx1fskl, .rx2fskl, .rx3fskl, .rx4fskl, .rx5fskl, .rx6fskl, .rx7fskl:
            names = ["上", "下"]
        case .yffs:
            names = ["一帆风顺"]
        case .hscs:
            names = ["好事成双"]
        case .sanxbx:
            names = ["三星报喜"]
        case .sijfc:
            names = ["四季发财"]
        case .rerzhixuanhezhi:
            names = ["直选和值"]
        case.rsanzhixuanhezhi:
            names = ["直选和值"]
        case .rerzhixuankuadu, .rsanzhixuankuadu:
            names = ["直选跨度"]
        case .rerzuxuanhezhi, .rsanzuxuanhezhi:
            names = ["组选和值"]
        case .rsanzu3fushi:
            names = ["组三复式"]
        case .rsanzu6fushi:
            names = ["组六复式"]
        case .rsizuxuan24:
            names = ["组选24"]
        case .rsizuxuan12:
            names = ["二重号", "单号"]
        case .rsizuxuan6:
            names = ["组选6"]
        case .rsizuxuan4:
            names = ["三重号", "单号"]
        case .rerzuxuanfushi:
            names = ["组选复式"]
        default:
            names = nil
        }
        
        return names
    }
    
    func itemsNameInSection(_ section: Int) -> [String]? {
        
        if self.methodType == nil {
            return nil
        }
        
        let number = self.numberOfItemsInSection(section: section)
        let arraM = NSMutableArray()
        var names: [String]?
        func getDefaultNames() -> [String]? {
            for index in 0...number-1 {
                arraM.add(String(format: "%ld", index))
            }
            return arraM.copy() as? [String]
        }
        
        switch self.methodType! {
        case .qsanzuxhz, .zsanzuxhz, .hsanzuxhz, .sbth, .ebth, .k3cbc, .k3c1bc, .k3c2bc, .k3c3bc, .cmc, .jqqefs, .jqqeds, .jqhefs, .jqheds, .jqqsanfs, .jqqsands, .jqhsanfs, .jqhsands, .jqqsifs, .jqqsids, .jqhsifs, .jqhsids, .jqqwufs, .jqqwuds, .jqhwufs, .jqhwuds, .zuxhz3d, .rerzuxuanhezhi, .rsanzuxuanhezhi:
            for index in 1...number {
                arraM.add(String(format: "%ld", index))
            }
            names = arraM.copy() as? [String]
        case .k3hz, .gyhhz:
            for index in 1...number {
                arraM.add(String(format:"%ld", index + 2))
            }
            names = arraM.copy() as? [String]
        case .sthdx:
            names = ["111", "222", "333", "444", "555", "666"]
        case .sthtx, .slhtx:
            names = ["通选"]
        case .ethdx:
            (section == 0) ? (names = ["11", "22", "33", "44", "55", "66"]) : (names = ["1", "2", "3", "4", "5", "6"])
        case .ethfx:
            names = ["11*", "22*", "33*", "44*", "55*", "66*"]
        case .k3dx:
            names = ["大","小"]
        case .k3ds, .hzdskl:
            names = ["单","双"]
        case .k3qhong:
            names = ["全红"]
        case .k3qhei:
            names = ["全黑"]
        case .dxdshedxds, .dxdshsandxds, .dxdsqedxds, .dxdsqsandxds, .dxdswxhzdxds, .gyhdxds:
            names = ["大", "小", "单", "双"]
        case .lhhwq, .lhhwb, .lhhws, .lhhwg, .lhhqb, .lhhqs, .lhhqg, .lhhbs, .lhhbg, .lhhsg, .lhhbs3d, .lhhbg3d, .lhhsg3d:
            names = ["龙", "虎", "和"]
        case .qsanzxfs3m, .qsanzxds3m, .qsanzuxfs3m, .qsanzuxds3m, .qsanzuxdt3m, .qezxfs2m, .qezxds2m, .qezuxfs2m, .qezuxds2m, .qezuxdt2m, .bdwqsanbdw, .dwd11x5, .rxyzyfs, .rxyzyds, .rxezefs, .rxezeds, .rxszsfs, .rxszsds, .rxsizsifs, .rxsizsids, .rxwzwfs, .rxwzwds, .rxlzwfs, .rxlzwds, .rxqzwfs, .rxqzwds, .rxbzwfs, .rxbzwds, .rxezedt, .rxszsdt, .rxsizsidt, .rxwzwdt, .rxlzwdt, .rxqzwdt, .rxbzwdt, .c1bc, .c2bc, .c3bc, .c4bc, .c5bc, .rx1, .rx2, .rx3, .rx4, .rx5, .rx6, .rx7, .rx8, .rx2ds, .rx3ds, .rx4ds, .rx5ds, .rx6ds, .rx7ds, .rx8ds, .rx2dt, .rx3dt, .rx4dt, .rx5dt, .rx6dt, .rx7dt, .rx8dt, .dwdkl12, .qerzxfs, .qerzxds, .qerzuxfs, .qerzuxds, .qerzuxdt, .qszxfskl12, .qszxdskl12, .qszuxfskl12, .qszuxdskl12, .qszuxdtkl12, .rx2kl10, .rx3kl10, .rx4kl10, .rx5kl10, .rx6kl10, .rx7kl10, .rx2dskl10, .rx3dskl10, .rx4dskl10, .rx5dskl10, .rx6dskl10, .rx7dskl10, .rx2dtkl10, .rx3dtkl10, .rx4dtkl10, .rx5dtkl10, .rx6dtkl10, .rx7dtkl10, .qerzxfskl10, .qerzxdskl10, .qerzuxfskl10, .qerzuxdskl10, .qerzuxdtkl10, .qszxfskl10, .qszxdskl10, .qszuxfskl10, .qszuxdskl10, .qszuxdtkl10:
            for index in 1...number {
                arraM.add(String(format: "%02ld", index))
            }
            names = arraM.copy() as? [String]
        case .ddsqwx:
            names = ["5单0双", "4单1双", "3单2双", "2单3双", "1单4双", "0单5双"]
        case .czwqwx:
            names = ["03", "04", "05", "06", "07", "08", "09"]
        case .lh:
            names = ["龙", "虎"]
        case .hzdx810kl:
            names = ["大", "810", "小"]
        case .hzwxkl:
            names = ["金", "木", "水", "火", "土"]
        case .johkl:
            names = ["奇", "偶", "和"]
        case .szxkl:
            names = ["上", "中", "下"]
        case .rx1fskl, .rx2fskl, .rx3fskl, .rx4fskl, .rx5fskl, .rx6fskl, .rx7fskl:
            for index in 1...number {
                var arrNumber = index
                if 1 == section {
                    arrNumber += number
                }
                arraM.add(String(format: "%02ld", arrNumber))
            }
            names = arraM.copy() as? [String]
        case .qsantshm, .zsantshm, .hsantshm:
            names = ["豹子", "顺子", "对子"]
        case .qsanbz, .zsanbz, .hsanbz:
            names = ["豹子"]
        case .qsansz, .zsansz, .hsansz:
            names = ["顺子"]
        case .qsandz, .zsandz, .hsandz:
            names = ["对子"]
        case .wmqwsanx:
            if section < 2 {
                names = ["小(0-4)", "大(5-9)"]
            } else {
                names = getDefaultNames()
            }
        case .simqwsanx, .hsanqwerx, .qsanqwerx:
            if section == 0 {
                names = ["小(0-4)", "大(5-9)"]
            } else {
                names = getDefaultNames()
            }
        case .wmqjsanx:
            if section < 2 {
                names = ["一区(0,1)", "二区(2,3)", "三区(4,5)", "四区(5,7)", "五区(8,9)"]
            } else {
                names = getDefaultNames()
            }
        case .simqjsanx, .hsanqjerx, .qsanqjerx:
            if section == 0 {
                names = ["一区(0,1)", "二区(2,3)", "三区(4,5)", "四区(5,7)", "五区(8,9)"]
            } else {
                names = getDefaultNames()
            }
        default:
            names = getDefaultNames()
        }
        
        return names
    }
    
    ///是否显示批量选号器
    func lotterySectionChooseType(_ section: Int) -> eLotterySectionChooseType {
        
        var chooseType = eLotterySectionChooseType.none
        if self.methodType == nil {
            return chooseType
        }
        
        switch self.methodType! {
        case .dxdshedxds, .dxdshsandxds, .dxdsqedxds, .dxdsqsandxds, .dxdswxhzdxds, .lhhwq, .lhhwb, .lhhws, .lhhwg, .lhhqb, .lhhqs, .lhhqg, .lhhbs, .lhhbg, .lhhsg, .qezuxdt2m, .qsanzuxdt3m, .rxezedt, .rxszsdt, .rxsizsidt, .rxwzwdt, .rxlzwdt, .rxqzwdt, .rxbzwdt, .ddsqwx, .k3hz, .sthdx, .sthtx, .ethdx, .ethfx, .sbth, .ebth, .slhtx, .k3dx, .k3ds, .k3cbc, .k3qhong, .k3qhei, .gyhdxds, .lh, .zxhz3d, .zuxhz3d, .lhhbs3d, .lhhbg3d, .lhhsg3d , .rx2dt, .rx3dt, .rx4dt, .rx5dt, .rx6dt, .rx7dt, .rx8dt, .qerzuxdt, .qszuxdtkl12, .qerzuxdtkl10, .qszuxdtkl10, .rx2dtkl10, .rx3dtkl10, .rx4dtkl10, .rx5dtkl10, .rx6dtkl10, .rx7dtkl10, .hzdskl, .hzdx810kl, .hzwxkl, .johkl, .szxkl, .rx1fskl, .rx2fskl, .rx3fskl, .rx4fskl, .rx5fskl, .rx6fskl, .rx7fskl, .qsantshm, .zsantshm, .hsantshm, .qsanbd, .qsanbz, .qsansz, .qsandz, .zsanbd, .zsanbz, .zsansz, .zsandz, .hsanbd, .hsanbz, .hsansz, .hsandz:
            chooseType = .none
        case .wmqwsanx, .wmqjsanx:
            if section < 2 {
                chooseType = .none
            } else {
                chooseType = .chooseButton
            }
        case .simqwsanx, .simqjsanx, .hsanqwerx, .hsanqjerx, .qsanqwerx, .qsanqjerx:
            if section == 0 {
                chooseType = .none
            } else {
                chooseType = .chooseButton
            }
        default:
            chooseType = .chooseButton
        }
        
        return chooseType
    }
    
    func numberOfSelectedItem(_ section: Int) -> Int {
        var itemCount = self.numberOfItemsInSection(section: section)
        if self.methodType == nil {
            return itemCount
        }
        
        switch self.methodType! {
        case .qezuxdt2m, .rxezedt, .rx2dt, .qerzuxdt, .rx2dtkl10, .qerzuxdtkl10:
            itemCount = 0 == section ? 1 : itemCount
        case .qsanzuxdt3m, .rxszsdt, .rx3dt, .qszuxdtkl12, .rx3dtkl10, .qszuxdtkl10:
            itemCount = 0 == section ? 2 : itemCount
        case .rxsizsidt, .rx4dt, .rx4dtkl10:
            itemCount = 0 == section ? 3 : itemCount
        case .rxwzwdt, .rx5dt, .rx5dtkl10:
            itemCount = 0 == section ? 4 : itemCount
        case .rxlzwdt, .rx6dt, .rx6dtkl10:
            itemCount = 0 == section ? 5 : itemCount
        case .rxqzwdt, .rx7dt, .rx7dtkl10:
            itemCount = 0 == section ? 6 : itemCount
        case .rxbzwdt, .rx8dt:
            itemCount = 0 == section ? 7 : itemCount
        case .qsanbd, .zsanbd, .hsanbd, .exherbd, .exqerbd:
            itemCount = 1
        default:
            break
        }
        
        return itemCount
    }
    
    ///  判断是否在所有组中选择的item唯一
    ///
    /// - Returns: Bool
    func isUniqueSelectedItemInAllSection() -> Bool {
        var isUnique = false
        if self.methodType == nil {
            return isUnique
        }
        
        switch self.methodType! {
        case .qezuxdt2m, .qsanzuxdt3m, .rxezedt, .rxszsdt, .rxsizsidt, .rxwzwdt, .rxlzwdt, .rxqzwdt, .rxbzwdt, .rx2dt, .rx3dt, .rx4dt, .rx5dt, .rx6dt, .rx7dt, .rx8dt, .qerzuxdt, .qszuxdtkl12, .qerzuxdtkl10, .qszuxdtkl10, .rx2dtkl10, .rx3dtkl10, .rx4dtkl10, .rx5dtkl10, .rx6dtkl10, .rx7dtkl10:
            isUnique = true
        default:
            break
        }
        
        return isUnique
    }
    
    ///球的尺寸
    func setBallSize(section: Int) -> CGSize {
        var size = CGSize.zero
        if self.methodType == nil {
            return size
        }
        
        switch self.methodType! {
        case .ddsqwx:
            size = CGSize(width: 60, height: 40)
        case .hzdskl, .hzdx810kl, .johkl, .szxkl, .qsantshm, .zsantshm, .hsantshm, .qsanbz, .qsansz, .qsandz, .zsanbz, .zsansz, .zsandz, .hsanbz, .hsansz, .hsandz:
            size = CGSize(width: 50, height: 40)
        case .wmqwsanx, .wmqjsanx:
            if section < 2 {
                size = CGSize(width: 60, height: 40)
            }
        case .simqwsanx, .simqjsanx, .hsanqwerx, .hsanqjerx, .qsanqwerx, .qsanqjerx:
            if section == 0 {
                size = CGSize(width: 60, height: 40)
            }
        default:
            break
        }
        
        return size
    }
    
    /// 计算选中的号码获得正确投注号码
    ///
    /// - Parameter numberList: <#numberList description#>
    /// - Returns: <#return value description#>
    func  calculateBettingNumber(numberList: [NSArray]) -> String {
        
        if self.lotteryMethodDict == nil || self.lotteryDict == nil || self.jsContext == nil {
            return "0"
        }
        
        let bettingJS = LotteryCalculateBettingCountByJS.default
        bettingJS.methodId = self.lotteryMethodDict!.object(forKey: MethodListAPIManager.DataKey.kId) as! Int
        bettingJS.methodName = self.lotteryMethodDict![MethodListAPIManager.DataKey.kNameEn] as? NSString
        bettingJS.lotteryId = self.lotteryDict!.object(forKey: LotteryListAPIManager.DataKey.kId) as! Int
        bettingJS.seriesId = self.lotteryDict!.object(forKey: LotteryListAPIManager.DataKey.kSeriesId) as! Int
        bettingJS.numberList = numberList
        self.jsContext.evaluateScript("calculate()")
        
        let bettingNumber = LotteryCalculateBettingCountByJS.default.bettingNumber
        
        
        return String(format: "%ld", bettingNumber)
    }
    
    /// 复式模式解析投注号码
    ///
    /// - Returns: <#return value description#>
    func parseTheBettingNumber(indexPathList: [IndexPath]) -> String {
        
        if self.methodType == nil {
            return ""
        }
        
        let sortArray = indexPathList.sorted(by: { (item1, item2) -> Bool in
            if item1.section > item2.section {
                return false
            } else if item1.section == item2.section {
                return item1.item < item2.item
            }
            return true
        })
        
        let nSection = self.numberOfSections()
        let numberList = NSMutableArray()
        for index in 0...nSection-1 {
            let itemsName = self.itemsNameInSection(index)
            if itemsName == nil {
                return ""
            }
            
            let numberStrM = NSMutableArray()
            for item in sortArray {
                if item.section == index {
                    numberStrM.add(itemsName![item.item])
                }
            }
            
            //同一组每个号码之间的分隔符设置
            var numberStr = numberStrM.componentsJoined(by: "")
            if self.isSpaceSeparatedNumber() {
                numberStr = numberStrM.componentsJoined(by: " ")
            }
            switch self.methodType! {
           
            case .qsanzxhz, .qsanzuxhz, .zsanzxhz, .zsanzuxhz, .hsanzxhz, .hsanzuxhz, .exhehz, .exqehz, .k3hz, .sthdx, .ethfx, .sbth, .ebth, .k3dx, .k3ds, .k3cbc, .gyhhz, .zxhz3d, .zuxhz3d, .wxzxhz, .rerzhixuanhezhi, .rerzuxuanhezhi, .rsanzuxuanhezhi, .rsanzhixuanhezhi:
                numberStr = numberStrM.componentsJoined(by: LotteryRulesOfPlay.kSeperactorCode)
            default:
                break
            }
            
            if numberStr.count == 0 {
                numberStr = ""
            }
            numberList.add(numberStr)
        }
        
        let joinedCode = self.joinStringInNumberList()
        return numberList.componentsJoined(by: joinedCode)
    }
    
    //itemName转换为服务端对应投注号码
    func convertBetingString(ballStr: String, type: eLotteryMethodType) -> String {
        
        var convertStr = ballStr
        
        switch type {
            
        case .dxdshedxds, .dxdshsandxds, .dxdsqedxds, .dxdsqsandxds, .dxdswxhzdxds, .k3dx, .gyhdxds:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "大", with: "1").replacingOccurrences(of: "小", with: "0").replacingOccurrences(of: "单", with: "3").replacingOccurrences(of: "双", with: "2")
        case .k3ds, .hzdskl:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "单", with: "1").replacingOccurrences(of: "双", with: "0")
        case .lhhwq, .lhhwb, .lhhws, .lhhwg, .lhhqb, .lhhqs, .lhhqg, .lhhbs, .lhhbg, .lhhsg, .lhhbs3d, .lhhbg3d, .lhhsg3d:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "龙", with: "2").replacingOccurrences(of: "虎", with: "0").replacingOccurrences(of: "和", with: "1")
        //快3三同号单选、二同号单选、二同号复选投注时每个号只取itemName的一个字符,如111、11*、11取1
        case .sthdx:
            for i in 1...6 {
                convertStr = (convertStr as NSString).replacingOccurrences(of: String(format:"%d%d%d",i,i,i), with: String(i))
            }
        case .ethdx:
            for i in 1...6 {
                convertStr = (convertStr as NSString).replacingOccurrences(of: String(format:"%d%d",i,i), with: String(i))
            }
        case .ethfx:
            for i in 1...6 {
                convertStr = (convertStr as NSString).replacingOccurrences(of: String(format:"%d%d%@",i,i,"*"), with: String(i))
            }
        case .lh:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "龙", with: "1").replacingOccurrences(of: "虎", with: "0")
        case .qsantshm, .zsantshm, .hsantshm:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "豹子", with: "0").replacingOccurrences(of: "顺子", with: "1").replacingOccurrences(of: "对子", with: "2")
        case .qsanbz, .zsanbz, .hsanbz:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "豹子", with: "0")
        case .qsansz, .zsansz, .hsansz:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "顺子", with: "1")
        case .qsandz, .zsandz, .hsandz:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "对子", with: "2")
        case .hzdx810kl:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "大", with: "2").replacingOccurrences(of: "810", with: "1").replacingOccurrences(of: "小", with: "0")
        case .hzwxkl:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "金", with: "0").replacingOccurrences(of: "木", with: "1").replacingOccurrences(of: "水", with: "2").replacingOccurrences(of: "火", with: "3").replacingOccurrences(of: "土", with: "4")
        case .johkl:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "奇", with: "1").replacingOccurrences(of: "偶", with: "0").replacingOccurrences(of: "和", with: "2")
        case .szxkl:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "上", with: "2").replacingOccurrences(of: "中", with: "1").replacingOccurrences(of: "下", with: "0")
        case .wmqwsanx, .simqwsanx, .hsanqwerx, .qsanqwerx:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "小(0-4)", with: "0").replacingOccurrences(of: "大(5-9)", with: "1")
        case .wmqjsanx, .simqjsanx, .hsanqjerx, .qsanqjerx:
            convertStr = (ballStr as NSString).replacingOccurrences(of: "一区(0,1)", with: "0").replacingOccurrences(of: "二区(2,3)", with: "1").replacingOccurrences(of: "三区(4,5)", with: "2").replacingOccurrences(of: "四区(5,7)", with: "3").replacingOccurrences(of: "五区(8,9)", with: "4")
        default:
            break
        }
        
        return convertStr
    }
    
    /// 是否是单式投注
    ///
    /// - Returns: <#return value description#>
    func isManualBetting() -> Bool {
        if let dic = self.lotteryMethodDict {
            print(dic["series_way_id"])
        }
        var bManual = false
        
        if self.methodType == nil {
            return bManual
        }
        
        switch self.methodType! {
        case .wxzxds, .qsizxds, .hsizxds, .qsanzxds, .zsanzxds, .hsanzxds, .exheds, .exqeds, .qsanzxds3m, .qsanzuxds3m, .qezxds2m, .qezuxds2m, .rxyzyds, .rxezeds, .rxszsds, .rxsizsids, .rxwzwds, .rxlzwds, .rxqzwds, .rxbzwds, .jqqeds, .jqheds, .jqqsands, .jqhsands, .jqqsids, .jqhsids, .jqqwuds, .jqhwuds, .zxds3d, .zuxz3ds3d, .zuxz6ds3d, .zxherzxds3d, .zxqerds3d, .zuxherds3d, .zuxqerds3d, .rx2ds, .rx3ds, .rx4ds, .rx5ds, .rx6ds, .rx7ds, .rx8ds, .qerzxds, .qerzuxds, .qszxdskl12, .qszuxdskl12, .rx2dskl10, .rx3dskl10, .rx4dskl10, .rx5dskl10, .rx6dskl10, .rx7dskl10, .qerzxdskl10, .qerzuxdskl10, .qszxdskl10, .qszuxdskl10, .qsanhhzux, .qsanz3ds, .qsanz6ds, .zsanhhzx, .zsanz3ds, .zsanz6ds, .hsanhhzux, .hsanz3ds, .hsanz6ds, .rerzhixuandanshi, .rerzuxuandanshi, .rsanzhixuandanshi, .rsanhunhezuxuan, .rsizhixuandanshi, .rsanzu3danshi, .rsanzu6danshi:
            bManual = true
        default:
            break
        }
        
        return bManual
    }
    
    /// 是否是空格分隔投注号码
    ///
    /// - Returns: <#return value description#>
    func isSpaceSeparatedNumber() -> Bool {
        var bSpace = false
        if self.methodType == nil || self.lotteryType == nil {
            return bSpace
        }
        
        switch self.lotteryType! {
        case .e11X5, .eKL12, .eKL10:
            bSpace = true
        default:
            break
        }
        
        switch self.methodType! {
        case .cmc, .jqqefs, .jqqeds, .jqhefs, .jqheds, .jqqsanfs, .jqqsands, .jqhsanfs, .jqhsands, .jqqsifs, .jqqsids, .jqhsifs, .jqhsids, .jqqwufs, .jqqwuds, .jqhwufs, .jqhwuds, .rx1fskl, .rx2fskl, .rx3fskl, .rx4fskl, .rx5fskl, .rx6fskl, .rx7fskl:
            bSpace = true
        default:
            break
        }
        
        return bSpace
    }
    
    func joinStringInNumberList() -> String {
        var code = LotteryRulesOfPlay.kSeperactorCode
        
        switch self.methodType! {
        case .rx1fskl, .rx2fskl, .rx3fskl, .rx4fskl, .rx5fskl, .rx6fskl, .rx7fskl:
            code = " "
        default:
            break
        }
        
        return code
    }
    
    ///MAEK:是否需要排序
    func needSort() -> Bool {
        switch self.methodType! {
        case .rerzuxuandanshi, .rsanzu6danshi, .rsanhunhezuxuan:
            return true
        default:
            return false
        }
    }
    
    ///MARK: 是否只有一列
    func isSoloSection() -> Bool {
        switch self.methodType! {
        case .rerzuxuandanshi:
            return true
        default:
            return false
        }
    }
}
