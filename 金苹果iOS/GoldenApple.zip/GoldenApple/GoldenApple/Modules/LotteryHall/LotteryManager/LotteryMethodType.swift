//
//  LotteryMethodType.swift
//  GoldenApple
//
//  Created by User on 09/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

enum eLotterySeriesType: UInt {
    case eTime = 1
    case e11X5 = 2
    case e3D = 3
    case eK3 = 4
    case ePk10 = 5
    case eKL = 7
    case eKL12 = 8
    case eKL10 = 9
    case eGaGame = 13
    case eOften = 9999
    case eAll = 10000
}

enum eLotteryType: UInt {
    
    ///苹果分分彩
    case ePGFFC = 13
    ///苹果三分彩
    case ePGSFC = 16
    ///苹果极速PK10
    case ePGJSPK10 = 19
    ///苹果极速3D
    case ePGJS3d = 20
    ///苹果五分彩
    case ePGWFC = 28
    ///苹果秒秒彩
    case ePGMMC = 26
    ///苹果11选5
    case ePG11X5 = 14
    ///苹果快三分分彩
    case ePGK3FFC = 17
    ///重庆快乐十分
    case eCQKLSF = 41
    ///广东快乐十分
    case eGDKLSF = 57
    
}

enum eLotteryId: Int {
    //所有
    case all = -1
    //重庆时时彩
    case cqssc = 1
    //山东11选5
    case sd11x5 = 2
    //黑龙江时时彩
    case hljssc = 3
    //上海时时乐
    case shssl = 4
    //新疆时时彩
    case xjssc = 6
    //天津时时彩
    case tjssc = 7
    //江西11选5
    case jx115 = 8
    //广东11选5
    case gd115 = 9
    //北京PK拾
    case bjpk10 = 10
    //3D
    case sd = 11
    //排列三/五
    case plw = 12
    //苹果分分彩
    case pgffc = 13
    //苹果11选5
    case pg115 = 14
    //江苏快三
    case jsks = 15
    //苹果三分彩
    case pg3fc = 16
    //苹果快三分分彩
    case pgksffc = 17
    //甘肃快三
    case gsks = 18
    //苹果极速PK10
    case pgjspk10 = 19
    //苹果极速3D
    case pgjs3d = 20
    //广西快三
    case gxks = 21
    //北京11选5
    case bj11x5 = 22
    //安徽11选5
    case ah115 = 24
    //辽宁11选5
    case ln115 = 25
    //福建11选5
    case fj115 = 27
    //苹果五分彩
    case pg5fc = 28
    //贵州11选5
    case gz115 = 29
    //安徽快三
    case ahks = 30
    //山西11选5
    case sx11x5 = 32
    //河北快三
    case hbks = 33
    //内蒙古11选5
    case nmg115 = 34
    //北京快乐8
    case bjkl8 = 37
    //四川快乐十二
    case scklse = 39
    //重庆快乐十分
    case cqsxklsf = 41
    //浙江快乐十二
    case zjklse = 42
    //11选5三分彩
    case pg11x5sfc = 44
    //江苏11选5
    case sj115 = 47
    //福建快三
    case fjks = 48
    //缅甸百秒彩
    case mdbmc = 49
    //苹果快乐8分分彩
    case pgkl8ffc = 51
    //上海11选5
    case sh11x5 = 52
    //河北11选5
    case hb115 = 53
    //河南快三
    case hnks = 55
    //天津11选5
    case tj115 = 56
    //广东快乐十分
    case gdsxklsf = 57
    //辽宁快乐十二
    case lnklse = 59
    //浙江11选5
    case zj115 = 92
    //台湾宾果
    case twbg = 93
}

/// 转账平台
///
/// - <#case#>: <#<#case#> description#>
enum eTransferPlatform: UInt {
    case eJC = 1    //
    case eAGGame = 2
    case eGoldApple //主平台
    case eGAGame = 4
}

enum eLotterySectionChooseType {
    case none
    case chooseButton //选择按钮，全大小奇偶清
}

enum eLotteryMethodType: UInt {
    
    case none = 0
    ///---时时彩
    
    ///五星直选复式
    case wxzxfs = 68
    ///五星组选120
    case wxzxds = 7
    ///五星组选和值
    case wxzxhz = 494
    ///五星组选120
    case wxzx120 = 32
    ///五星组选60
    case wxzx60 = 31
    ///五星组选30
    case wxzx30 = 30
    ///五星组选20
    case wxzx20 = 29
    ///五星组选10
    case wxzx10 = 28
    ///五星组选5
    case wxzx5 = 27
    
    ///前四直选复式
    case qsizxfs = 295
    ///前四直选单式
    case qsizxds = 351
    /// 前四组选24
    case qsizux24 = 242
    /// 前四组选12
    case qsizux12 = 329
    /// 前四组选6
    case qsizux6 = 243
    /// 前四组选4
    case qsizux4 = 330
    
    ///后四直选复式
    case hsizxfs = 67
    ///后四直选单式
    case hsizxds = 6
    ///后四组选24
    case hsizux24 = 26
    ///后四组选12
    case hsizux12 = 25
    ///后四组选6
    case hsizux6 = 24
    ///后四组选4
    case hsizux4 = 23
    
    ///前三直选复式
    case qsanzxfs = 65
    ///前三直选单式
    case qsanzxds = 1
    ///前三直选和值
    case qsanzxhz = 71
    ///前三直选跨度
    case qsanzxkd = 60
    ///前三组三
    case qsanz3 = 16
    ///前三组六
    case qsanz6 = 17
    /// 前三混合组选
    case qsanhhzux = 13
    ///前三组选和值
    case qsanzuxhz = 75
    /// 前三组三单式
    case qsanz3ds = 2
    /// 前三组六单式
    case qsanz6ds = 3
    /// 前三和值尾数
    case qsanhzws = 33
    /// 前三特殊号码
    case qsantshm = 48
    /// 前三包胆
    case qsanbd = 64
    /// 前三豹子
    case qsanbz = 388
    /// 前三顺子
    case qsansz = 387
    /// 前三对子
    case qsandz = 385
    
    ///中三直选复式
    case zsanzxfs = 150
    ///中三直选单式
    case zsanzxds = 142
    ///中三直选和值
    case zsanzxhz = 151
    ///中三直选跨度
    case zsanzxkd = 149
    ///中三组三
    case zsanz3 = 145
    ///中三组六
    case zsanz6 = 146
    ///中三组选和值
    case zsanzuxhz = 154
    /// 中三混合组选
    case zsanhhzx = 152
    ///中三组三单式
    case zsanz3ds = 143
    ///中三组六单式
    case zsanz6ds = 144
    /// 中三和值尾数
    case zsanhzws = 156
    /// 中三特殊号码
    case zsantshm = 155
    /// 中三包胆
    case zsanbd = 153
    /// 中三豹子
    case zsanbz = 393
    /// 中三顺子
    case zsansz = 392
    /// 中三对子
    case zsandz = 391
    
    ///后三直选复式
    case hsanzxfs = 69
    ///后三直选单式
    case hsanzxds = 8
    ///后三直选和值
    case hsanzxhz = 73
    ///后三直选跨度
    case hsanzxkd = 62
    ///后三组三
    case hsanz3 = 49
    ///后三组六
    case hsanz6 = 50
    ///后三组选和值
    case hsanzuxhz = 80
    ///后三包胆
    case hsanbd = 83
    ///后三混合组选
    case hsanhhzux = 81
    ///后三组三单式
    case hsanz3ds = 9
    ///后三组六单式
    case hsanz6ds = 10
    ///后三和值尾数
    case hsanhzws = 54
    ///后三特殊号码
    case hsantshm = 57
    /// 后三豹子
    case hsanbz = 390
    /// 后三顺子
    case hsansz = 389
    /// 后三对子
    case hsandz = 386
    
    ///二星后二复式
    case exhefs = 70
    ///二星后二单式
    case exheds = 11
    ///二星后二和值
    case exhehz = 74
    ///二星后二跨度
    case exhekd = 63
    ///二星前二复式
    case exqefs = 66
    ///二星前二单式
    case exqeds = 4
    ///二星前二和值
    case exqehz = 72
    ///二星前二跨度
    case exqekd = 61
    /// 二星后二包胆
    case exherbd = 85
    /// 二星前二包胆
    case exqerbd = 84
    
    ///一星定位胆
    case yxdwd = 78
    
    ///不定位后三一码不定位
    case bdwhsanymbdw = 51
    ///不定位后三二码不定位
    case bdwhsanembdw = 52
    ///不定位前三一码不定位
    case bdwqsanymbdw = 18
    ///不定位前三二码不定位
    case bdwqsanembdw = 21
    ///不定位四星一码不定位
    case bdwsixymbdw = 34
    ///不定位四星二码不定位
    case bdwsixembdw = 35
    ///不定位五星二码不定位
    case bdwwuxembdw = 36
    ///不定位五星三码不定位
    case bdwwuxsmbdw = 37
    
    ///大小单双后二大小单双
    case dxdshedxds = 58
    ///大小单双后三大小单双
    case dxdshsandxds = 53
    ///大小单双前二大小单双
    case dxdsqedxds = 19
    ///大小单双前三大小单双
    case dxdsqsandxds = 22
    ///大小单双五星和值大小单双
    case dxdswxhzdxds = 495
    
    ///龙虎和万千
    case lhhwq = 352
    ///龙虎和万百
    case lhhwb = 353
    ///龙虎和万十
    case lhhws = 354
    ///龙虎和万个
    case lhhwg = 355
    ///龙虎和千百
    case lhhqb = 356
    ///龙虎和千十
    case lhhqs = 357
    ///龙虎和千个
    case lhhqg = 358
    ///龙虎和百十
    case lhhbs = 359
    ///龙虎和百个
    case lhhbg = 360
    ///龙虎和十个
    case lhhsg = 361
    ///趣味
    ///五码趣味三星
    case wmqwsanx = 38
    ///四码趣味三星
    case simqwsanx = 39
    ///后三趣味二星
    case hsanqwerx = 55
    ///前三趣味二星
    case qsanqwerx = 40
    ///五码区间三星
    case wmqjsanx = 41
    ///四码区间三星
    case simqjsanx = 42
    ///后三区间二星
    case hsanqjerx = 56
    ///前三区间二星
    case qsanqjerx = 43
    ///一帆风顺
    case yffs = 44
    ///好事成双
    case hscs = 45
    ///三星报喜
    case sanxbx = 46
    ///四季发财
    case sijfc = 47
    ///猜不出时时彩
    ///猜1不出
    case c1bcssc = 362
    ///猜2不出
    case c2bcssc = 363
    /// 猜3不出
    case c3bcssc = 364
    /// 猜4不出
    case c4bcssc = 365
    /// 猜5不出
    case c5bcssc = 366
    /// 任选二直选复式
    case rerzhixuanfushi = 199
    /// 任选三直选复式
    case rsanzhixuanfushi = 179
    /// 任选四直选复式
    case rsizhixuanfushi = 180
    /// 任选二直选和值
    case rerzhixuanhezhi = 196
    /// 任选三直选和值
    case rsanzhixuanhezhi = 183
    ///任二直选跨度
    case rerzhixuankuadu = 198
    ///任三直选跨度
    case rsanzhixuankuadu = 185
    ///任二组选复式
    case rerzuxuanfushi = 195
    ///任二组选和值
    case rerzuxuanhezhi = 197
    ///任三组选和值
    case rsanzuxuanhezhi = 184
    ///任三组三复式
    case rsanzu3fushi = 181
    ///任三组六复式
    case rsanzu6fushi = 182
    ///任二直选单式
    case rerzhixuandanshi = 200
    ///任二组选单式
    case rerzuxuandanshi = 201
    ///任三直选单式
    case rsanzhixuandanshi = 186
    ///任三组选混合
    case rsanhunhezuxuan = 190
    ///任四直选单式
    case rsizhixuandanshi = 187
    ///任三组三单式
    case rsanzu3danshi = 188
    ///任三组六单式
    case rsanzu6danshi = 189
    ///任四组选24
    case rsizuxuan24 = 194
    ///任四组选12
    case rsizuxuan12 = 193
    ///任四组选6
    case rsizuxuan6 = 192
    ///任四组选4
    case rsizuxuan4 = 191
    
    
    ///11选5
    ///前三直选复式--三码11x5
    case qsanzxfs3m = 112
    ///前三直选单式--三码11x5
    case qsanzxds3m = 95
    ///前三组选复式--三码11x5
    case qsanzuxfs3m = 108
    ///前三组选单式--三码11x5
    case qsanzuxds3m = 97
    ///前三组选胆拖--三码11x5
    case qsanzuxdt3m = 121
    ///前二直选复式--二码11x5
    case qezxfs2m = 111
    ///前二直选单式--二码11x5
    case qezxds2m = 94
    ///前二组选复式--二码11x5
    case qezuxfs2m = 107
    ///前二组选单式--二码11x5
    case qezuxds2m = 96
    ///前二组选胆拖--二码11x5
    case qezuxdt2m = 120
    ///前三不定位--不定位11x5
    case bdwqsanbdw = 122
    ///定单双--趣味型11x5
    case ddsqwx = 109
    ///猜中位--趣味型11x5
    case czwqwx = 110
    ///定位胆--11x5
    case dwd11x5 = 106
    ///任选一中一复式--11x5
    case rxyzyfs = 98
    ///任选二中二复式--11x5
    case rxezefs = 99
    ///任选三中三复式--11x5
    case rxszsfs = 100
    ///任选四中四复式--11x5
    case rxsizsifs = 101
    ///任选五中五复式--11x5
    case rxwzwfs = 102
    ///任选六中五复式--11x5
    case rxlzwfs = 103
    ///任选七中五复式--11x5
    case rxqzwfs = 104
    ///任选八中五复式--11x5
    case rxbzwfs = 105
    ///任选一中一单式--11x5
    case rxyzyds = 86
    ///任选二中二单式--11x5
    case rxezeds = 87
    ///任选三中三单式--11x5
    case rxszsds = 88
    ///任选四中四单式--11x5
    case rxsizsids = 89
    ///任选五中五单式--11x5
    case rxwzwds = 90
    ///任选六中五单式--11x5
    case rxlzwds = 91
    ///任选七中五单式--11x5
    case rxqzwds = 92
    ///任选八中五单式--11x5
    case rxbzwds = 93
    ///任选二中二胆拖--11x5
    case rxezedt = 113
    ///任选三中三胆拖
    case rxszsdt = 114
    ///任选四中四胆拖
    case rxsizsidt = 115
    ///任选五中五胆拖
    case rxwzwdt = 116
    ///任选六中五胆拖
    case rxlzwdt = 117
    ///任选七中五胆拖
    case rxqzwdt = 118
    ///任选八中五胆拖
    case rxbzwdt = 119
    ///猜1不出
    case c1bc = 380
    ///猜2不出
    case c2bc = 381
    ///猜3不出
    case c3bc = 382
    ///猜4不出
    case c4bc = 383
    ///猜5不出
    case c5bc = 384
    
    ///快3
    ///和值
    case k3hz = 157
    ///三同号单选
    case sthdx = 158
    ///三同号通选
    case sthtx = 159
    ///二同号单选
    case ethdx = 160
    ///二同号复选
    case ethfx = 161
    ///三不同号
    case sbth = 162
    ///二不同号
    case ebth = 163
    ///三连号通选
    case slhtx = 164
    ///大小
    case k3dx = 165
    ///单双
    case k3ds = 166
    ///猜必出
    case k3cbc = 167
    ///猜1不出
    case k3c1bc = 375
    ///猜2不出
    case k3c2bc = 376
    ///猜3不出
    case k3c3bc = 377
    ///全红
    case k3qhong = 378
    ///全黑
    case k3qhei = 379
    
    /// pk10
    /// 冠亚和值-和值
    case gyhhz = 175
    /// 冠亚和值-大小单双
    case gyhdxds = 176
    /// 猜名次
    case cmc = 177
    /// 龙虎
    case lh = 178
    /// 精确前二复式
    case jqqefs = 172
    /// 精确前二单式
    case jqqeds = 396
    /// 精确后二复式
    case jqhefs = 394
    /// 精确后二单式
    case jqheds = 398
    /// 精确前三复式
    case jqqsanfs = 173
    /// 精确前三单式
    case jqqsands = 397
    /// 精确后三复式
    case jqhsanfs = 395
    /// 精确后三单式
    case jqhsands = 399
    /// 精确前四复式
    case jqqsifs = 486
    /// 精确前四单式
    case jqqsids = 488
    /// 精确后四复式
    case jqhsifs = 487
    /// 精确后四单式
    case jqhsids = 489
    /// 精确前五复式
    case jqqwufs = 490
    /// 精确前五单式
    case jqqwuds = 492
    /// 精确后五复式
    case jqhwufs = 491
    /// 精确后五单式
    case jqhwuds = 493
    
    ///3D
    /// 直选-复式
    case zxfs3d = 136
    /// 直选-单式
    case zxds3d = 123
    /// 直选和值
    case zxhz3d = 139
    /// 组选-组三
    case zuxz33d = 131
    /// 组六
    case zuxz63d = 132
    /// 组选和值
    case zuxhz3d = 140
    /// 组三单式
    case zuxz3ds3d = 124
    /// 组六单式
    case zuxz6ds3d = 125
    /// 直选-后二直选
    case zxherzx3d = 138
    /// 后二直选单式
    case zxherzxds3d = 128
    /// 前二直选
    case zxqerzx3d = 137
    /// 前二单式
    case zxqerds3d = 126
    /// 后二组选
    case zuxherzux3d = 135
    /// 后二单式
    case zuxherds3d = 129
    /// 前二组选
    case zuxqerzux3d = 134
    /// 前二单式
    case zuxqerds3d = 127
    /// 3d一星-定位胆
    case yxdwd3d = 141
    /// 3d一码不定位
    case ymbdw3d = 133
    /// 二码不定位
    case ermbdw3d = 485
    /// 龙虎和-百十
    case lhhbs3d = 372
    /// 龙虎和-百个
    case lhhbg3d = 373
    /// 龙虎和-十个
    case lhhsg3d = 374
    /// 猜1不出
    case cbc13d = 367
    /// 猜2不出
    case cbc23d = 368
    /// 猜3不出
    case cbc33d = 369
    /// 猜4不出
    case cbc43d = 370
    /// 猜5不出
    case cbc53d = 371
    
    ///快乐十二
    /// 任选一
    case rx1 = 409
    /// 任选二
    case rx2 = 410
    /// 任选三
    case rx3 = 411
    /// 任选四
    case rx4 = 412
    /// 任选五
    case rx5 = 413
    /// 任选六
    case rx6 = 461
    /// 任选七
    case rx7 = 462
    /// 任选八
    case rx8 = 463
    /// 单式任选二
    case rx2ds = 418
    /// 单式任选三
    case rx3ds = 419
    /// 单式任选四
    case rx4ds = 420
    /// 单式任选五
    case rx5ds = 421
    /// 单式任选六
    case rx6ds = 464
    /// 单式任选七
    case rx7ds = 465
    /// 单式任选八
    case rx8ds = 466
    /// 任选胆拖任选二
    case rx2dt = 467
    /// 任选胆拖任选三
    case rx3dt = 468
    /// 任选胆拖任选四
    case rx4dt = 469
    /// 任选胆拖任选五
    case rx5dt = 470
    /// 任选胆拖任选六
    case rx6dt = 473
    /// 任选胆拖任选七
    case rx7dt = 474
    /// 任选胆拖任选八
    case rx8dt = 475
    /// 定位胆--快乐12
    case dwdkl12 = 426
    /// 前二直选复式--快乐12
    case qerzxfs = 414
    /// 前二直选单式--快乐12
    case qerzxds = 422
    /// 前二组选复式--快乐12
    case qerzuxfs = 417
    /// 前二组选单式--快乐12
    case qerzuxds = 425
    /// 前二组选胆拖--快乐12
    case qerzuxdt = 472
    /// 前三直选复式--快乐12
    case qszxfskl12 = 415
    /// 前三直选单式--快乐12
    case qszxdskl12 = 423
    /// 前三组选复式--快乐12
    case qszuxfskl12 = 416
    /// 前三组选单式--快乐12
    case qszuxdskl12 = 424
    /// 前三组选胆拖--快乐12
    case qszuxdtkl12 = 471
    
    ///快乐十
    /// 任选二kl10
    case rx2kl10 = 448
    /// 任选三kl10
    case rx3kl10 = 449
    /// 任选四kl10
    case rx4kl10 = 450
    /// 任选五kl10
    case rx5kl10 = 451
    /// 任选六kl10
    case rx6kl10 = 457
    /// 任选七kl10
    case rx7kl10 = 458
    /// 任选二单式kl10
    case rx2dskl10 = 439
    /// 任选三单式kl10
    case rx3dskl10 = 440
    /// 任选四单式kl10
    case rx4dskl10 = 441
    /// 任选五单式kl10
    case rx5dskl10 = 442
    /// 任选六单式kl10
    case rx6dskl10 = 459
    /// 任选七单式kl10
    case rx7dskl10 = 460
    /// 任选二胆拖kl10
    case rx2dtkl10 = 477
    /// 任选三胆拖kl10
    case rx3dtkl10 = 478
    /// 任选四胆拖kl10
    case rx4dtkl10 = 479
    /// 任选五胆拖kl10
    case rx5dtkl10 = 480
    /// 任选六胆拖kl10
    case rx6dtkl10 = 483
    /// 任选七胆拖kl10
    case rx7dtkl10 = 484
    /// 前二直选复式--快乐10
    case qerzxfskl10 = 456
    /// 前二直选单式--快乐10
    case qerzxdskl10 = 445
    /// 前二组选复式--快乐10
    case qerzuxfskl10 = 453
    /// 前二组选单式--快乐10
    case qerzuxdskl10 = 446
    /// 前二组选胆拖--快乐10
    case qerzuxdtkl10 = 482
    /// 前三直选复式--快乐10
    case qszxfskl10 = 455
    /// 前三直选单式--快乐10
    case qszxdskl10 = 443
    /// 前三组选复式--快乐10
    case qszuxfskl10 = 452
    /// 前三组选单式--快乐10
    case qszuxdskl10 = 444
    /// 前三组选胆拖--快乐10
    case qszuxdtkl10 = 481
    
    ///快乐彩
    /// 和值单双
    case hzdskl = 427
    /// 和值大小810
    case hzdx810kl = 428
    /// 和值五行
    case hzwxkl = 431
    /// 奇偶和
    case johkl = 429
    /// 上中下
    case szxkl = 430
    /// 任选一复式
    case rx1fskl = 400
    /// 任选二复式
    case rx2fskl = 401
    /// 任选三复式
    case rx3fskl = 402
    /// 任选四复式
    case rx4fskl = 403
    /// 任选五复式
    case rx5fskl = 404
    /// 任选六复式
    case rx6fskl = 405
    /// 任选七复式
    case rx7fskl = 406
}

class LotteryMethodType: NSObject {

    
    
}
