//
//  LotteryCalculateBettingCountByJS.swift
//  GoldenApple
//
//  Created by User on 10/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import JavaScriptCore

@objc protocol LotteryBettingCountByJSProtocol: JSExport {
    
    /// 获取json数据
    ///
    /// - Returns: json二维数组
    func getData() -> String?
    
    /// 获取玩法id
    ///
    /// - Returns: 玩法id
    func getMethodId() -> Int
    
    /// 获取彩种id
    ///
    /// - Returns: 彩种id
    func getLotteryId() -> Int
    
    /// 获取彩系id
    ///
    /// - Returns: 彩系id
    func getSeriesId() -> Int
    
    /// 获取彩票玩法的拼音简称，如fushi
    ///
    /// - Returns: 彩票玩法的拼音简称
    func getMethodName() -> String
    
    /// 计算得到注数结果
    ///
    /// - Parameter singleNum: 投注数
    func result(_ singleNum: Int)

}

@objc class LotteryCalculateBettingCountByJS: NSObject {
    
    static let `default` = LotteryCalculateBettingCountByJS()

    private override init() {
        super.init()
        
    }
    
    var numberList: [NSArray]?
    var methodId: Int = 0
    var lotteryId: Int = 0
    var seriesId: Int = 0
    var methodName: NSString?
    
    
    fileprivate(set) var bettingNumber = 0
    
}

// MARK: - LotteryBettingCountByJSProtocol
extension LotteryCalculateBettingCountByJS: LotteryBettingCountByJSProtocol {
    
    func getData() -> String? {
//        let data: [NSArray] = [[0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
//                               [1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
//                               [0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
//                               [0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
//                               [0, 0, 0, 0, 0, 0, 1, 0, 0, 0]]
        if self.numberList == nil {
            return nil
        }
        
        let jsonData = try! JSONSerialization.data(withJSONObject: self.numberList!, options: JSONSerialization.WritingOptions.prettyPrinted)
        let dataString = String(data: jsonData, encoding: String.Encoding.utf8)!
        
        return dataString
    }
    
    func getMethodId() -> Int {
//        return 78
        return self.methodId
    }
    
    func getLotteryId() -> Int {
//        return 1
        return self.lotteryId
    }
    
    func getSeriesId() -> Int {
        return self.seriesId
    }
    
    func getMethodName() -> String {
//        return "fushi"
        if self.methodName == nil {
            return ""
        }
        
        return self.methodName! as String
    }
    
    func result(_ singleNum: Int) {
        
        self.bettingNumber = singleNum
//        NSLog("result = %d", singleNum)
        
    }
}
