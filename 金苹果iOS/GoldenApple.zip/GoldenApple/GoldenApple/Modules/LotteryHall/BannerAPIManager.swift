//
//  BannerAPIManager.swift
//  GoldenApple
//
//  Created by User on 20/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class BannerAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        static let kNoticeId = "notice_id"
        static let kPath = "path"
        static let kUrl = "url"
    }
    
}

extension BannerAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Notice&action=getBannerList"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
}


extension BannerAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let bannerDictList = data.object(forKey: "data") as? [NSDictionary] else { return nil }
        
        return bannerDictList
    }
}
