//
//  LotteryPlayingViewController.swift
//  GoldenApple
//
//  Created by User on 30/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryPlayingViewController: UIViewController {
    
    static let cellIdentifier = "LotteryPlayingViewCell"
    static let headerIdentifier = "LotterySectionHeader"
    static let footerIdentifier = "footerIdentifier"
    
    /// 开奖延时时间，分分彩类是8秒
    static let kDeleaySecondFast = 8.0
    
    /// 开奖延时时间，其它是10秒
    static let kDeleaySecondSlow = 10.0
    
    fileprivate let contentView: LotteryPlayingView = {
        return LotteryPlayingView()
    }()
    
    /// 彩种玩法管理器
    let methodListAPIManager = MethodListAPIManager()
    
    /// 当前销售奖期信息管理器
    let issueInfoAPIManager = IssueInfoAPIManager()
    
    /// 获得指定游戏最近的中奖号码列表管理器
    let winNumListAPIManager = WinNumListAPIManager()
    
    
    /// 彩种信息字典, LotteryListAPIManager
    fileprivate let lotteryDict: NSDictionary
    
    //任选计算注数相关数据
    var digitBettingCalcArray = [-1, -1, -1, -1, -1]
    
    /// 倒计时计算器
    fileprivate lazy var timer : DispatchSourceTimer = {[weak self]
        ()-> DispatchSourceTimer in
        var timer : DispatchSourceTimer
        let queue = DispatchQueue(label: "com.GlodenApple.openIssue.queue")
        timer = DispatchSource.makeTimerSource(flags: [], queue: queue)
        timer.scheduleRepeating(wallDeadline: DispatchWallTime.now(), interval: .seconds(1))
        timer.setEventHandler(handler: {[weak self] in
            self?.startCountDownTimer()
        })
        return timer
        }()
    
    fileprivate lazy var updateWinNumTimer : DispatchSourceTimer = {[weak self]
        ()-> DispatchSourceTimer in
        var timer : DispatchSourceTimer
        let queue1 = DispatchQueue(label: "com.GlodenApple.updateWinNumber.queue")
        timer = DispatchSource.makeTimerSource(flags: [], queue: queue1)
        timer.scheduleRepeating(wallDeadline: DispatchWallTime.now(), interval: .seconds(Int((self?.calculatingCountDownTime())!)))
        timer.setEventHandler(handler: {[weak self] in
            self?.updateWinNumListDownTimer()
        })
        return timer
        }()

    
    /// 倒计时秒数
    fileprivate var countDownTime: TimeInterval = 0
    
    /// 判断在开奖中
    fileprivate var isWinningTime = false
    /// 判断在获取上期开奖结果倒计时中
    fileprivate var isUpdateTime = false
    
    ///  纪录上一次选中的cell的indexPath，其中key值为@(indexPath的section)，value为indexPath
    fileprivate let lastSelectedItemDict = NSMutableDictionary()
    
    /// 单式投注号码数组[String]
    fileprivate var manualBettingArray: [String]?
    /// 开奖历史
    fileprivate var winNumListDict: NSDictionary?
    
    fileprivate var winNumString: String?
    
    let titleButton: GATitleButton = {
        let button = GATitleButton(type: UIButtonType.custom)
        button.setImage(UIImage(named: "allow_down"), for: UIControlState.normal)
        
        return button
    }()
    
    let methodViewController: LotteryMethodViewController = {
        let viewContorller = LotteryMethodViewController()
        
        return viewContorller
    }()
    
    let bettingViewController = LotteryBettingViewController()
    
    
    required init(lotteryDict: NSDictionary) {
        
        self.lotteryDict = lotteryDict
        LotteryRulesOfPlay.default.setLotteryDict(dict: lotteryDict)
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.lotteryDict = NSDictionary()
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        super.loadView()
        
        self.view = self.contentView
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = kGAViewGrayBackgoundColor
        
        self.navigationItem.titleView = self.titleButton
        self.titleButton.addTarget(self, action: #selector(titleButtonClick), for: UIControlEvents.touchUpInside)
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.setNavigationBackTarget(self, action: #selector(leftBarButtonClick))
        let lotteryHistory = UIBarButtonItem(image: UIImage(named: "top_kjzs"), style: .done, target: self, action: #selector(lotteryHistoryItemClick))
        
        let betNote = UIBarButtonItem(image: UIImage(named: "top_wfsm"), style: .done, target: self, action: #selector(betNoteItemClick))
        self.navigationItem.setRightBarButtonItems([lotteryHistory, betNote], animated: true)
        
        self.methodListAPIManager.delegate = self
        self.methodListAPIManager.paramSource = self
        self.issueInfoAPIManager.delegate = self
        self.issueInfoAPIManager.paramSource = self
        self.winNumListAPIManager.delegate = self
        self.winNumListAPIManager.paramSource = self
        self.contentView.delegate = self
        
        self.contentView.collectionView.dataSource = self
        self.contentView.collectionView.delegate = self
        self.contentView.inputBettingTextView.delegate = self
        self.contentView.collectionView.register(LotteryPlayingViewCell.classForCoder(), forCellWithReuseIdentifier: LotteryPlayingViewController.cellIdentifier)
        self.contentView.collectionView.register(LotterySectionHeader.classForCoder(), forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: LotteryPlayingViewController.headerIdentifier)
        self.contentView.collectionView.register(UICollectionReusableView.classForCoder(), forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: LotteryPlayingViewController.footerIdentifier)
        self.contentView.bettingBtn.addTarget(self, action: #selector(bettingBtnClick), for: UIControlEvents.touchUpInside)
        self.contentView.bettingCount.addObserver(self, forKeyPath: "text", options: .new, context: nil)
        
        self.addChildViewController(self.bettingViewController)

        
        GAProgressHUD.showLoading(message: "正在加载...")
        self.issueInfoAPIManager.loadData()
        self.winNumListAPIManager.loadData()
        self.methodListAPIManager.loadData()
     
    }
    
    deinit {
        self.contentView.bettingCount.removeObserver(self, forKeyPath: "text")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let titleStr = LotteryRulesOfPlay.default.titleName()
        self.titleButton.setTitle(titleStr, for: UIControlState.normal)
        
        self.contentView.maxPrice.text = LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kMaxPrize] as? String
        
        self.contentView.bettingBtn.isEnabled = self.bettingViewController.bettingList.count > 0
        
        if LotteryRulesOfPlay.default.hasDigit() == nil {
            self.contentView.digitView.isHidden = true
            self.contentView.digitView.snp.updateConstraints { (make) in
                make.height.equalTo(0)
            }
        }else{
            self.contentView.digitView.isHidden = false
            self.contentView.digitView.snp.updateConstraints { (make) in
                make.height.equalTo(40)
            }
        }

        if LotteryRulesOfPlay.default.isManualBetting() {
            self.contentView.collectionView.isHidden = true
            self.contentView.manualLotteryView.isHidden = false
        } else {
            self.contentView.collectionView.isHidden = false
            self.contentView.manualLotteryView.isHidden = true
            self.contentView.collectionView.reloadData()
        }
        
        if self.winNumListDict != nil {
            self.contentView.setLastPeriodNumber(winNumString)
        }
        
        if let digit = LotteryRulesOfPlay.default.hasDigit() {
            if digit.contains("万"){
                digitBettingCalcArray[0] = 1
                self.contentView.wanBtn.isSelected = true
                self.contentView.selectedDigitList["wan"] = true
            }else {
                digitBettingCalcArray[0] = -1
                self.contentView.wanBtn.isSelected = false
                self.contentView.selectedDigitList["wan"] = false
            }
            if digit.contains("千"){
                digitBettingCalcArray[1] = 1
                self.contentView.qianBtn.isSelected = true
                self.contentView.selectedDigitList["qian"] = true
            }else {
                digitBettingCalcArray[1] = -1
                self.contentView.qianBtn.isSelected = false
                self.contentView.selectedDigitList["qian"] = false
            }
            if digit.contains("百"){
                digitBettingCalcArray[2] = 1
                self.contentView.baiBtn.isSelected = true
                self.contentView.selectedDigitList["bai"] = true
            }else {
                digitBettingCalcArray[2] = -1
                self.contentView.baiBtn.isSelected = false
                self.contentView.selectedDigitList["bai"] = false
            }
            if digit.contains("十"){
                digitBettingCalcArray[3] = 1
                self.contentView.shiBtn.isSelected = true
                self.contentView.selectedDigitList["shi"] = true
            }else {
                digitBettingCalcArray[3] = -1
                self.contentView.shiBtn.isSelected = false
                self.contentView.selectedDigitList["shi"] = false
            }
            if digit.contains("个"){
                digitBettingCalcArray[4] = 1
                self.contentView.geBtn.isSelected = true
                self.contentView.selectedDigitList["ge"] = true
            }else {
                digitBettingCalcArray[4] = -1
                self.contentView.geBtn.isSelected = false
                self.contentView.selectedDigitList["ge"] = false
            }
            
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.manualBettingArray = nil
        self.contentView.inputBettingTextView.endEditing(true)
        self.contentView.bettingCount.text = "0"
        self.contentView.inputBettingTextView.text = ""
    }
    
    // MARK: - response event methods
    
    @objc func leftBarButtonClick() {
        LotteryRulesOfPlay.default.clearAllData()
        //退出页面是要取消定时器,否则会出现crash
        self.timer.cancel()
        if isUpdateTime {
            self.updateWinNumTimer.cancel()
        }
        self.countDownTime = 0
        
        self.navigationController?.popViewController(animated: true)
    }

    @objc func titleButtonClick() {
        
        self.navigationController?.pushViewController(self.methodViewController, animated: true)
    }

    @objc func bettingBtnClick() {
        
        var ballStr = ""
        var bettingCount = 0
        
        if LotteryRulesOfPlay.default.isManualBetting() {
            

            if self.manualBettingArray == nil || self.manualBettingArray!.count == 0 {
                self.navigationController?.pushViewController(self.bettingViewController, animated: true)
                return
            }
            
            
            let set = NSSet(array: self.manualBettingArray!)
            if set.count < self.manualBettingArray!.count {
                GAAlertController.showAlert("提示", "号码重复,自动过滤!", nil, "确认", cancelCallBack: nil, commitCallBack: {
                })
                self.manualBettingArray = set.allObjects as? [String]
            }
            
            ballStr = (self.manualBettingArray! as NSArray).componentsJoined(by: "|")
            bettingCount = self.manualBettingArray!.count
            if LotteryRulesOfPlay.default.hasDigit() != nil {
                bettingCount = LotteryCalculateBettingCountByJS.default.bettingNumber
            }
            
        } else  {
            //复式投注
            let selectedItems = self.contentView.collectionView.indexPathsForSelectedItems
            if selectedItems != nil && selectedItems!.count > 0 {
                ballStr = LotteryRulesOfPlay.default.parseTheBettingNumber(indexPathList: selectedItems!)
                //        print("ballStr: \(ballStr)")
                bettingCount = LotteryCalculateBettingCountByJS.default.bettingNumber
            } else {
                self.navigationController?.pushViewController(self.bettingViewController, animated: true)
                return
            }
        }
        
        let lotteryId = self.lotteryDict[LotteryListAPIManager.DataKey.kId] as! Int
        let wayId = LotteryRulesOfPlay.default.lotteryMethodDict![MethodListAPIManager.DataKey.MethodDetailKey.kSeriesWayId] as! Int
        let groupMethodName = LotteryRulesOfPlay.default.groupMethodName()!
        let price = LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kPrice] as! Int
        let name = lotteryDict[LotteryListAPIManager.DataKey.kName] as! String
        
        var bettingDict = [ LotteryBettingViewController.DataKey.kBall: ballStr,
                            LotteryBettingViewController.DataKey.kWayId: wayId,
                            LotteryBettingViewController.DataKey.kGameId: lotteryId,
                            LotteryBettingViewController.DataKey.kNum: bettingCount,
                            LotteryBettingViewController.DataKey.kTitleName: groupMethodName,
                            LotteryBettingViewController.DataKey.kName: name,
                            LotteryBettingViewController.DataKey.kPrice: price] as [String : Any]
        
        if LotteryRulesOfPlay.default.renxuanNumbers() != nil {
            bettingDict[LotteryBettingViewController.DataKey.seat] = LotteryRulesOfPlay.default.renxuanNumbers()
            var position = ""
            for (index, item) in digitBettingCalcArray.enumerated(){
                if item != -1{
                    position.append(String(format:"%d", index))
                }
            }
            bettingDict[LotteryBettingViewController.DataKey.position] = position
            bettingDict[LotteryBettingViewController.DataKey.kExtra] = [LotteryBettingViewController.DataKey.seat: LotteryRulesOfPlay.default.renxuanNumbers()!,
            LotteryBettingViewController.DataKey.position: position]
        }
        //        let arrayT = [,"balls":[["ball":"||8|9|2",,"wayId":78]],"gameId":1,,,] bettingNumber,titileName
        
        self.bettingViewController.setBettingDict(bettingDict: bettingDict as NSDictionary)
        
        self.navigationController?.pushViewController(self.bettingViewController, animated: true)
    }
    
    func lotteryHistoryItemClick() {
        let lotteryId = self.lotteryDict[LotteryListAPIManager.DataKey.kId] as! Int
        let detailVC = LotteryTrendDetailViewController()
        detailVC.lotteryId = lotteryId
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    func betNoteItemClick() {
        self.contentView.inputBettingTextView.endEditing(true)
        guard let noteString = LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kBetNote] as? String else {return}
        
        let alertController = UIAlertController(title: "提示", message: noteString, preferredStyle: .alert)
        let yesAction = UIAlertAction(title: "确定", style: .default, handler: nil)
        alertController.addAction(yesAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func startCountDownTimer() {
        
        if self.countDownTime >= 0 {
            let hour = Int(self.countDownTime / (60 * 60))
            var minute = Int(self.countDownTime / 60)
            if hour > 0 {
                minute = Int(self.countDownTime.truncatingRemainder(dividingBy: (60 * 60)) / 60)
            }
            let second = Int(self.countDownTime.truncatingRemainder(dividingBy: 60))
            let countDownString = String(format: "%02ld : %02ld : %02ld", hour, minute, second)
            
            DispatchQueue.main.async(execute: {
                self.contentView.countdownLabel.text = countDownString
                self.bettingViewController.coutdownString = countDownString
            })
            
        } else {
//            if !self.isWinningTime {
//
//                self.countDownTime = self.calculatingCountDownTime()
//                self.isWinningTime = true
//            } else {
//                self.isWinningTime = false
            self.timer.suspend()
            self.issueInfoAPIManager.loadData()
            if self.isUpdateTime {
                self.updateWinNumTimer.suspend()
                self.isUpdateTime = false
            }
            self.winNumListAPIManager.loadData()
                
//            }
        }
        self.countDownTime -= 1
    }
    
    func updateWinNumListDownTimer() {
        if self.isUpdateTime {
            self.updateWinNumTimer.suspend()
            self.isUpdateTime = false
        }
        self.winNumListAPIManager.loadData()
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        guard let text = self.contentView.bettingCount.text as NSString? else { return }
        if (object as? UILabel) == self.contentView.bettingCount{
            
            if text.integerValue > 0 {
                self.contentView.bettingBtn.isEnabled = true
            } else {
                self.contentView.bettingBtn.isEnabled = false
            }
            
            let price = LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kPrice] as? Int
            if price != nil {
                let totalPrice = price! * text.integerValue
                self.contentView.totalPrice.text = String(format: "%ld", totalPrice)
            }
        }
        
    }
}

extension LotteryPlayingViewController: LotteryDigitDelegate {
    
    func lotteryDigitBtnClick(digitDic: Dictionary<String, Bool>) {
        var seat = ""
        for (key, value) in digitDic{
            if key == LotteryPlayingView.eDigitType.wan.rawValue {
                if value {
                    seat.append("0")
                    digitBettingCalcArray[0] = 1
                }else {
                    digitBettingCalcArray[0] = -1
                }
            }
            if key == LotteryPlayingView.eDigitType.qian.rawValue {
                if value {
                    seat.append("1")
                    digitBettingCalcArray[1] = 1
                }else {
                    digitBettingCalcArray[1] = -1
                }
            }
            if key == LotteryPlayingView.eDigitType.bai.rawValue {
                if value {
                    seat.append("2")
                    digitBettingCalcArray[2] = 1
                }else {
                    digitBettingCalcArray[2] = -1
                }
            }
            if key == LotteryPlayingView.eDigitType.shi.rawValue{
                if value {
                    seat.append("3")
                    digitBettingCalcArray[3] = 1
                }else {
                    digitBettingCalcArray[3] = -1
                }
            }
            if key == LotteryPlayingView.eDigitType.ge.rawValue {
                if value {
                    seat.append("4")
                    digitBettingCalcArray[4] = 1
                }else {
                    digitBettingCalcArray[4] = -1
                }
            }
        }
        if LotteryRulesOfPlay.default.hasDigit() != nil && LotteryRulesOfPlay.default.isManualBetting(){
            DispatchQueue.global().async {
                self.manualBetting(self.contentView.inputBettingTextView.text ?? "")
            }
        }else {
            updateBettingNumber()
        }
    }
    
}

// MARK: - LYAPIManagerParamSource

extension LotteryPlayingViewController: LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        if manager == self.methodListAPIManager ||
            manager == self.issueInfoAPIManager {
            return ["lottery_id" : self.lotteryDict["id"] as Any]
        } else if manager == self.winNumListAPIManager {
            return ["lottery_id" : self.lotteryDict["id"] as Any]
        }
        
        return nil
    }
}

// MARK: - LYAPIManagerCallBackDelegate

extension LotteryPlayingViewController: LYAPIManagerCallBackDelegate {

    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        
        if manager == self.methodListAPIManager {
            self.methodViewController.methodInfoList = manager.fetchData(self.methodListAPIManager) as? [NSDictionary]
            let titleStr = LotteryRulesOfPlay.default.titleName()
            self.titleButton.setTitle(titleStr, for: UIControlState.normal)
            self.contentView.maxPrice.text = LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kMaxPrize] as? String
        } else if manager == self.issueInfoAPIManager {
            let issueInfoDict = manager.fetchData(self.issueInfoAPIManager) as? NSDictionary
            
            let timesCount = issueInfoDict?.object(forKey: IssueInfoAPIManager.DataKey.kTimesCount) as? TimeInterval
            if timesCount != nil && timesCount! > -20 && !self.timer.isCancelled {
                self.countDownTime = timesCount!
                self.timer.resume()
            }
            self.contentView.awardPeriodLabel.text = self.shortIssue(issue: issueInfoDict?.object(forKey: IssueInfoAPIManager.DataKey.kIssue) as? String)
            self.bettingViewController.currentAwardPriceString = issueInfoDict?.object(forKey: IssueInfoAPIManager.DataKey.kIssue) as? String
            
        } else if manager == self.winNumListAPIManager {
            let winNumListArray = manager.fetchData(self.winNumListAPIManager) as? [NSDictionary]
            self.winNumListDict = winNumListArray?.first
            guard let wnNumber : String = winNumListDict?[WinNumListAPIManager.DataKey.kWNnumber] as? String else {return}
            if wnNumber.isEmpty {
                self.updateWinNumTimer.resume()
                self.isUpdateTime = true
            }
            self.contentView.lastAwardPeriodLabel.text = self.shortIssue(issue: (winNumListDict?[WinNumListAPIManager.DataKey.kIssue]) as? String)
            let winNumberString = winNumListDict?[WinNumListAPIManager.DataKey.kWNnumber] as? String
            
            if winNumberString != nil && winNumberString!.count > 0 {
                self.winNumString = (winNumListDict?[WinNumListAPIManager.DataKey.kWNnumber]) as? String
            } else {
                guard let winLength = winNumListDict?[WinNumListAPIManager.DataKey.kWinLength] as? NSString else {return}
                self.winNumString = String.init(repeating: "-", count: winLength.integerValue)
            }
            self.contentView.setLastPeriodNumber(self.winNumString)
        }
        
        if isEndCall {
            GAProgressHUD.hidHUD()
        }
        
//        print("LotteryPlayingViewController-----managerCallAPIDidSuccess---\(manager.fetchData(nil))")
//        NSLog("LotteryHallViewController-----managerCallAPIDidSuccess---%@", self.methodDict!)
    }
    
    func shortIssue(issue : String?) -> String? {
        let lotteryId = self.lotteryDict[LotteryListAPIManager.DataKey.kId] as! UInt
        switch eLotteryType(rawValue: lotteryId) {
        case .ePGJSPK10?,.eCQKLSF?,.eGDKLSF?:
            if issue != nil && issue != "" && (issue! as NSString).length > 4 {
                return (issue! as NSString).substring(from: (issue! as NSString).length - 4)
            } else {
                return issue
            }
        default:
            return issue
        }
    }
    
}



//MARK: - GACollectionViewDelegateFlowLayout

extension LotteryPlayingViewController: GACollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, backgroundColorForSectionAt section: Int) -> UIColor {
        return UIColor.white
    }
}

//MARK: - UICollectionViewDataSource

extension LotteryPlayingViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return LotteryRulesOfPlay.default.numberOfSections()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return LotteryRulesOfPlay.default.numberOfItemsInSection(section: section)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LotteryPlayingViewController.cellIdentifier, for: indexPath) as! LotteryPlayingViewCell
        let itemName = LotteryRulesOfPlay.default.itemsNameInSection(indexPath.section)
        cell.ballBtn.setTitle(itemName?[indexPath.item], for: UIControlState.normal)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        if kind == UICollectionElementKindSectionHeader {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: LotteryPlayingViewController.headerIdentifier, for: indexPath) as! LotterySectionHeader
            let sectionNameList = LotteryRulesOfPlay.default.sectionsName()
            header.sectionName = sectionNameList?[indexPath.section]
            header.delegate = self
            header.section = indexPath.section
            header.chooseType = LotteryRulesOfPlay.default.lotterySectionChooseType(indexPath.section)
            
            return header
        } else if kind == UICollectionElementKindSectionFooter {
            
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: LotteryPlayingViewController.footerIdentifier, for: indexPath)
            footer.backgroundColor = UIColor.clear
            return footer
        }

        return UICollectionReusableView()
    }
}

//MARK: - UICollectionViewDelegate

extension LotteryPlayingViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if LotteryRulesOfPlay.default.isUniqueSelectedItemInAllSection() && (collectionView.indexPathsForSelectedItems != nil) {
            for selectedIndexPath in collectionView.indexPathsForSelectedItems! {
                if selectedIndexPath.section != indexPath.section && selectedIndexPath.row == indexPath.row {
                    self.selectItem(isSelect: false, indexPath: selectedIndexPath)
                }
            }
        }
        
        let itemCount = LotteryRulesOfPlay.default.numberOfSelectedItem(indexPath.section)
        if itemCount + 1 == self.countOfSelectedItem(atSection: indexPath.section) {
            let lastIndexPath = self.lastSelectedItemDict[indexPath.section] as? IndexPath
            if lastIndexPath != nil {
                self.selectItem(isSelect: false, indexPath: lastIndexPath!)
            }
        }
        
        self.updateBettingNumber()
        
        self.lastSelectedItemDict[indexPath.section] = indexPath
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
//        self.selectItem(isSelect: false, indexPath: indexPath)
        self.updateBettingNumber()
    }
    
}

extension LotteryPlayingViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = LotteryRulesOfPlay.default.setBallSize(section: indexPath.section)
        if !size.equalTo(CGSize.zero) {
            return size
        }
        
        guard let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout else { return CGSize.zero }
        return flowLayout.itemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        let sectionsName = LotteryRulesOfPlay.default.sectionsName()
        if sectionsName == nil || sectionsName!.count == 0 {
            return CGSize.zero
        }
        return CGSize(width: self.view.bounds.size.width, height: 55)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        
        return CGSize(width: self.view.bounds.size.width, height: 10)
    }
    
}

//MARK: - LotterySectionHeaderDelegate

extension LotteryPlayingViewController: LotterySectionHeaderDelegate {
    
    func lotterySectionHeaderBtnClick(buttonType: LotterySectionHeader.eButtonType, section: Int) {
        
        //清理所以选中的item
        if buttonType != .all && self.contentView.collectionView.indexPathsForSelectedItems != nil {
            for item in self.contentView.collectionView.indexPathsForSelectedItems! {
                if item.section == section {
                    self.selectItem(isSelect: false, indexPath: item)
                }
            }

        }
        
        let nItems = LotteryRulesOfPlay.default.numberOfItemsInSection(section: section)
        var minIndex = 0
        var maxIndex = 0
        if buttonType == .all ||
            buttonType == .odd ||
            buttonType == .even {
            minIndex = 0
            maxIndex = nItems
        } else if buttonType == .large {
            maxIndex = nItems
            minIndex = maxIndex / 2
        } else if buttonType == .small {
            minIndex = 0
            maxIndex = nItems / 2
        }
        
        guard let itemsList = LotteryRulesOfPlay.default.itemsNameInSection(section) else { return }
        if buttonType != .clear {
            for index in minIndex...maxIndex-1 {
                let number = (itemsList[index] as NSString).integerValue
                if buttonType == .odd && (number % 2 == 0) ||
                    buttonType == .even && (number % 2 != 0 ) {
                    continue
                }
                
                let indexPath = IndexPath(item: index, section: section)
                self.selectItem(isSelect: true, indexPath: indexPath)


            }
        }
        
    }
    
    
}

// MARK: - UITextViewDelegate

extension LotteryPlayingViewController: UITextViewDelegate {
    
    func textViewDidEndEditing(_ textView: UITextView) {
        textView.endEditing(true)
    }
    
    func textViewDidChange(_ textView: UITextView) {
        let text : String = textView.text
        DispatchQueue.global().async {
            self.manualBetting(text)
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.contentView.inputBettingTextView.endEditing(true)
    }
    
}

// MARK: - Private methods

extension LotteryPlayingViewController {
    
    fileprivate func selectItem(isSelect: Bool, indexPath: IndexPath) {
        
        if isSelect {
            self.contentView.collectionView.selectItem(at: indexPath, animated: true, scrollPosition: UICollectionViewScrollPosition.init(rawValue: 0))
        } else {
            self.contentView.collectionView.deselectItem(at: indexPath, animated: true)
        }
        
        self.updateBettingNumber()
    }
    
    fileprivate func countOfSelectedItem(atSection: Int) -> Int {
        var count = 0
        let indexPathArray = self.contentView.collectionView.indexPathsForSelectedItems
        if indexPathArray == nil {
            return count
        }
        for indexPath in indexPathArray! {
            if atSection == indexPath.section {
                count += 1
            }
        }
        
        return count
    }
    
    fileprivate func updateBettingNumber() {
        
        var selectedItems = self.contentView.collectionView.indexPathsForSelectedItems
        if selectedItems == nil {
            return
        }
        
        let nSections = LotteryRulesOfPlay.default.numberOfSections()
        let numberList = NSMutableArray()
        if LotteryRulesOfPlay.default.hasDigit() != nil {
            numberList.add(digitBettingCalcArray)
        }
        for section in 0...nSections-1 {
            let nItems = LotteryRulesOfPlay.default.numberOfItemsInSection(section: section)

            let subNumberList = NSMutableArray(capacity: nItems)
            for item in 0...nItems-1 {
                let currenIndex = IndexPath(item: item, section: section)
                if selectedItems!.contains(currenIndex) {
                    selectedItems!.remove(at: selectedItems!.index(of: currenIndex)!)
                    subNumberList.add(1)
                } else {
                    subNumberList.add(-1)
                }
            }
            numberList.add(subNumberList)
        }

        let bettingNumber = LotteryRulesOfPlay.default.calculateBettingNumber(numberList: numberList as! [NSArray])
        self.contentView.bettingCount.text = bettingNumber as String
        
        let price = LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kPrice] as? Int
        if price != nil {
            let totalPrice = price! * LotteryCalculateBettingCountByJS.default.bettingNumber
            self.contentView.totalPrice.text = String(format: "%ld", totalPrice)
        }
    }
    
    func calculatingManualBettingNumber(_ numberArray: Array<String>, _ isMutiple: Bool = false) -> String {
        
        let nSections = LotteryRulesOfPlay.default.numberOfSections()
        if nSections != numberArray.count && !isMutiple {
            return "0"
        }
        
        if self.isSpecailManulBettingZ3() {
            //组三单式
            if numberArray.count != 3 {
                return "0"
            }
            
            let setArray = NSSet(array: numberArray)
            if setArray.count + 1 == numberArray.count {
                return "1"
            }
            
            return "0"
        }
        
        var copyArray = numberArray
        let numberList = NSMutableArray()
        for section in 0...nSections-1 {
            guard let items = LotteryRulesOfPlay.default.itemsNameInSection(section) else { return "0" }
            
            let currentNumber = numberArray[section]
            let subNumberList = NSMutableArray(capacity: items.count)
            for item in items {
                
                if isMutiple {
                    if copyArray.contains(item) {
                        subNumberList.add(1)
                        copyArray.remove(at: copyArray.index(of: item)!)
                    } else {
                        subNumberList.add(-1)
                    }
                } else {
                    if item == currentNumber {
                        subNumberList.add(1)
                    } else {
                        subNumberList.add(-1)
                    }
                }
                
            }
            numberList.add(subNumberList)
            
        }
        
        if copyArray.count != 0 && isMutiple {
            //数据多余
            return "0"
        }
        
        let bettingNumber = LotteryRulesOfPlay.default.calculateBettingNumber(numberList: numberList as! [NSArray])
        if (bettingNumber as NSString).integerValue != 1 {
            return "0"
        }
        
        return bettingNumber
    }
    
    fileprivate func manualBetting(_ text: String) {
        let validityRegex = "[ 0-9,|;:.\n]+"
        let validity = NSPredicate(format: "SELF MATCHES %@", validityRegex)
 
        let bValidity = validity.evaluate(with: text)
        if !bValidity {
            return
        }
        
        var pattern = "[0-9]+";
        let bSpace = LotteryRulesOfPlay.default.isSpaceSeparatedNumber()
        if bSpace {
            pattern = "[ 0-9]+"
        }
        
        var totalNumber = 0
        let stringArray = NSMutableArray()
        let reg = try? NSRegularExpression(pattern: pattern, options: .dotMatchesLineSeparators)
        reg?.enumerateMatches(in: text, options: .reportCompletion, range: NSMakeRange(0, text.count), using: { (result, flags, stop) in
            if result != nil {
                var subStr = (text as NSString).substring(with: result!.range).trimmingCharacters(in: CharacterSet.whitespaces)
                if self.isOrderManualBettingNumber() {
                    //如果是组三模式数组要排序
                    let subStrArray = subStr.sorted()
                    var tempStr = ""
                    for item in subStrArray {
                        tempStr += String(item)
                    }
                    subStr = tempStr
                }
//                let trimStr = subStr.trimmingCharacters(in: CharacterSet.whitespaces)
                if subStr.count > 0 {
//                    print("subString----:%@", subStr)
                    var numberArray = NSMutableArray()
                    
                    if let _ = LotteryRulesOfPlay.default.hasDigit() {
                        numberArray.add(digitBettingCalcArray)
                        if subStr.count != LotteryRulesOfPlay.default.renxuanNumbers()! {
                            return
                        }
                        if LotteryRulesOfPlay.default.needSort() {
                            if stringArray.map({ (str) -> [Character] in
                                return (str as! String).sorted()
                            }).contains(subStr.sorted()){
                                return
                            }
                        }else {
                            if stringArray.contains(subStr){
                                return
                            }
                        }
                        if LotteryRulesOfPlay.default.isSoloSection() {
                            let tempArray: NSMutableArray = [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
                            for item in subStr{
                                tempArray[Int(String(item))!] = 1
                            }
                            numberArray.add(tempArray)
                        }else {
                            let temp = subStr.map({ (character) -> [Int] in
                                let tempArray: NSMutableArray = [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
                                tempArray[Int(String(character))!] = 1
                                return tempArray as! [Int]
                            })
                            numberArray.addObjects(from: temp)
                        }
                        let currentNumber = LotteryRulesOfPlay.default.calculateBettingNumber(numberList: numberArray as! [NSArray]) as NSString
                        let array = stringArray.map({ (str) -> String in
                            return String((str as! String).sorted())
                        })
                      
                        if currentNumber.integerValue > 0 && !array.contains(subStr) {
                            
                            
                            stringArray.add(subStr)
                            //                        NSLog("stringArray---:%@", stringArray)
                            totalNumber += currentNumber.integerValue
                        }
                        
                    }else {
                        if bSpace {
                            let trimStrArray = subStr.components(separatedBy: " ")
                            numberArray = NSMutableArray(array: trimStrArray)
                        } else {
                            for index in 0...subStr.count-1 {
                                let strNumber = (subStr as NSString).substring(with: NSMakeRange(index, 1))
                                numberArray.add(strNumber)
                            }
                        }
                        let nSections = LotteryRulesOfPlay.default.numberOfSections()
                        let bMutiple = nSections == 1
                        let currentNumber = self.calculatingManualBettingNumber(numberArray as! [String], bMutiple) as NSString
                        if currentNumber.integerValue > 0 {
                            stringArray.add(subStr)
                            //                        NSLog("stringArray---:%@", stringArray)
                            totalNumber += currentNumber.integerValue
                        }
                    }

                }
            }
            
            self.manualBettingArray = stringArray.copy() as? [String]
            
            DispatchQueue.main.async {
                self.contentView.bettingCount.text = String(format: "%ld", totalNumber)
            }
            
            let price = LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kPrice] as? Int
            if price != nil {
                let totalPrice = price! * totalNumber
                DispatchQueue.main.async {
                    self.contentView.totalPrice.text = String(format: "%ld", totalPrice)
                }
                
            }
        })
        
    }

    fileprivate func calculatingCountDownTime() -> TimeInterval {
        
        var times: TimeInterval = 0
        
        let lotteryId = self.lotteryDict[LotteryListAPIManager.DataKey.kId] as! UInt
        switch eLotteryType(rawValue: lotteryId) {
        case .ePGFFC?, .ePGSFC?, .ePGWFC?, .ePGMMC?, .ePG11X5?, .ePGK3FFC?, .ePGJS3d?, .ePGJSPK10?:
            times = LotteryPlayingViewController.kDeleaySecondFast
        case .none:
            times = LotteryPlayingViewController.kDeleaySecondSlow
        default:
            times = LotteryPlayingViewController.kDeleaySecondSlow
        }
        
        return times
    }
    
    /// 特殊的单式投注---组3
    ///
    /// - Returns: <#return value description#>
    fileprivate func isSpecailManulBettingZ3() -> Bool {
        var bSpecail = false
        
        switch LotteryRulesOfPlay.default.methodType {
        case .zuxz3ds3d?, .qsanz3ds?, .zsanz3ds?, .hsanz3ds?:
            bSpecail = true
        default:
            break
        }
        
        return bSpecail
    }
    
    
    /// 单式投注需要对号码排序
    ///
    /// - Returns: <#return value description#>
    fileprivate func isOrderManualBettingNumber() -> Bool {
        var bOrder = false
        
        switch LotteryRulesOfPlay.default.methodType {
        case .zuxz3ds3d?, .zuxz6ds3d?, .zuxherds3d?, .zuxqerds3d?, .qsanz3ds?, .zsanz3ds?, .hsanz3ds?, .qsanz6ds?, .zsanz6ds?, .hsanz6ds?:
            bOrder = true
        default:
            break
        }
        
        return bOrder
    }
    
}
