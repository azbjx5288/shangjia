//
//  LotterySectionHeader.swift
//  GoldenApple
//
//  Created by User on 02/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

protocol LotterySectionHeaderDelegate {
    
    func lotterySectionHeaderBtnClick(buttonType: LotterySectionHeader.eButtonType, section: Int)
    
}

class LotterySectionHeader: UICollectionReusableView {
    
    enum eButtonType {
        case all, large, small, odd, even, clear, none
    }
    
    var delegate: LotterySectionHeaderDelegate?
    
    var section: Int = 0
    
    var sectionName: String? {
        didSet {
            
            self.titleBtn.isHidden = (sectionName == nil)
            if sectionName != nil {
                self.titleBtn.setTitle(sectionName, for: UIControlState.normal)
                let titleFont = UIFont.systemFont(ofSize: self.titleBtn.titleLabel!.font.pointSize + 4)
                let titleSize = (sectionName! as NSString).size(attributes: [NSFontAttributeName : titleFont])
                
                self.titleBtn.snp.updateConstraints { (make) in
                    make.width.equalTo(titleSize.width)
                }
            }
        }
    }
    
    var chooseType: eLotterySectionChooseType? {
        didSet {
            self.rapidChooseView.isHidden = (chooseType == eLotterySectionChooseType.none)
        }
    }
    
    fileprivate let titleBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setBackgroundImage(UIImage(named: "allow-button_L"), for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.isUserInteractionEnabled = false
        return button
    }()
    
    let rapidChooseView: UIView = {
        let view = UIView()
        return view
    }()
    
    let largeBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(kGAFontRedColor, for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("大", for: UIControlState.normal)
        return button
    }()
    
    let smallBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(kGAFontRedColor, for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("小", for: UIControlState.normal)
        return button
    }()
    
    let oddBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(kGAFontRedColor, for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("奇", for: UIControlState.normal)
        return button
    }()
    
    let evenBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(kGAFontRedColor, for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("偶", for: UIControlState.normal)
        return button
    }()
    
    let allBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(kGAFontRedColor, for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("全", for: UIControlState.normal)
        return button
    }()
    
    let clearBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(kGAFontRedColor, for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("清", for: UIControlState.normal)
        return button
    }()
    
    fileprivate let serperatorLine: UIView = {
        let view = UIView()
        view.backgroundColor = kGASerperatorLineGrayColor
        return view
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        
        self.addSubview(self.titleBtn)
        self.addSubview(self.rapidChooseView)
        
        self.rapidChooseView.addSubview(self.largeBtn)
        self.rapidChooseView.addSubview(self.smallBtn)
        self.rapidChooseView.addSubview(self.evenBtn)
        self.rapidChooseView.addSubview(self.oddBtn)
        self.rapidChooseView.addSubview(self.allBtn)
        self.rapidChooseView.addSubview(self.clearBtn)
        
        self.addSubview(self.serperatorLine)

        self.makeConstraintsForSubviews()
        
        self.largeBtn.addTarget(self, action: #selector(buttonClick(_:)), for: UIControlEvents.touchUpInside)
        self.smallBtn.addTarget(self, action: #selector(buttonClick(_:)), for: UIControlEvents.touchUpInside)
        self.evenBtn.addTarget(self, action: #selector(buttonClick(_:)), for: UIControlEvents.touchUpInside)
        self.oddBtn.addTarget(self, action: #selector(buttonClick(_:)), for: UIControlEvents.touchUpInside)
        self.allBtn.addTarget(self, action: #selector(buttonClick(_:)), for: UIControlEvents.touchUpInside)
        self.clearBtn.addTarget(self, action: #selector(buttonClick(_:)), for: UIControlEvents.touchUpInside)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    func makeConstraintsForSubviews() {
        self.titleBtn.snp.makeConstraints { (make) in
            make.left.equalTo(self).offset(15)
            make.centerY.equalTo(self)
            make.width.equalTo(55)
            make.height.equalTo(25)
        }
        
        self.rapidChooseView.snp.makeConstraints { (make) in
            make.top.right.bottom.equalTo(self)
            make.left.equalTo(self.titleBtn.snp.right)
        }
        self.clearBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.rapidChooseView)
            make.right.equalTo(self.rapidChooseView).offset(-10)
        }
        self.allBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.rapidChooseView)
            make.right.equalTo(self.clearBtn.snp.left).offset(-10)
        }
        self.evenBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.rapidChooseView)
            make.right.equalTo(self.allBtn.snp.left).offset(-10)
        }
        self.oddBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.rapidChooseView)
            make.right.equalTo(self.evenBtn.snp.left).offset(-10)
        }
        self.smallBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.rapidChooseView)
            make.right.equalTo(self.oddBtn.snp.left).offset(-10)
        }
        self.largeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.rapidChooseView)
            make.right.equalTo(self.smallBtn.snp.left).offset(-10)
        }
        
        self.serperatorLine.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(self)
            make.height.equalTo(1)
        }
        
    }
    
    @objc func buttonClick(_ button: UIButton) {
        
        if self.delegate != nil {
            var btnType = LotterySectionHeader.eButtonType.none
            
            switch button {
            case self.allBtn:
                btnType = .all
                break
            case self.largeBtn:
                btnType = .large
                break
            case self.smallBtn:
                btnType = .small
                break
            case self.oddBtn:
                btnType = .odd
                break
            case self.evenBtn:
                btnType = .even
                break
            case self.clearBtn:
                btnType = .clear
                break
            default:
                btnType = .none
            }
            self.delegate!.lotterySectionHeaderBtnClick(buttonType: btnType, section: self.section)
        }
        
    }
    
}
