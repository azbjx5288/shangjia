//
//  PK10WinNumberView.swift
//  GoldenApple
//
//  Created by El Capitan on 2018/2/7.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class PK10WinNumberView: UIView {

    /// pk10标题数组
    fileprivate let tipsTitleArray = ["冠", "亚", "季", "四", "五", "六", "七", "八", "九", "十"]
    private let labelArray : NSMutableArray = NSMutableArray()
    private let buttonArray : NSMutableArray = NSMutableArray()
    private let btnWidth : CGFloat = 19
    private let btnHeight : CGFloat = 15
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setSubViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setSubViews() {
        for index in 0...self.tipsTitleArray.count - 1 {
            let btn : UIButton = UIButton()
            btn.setTitleColor(.clear, for: .normal)
            self.addSubview(btn)
            self.buttonArray.add(btn)
            
            let label : UILabel = UILabel()
            label.text = self.tipsTitleArray[index]
            label.textColor = kGAFontGrayColor
            label.font = UIFont.systemFont(ofSize: 11)
            self.addSubview(label)
            self.labelArray.add(label)
        }

    }
    
    public func setSubviewsConstrain(leftView : UIView,centerYView : UIView) {
        let margin : CGFloat = 2.0
        for index in 0...self.tipsTitleArray.count - 1 {
            let btn : UIButton = self.buttonArray[index] as! UIButton
            let label : UILabel = self.labelArray[index] as! UILabel
            btn.snp.makeConstraints({ (make) in
                make.top.equalTo(self)
                make.left.equalTo(self).offset((margin + self.btnWidth) * CGFloat(index))
                make.size.equalTo(CGSize.init(width: self.btnWidth, height: self.btnHeight))
            })
            label.snp.makeConstraints({ (make) in
                make.top.equalTo(btn.snp.bottom).offset(margin * 0.5)
                make.centerX.equalTo(btn)
            })
            if index == self.tipsTitleArray.count - 1 {
                self.snp.makeConstraints { (make) in
                    make.left.equalTo(leftView)
                    make.centerY.equalTo(centerYView)
                    make.bottom.equalTo(label)
                    make.right.equalTo(btn)
                }
            }
        }
    }
    public func setButtonTitles(numberArray : [String]) {
        for index in 0...self.buttonArray.count - 1 {
            let btn = self.buttonArray[index] as! UIButton
            var image : UIImage?
            if index < numberArray.count {
                image = UIImage(named: "car_" + numberArray[index])
            }
            if image != nil {
                btn.setBackgroundImage(image, for: .normal)
                btn.setTitleColor(.clear, for: .normal)
            } else {
                btn.setTitle(numberArray[0], for: .normal)
                btn.setTitleColor(kGAFontGrayColor, for: .normal)
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
            }
            
        }
    }

}
