//
//  LotteryPlayingViewCell.swift
//  GoldenApple
//
//  Created by User on 03/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryPlayingViewCell: UICollectionViewCell {
    
    let ballBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("01", for: UIControlState.normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.setTitleColor(kGAFontRedColor, for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.selected)
        button.setBackgroundImage(UIImage(named: "lottery_ball_normal"), for: UIControlState.normal)
        button.setBackgroundImage(UIImage(named: "lottery_ball_selected"), for: UIControlState.selected)
        button.isUserInteractionEnabled = false
        
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.ballBtn)
        self.ballBtn.snp.makeConstraints { (make) in
            make.left.right.bottom.top.equalTo(self)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        fatalError("init(coder:) has not been implemented")
    }
    
    override var isSelected: Bool {
        didSet {
            self.ballBtn.isSelected = isSelected
        }
    }
    
    
}
