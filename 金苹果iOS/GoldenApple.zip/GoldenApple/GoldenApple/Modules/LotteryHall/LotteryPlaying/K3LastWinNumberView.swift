//
//  K3SpecialVIew.swift
//  GoldenApple
//
//  Created by El Capitan on 2018/2/5.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class K3LastWinNumberView: UIView {

    private let pointBtn : UIButton = UIButton()
    private let sizeBtn : UIButton = UIButton()
    private let SingleDoubleBtn : UIButton = UIButton()
    private let itemWidth : CGFloat = 25.0
    private let numberBtnArray : NSMutableArray = NSMutableArray()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setSubViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setSubViews() {
        for _ in 0...2 {
            let numberBtn : UIButton = UIButton()
            numberBtn.setTitleColor(.clear, for: .normal)
            self.addSubview(numberBtn)
            self.numberBtnArray.add(numberBtn)
        }
        self.pointBtn.backgroundColor = UIColor.init(red: 138.0 / 255, green: 43.0 / 255, blue: 226.0 / 255, alpha: 1)
        self.pointBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        self.pointBtn.isEnabled = false
        self.pointBtn.layer.cornerRadius = itemWidth * 0.5
        self.addSubview(self.pointBtn)
        
        self.sizeBtn.backgroundColor = UIColor.init(red: 32.0 / 255, green: 178.0 / 255, blue: 170.0 / 255, alpha: 1)
        self.sizeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        self.sizeBtn.isEnabled = false
        self.addSubview(self.sizeBtn)
        
        self.SingleDoubleBtn.backgroundColor = UIColor.init(red: 34.0 / 255, green: 139.0 / 255, blue: 34.0 / 255, alpha: 1)
        self.SingleDoubleBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        self.SingleDoubleBtn.isEnabled = false
        self.addSubview(self.SingleDoubleBtn)
    }
    
    public func setSubviewsConstrain(leftView : UIView,centerYView : UIView) {
        let margin : CGFloat = 2.0
        var lastNumberBtn : UIButton?
        for index in 0...self.numberBtnArray.count - 1 {
            let numberBtn : UIButton = self.numberBtnArray[index] as! UIButton
            numberBtn.snp.makeConstraints({ (make) in
                make.top.equalTo(self)
                make.size.equalTo(CGSize.init(width: itemWidth, height: itemWidth))
                make.left.equalTo(self).offset((itemWidth + margin) * CGFloat(index))
            })
            if index == self.numberBtnArray.count - 1 {
                lastNumberBtn = numberBtn
            }
        }
        
        self.pointBtn.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.bottom.equalTo(self)
            make.left.equalTo((lastNumberBtn?.snp.right)!).offset(margin)
            make.width.equalTo(itemWidth)
        }
        self.sizeBtn.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.size.equalTo(self.pointBtn)
            make.left.equalTo(self.pointBtn.snp.right).offset(margin)
        }
        self.SingleDoubleBtn.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.size.equalTo(self.pointBtn)
            make.left.equalTo(self.sizeBtn.snp.right).offset(margin)
        }
        self.snp.makeConstraints { (make) in
            make.height.equalTo(self.itemWidth)
            make.right.equalTo(self.SingleDoubleBtn.snp.right)
            make.centerY.equalTo(centerYView)
            make.left.equalTo(leftView)
        }
    }
    
    public func setTitles(numbers : NSArray) {
        for index in 0...self.numberBtnArray.count - 1 {
            let numberBtn : UIButton = self.numberBtnArray[index] as! UIButton
            if numbers[index] as! String != "-" {
                numberBtn.setBackgroundImage(UIImage(named: "icon_sz" + (numbers[index] as! String)), for: .normal)
                numberBtn.setTitleColor(.clear, for: .normal)
            } else {
                numberBtn.setTitle(numbers[0] as? String , for: .normal)
                numberBtn.backgroundColor = UIColor.clear
                numberBtn.setTitleColor(kGAFontGrayColor, for: .normal)
                numberBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
                numberBtn.setBackgroundImage(nil, for: .normal)
            }
        }
        var point : Int = 0
        var size : String = "小"
        var singleDouble : String = "单"
        for number in numbers {
            if number as! String == "-" {
                self.pointBtn.isHidden = true
                self.sizeBtn.isHidden = true
                self.SingleDoubleBtn.isHidden = true
                return
            }
            point = point + (Int(number as! String))!
        }
        
        self.pointBtn.isHidden = false
        self.sizeBtn.isHidden = false
        self.SingleDoubleBtn.isHidden = false
        
        self.pointBtn.setTitle(String.init(format: "%d", point), for: .normal)
        
        if point > 10 {
            size = "大"
        }
        if point % 2 == 0 {
            singleDouble = "双"
        }
        
        self.sizeBtn.setTitle(size, for: .normal)
        self.SingleDoubleBtn.setTitle(singleDouble, for: .normal)
        
    }
    
}
