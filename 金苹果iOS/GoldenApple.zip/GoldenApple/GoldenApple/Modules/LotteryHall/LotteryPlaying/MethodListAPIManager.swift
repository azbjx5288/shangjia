//
//  MethodListAPIManager.swift
//  GoldenApple
//
//  Created by User on 01/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class MethodListAPIManager: GAAPIBaseManager {

    struct DataKey {
        static let kId = "id"
        static let kNameCn = "name_cn"
        static let kNameEn = "name_en"
        static let kPid = "pid"
        static let kChildren = "children"
        
        /// iOS客户端定义的玩法详细字典key
        static let kMehtodDetail = "methodDetail"
        
        struct MethodDetailKey {
            
            /// 玩法ID
            static let kSeriesWayId = "series_way_id"
            static let kPrice = "price"
            static let kBetNote = "bet_note"
            static let kBasicMethods = "basic_methods"
            static let kBonusNote = "bonus_note"
            static let kMaxPrize = "maxPrize"
        }
    }
    
}

extension MethodListAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Game&action=getWaySettings"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return true
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
    
}

extension MethodListAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let methodGroupList = data.object(forKey: "data") as? [NSDictionary] else { return nil }
        
        let newMethodGroupInfoList = NSMutableArray()
        let currentMethodType = LotteryRulesOfPlay.default.methodType
        for mainGroupInfoDict in methodGroupList {
            //最外层组信息，如五星
            let newMainGroupDict = NSMutableDictionary(dictionary: mainGroupInfoDict)
            let methodInfoList = NSMutableArray()
            
            for subGroupInfoDict in mainGroupInfoDict.object(forKey: MethodListAPIManager.DataKey.kChildren) as! [NSDictionary] {
                //获取二层方法信息，如直选
                let methodDictList = subGroupInfoDict.object(forKey: MethodListAPIManager.DataKey.kChildren) as! [NSDictionary]
                methodInfoList.addObjects(from: methodDictList)
                for methodDict in methodDictList {
                    //methodDict为底层具体彩种方法信息，如直选复式
                    let methodType = methodDict.object(forKey: MethodListAPIManager.DataKey.MethodDetailKey.kSeriesWayId) as! NSNumber
                    if currentMethodType?.rawValue == methodType.uintValue {
                        let name = mainGroupInfoDict.object(forKey: MethodListAPIManager.DataKey.kNameCn) as! String
                        LotteryRulesOfPlay.default.setLotteryMethodDict(dict: methodDict, mainGroupName: name)
                    }
                }
                
            }
            newMainGroupDict[MethodListAPIManager.DataKey.kMehtodDetail] = methodInfoList
            newMethodGroupInfoList.add(newMainGroupDict)
        }
        
        return newMethodGroupInfoList
    }
    
    
}
