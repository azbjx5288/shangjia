//
//  IssueInfoAPIManager.swift
//  GoldenApple
//
//  Created by User on 14/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class IssueInfoAPIManager: GAAPIBaseManager {

    struct DataKey {
        
        /// 奖期
        static let kIssue = "issue"
        
        /// 服务器时间
        static let kServerTime = "server_time"
        
        /// 开奖结束时间
        static let kEndTime = "end_time"
        
        /// 时间计数，服务器时间和开奖结束时间差的秒数
        static let kTimesCount = "timesCount"
    }
    
}

extension IssueInfoAPIManager: LYAPIManager {
    
    func methodName() -> NSString {
        return "service?packet=Game&action=getCurrentIssue"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
    
}

extension IssueInfoAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let issueInfoDict = data.object(forKey: "data") as? NSDictionary else { return nil }
        
        //计算开奖倒计时
        let serverTime = issueInfoDict.object(forKey: IssueInfoAPIManager.DataKey.kServerTime) as! String
        let endTime = issueInfoDict.object(forKey: IssueInfoAPIManager.DataKey.kEndTime) as! String
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "YYYY-MM-dd HH:mm:ss"
        let serverDate = dateFormat.date(from: serverTime)!
        let endDate = dateFormat.date(from: endTime)!
        let timesCount = endDate.timeIntervalSince(serverDate)
        
        let resultParams = NSMutableDictionary(dictionary: issueInfoDict)
        resultParams[DataKey.kTimesCount] = timesCount
        
        return resultParams
    }
}
