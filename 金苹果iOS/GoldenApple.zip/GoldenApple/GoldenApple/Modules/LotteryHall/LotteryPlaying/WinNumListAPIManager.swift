//
//  WinNumListAPIManager.swift
//  GoldenApple
//
//  Created by User on 14/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//  7.16.    获得指定游戏最近的中奖号码列表

import UIKit

class WinNumListAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        
        /// 奖期
        static let kIssue = "issue"
        
        /// 官方开奖时间
        static let kOfficalTime = "offical_time"
        
        /// 中奖号码位数
        static let kWinLength = "win_length"
        
        /// 中奖号码
        static let kWNnumber = "wn_number"
    }
}

extension WinNumListAPIManager: LYAPIManager {
    
    func methodName() -> NSString {
        return "service?packet=Game&action=getWnNumberList"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
    }
}

extension WinNumListAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let dataArray = data.object(forKey: "data") else { return NSArray() }
        return dataArray
    }
    
    
}
