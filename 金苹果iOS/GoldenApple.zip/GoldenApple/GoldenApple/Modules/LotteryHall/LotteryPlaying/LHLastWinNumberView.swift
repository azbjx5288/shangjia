//
//  LHLastWinNumberView.swift
//  GoldenApple
//
//  Created by El Capitan on 2018/2/6.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class LHLastWinNumberView: UIView {

    private let itemWidth : CGFloat = 28
    private let titleArray : [String] = ["1V10","2V9","3V8","4V7","5V6"]
    private let labelArray : NSMutableArray = NSMutableArray()
    private let buttonArray : NSMutableArray = NSMutableArray()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setSubViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setSubViews() {
        for index in 0...self.titleArray.count - 1 {
            let btn : UIButton = UIButton()
            if #available(iOS 8.2, *) {
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: 600)
            } else {
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
            }
            
            btn.setTitle("龙", for: .normal)
            btn.layer.cornerRadius = self.itemWidth * 0.5
            btn.isEnabled = false
            btn.backgroundColor = UIColor.init(red: 50.0 / 255, green: 205.0 / 255, blue: 50.0 / 255, alpha: 1)
            self.addSubview(btn)
            self.buttonArray.add(btn)
            
            let label : UILabel = UILabel()
            label.text = self.titleArray[index]
            label.textColor = kGAFontGrayColor
            label.font = UIFont.systemFont(ofSize: 14)
            self.addSubview(label)
            self.labelArray.add(label)
        }
    }
    
    public func setSubviewsConstrain(leftView : UIView,centerYView : UIView) {
        let margin : CGFloat = 5.0
        for index in 0...self.titleArray.count - 1 {
            let btn : UIButton = self.buttonArray[index] as! UIButton
            let label : UILabel = self.labelArray[index] as! UILabel
            btn.snp.makeConstraints({ (make) in
                make.top.equalTo(self)
                make.left.equalTo(self).offset((margin + itemWidth) * CGFloat(index))
                make.width.height.equalTo(self.itemWidth)
            })
            label.snp.makeConstraints({ (make) in
                make.top.equalTo(btn.snp.bottom).offset(margin * 0.5)
                make.centerX.equalTo(btn)
            })
            if index == self.titleArray.count - 1 {
                self.snp.makeConstraints { (make) in
                    make.left.equalTo(leftView)
                    make.centerY.equalTo(centerYView)
                    make.bottom.equalTo(label)
                    make.right.equalTo(btn)
                }
            }
        }
    }
    
    public func setButtonTitles(numberArray : [String]) {
        
        for index in 0...self.buttonArray.count - 1 {
            let btn = self.buttonArray[index] as! UIButton
            if numberArray[index] == "-" {
                btn.setTitle(numberArray[0] , for: .normal)
                btn.backgroundColor = UIColor.clear
                btn.setTitleColor(kGAFontGrayColor, for: .normal)
                btn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
            } else {
                let frontNumbert = Int(numberArray[index])!
                let behindNumber = Int(numberArray[numberArray.count - 1 - index])!
                if frontNumbert < behindNumber {
                    btn.setTitle("虎", for: .normal)
                    btn.backgroundColor = UIColor.init(red: 255.0 / 255, green: 127.0 / 255, blue: 80.0 / 255, alpha: 1)
                } else {
                    btn.setTitle("龙", for: .normal)
                    btn.backgroundColor = UIColor.init(red: 50.0 / 255, green: 205.0 / 255, blue: 50.0 / 255, alpha: 1)
                }
            }
            
        }
    }
    
   

}
