//
//  NormalLastWinNumberView.swift
//  GoldenApple
//
//  Created by El Capitan on 2018/2/7.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class NormalLastWinNumberView: UIView {

    private let buttonArray : NSMutableArray = NSMutableArray()
    private let btnWidth : CGFloat = 23
    private let btnHeight : CGFloat = 23
    private var numberArray : [NSString]?
    init(frame: CGRect,numberArray : [NSString]) {
        super.init(frame: frame)
        self.numberArray = numberArray
        self.setSubViews()
        self.setButtonTitles()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setSubViews() {
        for _ in 0...(self.numberArray?.count)! - 1 {
            let btn : UIButton = UIButton()
            btn.setTitleColor(.clear, for: .normal)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
            self.addSubview(btn)
            self.buttonArray.add(btn)
        }
        
    }
    
    public func setSubviewsConstrain() {
        let margin : CGFloat = 2.0
        for index in 0...self.buttonArray.count - 1 {
            let btn : UIButton = self.buttonArray[index] as! UIButton
            btn.snp.makeConstraints({ (make) in
                make.top.equalTo(self)
                make.left.equalTo(self).offset((margin + self.btnWidth) * CGFloat(index))
                make.size.equalTo(CGSize.init(width: self.btnWidth, height: self.btnHeight))
            })
            if index == self.buttonArray.count - 1 {
                self.snp.makeConstraints { (make) in
                    make.left.equalTo(self.superview!)
                    make.centerY.equalTo(self.superview!)
                    make.bottom.equalTo(btn)
                    make.right.equalTo(btn)
                }
            }
        }
    }
    public func setButtonTitles() {
        for index in 0...self.buttonArray.count - 1 {
            let btn = self.buttonArray[index] as! UIButton
            btn.setBackgroundImage(UIImage(named: "lottery_ball_selected"), for: .normal)
            btn.setTitleColor(.white, for: .normal)
            btn.setTitle(self.numberArray?[index] as String?, for: .normal)
        }
    }

}
