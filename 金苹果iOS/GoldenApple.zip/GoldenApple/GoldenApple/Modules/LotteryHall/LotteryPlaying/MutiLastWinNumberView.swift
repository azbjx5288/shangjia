//
//  MutiLastWinNumberView.swift
//  GoldenApple
//
//  Created by User on 2018/6/4.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class MutiLastWinNumberView: UIView {

    private let buttonArray : NSMutableArray = NSMutableArray()
    private let btnWidth : CGFloat = 23
    private let btnHeight : CGFloat = 23
    private let margin : CGFloat = 2.0
    private var numberArray : [NSString]?
    ///最大视图显示宽度
    var maxViewDisplayWidth:Double = 0.0
    
    required init(numberArray : [NSString], maxViewWidth: Double = 0) {
        super.init(frame: CGRect.zero)
        
        self.numberArray = numberArray
        self.maxViewDisplayWidth = maxViewWidth
        
        self.setSubViews()
        self.setButtonTitles()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setSubViews() {
        for _ in 0...(self.numberArray?.count)! - 1 {
            let btn : UIButton = UIButton()
            btn.setTitleColor(.clear, for: .normal)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
            self.addSubview(btn)
            self.buttonArray.add(btn)
        }
        
    }
    
    public func setSubviewsConstrain() -> CGFloat {
        
        if self.maxViewDisplayWidth > 0 {
            
            let totalBallWidth = Double((self.numberArray?.count)!) * Double(btnWidth + margin * 2)
            let maxRow = ceil(totalBallWidth / self.maxViewDisplayWidth)
            let rowNumber = Int(ceil(Double((self.numberArray?.count)!) / maxRow))
            
            let iMaxRow = Int(maxRow)
            for index in 0...iMaxRow-1 {
                
                var maxCount = rowNumber * (index+1)
                if index == iMaxRow-1 {
                    maxCount = self.numberArray!.count
                }
                
                for indexBtn in (rowNumber * index)...maxCount-1 {
                    let btn : UIButton = self.buttonArray[indexBtn] as! UIButton
                    let topMake = CGFloat(index) * (self.btnHeight + self.margin)
                    btn.snp.makeConstraints { (make) in
                        make.top.equalTo(self).offset(topMake)
                        make.left.equalTo(self).offset((self.margin + self.btnWidth) * CGFloat(indexBtn % (maxCount-rowNumber*index)))
                        make.size.equalTo(CGSize.init(width: self.btnWidth, height: self.btnHeight))
                    }
                }
            }
            
            return CGFloat(maxRow) * (self.btnHeight + self.margin)
        }
        
        return 0
    }
    public func setButtonTitles() {
        for index in 0...self.buttonArray.count - 1 {
            let btn = self.buttonArray[index] as! UIButton
            btn.setBackgroundImage(UIImage(named: "lottery_ball_selected"), for: .normal)
            btn.setTitleColor(.white, for: .normal)
            btn.setTitle(self.numberArray?[index] as String?, for: .normal)
        }
    }


}
