//
//  LotteryPlayingView.swift
//  GoldenApple
//
//  Created by User on 30/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import UITextView_Placeholder
import TangramKit

class LotteryPlayingView: UIView {
    
    var delegate: LotteryDigitDelegate?
    
    /// pk10标题数组
    fileprivate let tipsTitleArray = ["冠", "亚", "季", "四", "五", "六", "七", "八", "九", "十"]
    
    enum eDigitType: String {
        case wan = "wan", qian = "qian", bai = "bai", shi = "shi", ge = "ge"
    }
    
    var selectedDigitList: Dictionary<String,Bool> = ["wan": false, "qian": false, "bai": false, "shi": false, "ge": false, ]
    
    fileprivate let topView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        return view
    }()
    
    let awardPeriodLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.darkGray
        label.text = "0"
        return label
    }()
    
    fileprivate let awardPeriodTipLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.darkGray
        label.text = "期"
        return label
    }()
    
    let countdownLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textColor = UIColor.red
        
        label.text = "00:00:00"
        return label
    }()
    
    let lastAwardPeriodLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.darkGray
        label.text = "000000000"
        return label
    }()
    
    fileprivate let lastAwardPeriodTipLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.darkGray
        label.text = "期"
        return label
    }()
    let lastPeriodNumberView: UIView = {
        let view = UIView()
        return view
    }()
    
    
    let collectionView: UICollectionView = {
        let flowLayout = GACollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: 40, height: 40)
        flowLayout.minimumLineSpacing = 10
        flowLayout.minimumInteritemSpacing = 35
        flowLayout.sectionInset = UIEdgeInsetsMake(20, 15, 20, 15)
        
        let collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = UIColor.clear
        collectionView.allowsMultipleSelection = true
        collectionView.showsVerticalScrollIndicator = false
        return collectionView
    }()
    
    /// 单式投注页面
    let manualLotteryView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        
        return view
    }()
    
    /// 单式输入注单提示
    fileprivate let inputLotteryTips: UILabel = {
        let label = UILabel()
        label.text = "请输入注单"
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = kGAFontBlackColor
        return label
    }()
    
    /// 单式清空按钮
    fileprivate let manualClearBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setImage(UIImage(named: "trash-icon"), for: UIControlState.normal)
        button.setTitle("清空", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        button.layer.borderWidth = 1
        
        return button
    }()
    
    /// 单式输入号码框
    let inputBettingTextView : UITextView = {
        let view = UITextView()
        view.placeholder = "输入注单后，系统将自动计数有效注数。"
        view.font = UIFont.systemFont(ofSize: 12)
        view.keyboardType = .numbersAndPunctuation
        view.textAlignment = .left
        view.backgroundColor = kGASerperatorLineGrayColor
        
        return view
    }()
    
    /// 单式输入说明提示
    fileprivate let bettingRuleTips: UILabel = {
        let label = UILabel()
        label.text = "说明:\n 时时彩：每一注号码之间的间隔符支持 回车 空格 逗号[,] 分号[;] 冒号[:] 竖杠[|] 点[.]，每注内无需间隔。\n11选5、PK10：每一注号码之间的间隔符支持 回车 逗号[,] 分号[;] 冒号[:] 竖杠[|] 点[.]，每注内间隔使用空格即可。\n文本内容支持复制、粘贴。\n一次投注支持5000注！"
        label.textColor = kGAFontGrayColor
        label.textAlignment = .left
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 12)
        
        return label
    }()
    
    let methodCollectionView: UIView = {
        let view = UIView()
        
        return view
    }()
    
    fileprivate let bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = kGATabbarBackgroundColor
        return view
    }()
    
    //    let randomBtn: UIButton = {
    //        let button = UIButton(type: UIButtonType.custom)
    //        button.titleLabel?.text = "机选"
    //
    //        return button
    //    }()
    
    fileprivate let bettingSelectTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "已选"
        
        return label
    }()
    
    let bettingCount: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "0"
        return label
    }()
    
    fileprivate let bettingTipsWord: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "注,"
        
        return label
    }()
    
    let totalPrice: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 14)
        label.textColor = kGAFontRedColor
        label.text = "0"
        
        return label
    }()
    
    fileprivate let yuanTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "元"
        
        return label
    }()
    
    fileprivate let bettingTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.textColor = UIColor.white
        label.text = "单注最高奖金:"
        return label
    }()
    
    let maxPrice: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.textColor = kGAFontRedColor
        label.text = "0.0"
        return label
    }()
    
    fileprivate let secondYuanTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12)
        label.textColor = UIColor.white
        label.text = "元"
        
        return label
    }()
    
    let bettingBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("确定", for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.disabled)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.setBackgroundImage(UIImage(named: "menu-press-background"), for: UIControlState.normal)
        
        return button
    }()
    
    let digitView: TGLinearLayout = {
        let view = TGLinearLayout(.horz)
        view.backgroundColor = .white
        return view
    }()
    
    
    let wanBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: .normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: .selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("万位", for: UIControlState.normal)
        return button
    }()
    
    let qianBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: .normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: .selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("千位", for: UIControlState.normal)
        return button
    }()
    
    let baiBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: .normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: .selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("百位", for: UIControlState.normal)
        return button
    }()
    
    let shiBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: .normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: .selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("十位", for: UIControlState.normal)
        return button
    }()
    
    let geBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: .normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: .selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        button.setTitle("个位", for: UIControlState.normal)
        return button
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.topView)
        self.topView.addSubview(self.awardPeriodLabel)
        self.topView.addSubview(self.awardPeriodTipLabel)
        self.topView.addSubview(self.countdownLabel)
        self.topView.addSubview(self.lastAwardPeriodLabel)
        self.topView.addSubview(self.lastAwardPeriodTipLabel)
        self.topView.addSubview(self.lastPeriodNumberView)
        
        self.addSubview(self.collectionView)
        
        self.addSubview(self.manualLotteryView)
        self.manualLotteryView.addSubview(self.inputLotteryTips)
        self.manualLotteryView.addSubview(self.manualClearBtn)
        self.manualLotteryView.addSubview(self.inputBettingTextView)
        self.manualLotteryView.addSubview(self.bettingRuleTips)
        
        self.addSubview(self.digitView)
        self.digitView.addSubview(self.wanBtn)
        self.digitView.addSubview(self.qianBtn)
        self.digitView.addSubview(self.baiBtn)
        self.digitView.addSubview(self.shiBtn)
        self.digitView.addSubview(self.geBtn)
        
        
        self.addSubview(self.bottomView)
        //        self.bottomView.addSubview(self.randomBtn)
        self.bottomView.addSubview(self.bettingSelectTips)
        self.bottomView.addSubview(self.bettingCount)
        self.bottomView.addSubview(self.bettingTipsWord)
        self.bottomView.addSubview(self.totalPrice)
        self.bottomView.addSubview(self.yuanTips)
        self.bottomView.addSubview(self.bettingTips)
        self.bottomView.addSubview(self.maxPrice)
        self.bottomView.addSubview(self.secondYuanTips)
        self.bottomView.addSubview(self.bettingBtn)
        
        self.addSubview(self.methodCollectionView)
        
        self.makeConstraintsForSubviews()
        
        self.methodCollectionView.isHidden = true
        self.manualClearBtn.addTarget(self, action: #selector(manualClearBtnClick), for: UIControlEvents.touchUpInside)
        self.wanBtn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        self.qianBtn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        self.baiBtn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        self.shiBtn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        self.geBtn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func setLastPeriodNumber(_ numberString: String?) {
        
        for view in (self.lastPeriodNumberView.subviews) {
            view.removeFromSuperview()
        }
        
        var numberArray = ["-", "-", "-", "-", "-"]
        if numberString != nil && !numberString!.isEmpty {
            numberArray = numberString!.components(separatedBy: " ")
            if numberArray.count < 2 {
                numberArray = numberString!.map{String($0)}
            }
        }
        
        //pk10的龙虎玩法上期开奖号码view处理
        if eLotteryMethodType.lh == LotteryRulesOfPlay.default.methodType{
            let lhLastView : LHLastWinNumberView = LHLastWinNumberView.init(frame: CGRect.zero)
            self.lastPeriodNumberView.addSubview(lhLastView)
            lhLastView.setSubviewsConstrain(leftView: self.lastPeriodNumberView, centerYView: self.lastPeriodNumberView)
            lhLastView.setButtonTitles(numberArray: numberArray)
            
            self.topView.snp.updateConstraints({ (make) in
                make.height.equalTo(100)
            })
            return
        }
        
        self.topView.snp.updateConstraints({ (make) in
            make.height.equalTo(80)
        })
        
        //pk10非龙虎玩法
        if eLotterySeriesType.ePk10 == LotteryRulesOfPlay.default.lotteryType {
            let pk10NumberView : PK10WinNumberView = PK10WinNumberView()
            self.lastPeriodNumberView.addSubview(pk10NumberView)
            pk10NumberView.setSubviewsConstrain(leftView: self.lastPeriodNumberView, centerYView: self.lastPeriodNumberView)
            pk10NumberView.setButtonTitles(numberArray: numberArray)
            return
        }
        //快三
        if LotteryRulesOfPlay.default.lotteryType == eLotterySeriesType.eK3 {
            let k3SpecialView : K3LastWinNumberView = K3LastWinNumberView.init(frame: CGRect.zero)
            self.lastPeriodNumberView.addSubview(k3SpecialView)
            k3SpecialView.setSubviewsConstrain(leftView: self.lastPeriodNumberView,centerYView: self.lastPeriodNumberView)
            k3SpecialView.setTitles(numbers: numberArray as NSArray)
            return
        }
        
        if eLotterySeriesType.eKL == LotteryRulesOfPlay.default.lotteryType {
            //号码视图显示的宽度
            let numberViewWidth = Double(lastPeriodNumberView.width)
            if numberViewWidth > 0 {
                let mutiNumberView = MutiLastWinNumberView(numberArray: numberArray as [NSString], maxViewWidth: numberViewWidth)
                self.lastPeriodNumberView.addSubview(mutiNumberView)
                let updateH = mutiNumberView.setSubviewsConstrain()
                topView.snp.updateConstraints { (make) in
                    make.height.equalTo(updateH + self.countdownLabel.frame.maxY + 10)
                }
                return
            }
            
        }
        
        //其他
        let normalNumberView : NormalLastWinNumberView = NormalLastWinNumberView.init(frame: CGRect.zero, numberArray: numberArray as [NSString])
        self.lastPeriodNumberView.addSubview(normalNumberView)
        normalNumberView.setSubviewsConstrain()
        
    }
    
    @objc fileprivate func manualClearBtnClick() {
        self.inputBettingTextView.text = ""
    }
    
    @objc fileprivate func keyboardWillShow(_ notice: Notification) {
        
        let endRect = (notice.userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let duration = (notice.userInfo![UIKeyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        
        UIView.animate(withDuration: duration, animations: {
            self.bottomView.transform = CGAffineTransform(translationX: 0, y: -endRect.height)
        })
    }
    
    @objc fileprivate func keyboardWillHide(_ notice: Notification) {
        
        let duration = (notice.userInfo![UIKeyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        UIView.animate(withDuration: duration) {
            self.bottomView.transform = CGAffineTransform.identity
        }
        
    }
    
    @objc func buttonClick(_ button: UIButton) {
        button.isSelected = !button.isSelected
        
        switch button {
        case self.wanBtn:
            selectedDigitList[eDigitType.wan.rawValue] = button.isSelected
            break
        case self.qianBtn:
            selectedDigitList[eDigitType.qian.rawValue] = button.isSelected
            break
        case self.baiBtn:
            selectedDigitList[eDigitType.bai.rawValue] = button.isSelected
            break
        case self.shiBtn:
            selectedDigitList[eDigitType.shi.rawValue] = button.isSelected
            break
        case self.geBtn:
            selectedDigitList[eDigitType.ge.rawValue] = button.isSelected
            break
        default:
            break
        }
        if let dalegate = self.delegate {
            dalegate.lotteryDigitBtnClick(digitDic: selectedDigitList)
        }
        
    }
    
    fileprivate func makeConstraintsForSubviews() {
        self.topView.snp.makeConstraints { (make) in
            make.top.left.right.equalTo(self)
            make.height.equalTo(80)
        }
        self.awardPeriodLabel.snp.makeConstraints { (make) in
            make.top.equalTo(20)
            make.left.equalTo(15)
        }
        self.awardPeriodTipLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.awardPeriodLabel)
            make.left.equalTo(self.awardPeriodLabel.snp.right)
        }
        self.countdownLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.awardPeriodLabel)
            make.left.equalTo(self.awardPeriodTipLabel.snp.right).offset(10)
        }
        self.lastAwardPeriodLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.awardPeriodLabel)
            make.centerY.equalTo(self.lastPeriodNumberView)
        }
        self.lastAwardPeriodTipLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.lastAwardPeriodLabel)
            make.left.equalTo(self.lastAwardPeriodLabel.snp.right)
        }
        self.lastPeriodNumberView.snp.makeConstraints { (make) in
            make.top.equalTo(self.countdownLabel.snp.bottom).offset(5)
            make.left.equalTo(self.lastAwardPeriodTipLabel.snp.right).offset(10)
            make.bottom.equalToSuperview().offset(-5)
            make.right.equalToSuperview().offset(-10)
        }
        
        self.collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(self.digitView.snp.bottom)
            make.left.right.equalTo(self)
            make.bottom.equalTo(self.bottomView.snp.top)
        }
        
        self.manualLotteryView.snp.makeConstraints { (make) in
            make.top.equalTo(self.digitView.snp.bottom)
            make.left.right.equalTo(self)
            make.bottom.equalTo(self.bottomView.snp.top)
        }
        self.inputLotteryTips.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.centerY.equalTo(self.manualClearBtn)
        }
        self.manualClearBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15)
            make.top.equalToSuperview().offset(20)
            make.width.equalTo(68)
            make.height.equalTo(30)
        }
        self.inputBettingTextView.snp.makeConstraints { (make) in
            make.top.equalTo(self.manualClearBtn.snp.bottom).offset(15)
            make.left.equalTo(self.inputLotteryTips)
            make.right.equalTo(self.manualClearBtn)
            make.height.equalTo(125)
        }
        self.bettingRuleTips.snp.makeConstraints { (make) in
            make.top.equalTo(self.inputBettingTextView.snp.bottom).offset(15)
            make.left.right.equalTo(self.inputBettingTextView)
            make.height.equalTo(120)
        }
        
        self.methodCollectionView.snp.makeConstraints { (make) in
            make.top.left.right.bottom.equalToSuperview()
        }
        
        self.bottomView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(self)
            make.height.equalTo(49)
        }
        self.bettingSelectTips.snp.makeConstraints { (make) in
            make.left.equalTo(15)
            make.top.equalToSuperview().offset(5)
        }
        self.bettingCount.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bettingSelectTips)
            make.left.equalTo(self.bettingSelectTips.snp.right)
        }
        self.bettingTipsWord.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.bettingSelectTips)
            make.left.equalTo(self.bettingCount.snp.right)
        }
        self.totalPrice.snp.makeConstraints { (make) in
            make.left.equalTo(self.bettingTipsWord.snp.right)
            make.centerY.equalTo(self.bettingSelectTips)
        }
        self.yuanTips.snp.makeConstraints { (make) in
            make.left.equalTo(self.totalPrice.snp.right)
            make.centerY.equalTo(self.bettingSelectTips)
        }
        self.bettingTips.snp.makeConstraints { (make) in
            make.left.equalTo(self.bettingSelectTips)
            make.bottom.equalTo(self.bottomView).offset(-5)
        }
        self.maxPrice.snp.makeConstraints { (make) in
            make.left.equalTo(self.bettingTips.snp.right).offset(5)
            make.centerY.equalTo(self.bettingTips)
        }
        self.secondYuanTips.snp.makeConstraints { (make) in
            make.left.equalTo(self.maxPrice.snp.right)
            make.centerY.equalTo(self.bettingTips)
        }
        self.bettingBtn.snp.makeConstraints { (make) in
            make.top.right.bottom.equalTo(self.bottomView)
            make.width.equalTo(95)
        }
        
        self.digitView.snp.makeConstraints { (make) in
            make.left.right.equalTo(self)
            make.top.equalTo(topView.snp.bottom).offset(10)
            make.height.equalTo(30)
        }
        self.digitView.tg_width.equal(.fill)
        self.digitView.tg_height.equal(30)
        self.digitView.tg_gravity = TGGravity.vert.center
        
        self.wanBtn.tg_width.equal(.average)
        self.wanBtn.tg_height.equal(.wrap)
        self.qianBtn.tg_width.equal(.average)
        self.qianBtn.tg_height.equal(.wrap)
        self.baiBtn.tg_width.equal(.average)
        self.baiBtn.tg_height.equal(.wrap)
        self.shiBtn.tg_width.equal(.average)
        self.shiBtn.tg_height.equal(.wrap)
        self.geBtn.tg_width.equal(.average)
        self.geBtn.tg_height.equal(.wrap)
        
    }
}

protocol LotteryDigitDelegate {
    
    func lotteryDigitBtnClick(digitDic: Dictionary<String, Bool>)
    
}
