//
//  LotteryHallView.swift
//  GoldenApple
//
//  Created by User on 29/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import FSPagerView
import SwiftySegmentedControl

class LotteryHallView: UIView {
    let bannerHeight : CGFloat = 160.0
    let segmentedBarHeight : CGFloat = 60.0
    let bannerView: FSPagerView = {
        let pagerView = FSPagerView()
        pagerView.automaticSlidingInterval = 5
        pagerView.isInfinite = true
        
        return pagerView
    }()
    
    let pageControl: FSPageControl = {
        let pageCtr = FSPageControl()
        pageCtr.contentHorizontalAlignment = .right
        pageCtr.contentInsets = UIEdgeInsetsMake(0, 20, 0, 20)
        pageCtr.hidesForSinglePage = true
        
        return pageCtr
    }()
    
    let lotterySegmentedControl: LotteryMenuView = {
        let segment = LotteryMenuView()
        return segment
    }()

    let collectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        let collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = UIColor.clear
        return collectionView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.collectionView)

        self.collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(self)
            make.bottom.equalTo(self)
            make.left.right.equalTo(self)
        }

        self.collectionView.contentInset = UIEdgeInsetsMake(self.bannerHeight + self.segmentedBarHeight, 0, 0, 0);
     
        self.collectionView.addSubview(self.bannerView);
        self.bannerView.backgroundColor = .red
        for view in self.bannerView.subviews {
            view.backgroundColor = .blue
        }
     
        self.bannerView.addSubview(self.pageControl)
        self.bannerView.frame = CGRect.init(x: 0, y: -(bannerHeight + self.segmentedBarHeight), width: UIScreen.main.bounds.width, height: bannerHeight)

        self.pageControl.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(self.bannerView)
            make.height.equalTo(25)
        }
        
        self.collectionView.addSubview(self.lotterySegmentedControl)
        self.lotterySegmentedControl.frame = CGRect.init(x: 0, y: self.bannerView.frame.maxY, width: UIScreen.main.bounds.width, height: self.segmentedBarHeight)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        fatalError("init(coder:) has not been implemented")
    }

    
}

extension LotteryHallView: UIScrollViewDelegate {
    
    func scrollViewDidScrollToTop(_ scrollView: UIScrollView) {
        
    }
    
    
}
