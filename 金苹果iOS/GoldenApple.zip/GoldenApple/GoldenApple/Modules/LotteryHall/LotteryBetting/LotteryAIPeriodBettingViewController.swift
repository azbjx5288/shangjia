//
//  LotteryAIPeriodBettingViewController.swift
//  智能追号画面
//  GoldenApple
//
//  Created by El Capitan on 02/08/2018.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class LotteryAIPeriodBettingViewController: UIViewController {
    
    struct DataKey {
        
        /// 玩法名
        static let kTitleName = "titileName"
        /// 彩票单价
        static let kPrice = "price"
        
        /// 投注码
        static let kBall = "ball"
        /// 注单的顺序ID
        static let kJsId = "jsId"
        /// 玩法ID
        static let kWayId = "wayId"
        /// 彩票ID
        static let kGameId = "gameId"
        /// 总金额
        static let kAmount = "amount"
        /// 投注详细信息
        static let kBalls = "balls"
        /// 附加信息，用于任选玩法，非任选时请设为空数组
        static let kExtra = "extra"
        /// 价格系数
        static let kMoneyunit = "moneyunit"
        /// 单倍注数
        static let kNum = "num"
        /// 奖金组
        static let kPrizeGroup = "prizeGroup"
        /// 是否追号,1或0
        static let kIsTrace = "isTrace"
        /// 奖期及倍数列表，键为奖期，值为倍数
        static let kOrders = "orders"
        /// 是否追中即停，在isTrace为0时，无效
        static let kTraceWinStop = "traceWinStop"
        /// 倍数
        static let kMultiple = "multiple"
        /// 彩种
        static let kName = "name"
        /// 选中状态
        static let kSelectStatus = "selectStatus"
        /// 单期总金额
        static let kSingleAmount = "singleAmount"
        /// 利润率追号单期奖金
        static let kProfitSingleReward = "profitSingleReward"
        /// 利润率追号本期为止总投入金额
        static let kProfitByNowCost = "profitByNowCost"
        /// 利润率追号预期盈利金额
        static let kProfitExpectedReward = "profitExpectedReward"
        /// 利润率追号预期盈利率
        static let kProfitExpectedRate = "profitExpectedRate"
        /// 期号
        static let kLotteryNumber = "number"
        /// 期数
        static let kTotalPeriod = "totalPeriod"
    }
    
    var coutdownString: String? {
        didSet {
            self.contentView.coutdownLabel.text = coutdownString
        }
    }
    
    fileprivate var refreshFlg = false
    
    var currentAwardPriceString: String? {
        willSet {
            refreshFlg = newValue != currentAwardPriceString && currentAwardPriceString != nil
        }
        
        didSet {
            self.contentView.awardPeriodLabel.text = currentAwardPriceString
            if refreshFlg {
                
                createSameRatePlan()
                createDoubleTracePlan()
                createProfitRatePlan()
            }
        }
    }
    
    // 彩种信息字典
    fileprivate var bettingList = [NSDictionary]()
    
    fileprivate var traceIssueList: [NSDictionary]?
    
    fileprivate var samePlanIssueList: [NSMutableDictionary] = []
    fileprivate var profitPlanIssueList: [NSMutableDictionary] = []
    fileprivate var doublePlanIssueList: [NSMutableDictionary] = []
    
    fileprivate let contentView: LotteryAIPeriodBettingView = {
        return LotteryAIPeriodBettingView()
    }()
    
    fileprivate let bettingAPIManager = BettingAPIManager()
    fileprivate let traceIssueAPIManager = TraceIssueAPIManager()
    fileprivate let zhuiHaoDetailAPIManager = ZhuiHaoDetailAPIManager()
    
    //bad way to do so
    fileprivate var profitRefreshFlg = false
    fileprivate var doubleRefreshFlg = false
    
    fileprivate var price = 0
    fileprivate var totalCountPerPeriod = 0
    fileprivate var lotteryId = 0
    var moneyUnit = 0.0
    var balance: String?
    weak var bettingCtrl: LotteryBettingViewController?
    
    
    required init(bettingList: [NSDictionary]) {
        
        self.bettingList = bettingList
        
        super.init(nibName: nil, bundle: nil)
        let bettingDic = bettingList.first as! NSDictionary
        self.navigationItem.title = bettingDic[LotteryAIPeriodBettingViewController.DataKey.kName] as? String
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        super.loadView()
        
        view = contentView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.backgroundColor = kGAViewGrayBackgoundColor
        traceIssueAPIManager.paramSource = self
        traceIssueAPIManager.delegate = self
        bettingAPIManager.paramSource = self
        bettingAPIManager.delegate = self
        zhuiHaoDetailAPIManager.paramSource = self
        zhuiHaoDetailAPIManager.delegate = self
        
        contentView.sameTableView.register(SameRateTraceTableViewCell.classForCoder(), forCellReuseIdentifier: SameRateTraceTableViewCell.cellIdentifier)
        contentView.profitTableView.register(ProfitTraceTableViewCell.classForCoder(), forCellReuseIdentifier: ProfitTraceTableViewCell.cellIdentifier)
        contentView.doubleTableView.register(SameRateTraceTableViewCell.classForCoder(), forCellReuseIdentifier: SameRateTraceTableViewCell.cellIdentifier)
        
        contentView.sameTableView.delegate = self
        contentView.sameTableView.dataSource = self
        
        contentView.profitTableView.delegate = self
        contentView.profitTableView.dataSource = self
        
        contentView.doubleTableView.delegate = self
        contentView.doubleTableView.dataSource = self
        
        contentView.sameHeaderSelectBtn.addTarget(self, action: #selector(sameHeaderSelectBtnClick(_:)), for: .touchUpInside)
        contentView.profitHeaderSelectBtn.addTarget(self, action: #selector(profitHeaderSelectBtnClick(_:)), for: .touchUpInside)
        contentView.doubleHeaderSelectBtn.addTarget(self, action: #selector(doubleHeaderSelectBtnClick(_:)), for: .touchUpInside)
        
        contentView.sameMutipleFiled.delegate = self
        contentView.samePeriodField.delegate = self
        
        contentView.sameCreatePlanBtn.addTarget(self, action: #selector(createSameRatePlan), for: .touchUpInside)
        
        contentView.profitPeriodField.delegate = self
        contentView.profitMinRateField.delegate = self
        contentView.profitStartMultiField.delegate = self
        
        contentView.profitCreatePlanBtn.addTarget(self, action: #selector(createProfitRatePlan), for: .touchUpInside)
        
        contentView.doubleMutipleFiled.delegate = self
        contentView.doubleStartMutipleFiled.delegate = self
        contentView.doublePeriodField.delegate = self
        contentView.doubleIntervalPeriodField.delegate = self
        
        contentView.doubleCreatePlanBtn.addTarget(self, action: #selector(createDoubleTracePlan), for: .touchUpInside)
        
        for bettingDict in self.bettingList {
            let count = bettingDict[LotteryAIPeriodBettingViewController.DataKey.kNum] as! Int
            totalCountPerPeriod += count
        }
        price = self.bettingList.first![LotteryAIPeriodBettingViewController.DataKey.kPrice] as! Int

        contentView.sameHeaderSelectBtn.addTarget(self, action: #selector(sameHeaderSelectBtnClick(_:)), for: .touchUpInside)
        contentView.balanceLabel.text = balance
        
        contentView.confirmBettingBtn.addTarget(self, action: #selector(bettingBtnClick), for: .touchUpInside)
        contentView.segmentControl.addTarget(self, action: #selector(segmentControlSwitch(_:)), for: .valueChanged)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        traceIssueAPIManager.loadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
    }
    
    func sameHeaderSelectBtnClick(_ btn: UIButton) {
        btn.isSelected = !btn.isSelected
        for dic in samePlanIssueList {
            dic.setObject(btn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
        }
        reloadListAndTotal(contentView.sameTableView)
    }
    
    func profitHeaderSelectBtnClick(_ btn: UIButton) {
        btn.isSelected = !btn.isSelected
        for dic in profitPlanIssueList {
            dic.setObject(btn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
        }
        reloadListAndTotal(contentView.profitTableView)
    }
    
    func doubleHeaderSelectBtnClick(_ btn: UIButton) {
        btn.isSelected = !btn.isSelected
        for dic in doublePlanIssueList {
            dic.setObject(btn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
        }
        reloadListAndTotal(contentView.doubleTableView)
    }
    
    func createTracePlan() {
        switch contentView.segmentControl.selectedSegmentIndex {
        case 0:
            createSameRatePlan()
        default:
            break
        }
    }
    
    func createSameRatePlan() {
        GAProgressHUD.showLoading(message: "正在为您生成计划...")
        self.contentView.endEditing(true)
        if let traceIssueList = self.traceIssueList {
            for index in 0...traceIssueList.count-1 {
                let numberStr = traceIssueList[index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == currentAwardPriceString! && ((contentView.samePeriodField.text as! NSString).integerValue > self.traceIssueList!.count - index) {
                    GAProgressHUD.showWarning(message: "最大只能追\(traceIssueList.count - index)期!")
                }
            }
        } else {
            GAProgressHUD.showWarning(message: "当前无可追期!")
            reloadListAndTotal(contentView.sameTableView)
            return
        }

        samePlanIssueList.removeAll()
        if contentView.samePeriodField.text == "0" {
        
        } else {
            let traceDict = NSMutableDictionary()
            let idx: Int = (contentView.samePeriodField.text! as NSString).integerValue
            var flagIndex = idx
            for index in 0...traceIssueList!.count-1 {
                let numberStr = self.traceIssueList![index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == currentAwardPriceString {
                    flagIndex = index
                    break
                }
            }
            
            var end = (idx+flagIndex)-1
            if (end >= (self.traceIssueList?.count)!) {
                end = (self.traceIssueList?.count)! - 1
                contentView.samePeriodField.text = "\(end)"
            }
            
            for index in flagIndex...end {
                let dic = NSMutableDictionary(dictionary: self.traceIssueList![index])
                dic.setObject(contentView.sameMutipleFiled.text!, forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
                dic.setObject(contentView.sameHeaderSelectBtn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
                dic.setObject(Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit * ((contentView.sameMutipleFiled.text as! NSString).doubleValue), forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount as NSCopying)
                samePlanIssueList.append(dic)
            }

        }
        
        reloadListAndTotal(contentView.sameTableView)
        GAProgressHUD.hidHUD()
    }
    
    func createProfitRatePlan() {
        self.contentView.endEditing(true)
        if bettingList.count > 1 {
            GAProgressHUD.showWarning(message: "多个玩法不支持利润率追号")
            
            return
        }
        
        GAProgressHUD.showLoading(message: "正在为您生成计划...")
        profitPlanIssueList.removeAll()
        
        if let traceIssueList = self.traceIssueList {
            for index in 0...traceIssueList.count-1 {
                let numberStr = traceIssueList[index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == currentAwardPriceString! && ((contentView.profitPeriodField.text as! NSString).integerValue > self.traceIssueList!.count - index) {
                    GAProgressHUD.showWarning(message: "最大只能追\(traceIssueList.count - index)期!")
                }
            }
        } else {
            GAProgressHUD.showWarning(message: "当前无可追期!")
            reloadListAndTotal(contentView.profitTableView)
            return
        }
        
        //计划中止flag（计划从一开始就完全无法实现）
        var overFlg = false
        //计划修改flag（生成计划里单期奖金大于最大奖金或者追期超过360期时则为真）
        var correctFlg = false
        
        if contentView.profitPeriodField.text == "0" {
            
        } else {
            var idx: Int = (contentView.profitPeriodField.text! as NSString).integerValue
            
            if idx > 360 {
                //最大只能追360期
                correctFlg = true
                idx = 360
            }
            var flagIndex = idx
            for index in 0...traceIssueList!.count-1 {
                let numberStr = self.traceIssueList![index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == currentAwardPriceString {
                    flagIndex = index
                    break
                }
            }
            
            var end = (idx+flagIndex)-1
            if (end >= (self.traceIssueList?.count)!) {
                end = (self.traceIssueList?.count)! - 1
                contentView.profitPeriodField.text = "\(end)"
            }
            
            var byNowAmount = 0.0
            
            //单倍最大盈利率(只发生在头期)
            var maxRate: Double = 0
            for index in flagIndex...end {
                
                let dic = NSMutableDictionary(dictionary: self.traceIssueList![index])
                
                var amount = Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit * ((contentView.profitStartMultiField.text as! NSString).doubleValue)
                
                let singleReward = NSString(string: LotteryRulesOfPlay.default.lotteryMethodDict?[MethodListAPIManager.DataKey.MethodDetailKey.kMaxPrize] as! String).doubleValue
                let startMulti = NSString(string: contentView.profitStartMultiField.text!).doubleValue
                var multi = startMulti
                
                var reward = singleReward * multi * self.moneyUnit

                var expectedReward = reward - byNowAmount - amount
                
                var rewardRate = expectedReward / (byNowAmount + amount)
                let minRate = NSString(string: contentView.profitMinRateField.text!).doubleValue
                if rewardRate < (minRate / 100) {
                    //该期预期盈利率没有达到最低收益率，需要进行调整倍数
                    if index == flagIndex {
                        //头期预计盈利率无法达到最低收益率，计划无法实现，结束
                        overFlg = true
                        break
                    } else {
                        //头期之外，进行调整倍数
                        
                        let minus = (100 * singleReward * moneyUnit - minRate * (Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit) - 100 * (Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit))
                        if minus <= 0 {
                            //本期无法实现最低盈利率
                            break
                        }
                        multi = ceil((minRate * byNowAmount + 100 * byNowAmount) / minus) //ceil((minRate * (byNowAmount + amount) / 100 + byNowAmount + amount) / singleReward)
                        reward = singleReward * multi * self.moneyUnit
                        amount = Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit * multi
                        let dic = traceIssueList![index]
                        let limitCostStr = traceIssueList![index].object(forKey: TraceIssueAPIManager.DataKey.kLimitAmount) as? String
                        if let limitCostStr1 = limitCostStr {
                            //如果设置最大奖金额，则要确保该期奖金不超过最大限额
                            let limit = NSString(string: limitCostStr1).doubleValue
                            if reward > limit {
                                //调整后本期奖金超过最大限额
                                correctFlg = true
                                break
                            }
                        }
                        
                        expectedReward = reward - byNowAmount - amount
                        rewardRate = expectedReward / (byNowAmount + amount)
                    }
                } else {
                    if index == flagIndex {
                        //取得最大盈利率
                        maxRate = rewardRate
                    }
                }
                //到本期为止总投入金额
                byNowAmount += amount
                dic.setObject(String(format: "%.0f", multi), forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
                dic.setObject(contentView.profitHeaderSelectBtn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
                dic.setObject(amount, forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount as NSCopying)
                dic.setObject(reward, forKey: LotteryAIPeriodBettingViewController.DataKey.kProfitSingleReward as NSCopying)
                dic.setObject(byNowAmount, forKey: LotteryAIPeriodBettingViewController.DataKey.kProfitByNowCost as NSCopying)
                dic.setObject(expectedReward, forKey: LotteryAIPeriodBettingViewController.DataKey.kProfitExpectedReward as NSCopying)
                dic.setObject(rewardRate, forKey: LotteryAIPeriodBettingViewController.DataKey.kProfitExpectedRate as NSCopying)
                profitPlanIssueList.append(dic)
            }
            
        }
        
        reloadListAndTotal(contentView.profitTableView)
        GAProgressHUD.hidHUD()
        if overFlg {
            GAProgressHUD.showWarning(message: "该计划超出无法实现，请调整目标")
        } else if correctFlg {
            GAProgressHUD.showWarning(message: "盈利率达不到，已为您推荐可实现的计划")
        } else {
        }
        
    }

    func createDoubleTracePlan() {
        self.contentView.endEditing(true)
        GAProgressHUD.showLoading(message: "正在为您生成计划...")
        doublePlanIssueList.removeAll()
        if let traceIssueList = self.traceIssueList {
            for index in 0...traceIssueList.count-1 {
                let numberStr = traceIssueList[index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == currentAwardPriceString! && ((contentView.samePeriodField.text as! NSString).integerValue > self.traceIssueList!.count - index) {
                    GAProgressHUD.showWarning(message: "最大只能追\(traceIssueList.count - index)期!")
                }
            }
        } else {
            GAProgressHUD.showWarning(message: "当前无可追期!")
            reloadListAndTotal(contentView.doubleTableView)
            return
        }
        
        
        if contentView.doublePeriodField.text == "0" {
            
        } else {
            let traceDict = NSMutableDictionary()
            let idx: Int = (contentView.doublePeriodField.text! as NSString).integerValue
            var flagIndex = idx
            for index in 0...traceIssueList!.count-1 {
                let numberStr = self.traceIssueList![index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == currentAwardPriceString {
                    flagIndex = index
                    break
                }
            }
            
            var end = (idx+flagIndex)-1
            if (end >= (self.traceIssueList?.count)!) {
                end = (self.traceIssueList?.count)! - 1
                contentView.doublePeriodField.text = "\(end)"
            }
            
            let interval = Double(contentView.doubleIntervalPeriodField.text!)!
            let doubleMulti = Double(contentView.doubleMutipleFiled.text!)!
            var currentMulti = Double(contentView.doubleStartMutipleFiled.text!)!
            var count: Double = 0
            for index in flagIndex...end {
                
                let dic = NSMutableDictionary(dictionary: self.traceIssueList![index])
                
                dic.setObject(String(format: "%.0f", currentMulti) , forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
                dic.setObject(contentView.doubleHeaderSelectBtn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
                dic.setObject(Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit * Double(currentMulti), forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount as NSCopying)
                doublePlanIssueList.append(dic)
                count += 1
                if count >= interval {
                    count = 0
                    currentMulti *= doubleMulti
                }
            }
            
        }
        
        reloadListAndTotal(contentView.doubleTableView)
        GAProgressHUD.hidHUD()
    }
    
    func sameSelectBtnClick(_ btn: UIButton) {
        btn.isSelected = !btn.isSelected
        let idx = btn.tag - SameRateTraceTableViewCell.sameSelectBtnStartTag
        self.samePlanIssueList[idx].setObject(btn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
        reloadTotal()
    }
    
    func profitSelectBtnClick(_ btn: UIButton) {
        btn.isSelected = !btn.isSelected
        let idx = btn.tag - ProfitTraceTableViewCell.profitSelectBtnStartTag
        self.profitPlanIssueList[idx].setObject(btn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
        reloadTotal()
    }
    
    func doubleSelectBtnClick(_ btn: UIButton) {
        btn.isSelected = !btn.isSelected
        let idx = btn.tag - SameRateTraceTableViewCell.doubleSelectBtnStartTag
        self.doublePlanIssueList[idx].setObject(btn.isSelected, forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying)
        reloadTotal()
    }
    
    func reloadTotal() {
        switch contentView.segmentControl.selectedSegmentIndex {
        case 0:
            var totalCount = 0
            var totalAmount = 0.0
            
            for idx in samePlanIssueList {
                if (idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool) {
                    totalCount += totalCountPerPeriod
                    totalAmount += idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount) as! Double
                }
            }
            contentView.bettingCount.text = "\(totalCount)"
            contentView.amountLabel.text = String(format: "%.3f", totalAmount)
            contentView.samePeriodField.text = "\(samePlanIssueList.count)"
        case 1:
            var totalCount = 0
            var totalAmount = 0.0
            
            for idx in profitPlanIssueList {
                if (idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool) {
                    totalCount += totalCountPerPeriod
                    totalAmount += idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount) as! Double
                }
            }
            contentView.bettingCount.text = "\(totalCount)"
            contentView.amountLabel.text = String(format: "%.3f", totalAmount)
            contentView.profitPeriodField.text = "\(profitPlanIssueList.count)"
        case 2:
            var totalCount = 0
            var totalAmount = 0.0
            
            for idx in doublePlanIssueList {
                if (idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool) {
                    totalCount += totalCountPerPeriod
                    totalAmount += idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount) as! Double
                }
            }
            contentView.bettingCount.text = "\(totalCount)"
            contentView.amountLabel.text = String(format: "%.3f", totalAmount)
            contentView.doublePeriodField.text = "\(doublePlanIssueList.count)"
        default:
            break
        }
    }

    func reloadListAndTotal(_ tableView: UITableView) {
        tableView.reloadData()
        
        reloadTotal()
        
    }
    
    func bettingBtnClick() {
        guard let amount = self.contentView.amountLabel.text as NSString? else { return }
        guard let balance = self.contentView.balanceLabel.text as NSString? else { return }
        let count = Int(self.contentView.bettingCount.text!)
        if count == 0 {
            GAProgressHUD.showWarning(message: "追号的期数不能为空")
            return;
        }
        
        if amount.doubleValue <= balance.doubleValue {
            
            let ctrl = LotteryAIPeriodBettingConfirmViewController()
            ctrl.modalPresentationStyle = .custom
            ctrl.transitioningDelegate = self
//            ctrl.preferredContentSize = CGSize(width: 200, height: 300)
            ctrl.submitClosure = {
                self.bettingAPIManager.loadData()
            }
            var arr: [NSMutableDictionary]
            var traceWinStopBtn: UIButton
            var multiTF: UITextField
            switch contentView.segmentControl.selectedSegmentIndex {
            case 0:
                arr = samePlanIssueList
                traceWinStopBtn = contentView.sameTraceWinStopBtn
                multiTF = contentView.sameMutipleFiled;
            case 1:
                arr = profitPlanIssueList
                traceWinStopBtn = contentView.profitTraceWinStopBtn
                multiTF = contentView.profitStartMultiField
            case 2:
                arr = doublePlanIssueList
                traceWinStopBtn = contentView.doubleTraceWinStopBtn
                multiTF = contentView.doubleStartMutipleFiled
            default:
                arr = []
                traceWinStopBtn = UIButton()
                multiTF = UITextField()
            }
            if arr.count == 0 {
                return
            }
          
            let dic = arr[0]
            var period = 0
            for idx in arr {
                if idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool {
                    period += 1
                }
            }
            let isTraceStr = period > 1
            ctrl.dataDic =
                [LotteryAIPeriodBettingViewController.DataKey.kNum : totalCountPerPeriod,
                 LotteryAIPeriodBettingViewController.DataKey.kIsTrace : true,
                 LotteryAIPeriodBettingViewController.DataKey.kAmount: contentView.amountLabel.text!,
                 LotteryAIPeriodBettingViewController.DataKey.kMoneyunit: moneyUnit,
                 LotteryAIPeriodBettingViewController.DataKey.kLotteryNumber: dic[LotteryAIPeriodBettingViewController.DataKey.kLotteryNumber],
                 LotteryAIPeriodBettingViewController.DataKey.kTotalPeriod: arr.count,
                 LotteryAIPeriodBettingViewController.DataKey.kMultiple: multiTF.text!]
            present(ctrl, animated: false, completion: nil)
//            ctrl.view.superview?.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
//            let amountTips = "总金额：¥" + self.contentView.amountLabel.text!
//            guard (self.currentAwardPriceString != nil) else { return }
//            let awardPriceTips = "投注期号：" + self.currentAwardPriceString!
//            var period = ""
//            switch contentView.segmentControl.selectedSegmentIndex {
//            case 0:
//                period = self.contentView.samePeriodField.text!
//            case 2:
//                period = self.contentView.doublePeriodField.text!
//            default:
//                break
//            }
//            let zhuihaoTips = "追号：" + period + "期" + self.contentView.bettingCount.text! + "注"
//            let mutipleTips = self.contentView.sameMutipleFiled.text! + "倍"
//            let allInfo = amountTips + "\n" + awardPriceTips + "\n" + zhuihaoTips + mutipleTips
//
//            GAAlertController.showAlert("投注确认", allInfo, "取消", "确定", cancelCallBack: nil, commitCallBack: {
//                self.bettingAPIManager.loadData()
//            })
            
        } else {
            GAProgressHUD.showWarning(message: "您的余额不足！")
        }
    }
    
    func segmentControlSwitch(_ segmentControl: UISegmentedControl) {
        let index = segmentControl.selectedSegmentIndex
        contentView.sameRateContentView.isHidden = index != 0
        contentView.profitContentView.isHidden = index != 1
        contentView.doubleRateContentView.isHidden = index != 2
        switch index {
//        case 1:
//            if profitRefreshFlg {
//                createProfitRatePlan()
//            }
        case 1:
            if !profitRefreshFlg {
                createProfitRatePlan()
                profitRefreshFlg = true
            }
        case 2:
            if !doubleRefreshFlg {
                createDoubleTracePlan()
                doubleRefreshFlg = true
            }
        default:
            break
        }
        reloadTotal()
    }
    
    // MARK: - private method
    /// 计算追期
    ///
    /// - Returns: <#return value description#>
    fileprivate func cacluateTraceIssue(traceIssueList: [NSMutableDictionary]) -> [String : String?] {
        let traceCount = traceIssueList.count
        if traceCount > 1 {
            
            let traceDict = NSMutableDictionary()
            var flagIndex = traceCount
            for index in 0...traceIssueList.count-1 {
                let numberStr = traceIssueList[index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == self.currentAwardPriceString! {
                    flagIndex = index
                    break
                }
            }
            for index in flagIndex...(traceCount+flagIndex)-1 {
                let dic = traceIssueList[index]
                if dic.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool == false {
                    continue
                }
                
                let numberStr = dic.object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                // 每期单独设置倍数
                traceDict[numberStr] = dic.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying) as! String
            }
            return traceDict as! [String : String?]
        }
        
        return [self.currentAwardPriceString!: "1"]
    }
}

extension LotteryAIPeriodBettingViewController: UIViewControllerTransitioningDelegate {
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        let ctrl = CustomPresentationController.init(presentedViewController: presented, presenting: presenting)
        return ctrl
    }
}


// MARK: - LYAPIManagerParamSource
extension LotteryAIPeriodBettingViewController: LYAPIManagerParamSource {
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        switch manager {
        case traceIssueAPIManager:
            GAProgressHUD.showLoading(message: "更新奖期数据...")
            let bettingDic = bettingList.first as! NSDictionary
            let lotteryId = bettingDic[LotteryAIPeriodBettingViewController.DataKey.kGameId] as! Int
            return ["lottery_id": lotteryId]
        case zhuiHaoDetailAPIManager:
            GAProgressHUD.showLoading(message: "正在加载...")
            
            let params = ["id" : self.lotteryId]
            return params as NSDictionary
        case bettingAPIManager:
            var arr: [NSMutableDictionary]
            var traceWinStopBtn: UIButton
            switch contentView.segmentControl.selectedSegmentIndex {
            case 0:
                arr = samePlanIssueList
                traceWinStopBtn = contentView.sameTraceWinStopBtn
            case 1:
                arr = profitPlanIssueList
                traceWinStopBtn = contentView.profitTraceWinStopBtn
            case 2:
                arr = doublePlanIssueList
                traceWinStopBtn = contentView.doubleTraceWinStopBtn
            default:
                arr = []
                traceWinStopBtn = UIButton()
            }
            if arr.count == 0 {
                return nil
            }
            
            GAProgressHUD.showLoading(message: "投注中...")
            if let bettingCtrl = self.bettingCtrl {
                bettingCtrl.updatePriceGroup()
            }
            
            let ballArray = NSMutableArray()
            for index in 0...self.bettingList.count-1 {
                let bettingInfoDict = self.bettingList[index]
                guard let ballStr = bettingInfoDict[LotteryBettingViewController.DataKey.kBall] as? String else { return nil }
                
                guard let methodType = bettingInfoDict[LotteryBettingViewController.DataKey.kWayId] as? UInt else { return nil}
                
                let type = eLotteryMethodType(rawValue: methodType)
                let ball = LotteryRulesOfPlay.default.convertBetingString(ballStr: ballStr, type: type!)
                let bettingDict = [LotteryBettingViewController.DataKey.kBall: ball,
                                   LotteryBettingViewController.DataKey.kExtra: [],
                                   LotteryBettingViewController.DataKey.kJsId: index+1,
                                   LotteryBettingViewController.DataKey.kMoneyunit: self.moneyUnit,
                                   //智能追号，每期可以单独设置倍数，所以这里设成1倍，每期单独的倍数在order里分别设置
                                    LotteryBettingViewController.DataKey.kMultiple: "1",
                                   LotteryBettingViewController.DataKey.kNum: bettingInfoDict[LotteryBettingViewController.DataKey.kNum] as Any,
                                   LotteryBettingViewController.DataKey.kPrizeGroup: bettingCtrl?.getContentView().priceLabel.text as Any,
                                   LotteryBettingViewController.DataKey.kWayId: bettingInfoDict[LotteryBettingViewController.DataKey.kWayId] as Any] as [String : Any]
                ballArray.add(bettingDict)
            }
            let amountStr = self.contentView.amountLabel.text
            var period = 0
            for idx in arr {
                if idx.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool {
                    period += 1
                }
            }
            let isTraceStr = period > 1 //(self.contentView.periodField.text! as NSString).integerValue > 1
            let ordersDict = self.cacluateTraceIssue(traceIssueList: arr)
            
            let traceWinStopStr = String(format: "%d", traceWinStopBtn.isSelected)
            let bettingInfoDict = [LotteryBettingViewController.DataKey.kAmount: amountStr as Any,
                                   LotteryBettingViewController.DataKey.kBalls: ballArray,
                                   LotteryBettingViewController.DataKey.kGameId: self.bettingList.first![LotteryBettingViewController.DataKey.kGameId] as Any,
                                   LotteryBettingViewController.DataKey.kIsTrace: isTraceStr as Any,
                                   LotteryBettingViewController.DataKey.kOrders: ordersDict,
                                   LotteryBettingViewController.DataKey.kTraceWinStop: traceWinStopStr] as [String: Any]
            
            
            let jsonData = try! JSONSerialization.data(withJSONObject: bettingInfoDict, options: JSONSerialization.WritingOptions.prettyPrinted)
            let dataString = String(data: jsonData, encoding: String.Encoding.utf8)!
            
            return ["betdata": dataString]
        default:
            return nil
        }
        
    }
}

// MARK: - LYAPIManagerCallBackDelegate
extension LotteryAIPeriodBettingViewController: LYAPIManagerCallBackDelegate {
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        GAProgressHUD.hidHUD()
        switch manager {
        case zhuiHaoDetailAPIManager:
            let dic = manager.fetchData(self.zhuiHaoDetailAPIManager) as? NSDictionary
            self.bettingList.removeAll()
            let vc = ZhuiHaoDetailViewController()
            vc.detailDict = dic?.object(forKey: "basic") as? NSDictionary
            self.navigationController?.pushViewController(vc, animated: true)
            self.navigationController?.viewControllers = (self.navigationController?.viewControllers.filter({ (ctrl) -> Bool in
                return !(ctrl is LotteryBettingViewController || ctrl is LotteryAIPeriodBettingViewController)
            }))!
        case traceIssueAPIManager:
            if self.traceIssueList?.count == 0 {
                //当前无可追期
                
            }
            
            self.traceIssueList = manager.fetchData(self.traceIssueAPIManager) as? [NSDictionary]
            createSameRatePlan()
        case bettingAPIManager:
            guard let bettingIdDict = manager.fetchData(self.bettingAPIManager) as? NSDictionary else { return }
            let bettingResultStr = "投注单号：" + String(format: "%ld", (bettingIdDict["id"] as! Int))
            self.lotteryId = bettingIdDict["id"] as! Int
            
            GAAlertController.showAlert("投注成功", bettingResultStr, "查看注单", "继续投注", cancelCallBack: {
                self.zhuiHaoDetailAPIManager.loadData()
            }, commitCallBack: {
                self.bettingList.removeAll()
                self.navigationController?.popViewController(animated: true)
            })
            
        default:
            break
        }
        
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        GAProgressHUD.hidHUD()
        
        let errorDict = manager.fetchFailedRequestMsg(nil) as? NSDictionary
        if errorDict != nil {
            let errorStr = errorDict!["error"] as! String
            GAProgressHUD.showError(message: errorStr)
            return
        }
        
        
    }
}

extension LotteryAIPeriodBettingViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch tableView {
        case contentView.sameTableView:
            return samePlanIssueList.count
        case contentView.profitTableView:
            return profitPlanIssueList.count
        case contentView.doubleTableView:
            return doublePlanIssueList.count
        default:
            return 0
        }

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch tableView {
        case contentView.sameTableView:
            let cell = tableView.dequeueReusableCell(withIdentifier: SameRateTraceTableViewCell.cellIdentifier, for: indexPath) as! SameRateTraceTableViewCell
            cell.moneyUnit = moneyUnit
            cell.price = price
            cell.totalCount = totalCountPerPeriod
            cell.dic = samePlanIssueList[indexPath.row]
            cell.mutipleFiled.delegate = self
            cell.selectButton.tag = SameRateTraceTableViewCell.sameSelectBtnStartTag + indexPath.row
            cell.mutipleFiled.tag = SameRateTraceTableViewCell.sameMultiFieldStartTag + indexPath.row
            cell.selectButton.addTarget(self, action: #selector(sameSelectBtnClick(_:)), for: .touchUpInside)
            return cell
        case contentView.profitTableView:
            let cell = tableView.dequeueReusableCell(withIdentifier: ProfitTraceTableViewCell.cellIdentifier, for: indexPath) as! ProfitTraceTableViewCell
            cell.moneyUnit = moneyUnit
            cell.price = price
            cell.totalCount = totalCountPerPeriod
            cell.dic = profitPlanIssueList[indexPath.row]
            cell.mutipleFiled.delegate = self
            cell.selectButton.tag = ProfitTraceTableViewCell.profitSelectBtnStartTag + indexPath.row
            cell.mutipleFiled.tag = ProfitTraceTableViewCell.profitMultiFieldStartTag + indexPath.row
            cell.selectButton.addTarget(self, action: #selector(profitSelectBtnClick(_:)), for: .touchUpInside)
            
            return cell
        case contentView.doubleTableView:
            let cell = tableView.dequeueReusableCell(withIdentifier: SameRateTraceTableViewCell.cellIdentifier, for: indexPath) as! SameRateTraceTableViewCell
            cell.moneyUnit = moneyUnit
            cell.price = price
            cell.totalCount = totalCountPerPeriod
            cell.dic = doublePlanIssueList[indexPath.row]
            cell.mutipleFiled.delegate = self
            cell.selectButton.tag = SameRateTraceTableViewCell.doubleSelectBtnStartTag + indexPath.row
            cell.mutipleFiled.tag = SameRateTraceTableViewCell.doubleMultiFieldStartTag + indexPath.row
            cell.selectButton.addTarget(self, action: #selector(doubleSelectBtnClick(_:)), for: .touchUpInside)
            return cell
        default:
            return UITableViewCell()
        }
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
}

extension LotteryAIPeriodBettingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch tableView {
        case contentView.sameTableView:
            return contentView.sameHeaderView
        case contentView.profitTableView:
            return contentView.profitHeaderView
        case contentView.doubleTableView:
            return contentView.doubleHeaderView
        default:
            return nil
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
}

extension LotteryAIPeriodBettingViewController: UIScrollViewDelegate {
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.contentView.endEditing(true)
    }
}

extension LotteryAIPeriodBettingViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        switch contentView.segmentControl.selectedSegmentIndex {
        case 0:
            let idx = textField.tag - SameRateTraceTableViewCell.sameMultiFieldStartTag
            if idx >= 0 {
                contentView.endEditing(true)
                let alert = UIAlertController(title: "更改数量", message: nil, preferredStyle: .alert)
                alert.addTextField { (tf) in
                    tf.text = self.samePlanIssueList[idx].object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying) as? String
                }
                let okAction = UIAlertAction(title: "更改", style: .`default`) { (_) in
                    var text = alert.textFields?.first?.text
                    if text?.lengthOfBytes(using: .utf8) == 0 {
                        text = "1"
                    } else {
                        if let intValue: Int = Int.init(text!) {
                            text = "\(intValue)"
                        } else {
                            text = "1"
                        }
                    }
                    self.samePlanIssueList[idx].setObject(text, forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
                    self.samePlanIssueList[idx].setObject(Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit * ((alert.textFields?.first?.text as! NSString).doubleValue), forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount as NSCopying)
                    self.reloadListAndTotal(self.contentView.sameTableView)
                }
                alert.addAction(okAction)
                let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                alert.addAction(cancelAction)
                present(alert, animated: true, completion: nil)
                
                return false
            }
        case 1:
            let idx = textField.tag - ProfitTraceTableViewCell.profitMultiFieldStartTag
            if idx >= 0 {
                contentView.endEditing(true)
                let alert = UIAlertController(title: "更改数量", message: nil, preferredStyle: .alert)
                alert.addTextField { (tf) in
                    tf.text = self.profitPlanIssueList[idx].object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying) as? String
                }
                let okAction = UIAlertAction(title: "更改", style: .`default`) { (_) in
                    var text = alert.textFields?.first?.text
                    if text?.lengthOfBytes(using: .utf8) == 0 {
                        text = "1"
                    }
                    if text?.lengthOfBytes(using: .utf8) == 0 {
                        text = "1"
                    } else {
                        if let intValue: Int = Int.init(text!) {
                            text = "\(intValue)"
                        } else {
                            text = "1"
                        }
                    }
                    self.profitPlanIssueList[idx].setObject(text, forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
                    self.profitPlanIssueList[idx].setObject(Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit * ((alert.textFields?.first?.text as! NSString).doubleValue), forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount as NSCopying)
                    self.reloadListAndTotal(self.contentView.profitTableView)
                }
                alert.addAction(okAction)
                let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                alert.addAction(cancelAction)
                present(alert, animated: true, completion: nil)
                
                return false
            }
        case 2:
            let idx = textField.tag - SameRateTraceTableViewCell.doubleMultiFieldStartTag
            if idx >= 0 {
                contentView.endEditing(true)
                let alert = UIAlertController(title: "更改数量", message: nil, preferredStyle: .alert)
                alert.addTextField { (tf) in
                    tf.text = self.doublePlanIssueList[idx].object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying) as? String
                }
                let okAction = UIAlertAction(title: "更改", style: .`default`) { (_) in
                    var text = alert.textFields?.first?.text
                    if text?.lengthOfBytes(using: .utf8) == 0 {
                        text = "1"
                    }
                    if text?.lengthOfBytes(using: .utf8) == 0 {
                        text = "1"
                    } else {
                        if let intValue: Int = Int.init(text!) {
                            text = "\(intValue)"
                        } else {
                            text = "1"
                        }
                    }
                    self.doublePlanIssueList[idx].setObject(text, forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
                    self.doublePlanIssueList[idx].setObject(Double(self.totalCountPerPeriod) * Double(self.price) * self.moneyUnit * ((alert.textFields?.first?.text as! NSString).doubleValue), forKey: LotteryAIPeriodBettingViewController.DataKey.kSingleAmount as NSCopying)
                    self.reloadListAndTotal(self.contentView.doubleTableView)
                }
                alert.addAction(okAction)
                let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
                alert.addAction(cancelAction)
                present(alert, animated: true, completion: nil)
                
                return false
            }
        default:
            break
        }
        textField.text = nil
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        let textStr = textField.text as NSString?
        
        switch textField {
        case contentView.sameMutipleFiled, contentView.profitMinRateField, contentView.profitStartMultiField:
            if (textStr?.integerValue)! <= 0 {
                textField.text = "1"
            } else {
                textField.text = "\(textStr!.integerValue)"
            }
        case contentView.samePeriodField, contentView.profitPeriodField, contentView.doublePeriodField, contentView.doubleStartMutipleFiled:
            if textField.text == nil || (textField.text != nil && textField.text!.isEmpty) || (textField.text as NSString?)?.integerValue == 0 {
                textField.text = "1"
            } else {
                textField.text = "\(textStr!.integerValue)"
            }
            if traceIssueList != nil {
                for index in 0...self.traceIssueList!.count-1 {
                    let numberStr = self.traceIssueList![index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                    if numberStr == self.currentAwardPriceString! && (textStr!.integerValue > self.traceIssueList!.count - index) {
                        GAProgressHUD.showWarning(message: "最大只能追\(self.traceIssueList!.count - index)期!")
                        textField.text = "\(self.traceIssueList!.count - index)"
                        break
                    }
                }
            }
        case contentView.doubleMutipleFiled, contentView.doubleIntervalPeriodField:
            if (textStr?.integerValue)! <= 0 {
                textField.text = "2"
            } else {
                textField.text = "\(textStr!.integerValue)"
            }
        default:
            break
        }
//
//
//
//        self.updateTotalBettingInfo()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
//        if (textField === self.contentView.samePeriodField || textField === self.contentView.profitPeriodField || textField === contentView.doublePeriodField || textField === contentView.doubleIntervalPeriodField) && textField.text != nil && textField.text!.count >= 4 && string.count > 0 {
//            return false
//        }
        switch textField {
        case contentView.samePeriodField, contentView.profitPeriodField, contentView.doublePeriodField, contentView.doubleIntervalPeriodField:
            return string.count <= 0 || textField.text!.count < 4
        default:
            return true
        }
        return true
    }
}
