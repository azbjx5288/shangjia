//
//  LotteryBettingViewController.swift
//  GoldenApple
//
//  Created by User on 06/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryBettingViewController: UIViewController {
    
    static let kRebateFlag = 20.0
    
    struct DataKey {
        
        /// 玩法名
        static let kTitleName = "titileName"
        /// 彩票单价
        static let kPrice = "price"
        
        /// 投注码
        static let kBall = "ball"
        /// 注单的顺序ID
        static let kJsId = "jsId"
        /// 玩法ID
        static let kWayId = "wayId"
        /// 彩票ID
        static let kGameId = "gameId"
        /// 总金额
        static let kAmount = "amount"
        /// 投注详细信息
        static let kBalls = "balls"
        /// 附加信息，用于任选玩法，非任选时请设为空数组
        static let kExtra = "extra"
        /// 用于任选玩法，01234 对应 万千百十个
        static let position = "position"
        /// 用于任选玩法， 任X   seat = x  （例如：任二 --> seat = 2, 任三 --> seat = 3）
        static let seat = "seat"
        /// 价格系数
        static let kMoneyunit = "moneyunit"
        /// 单倍注数
        static let kNum = "num"
        /// 奖金组
        static let kPrizeGroup = "prizeGroup"
        /// 是否追号,1或0
        static let kIsTrace = "isTrace"
        /// 奖期及倍数列表，键为奖期，值为倍数
        static let kOrders = "orders"
        /// 是否追中即停，在isTrace为0时，无效
        static let kTraceWinStop = "traceWinStop"
        /// 倍数
        static let kMultiple = "multiple"
        /// 彩种
        static let kName = "name"
    }
    
    static let cellIdentifier = "LotteryBettingTableCell"
    
    fileprivate var prizeGroupsList: [NSString]?
    
    fileprivate var userInfoDict: NSDictionary?
    
    fileprivate var traceIssueList: [NSDictionary]?
    
    var currentAwardPriceString: String? {
        didSet {
            self.contentView.awardPeriodLabel.text = currentAwardPriceString
            if let aiPCtrl = aiPeriodCtrl {
                aiPCtrl.currentAwardPriceString = currentAwardPriceString
            }
        }
    }
    
    var coutdownString: String? {
        didSet {
            self.contentView.coutdownLabel.text = coutdownString
            if let aiPCtrl = aiPeriodCtrl {
                aiPCtrl.coutdownString = coutdownString
            }
        }
    }
    
    weak var aiPeriodCtrl: LotteryAIPeriodBettingViewController?
    
    var bettingDict: NSDictionary = [:]
    
    fileprivate(set) var bettingList = [NSDictionary]()
    
    fileprivate var moneyUnit = 1.0
    
    fileprivate let contentView: LotteryBettingView = {
        return LotteryBettingView()
    }()
    
    fileprivate let bettingAPIManager = BettingAPIManager()
    fileprivate let prizeGroupAPIManager = PrizeGroupsAPIManager()
    fileprivate let acountCenterAPIManager = AccountCenterAPIManager()
    fileprivate let traceIssueAPIManager = TraceIssueAPIManager()
    fileprivate let bettingDetailApiManager = BettingDetailAPIManager()
    var bettingId = -1
    
    override func loadView() {
        super.loadView()
        
        self.view = self.contentView
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = kGAViewGrayBackgoundColor
//        self.navigationItem.setRightBarButton(UIBarButtonItem(image: UIImage(named: "point-icon"), style: .plain, target: self, action: #selector(rightBarBtnClick)), animated: true)
        
        self.contentView.tableView.register(LotteryBettingTableCell.classForCoder(), forCellReuseIdentifier: LotteryBettingViewController.cellIdentifier)
        self.contentView.tableView.dataSource = self
        self.contentView.mutipleFiled.delegate = self
//        self.contentView.periodField.delegate = self
        self.contentView.switchMoneyUnit(self.contentView.twoYuanBtn)
        self.contentView.moneyUnitClosures = { (moneyUnit) in
            self.moneyUnit = moneyUnit
            switch moneyUnit {
            case 1.0:
                self.contentView.chasingButton.setTitle("2元", for: .normal)
            case 0.5:
                self.contentView.chasingButton.setTitle("1元", for: .normal)
            case 0.1:
                self.contentView.chasingButton.setTitle("2角", for: .normal)
            case 0.05:
                self.contentView.chasingButton.setTitle("1角", for: .normal)
            case 0.01:
                self.contentView.chasingButton.setTitle("2分", for: .normal)
            case 0.001:
                self.contentView.chasingButton.setTitle("2厘", for: .normal)
            default:
                self.contentView.chasingButton.setTitle("2元", for: .normal)
            }
            self.updateTotalBettingInfo()
        }
        
        self.contentView.priceGroupSlider.addTarget(self, action: #selector(priceGroupSliderChange), for: .valueChanged)
        self.contentView.confirmBettingBtn.addTarget(self, action: #selector(confirmBettingBtnClick), for: .touchUpInside)
        self.contentView.onceAgainBtn.addTarget(self, action: #selector(onceAgainBtnClick), for: UIControlEvents.touchUpInside)
        self.contentView.aiPeriodBtn.addTarget(self, action: #selector(aiPeriodBtnClick), for: .touchUpInside)
        self.contentView.chasingButton.addTarget(self, action: #selector(rightBarBtnClick), for: UIControlEvents.touchUpInside)
        
        self.prizeGroupAPIManager.paramSource = self
        self.prizeGroupAPIManager.delegate = self
        self.bettingAPIManager.paramSource = self
        self.bettingAPIManager.delegate = self
        self.acountCenterAPIManager.paramSource = self
        self.acountCenterAPIManager.delegate = self
        self.traceIssueAPIManager.paramSource = self
        self.traceIssueAPIManager.delegate = self
        self.bettingDetailApiManager.paramSource = self
        self.bettingDetailApiManager.delegate = self

        self.prizeGroupAPIManager.loadData()
        self.contentView.priceGroupSlider.setValue(self.contentView.priceGroupSlider.maximumValue, animated: false)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.acountCenterAPIManager.loadData()
        
        self.traceIssueAPIManager.loadData()
        
        self.contentView.tableView.reloadData()
        
        
    }

    
    // MARK: - Resopnse event methods
    
    func rightBarBtnClick() {
        self.contentView.modeView.isHidden = !self.contentView.modeView.isHidden
        
        self.priceGroupSliderChange()
    }

    func setBettingDict(bettingDict: NSDictionary) {
        
        self.bettingDict = bettingDict
        self.bettingList.append(bettingDict)
        
        self.updateTotalBettingInfo()
    }
    
    func priceGroupSliderChange() {
        
        let slider = self.contentView.priceGroupSlider
        let currentValue = Int(slider.value)
        if (self.prizeGroupsList != nil && self.prizeGroupsList!.count < currentValue) || self.userInfoDict == nil {
            return
        }
        
        let prizeGroups = self.prizeGroupsList![currentValue].integerValue
        
        let userPrizeGroup = self.userInfoDict![AccountCenterAPIManager.DataKey.kPrize_group] as! NSString

        let rebate = (userPrizeGroup.doubleValue - Double(prizeGroups)) / LotteryBettingViewController.kRebateFlag
        
        self.contentView.rebateLabel.text = String(format: "%.2lf%%", rebate)
        self.contentView.priceLabel.text = String(format: "%ld", prizeGroups)
    }
    
    func confirmBettingBtnClick() {
        
        if self.bettingList.count == 0 {
            GAAlertController.showAlert("提示", "至少选择一注", nil, "返回", cancelCallBack: nil, commitCallBack: {
                self.onceAgainBtnClick()
            })
            return
        }
        
        guard let amount = self.contentView.amountLabel.text as NSString? else { return }
        guard let balance = self.contentView.balanceLabel.text as NSString? else { return }
        
        if amount.doubleValue <= balance.doubleValue {
            
            let amountTips = "总金额：¥" + self.contentView.amountLabel.text!
            guard (self.currentAwardPriceString != nil) else { return }
            let awardPriceTips = "投注期号：" + self.currentAwardPriceString!
            let zhuihaoTips = self.contentView.bettingCount.text! + "注"
            let mutipleTips = self.contentView.mutipleFiled.text! + "倍"
            let allInfo = amountTips + "\n" + awardPriceTips + "\n" + zhuihaoTips + mutipleTips
            let zhuihaoTips1 = """
            请确认以下投注内容:
            *************************
            投注期号：\(self.currentAwardPriceString!)
            单倍注数：\(self.contentView.bettingCount.text!)注
            模式：\(self.contentView.chasingButton.titleLabel!.text!)
            倍数：\(self.contentView.mutipleFiled.text!)倍
            总金额：¥\(self.contentView.amountLabel.text!)
            *************************
            """
            let vc = MessageDialogViewController("提示", zhuihaoTips1)
            let dialog = CustomerDialogBuilder(customerVc: vc)
            .hasPositiveTap(true, "确认投注", positive: {
                 self.bettingAPIManager.loadData()
            })
            .hasNagativeTap(false, "", nagative: {})
            .build()
            present(dialog, animated: true, completion: nil)
//            GAAlertController.showAlert("投注确认", zhuihaoTips1, "取消", "确定", cancelCallBack: nil, commitCallBack: {
//                self.bettingAPIManager.loadData()
//            })
            
        } else {
            GAProgressHUD.showWarning(message: "您的余额不足！")
        }
    }
    
    
    
    func onceAgainBtnClick() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func aiPeriodBtnClick() {
        if self.bettingList.count == 0 {
            GAAlertController.showAlert("提示", "至少选择一注", nil, "返回", cancelCallBack: nil, commitCallBack: {
                self.onceAgainBtnClick()
            })
            return
        }
        let aiPeriodCtrl = LotteryAIPeriodBettingViewController(bettingList: bettingList)
        self.aiPeriodCtrl = aiPeriodCtrl
        aiPeriodCtrl.currentAwardPriceString = currentAwardPriceString
        aiPeriodCtrl.coutdownString = coutdownString
        aiPeriodCtrl.moneyUnit = moneyUnit
        aiPeriodCtrl.bettingCtrl = self
        aiPeriodCtrl.balance = self.userInfoDict![AccountCenterAPIManager.DataKey.kAbalance] as? String
        self.navigationController?.pushViewController(aiPeriodCtrl, animated: true)
    }
    
    func getContentView() -> LotteryBettingView {
        return contentView
    }
}

// MARK: - LYAPIManagerParamSource

extension LotteryBettingViewController: LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        if manager == self.bettingAPIManager {
            
            if self.bettingList.count == 0 {
                return nil
            }
            
            GAProgressHUD.showLoading(message: "投注中...")
            self.updatePriceGroup()
            
            let ballArray = NSMutableArray()
            for index in 0...self.bettingList.count-1 {
                let bettingInfoDict = self.bettingList[index]
                guard let ballStr = bettingInfoDict[LotteryBettingViewController.DataKey.kBall] as? String else { return nil }
                
                guard let methodType = bettingInfoDict[LotteryBettingViewController.DataKey.kWayId] as? UInt else { return nil}
                
                let type = eLotteryMethodType(rawValue: methodType)
                let ball = LotteryRulesOfPlay.default.convertBetingString(ballStr: ballStr, type: type!)
                let bettingDict = [LotteryBettingViewController.DataKey.kBall: ball,
                                   LotteryBettingViewController.DataKey.kExtra: bettingInfoDict[LotteryBettingViewController.DataKey.kExtra] ?? [:],
                                   LotteryBettingViewController.DataKey.position: bettingInfoDict[LotteryBettingViewController.DataKey.position] as Any,
                                   LotteryBettingViewController.DataKey.seat: bettingInfoDict[LotteryBettingViewController.DataKey.seat] as Any,
                                   LotteryBettingViewController.DataKey.kJsId: index+1,
                                   LotteryBettingViewController.DataKey.kMoneyunit: self.moneyUnit,
                                   LotteryBettingViewController.DataKey.kMultiple: self.contentView.mutipleFiled.text as Any,
                                   LotteryBettingViewController.DataKey.kNum: bettingInfoDict[LotteryBettingViewController.DataKey.kNum] as Any,
                                   LotteryBettingViewController.DataKey.kPrizeGroup: self.contentView.priceLabel.text as Any,
                                   LotteryBettingViewController.DataKey.kWayId: bettingInfoDict[LotteryBettingViewController.DataKey.kWayId] as Any] as [String : Any]
                ballArray.add(bettingDict)
            }
            let amountStr = self.contentView.amountLabel.text
//            let isTraceStr = (self.contentView.periodField.text! as NSString).integerValue > 1
            let ordersDict = self.cacluateTraceIssue(traceCount: ("0" as NSString).integerValue)
            
            let traceWinStopStr = String(format: "%d", true)
            let bettingInfoDict = [LotteryBettingViewController.DataKey.kAmount: amountStr as Any,
                                   LotteryBettingViewController.DataKey.kBalls: ballArray,
                                   LotteryBettingViewController.DataKey.kGameId: self.bettingList.first![LotteryBettingViewController.DataKey.kGameId] as Any,
                                   LotteryBettingViewController.DataKey.kIsTrace: false as Any,
                                   LotteryBettingViewController.DataKey.kOrders: ordersDict,
            LotteryBettingViewController.DataKey.kTraceWinStop: traceWinStopStr] as [String: Any]
            
//            let arrayT = ["amount":6.0,"balls":[["ball":"||8|9|2","extra":[],"jsId":1,"moneyunit":1.0,"multiple":1,"num":3,"prizeGroup":1718,"wayId":78]],"gameId":1,"isTrace":0,"orders":["171121059":1],"traceWinStop":1] as [String : Any]
            
            let jsonData = try! JSONSerialization.data(withJSONObject: bettingInfoDict, options: JSONSerialization.WritingOptions.prettyPrinted)
            let dataString = String(data: jsonData, encoding: String.Encoding.utf8)!
            
            return ["betdata": dataString]
        } else if manager == self.prizeGroupAPIManager {
            
            guard let bettingDict = self.bettingList.first else { return nil }
            GAProgressHUD.showLoading(message: "更新数据...")
            let lotteryId = bettingDict[LotteryBettingViewController.DataKey.kGameId] as! Int
            return ["lottery_id": lotteryId]
        } else if manager == self.traceIssueAPIManager {
            
            guard let bettingDict = self.bettingList.first else { return nil }
            GAProgressHUD.showLoading(message: "更新奖期数据...")
            let lotteryId = bettingDict[LotteryBettingViewController.DataKey.kGameId] as! Int
            return ["lottery_id": lotteryId]
        }else if manager == bettingDetailApiManager {
            return ["id": self.bettingId]
        }
   
        return nil
    }
    
}

extension LotteryBettingViewController: UIAlertViewDelegate {
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        
    }
}
// MARK: - LYAPIManagerCallBackDelegate

extension LotteryBettingViewController: LYAPIManagerCallBackDelegate {
    
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        
        if manager == self.acountCenterAPIManager {
            GAProgressHUD.hidHUD()
            self.userInfoDict = manager.fetchData(self.acountCenterAPIManager) as? NSDictionary
            if self.userInfoDict == nil {
                return
            }
            
            self.contentView.balanceLabel.text = self.userInfoDict![AccountCenterAPIManager.DataKey.kAbalance] as? String
            
        } else if manager == self.prizeGroupAPIManager {
            GAProgressHUD.hidHUD()
            guard let prizeGoupsDict = manager.fetchData(self.prizeGroupAPIManager) as? NSDictionary else { return }
            let count = prizeGoupsDict[PrizeGroupsAPIManager.DataKey.kCount] as! Int
            self.contentView.priceGroupSlider.maximumValue = Float(count - 1)
            self.prizeGroupsList = prizeGoupsDict[PrizeGroupsAPIManager.DataKey.kGroups] as? [NSString]
            self.contentView.priceGroupSlider.setValue(self.contentView.priceGroupSlider.maximumValue, animated: false)
            
//            print("LotteryBettingViewController---%@\(manager.fetchData(nil))")
        } else if manager == self.bettingAPIManager {
            GAProgressHUD.hidHUD()
            guard let bettingIdDict = manager.fetchData(self.bettingAPIManager) as? NSDictionary else { return }
            let bettingResultStr = "投注单号：" + String(format: "%ld", (bettingIdDict["id"] as! Int))
            self.bettingId = bettingIdDict["id"] as! Int
            GAAlertController.showAlert("投注成功", bettingResultStr, "查看注单", "继续投注", cancelCallBack: {
                self.bettingDetailApiManager.loadData()
            }, commitCallBack: {
                self.bettingList.removeAll()
                self.navigationController?.popViewController(animated: true)
            })
            
//            print("LotteryBettingViewController---%@\(manager.fetchData(nil))")
        } else if manager == self.traceIssueAPIManager {
            GAProgressHUD.hidHUD()
            self.traceIssueList = manager.fetchData(self.traceIssueAPIManager) as? [NSDictionary]
            
        } else if manager == self.bettingDetailApiManager {
            let data = manager.fetchData(self.bettingDetailApiManager) as? NSDictionary
            let vc = BettingDetailViewController()
            vc.hidesBottomBarWhenPushed = true
            vc.detailDict = data
            self.navigationController?.pushViewController(vc, animated: true)
            self.navigationController?.viewControllers = self.navigationController?.viewControllers.filter({ (vc) -> Bool in
                return !vc.isKind(of: LotteryBettingViewController.self) && !vc.isKind(of: LotteryPlayingViewController.self)
            }) ?? []
        }
        
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        GAProgressHUD.hidHUD()
        
        let errorDict = manager.fetchFailedRequestMsg(nil) as? NSDictionary
        if errorDict != nil {
            let errorStr = errorDict!["error"] as! String
            GAProgressHUD.showError(message: errorStr)
        }
    }
    
    
}

// MARK: - UITableViewDataSource

extension LotteryBettingViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.bettingList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: LotteryBettingViewController.cellIdentifier, for: indexPath) as! LotteryBettingTableCell
        
        let bettingDict = self.bettingList[indexPath.item]
        cell.setBettingDict(bettingDict)
        cell.deleteItemBlock = {
            self.bettingList.remove(at: indexPath.item)
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
            tableView.reloadData()
            self.updateTotalBettingInfo()
        }
        
        return cell
    }
    
    
}

// MARK: - UITextFieldDelegate

extension LotteryBettingViewController: UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        textField.text = nil
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        let textStr = textField.text as NSString?
        if textField == self.contentView.mutipleFiled && textStr?.integerValue == 0 {
            textField.text = "1"
        }
        

        
        self.updateTotalBettingInfo()
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//
//        if textField == self.contentView.periodField && textField.text != nil && textField.text!.count >= 4 && string.count > 0 {
//            return false
//        }
//
//        return true
//    }
}


// MARK: - Priavate methods

extension LotteryBettingViewController {
    
    fileprivate func updateTotalBettingInfo() {
        
        if self.bettingList.count == 0 {
            self.contentView.bettingCount.text = "0"
            self.contentView.amountLabel.text = "0.000"
            return
        }
        
        var totalCount = 0
        for bettingDict in self.bettingList {
            let count = bettingDict[LotteryBettingViewController.DataKey.kNum] as! Int
            totalCount += count
        }
        let price = self.bettingList.first![LotteryBettingViewController.DataKey.kPrice] as! Int
        let mutipleStr = self.contentView.mutipleFiled.text! as NSString
        
        var totalAmount = Double(totalCount) * Double(price) * self.moneyUnit * mutipleStr.doubleValue
//        let periodStr = self.contentView.periodField.text! as NSString
//        if periodStr.doubleValue > 0 {
//            totalAmount *= periodStr.doubleValue
//        }
        
        self.contentView.bettingCount.text = String(format: "%ld", totalCount)
        self.contentView.amountLabel.text = String(format: "%.3lf", totalAmount)
    }
    
    func updatePriceGroup() {
        if self.prizeGroupsList == nil {
            return
        }
        
        let currentValue = Int(self.contentView.priceGroupSlider.value)
        let prizeGroups = self.prizeGroupsList![currentValue].integerValue
        self.contentView.priceLabel.text = String(format: "%ld", prizeGroups)
    }
    
    /// 计算追期
    ///
    /// - Returns: <#return value description#>
    fileprivate func cacluateTraceIssue(traceCount: Int) -> [String : String?] {
        if traceIssueList != nil && traceCount > 1 {
            
            let traceDict = NSMutableDictionary()
            var flagIndex = traceCount
            for index in 0...self.traceIssueList!.count-1 {
                let numberStr = self.traceIssueList![index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                if numberStr == self.currentAwardPriceString! {
                    flagIndex = index
                    break
                }
            }
            for index in flagIndex...(traceCount+flagIndex)-1 {
                let numberStr = self.traceIssueList![index].object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String
                //追期号必须都为1
                traceDict[numberStr] = "1"
            }
            return traceDict as! [String : String?]
        }
        
        return [self.currentAwardPriceString!: "1"]
    }
}
