//
//  CustomPresentationController.swift
//  GoldenApple
//
//  Created by El Capitan on 28/08/2018.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class CustomPresentationController: UIPresentationController {
    var visualView: UIView?//UIVisualEffectView?

    override func presentationTransitionWillBegin() {
        visualView = UIView(frame: containerView!.bounds)
        
//        let blur = UIBlurEffect(style: .light)
//        visualView = UIVisualEffectView(effect: blur)
//        visualView?.frame = containerView!.bounds
        visualView?.backgroundColor = UIColor(white: 0, alpha: 0.4)
        containerView?.addSubview(visualView!)
    }
    
    override func presentationTransitionDidEnd(_ completed: Bool) {
        if !completed {
            visualView?.removeFromSuperview()
        }
    }

    override func dismissalTransitionWillBegin() {
        visualView?.alpha = 0
    }

    override func dismissalTransitionDidEnd(_ completed: Bool) {
        if completed {
            visualView?.removeFromSuperview()
        }
    }
    
    override var frameOfPresentedViewInContainerView: CGRect {
        let padding: CGFloat = 40
        let height: CGFloat = 380
        return CGRect.init(x: padding, y: (screenHeight - height) / 2, width: (screenWidth - 2 * padding), height: height)
    }
    
}
