//
//  TraceIssueAPIManager.swift
//  GoldenApple
//
//  Created by User on 07/12/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class TraceIssueAPIManager: GAAPIBaseManager {

    struct DataKey {
        
        /// 奖期
        static let kNumber = "number"
        
        /// 销售截止时间
        static let kTime = "time"
        
        /// 投注最大奖金
        static let kLimitAmount = "limit_amount"
    }
    
}

extension TraceIssueAPIManager: LYAPIManager {
    
    public func methodName() -> NSString {
        return "service?packet=Game&action=getAvailableIssues"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return true
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
}

extension TraceIssueAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        guard let traceIssueList = data.object(forKey: "data") as? [NSDictionary] else { return nil }
        
        return traceIssueList
    }
    
    
    
}

