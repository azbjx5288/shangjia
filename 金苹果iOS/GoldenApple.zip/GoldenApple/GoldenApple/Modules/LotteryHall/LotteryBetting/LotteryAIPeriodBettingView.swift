//
//  LotteryAIPeriodBettingView.swift
//  GoldenApple
//
//  Created by El Capitan on 02/08/2018.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class LotteryAIPeriodBettingView: UIView {
    static let samePeriodListStartTag = 10000
    static let sameMutiListStartTag = 20000
    static let profitPeriodListStartTag = 30000
    static let profitMutiListStartTag = 40000
    static let doublePeriodListStartTag = 50000
    static let doubleMutiListStartTag = 60000
    
    var isTraceWinStop = true
    
    let segmentControl: UISegmentedControl = {
        let arr = ["同倍追号", "利润率追号", "翻倍追号"]
        let segCtrl = UISegmentedControl(items: arr)
        segCtrl.selectedSegmentIndex = 0
        segCtrl.tintColor = .white
        segCtrl.backgroundColor = kGAViewGrayBackgoundColor
        
        segCtrl.setTitleTextAttributes([NSForegroundColorAttributeName: kGAFontRedColor, NSFontAttributeName: UIFont.systemFont(ofSize: 18)], for: .selected)
        segCtrl.setTitleTextAttributes([NSForegroundColorAttributeName: kGAFontBlackColor, NSFontAttributeName: UIFont.systemFont(ofSize: 18)], for: .normal)
        
        
        return segCtrl
    }()
    
    fileprivate let topView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        
        return view
    }()
    
    let awardPeriodLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = "0000"
        
        return label
    }()
    
    fileprivate let periodTipsLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.systemFont(ofSize: 16)
        label.tintColor = RGBCOLOR(51, 51, 51)
        label.text = "期"
        
        return label
    }()

    let coutdownLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontRedColor
        label.text = "00:00:00"
        
        return label
    }()
    
    fileprivate let endPeriodLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.systemFont(ofSize: 16)
        label.tintColor = RGBCOLOR(51, 51, 51)
        label.text = "截止投注"
        
        return label
    }()
    
    fileprivate let sepLbl: UILabel = {
        let label = UILabel()
        
        label.backgroundColor = kGASerperatorLineGrayColor
        
        return label
    }()
    
    fileprivate let bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = kGATabbarBackgroundColor
        return view
    }()
    
    fileprivate let totalBettingTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "总注数："
        
        return label
    }()
    
    let bettingCount: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "0"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    fileprivate let bettingTipsWord: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "注，"
        
        return label
    }()
    
    fileprivate let totalAmountTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "总金额："
        
        return label
    }()
    
    let amountLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = kGAFontRedColor
        label.text = "0.00"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    let yuanAmontLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "元"
        
        return label
    }()
    
    fileprivate let balanceTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "账户余额："
        
        return label
    }()
    
    let balanceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "0.00"
        
        return label
    }()
    
    fileprivate let yuanBalanceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "元"
        
        return label
    }()
    
    let confirmBettingBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("确认追号", for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.backgroundColor = kGAFontRedColor
        
        return button
    }()
    
    fileprivate let centerView: UIView = {
        let view = UIView()
        
        return view
    }()
    
    //同倍追号
    let sameRateContentView: UIView = {
        let view = UIView()
        
        return view
    }()
    
    let sameTopView: UIView = {
        let view = UIView()
        
        view.backgroundColor = .white
        
        return view
    }()
    
    let sameMutipleFiled: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "1"
        field.font = UIFont.systemFont(ofSize: 16)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let sameMutipleTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "倍数"
        
        return label
    }()
    
    fileprivate let samePeriodFromTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "追"
        
        return label
    }()
    
    let samePeriodField: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.font = UIFont.systemFont(ofSize: 16)
        field.text = "10"
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let samePeriodToTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "期"
        
        return label
    }()
    
    let sameCreatePlanBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("生成计划", for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.backgroundColor = kGAFontRedColor
        
        return button
    }()
    
    let sameTraceWinStopBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("追中即停", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        
        return button
    }()
    
    let sameTableView: UITableView = {
        let table = UITableView(frame: CGRect.zero, style: UITableViewStyle.plain)
        table.backgroundColor = .white
        table.separatorStyle = .none
        table.rowHeight = 60
        return table
    }()
    
    let sameHeaderView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        
        let sepLbl = UILabel()
        view.addSubview(sepLbl)
        sepLbl.backgroundColor = kGASerperatorLineGrayColor
        sepLbl.snp.makeConstraints({ (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        })
        
        return view
    }()
    
    let sameHeaderSelectBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        button.isSelected = true
        
        return button
    }()
    
    let sameHeaderPeriodLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "追号期数"
        
        return label
    }()
    
    let sameHeadermutiLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "倍数"
        label.textAlignment = .center
        
        return label
    }()
    
    let sameHeaderAmountLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "金额"
        label.textAlignment = .center
        
        return label
    }()
    
    //利润率追号
    let profitContentView: UIView = {
        let view = UIView()
        
        view.isHidden = true
        
        return view
    }()
    
    let profitTopView: UIView = {
        let view = UIView()
        
        view.backgroundColor = .white
        
        return view
    }()
    
    fileprivate let profitMinRateTitleLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "最低收益率"
        
        return label
    }()
    
    let profitMinRateField: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "10"
        field.font = UIFont.systemFont(ofSize: 16)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let profitMinRateToTitleLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "%"
        
        return label
    }()
    
    fileprivate let profitPeriodTitleLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "追"
        
        return label
    }()
    
    let profitPeriodField: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "10"
        field.font = UIFont.systemFont(ofSize: 16)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let profitPeriodToTitleLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "期"
        
        return label
    }()
    
    fileprivate let profitStartMultiTitleLbl:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "起始"
        
        return label
    }()
    
    let profitStartMultiField: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "1"
        field.font = UIFont.systemFont(ofSize: 16)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let profitStartMultiToTitleLbl:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "倍"
        
        return label
    }()
    
    let profitTraceWinStopBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("追中即停", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        
        return button
    }()
    
    let profitCreatePlanBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("生成计划", for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.backgroundColor = kGAFontRedColor
        
        return button
    }()
    
    let profitHintLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12)
        label.textColor = kGAFontRedColor
        label.text = "注意：利润率计算使用当前用户最大奖金组计算。"
        
        return label
    }()
    
    let profitTableView: UITableView = {
        let table = UITableView(frame: CGRect.zero, style: UITableViewStyle.plain)
        table.backgroundColor = .white
        table.separatorStyle = .none
        table.rowHeight = 60
        return table
    }()
    
    let profitHeaderView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        
        let sepLbl = UILabel()
        view.addSubview(sepLbl)
        sepLbl.backgroundColor = kGASerperatorLineGrayColor
        sepLbl.snp.makeConstraints({ (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        })
        
        return view
    }()
    
    let profitHeaderSelectBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        button.isSelected = true
        
        return button
    }()
    
    let profitHeaderPeriodLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "追号期数"
        
        return label
    }()
    
    let profitHeadermutiLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "倍数"
        label.textAlignment = .center
        
        return label
    }()
    
    let profitHeaderAmountLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "金额"
        label.textAlignment = .center
        
        return label
    }()
    
    let profitHeaderRewardLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "奖金"
        label.textAlignment = .center
        
        return label
    }()
    
    let profitHeaderExpectedRewardLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "预期盈利金额"
        label.textAlignment = .center
        
        return label
    }()
    
    let profitHeaderExpectedProfitLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "预期盈利率"
        label.textAlignment = .center
        
        return label
    }()
    
    //翻倍追号
    let doubleRateContentView: UIView = {
        let view = UIView()
        
        view.isHidden = true
        
        return view
    }()
    
    let doubleTopView: UIView = {
        let view = UIView()
        
        view.backgroundColor = .white
        
        return view
    }()
    
    let doubleStartMutipleFiled: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "1"
        field.font = UIFont.systemFont(ofSize: 16)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    let doubleMutipleFiled: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "2"
        field.font = UIFont.systemFont(ofSize: 16)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let doubleMutipleTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "倍×"
        
        return label
    }()
    
    fileprivate let doubleStartMutipleTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.numberOfLines = 2
        label.text = "起始\n倍数"
        
        return label
    }()
    
    fileprivate let doublePeriodFromTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "追"
        
        return label
    }()
    
    fileprivate let doublePeriodIntervalTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "隔"
        
        return label
    }()
    
    let doublePeriodField: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.font = UIFont.systemFont(ofSize: 16)
        field.text = "10"
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    let doubleIntervalPeriodField: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.font = UIFont.systemFont(ofSize: 16)
        field.text = "2"
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let doublePeriodToTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "期"
        
        return label
    }()
    
    fileprivate let doublePeriodIntervalToTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = kGAFontGrayColor
        label.text = "期"
        
        return label
    }()
    
    let doubleCreatePlanBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("生成计划", for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.backgroundColor = kGAFontRedColor
        
        return button
    }()
    
    let doubleTraceWinStopBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("追中即停", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        
        return button
    }()
    
    let doubleTableView: UITableView = {
        let table = UITableView(frame: CGRect.zero, style: UITableViewStyle.plain)
        table.backgroundColor = .white
        table.separatorStyle = .none
        table.rowHeight = 60
        return table
    }()
    
    let doubleHeaderView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        
        let sepLbl = UILabel()
        view.addSubview(sepLbl)
        sepLbl.backgroundColor = kGASerperatorLineGrayColor
        sepLbl.snp.makeConstraints({ (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        })
        
        return view
    }()
    
    let doubleHeaderSelectBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        button.isSelected = true
        
        return button
    }()
    
    fileprivate let doubleHeaderPeriodLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "追号期数"
        
        return label
    }()
    
    fileprivate let doubleHeadermutiLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "倍数"
        label.textAlignment = .center
        
        return label
    }()
    
    fileprivate let doubleHeaderAmountLbl: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = "金额"
        label.textAlignment = .center
        
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(segmentControl)
        
        addSubview(self.topView)
        self.topView.addSubview(self.awardPeriodLabel)
        self.topView.addSubview(self.periodTipsLabel)
        self.topView.addSubview(self.coutdownLabel)
        self.topView.addSubview(self.endPeriodLabel)
        topView.addSubview(sepLbl)
        
        //同倍追号
        addSubview(sameRateContentView)
        sameRateContentView.addSubview(sameTopView)
        sameTopView.addSubview(sameMutipleFiled)
        sameTopView.addSubview(sameMutipleTitleLabel)
        sameTopView.addSubview(samePeriodFromTitleLabel)
        sameTopView.addSubview(samePeriodField)
        sameTopView.addSubview(samePeriodToTitleLabel)
        sameTopView.addSubview(sameTraceWinStopBtn)
        sameTopView.addSubview(sameCreatePlanBtn)
        
        sameTraceWinStopBtn.isSelected = true
        sameTraceWinStopBtn.addTarget(self, action: #selector(sameTraceWinStopBtnClick(_:)), for: .touchUpInside)
        
        sameRateContentView.addSubview(sameTableView)
        
        sameHeaderView.addSubview(sameHeaderSelectBtn)
        sameHeaderView.addSubview(sameHeaderPeriodLbl)
        sameHeaderView.addSubview(sameHeadermutiLbl)
        sameHeaderView.addSubview(sameHeaderAmountLbl)
        
        //利润率追号
        addSubview(profitContentView)
        profitContentView.isHidden = true
        
        profitContentView.addSubview(profitTopView)
        profitTopView.addSubview(profitMinRateTitleLbl)
        profitTopView.addSubview(profitMinRateField)
        profitTopView.addSubview(profitMinRateToTitleLbl)
        profitTopView.addSubview(profitPeriodTitleLbl)
        profitTopView.addSubview(profitPeriodField)
        profitTopView.addSubview(profitPeriodToTitleLbl)
        profitTopView.addSubview(profitStartMultiTitleLbl)
        profitTopView.addSubview(profitStartMultiField)
        profitTopView.addSubview(profitStartMultiToTitleLbl)
        profitTopView.addSubview(profitTraceWinStopBtn)
        profitTopView.addSubview(profitCreatePlanBtn)
        profitTopView.addSubview(profitHintLbl)
        
        profitTraceWinStopBtn.isSelected = true
        profitTraceWinStopBtn.addTarget(self, action: #selector(profitTraceWinStopBtnClick(_:)), for: .touchUpInside)
        
        let scrollView = UIScrollView()
        scrollView.backgroundColor = UIColor.blue
        profitContentView.addSubview(scrollView)
        scrollView.bounces = false
        scrollView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(profitTopView.snp.bottom).offset(15)
        }
        let contentView = UIView()
        scrollView.addSubview(contentView)
        contentView.addSubview(profitTableView)
        contentView.snp.makeConstraints { (make) in
            make.edges.equalTo(scrollView)
            make.height.equalTo(scrollView)
            make.width.equalTo(50 + 60 + 15 + ProfitTraceTableViewCell.itemWidth * 5 + ProfitTraceTableViewCell.itemPadding * 5)
        }
        
        profitHeaderView.addSubview(profitHeaderSelectBtn)
        profitHeaderView.addSubview(profitHeaderPeriodLbl)
        profitHeaderView.addSubview(profitHeadermutiLbl)
        profitHeaderView.addSubview(profitHeaderAmountLbl)
        profitHeaderView.addSubview(profitHeaderRewardLbl)
        profitHeaderView.addSubview(profitHeaderExpectedRewardLbl)
        profitHeaderView.addSubview(profitHeaderExpectedProfitLbl)
        
        //翻倍追号
        doubleRateContentView.isHidden = true
        addSubview(doubleRateContentView)
        doubleRateContentView.addSubview(doubleTopView)
        doubleTopView.addSubview(doubleMutipleFiled)
        doubleTopView.addSubview(doubleMutipleTitleLabel)
        doubleTopView.addSubview(doublePeriodFromTitleLabel)
        doubleTopView.addSubview(doublePeriodField)
        doubleTopView.addSubview(doublePeriodToTitleLabel)
        doubleTopView.addSubview(doubleTraceWinStopBtn)
        doubleTopView.addSubview(doubleCreatePlanBtn)
        doubleTopView.addSubview(doubleStartMutipleFiled)
        doubleTopView.addSubview(doubleStartMutipleTitleLabel)
        doubleTopView.addSubview(doublePeriodIntervalTitleLabel)
        doubleTopView.addSubview(doublePeriodIntervalToTitleLabel)
        doubleTopView.addSubview(doubleIntervalPeriodField)

        doubleTraceWinStopBtn.isSelected = true
        doubleTraceWinStopBtn.addTarget(self, action: #selector(doubleTraceWinStopBtnClick(_:)), for: .touchUpInside)
        
        doubleRateContentView.addSubview(doubleTableView)
        
        doubleHeaderView.addSubview(doubleHeaderSelectBtn)
        doubleHeaderView.addSubview(doubleHeaderPeriodLbl)
        doubleHeaderView.addSubview(doubleHeadermutiLbl)
        doubleHeaderView.addSubview(doubleHeaderAmountLbl)
        
        addSubview(bottomView)
        bottomView.addSubview(totalBettingTips)
        bottomView.addSubview(bettingCount)
        bottomView.addSubview(bettingTipsWord)
        bottomView.addSubview(totalAmountTips)
        bottomView.addSubview(amountLabel)
        bottomView.addSubview(yuanAmontLabel)
        bottomView.addSubview(balanceTitleLabel)
        bottomView.addSubview(balanceLabel)
        bottomView.addSubview(yuanBalanceLabel)
        bottomView.addSubview(confirmBettingBtn)
        
        makeConstraintsForSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate func makeConstraintsForSubviews() {
        segmentControl.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(55)
        }
        
        topView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.height.equalTo(40)
            make.top.equalTo(segmentControl.snp.bottom)
        }
        self.awardPeriodLabel.snp.makeConstraints { (make) in
            make.top.equalTo(self.periodTipsLabel)
            make.left.equalTo(15)
        }
        self.periodTipsLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(awardPeriodLabel.snp.right).offset(5)
        }
        
        endPeriodLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(awardPeriodLabel)
            make.right.equalToSuperview().offset(-15)
        }
        self.coutdownLabel.snp.makeConstraints { (make) in
            make.top.equalTo(periodTipsLabel)
            make.left.equalTo(topView.snp.centerX).offset(-10)
//            make.right.equalTo(self.endPeriodLabel.snp.left).offset(-20)
//            make.width.equalTo(120)
        }
        sepLbl.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-1)
            make.left.equalTo(15)
            make.right.equalTo(-15)
            make.height.equalTo(1)
        }
        
        bottomView.snp.makeConstraints { (make) in
            make.left.bottom.right.equalToSuperview()
            make.height.equalTo(49)
        }
        totalBettingTips.snp.makeConstraints { (make) in
            make.left.equalTo(15)
            make.top.equalToSuperview().offset(5)
        }
        bettingCount.snp.makeConstraints { (make) in
            make.left.equalTo(totalBettingTips.snp.right)
            make.centerY.equalTo(totalBettingTips)
        }
        bettingTipsWord.snp.makeConstraints { (make) in
            make.left.equalTo(bettingCount.snp.right)
            make.centerY.equalTo(totalBettingTips)
        }
        totalAmountTips.snp.makeConstraints { (make) in
            make.left.equalTo(bettingTipsWord.snp.right)
            make.centerY.equalTo(totalBettingTips)
        }
        amountLabel.snp.makeConstraints { (make) in
            make.left.equalTo(totalAmountTips.snp.right)
            make.centerY.equalTo(totalAmountTips)
            make.right.equalTo(confirmBettingBtn.snp.left).offset(-3).priority(250)
        }
        yuanAmontLabel.snp.makeConstraints { (make) in
            make.left.equalTo(amountLabel.snp.right)
            make.centerY.equalTo(totalBettingTips)
        }
        balanceTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(totalBettingTips)
            make.top.equalTo(totalBettingTips.snp.bottom).offset(5)
        }
        balanceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(balanceTitleLabel.snp.right)
            make.centerY.equalTo(balanceTitleLabel)
        }
        yuanBalanceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(balanceLabel.snp.right)
            make.centerY.equalTo(balanceTitleLabel)
        }
        confirmBettingBtn.snp.makeConstraints { (make) in
            make.top.right.bottom.equalToSuperview()
            make.width.equalTo(95)
        }
        
        //同倍追号
        sameRateContentView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(topView.snp.bottom)
            make.bottom.equalTo(bottomView.snp.top)
        }
        
        sameTopView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
        }
        
        samePeriodFromTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(15)
            make.top.equalToSuperview().offset(25)
            
        }
        samePeriodField.snp.makeConstraints { (make) in
            make.left.equalTo(samePeriodFromTitleLabel.snp.right).offset(5)
            make.centerY.equalTo(samePeriodFromTitleLabel)
            make.width.equalTo(50)
            make.height.equalTo(27.5)
        }
        
        samePeriodToTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(samePeriodField.snp.right).offset(5)
            make.centerY.equalTo(samePeriodField)
        }

        sameMutipleTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(samePeriodToTitleLabel.snp.right).offset(10)
            make.centerY.equalTo(samePeriodField)
        }
        
        sameMutipleFiled.snp.makeConstraints { (make) in
            make.left.equalTo(sameMutipleTitleLabel.snp.right).offset(5)
            make.centerY.equalTo(samePeriodFromTitleLabel)
            make.width.equalTo(50)
            make.height.equalTo(27.5)
        }
        
        sameTraceWinStopBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15)
            make.centerY.equalTo(samePeriodField)
            make.height.equalTo(30)
            make.width.equalTo(100)
        }

        sameCreatePlanBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(sameMutipleFiled.snp.bottom).offset(10)
            make.height.equalTo(40)
            make.width.equalTo(90)
            make.bottom.equalToSuperview().offset(-22.5)
        }
        
        sameTableView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(sameTopView.snp.bottom).offset(15)
        }
        
        sameHeaderSelectBtn.snp.makeConstraints { (make) in
            make.left.equalTo(15)
            make.centerY.equalToSuperview()
        }
        
        sameHeaderPeriodLbl.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(50)
            make.width.equalTo(SameRateTraceTableViewCell.itemWidth)
        }
        sameHeadermutiLbl.snp.makeConstraints { (make) in
            make.left.equalTo(sameHeaderPeriodLbl.snp.right).offset(SameRateTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(60)
            make.height.equalTo(30)
        }
        
        sameHeaderAmountLbl.snp.makeConstraints { (make) in
            make.trailing.equalTo(-30)
            make.centerY.equalToSuperview()
        }

        //利润率追号
        profitContentView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(topView.snp.bottom)
            make.bottom.equalTo(bottomView.snp.top)
        }
        
        profitTopView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
        }
        
        profitMinRateTitleLbl.snp.makeConstraints { (make) in
            make.left.equalTo(15)
        }
        
        profitMinRateField.snp.makeConstraints { (make) in
            make.left.equalTo(profitMinRateTitleLbl.snp.right).offset(5)
            make.top.equalTo(22.5)
            make.centerY.equalTo(profitMinRateTitleLbl)
            make.width.equalTo(50)
            make.height.equalTo(27.5)
        }
        
        profitMinRateToTitleLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitMinRateField.snp.right).offset(5)
            make.centerY.equalTo(profitMinRateField)
        }
        
        profitPeriodTitleLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitMinRateToTitleLbl.snp.right).offset(15)
            make.centerY.equalTo(profitMinRateToTitleLbl)
        }
        
        profitPeriodField.snp.makeConstraints { (make) in
            make.left.equalTo(profitPeriodTitleLbl.snp.right).offset(5)
            make.width.height.centerY.equalTo(profitMinRateField)
        }
        
        profitPeriodToTitleLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitPeriodField.snp.right).offset(5)
            make.centerY.equalTo(profitMinRateField)
        }
        
        profitStartMultiTitleLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitMinRateTitleLbl)
        }
        
        profitStartMultiField.snp.makeConstraints { (make) in
            make.left.equalTo(profitStartMultiTitleLbl.snp.right).offset(5)
            make.top.equalTo(profitMinRateField.snp.bottom).offset(20)
            make.centerY.equalTo(profitStartMultiTitleLbl)
            make.width.equalTo(50)
            make.height.equalTo(27.5)
        }
        
        profitStartMultiToTitleLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitStartMultiField.snp.right).offset(5)
            make.centerY.equalTo(profitStartMultiField)
        }
        
        profitTraceWinStopBtn.snp.makeConstraints { (make) in
            make.left.equalTo(profitStartMultiToTitleLbl.snp.right).offset(15)
            make.centerY.equalTo(profitStartMultiField)
        }
        
        profitCreatePlanBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15)
            make.width.equalTo(90)
            make.centerY.equalTo(profitTraceWinStopBtn)
            make.height.equalTo(40)
        }
        
        profitHintLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitMinRateTitleLbl)
            make.top.equalTo(profitStartMultiField.snp.bottom).offset(20)
            make.bottom.equalToSuperview().offset(-10)
        }
        
        profitTableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
            make.height.equalToSuperview()
//            make.top.equalTo(profitTopView.snp.bottom).offset(15)
//            make.width.equalTo(50 + 60 + 15 + ProfitTraceTableViewCell.itemWidth * 5 + ProfitTraceTableViewCell.itemPadding)
        }
        
        profitHeaderSelectBtn.snp.makeConstraints { (make) in
            make.left.equalTo(15)
            make.centerY.equalToSuperview()
        }
        
        profitHeaderPeriodLbl.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(50)
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        
        profitHeadermutiLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitHeaderPeriodLbl.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(60)
            make.height.equalTo(30)
        }
        
        profitHeaderAmountLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitHeadermutiLbl.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        
        profitHeaderRewardLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitHeaderAmountLbl.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        
        profitHeaderExpectedRewardLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitHeaderRewardLbl.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        profitHeaderExpectedProfitLbl.snp.makeConstraints { (make) in
            make.left.equalTo(profitHeaderExpectedRewardLbl.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
            make.right.equalToSuperview().offset(-15)
        }
//        profitTableView.superview?.snp.remakeConstraints({ (make) in
//            make.right.equalTo(profitTableView)
//            make.left.top.bottom.height.equalTo((profitTableView.superview?.superview)!)
////            make.height.equalTo(scrollView)
//        })
        
        //翻倍追号
        doubleRateContentView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(topView.snp.bottom)
            make.bottom.equalTo(bottomView.snp.top)
        }
        
        doubleTopView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
        }
        
        doubleStartMutipleTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(15)
        }
        
        doubleStartMutipleFiled.snp.makeConstraints { (make) in
            make.left.equalTo(doubleStartMutipleTitleLabel.snp.right).offset(5)
            make.centerY.equalTo(doubleStartMutipleTitleLabel)
            make.top.equalToSuperview().offset(22.5)
            make.width.equalTo(50)
            make.height.equalTo(27.5)
        }
        
        doublePeriodField.snp.makeConstraints { (make) in
            make.left.equalTo(doublePeriodFromTitleLabel.snp.right).offset(5)
            make.centerY.equalTo(doublePeriodFromTitleLabel)
            make.width.equalTo(50)
            make.height.equalTo(27.5)
        }
        
        doublePeriodFromTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(doublePeriodIntervalTitleLabel)
            make.centerY.equalTo(doubleMutipleFiled)
        }
        
        doublePeriodIntervalTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(doubleStartMutipleFiled.snp.right).offset(10)
            make.centerY.equalTo(doubleStartMutipleFiled)
        }
        
        doubleIntervalPeriodField.snp.makeConstraints { (make) in
            make.left.equalTo(doublePeriodFromTitleLabel.snp.right).offset(5)
            make.centerY.equalTo(doublePeriodIntervalTitleLabel)
            make.width.equalTo(50)
            make.height.equalTo(27.5)
        }
        
        doublePeriodIntervalToTitleLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(doublePeriodIntervalTitleLabel)
            make.left.right.equalTo(doublePeriodToTitleLabel)
        }
        
        doublePeriodToTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(doublePeriodField.snp.right).offset(5)
            make.centerY.equalTo(doublePeriodField)
        }
        
        doubleMutipleTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(doubleStartMutipleTitleLabel)
            make.centerY.equalTo(doubleMutipleFiled)
        }
        
        doubleMutipleFiled.snp.makeConstraints { (make) in
            make.left.equalTo(doubleStartMutipleFiled)
            make.top.equalTo(doubleStartMutipleFiled.snp.bottom).offset(20)
            make.width.equalTo(50)
            make.bottom.equalToSuperview().offset(-37.5)
            make.height.equalTo(27.5)
        }
        
        doubleTraceWinStopBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15)
            make.centerY.equalTo(doublePeriodIntervalTitleLabel)
            make.height.equalTo(30)
            make.width.equalTo(100)
        }
        
        doubleCreatePlanBtn.snp.makeConstraints { (make) in
            make.centerX.equalTo(doubleTraceWinStopBtn)
            make.width.equalTo(90)
            make.top.equalTo(doubleTraceWinStopBtn.snp.bottom).offset(10)
            make.height.equalTo(40)
        }
        
        doubleTableView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(doubleTopView.snp.bottom).offset(15)
        }
        
        doubleHeaderSelectBtn.snp.makeConstraints { (make) in
            make.left.equalTo(15)
            make.centerY.equalToSuperview()
        }
        
        doubleHeaderPeriodLbl.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(50)
            make.width.equalTo(SameRateTraceTableViewCell.itemWidth)
        }
        
        doubleHeadermutiLbl.snp.makeConstraints { (make) in
            make.left.equalTo(doubleHeaderPeriodLbl.snp.right).offset(SameRateTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(60)
            make.height.equalTo(30)
        }
        
        doubleHeaderAmountLbl.snp.makeConstraints { (make) in
            make.trailing.equalTo(-30)
            make.centerY.equalToSuperview()
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        self.endEditing(true)
    }
    
//    func segmentControlSwitch(_ segmentControl: UISegmentedControl) {
//        let index = segmentControl.selectedSegmentIndex
//        sameRateContentView.isHidden = index != 0
//        profitContentView.isHidden = index != 1
//        doubleRateContentView.isHidden = index != 2
//
//    }
    
    func sameTraceWinStopBtnClick(_ button: UIButton) {
        button.isSelected = !button.isSelected
    }
    
    func doubleTraceWinStopBtnClick(_ button: UIButton) {
        button.isSelected = !button.isSelected
    }
    
    func profitTraceWinStopBtnClick(_ button: UIButton) {
        button.isSelected = !button.isSelected
    }
}
