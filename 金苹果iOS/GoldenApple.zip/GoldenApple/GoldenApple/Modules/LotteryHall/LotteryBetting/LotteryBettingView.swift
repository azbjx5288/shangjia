//
//  LotteryBettingView.swift
//  GoldenApple
//
//  Created by User on 06/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryBettingView: UIView {

    fileprivate let topView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        
        return view
    }()
    
    let awardPeriodLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.tintColor = RGBCOLOR(51, 51, 51)
        label.text = "0000"
        
        return label
    }()
    
    fileprivate let periodTipsLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.tintColor = RGBCOLOR(51, 51, 51)
        label.text = "期"
        
        return label
    }()
    
    let coutdownLabel: UILabel = {
        let label = UILabel()
        
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.textColor = kGAFontRedColor
        label.text = "00:00:00"
        
        return label
    }()
    
    let onceAgainBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        
        button.backgroundColor = kGAFontRedColor
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.setTitle("继续选号", for: UIControlState.normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        
        return button
    }()
    
    let tableView: UITableView = {
        let table = UITableView(frame: CGRect.zero, style: UITableViewStyle.plain)
        table.backgroundColor = UIColor.clear
        table.separatorStyle = .none
        table.allowsSelection = false
        table.estimatedRowHeight = 85
        table.rowHeight = UITableViewAutomaticDimension
        return table
    }()
    
    fileprivate let toolbarView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        
        return view
    }()
    
    let toolbarSeperatorLine: UIView = {
        let view = UIView()
        view.backgroundColor = kGASerperatorLineGrayColor
        
        return view
    }()
    
    fileprivate let bettingTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12)
        label.textColor = kGAFontGrayColor
        label.text = "投"
        
        return label
    }()
    
    let mutipleFiled: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "1"
        field.font = UIFont.systemFont(ofSize: 12)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    fileprivate let mutipleTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12)
        label.textColor = kGAFontGrayColor
        label.text = "倍"
        
        return label
    }()
    
    //智能追号按钮
    let aiPeriodBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("智能追号", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = kGAFontRedColor
        btn.layer.cornerRadius = 1
        btn.layer.borderColor = UIColor.red.cgColor
        
        return btn
    }()
    
    fileprivate let label_moshi: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12)
        label.textColor = kGAFontGrayColor
        label.text = "模式"
        return label
    }()
    
    let chasingButton: UIButton = {
        let view = UIButton()
        view.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        view.setTitleColor(kGAFontRedColor, for: .normal)
        view.setTitle("2元", for: .normal)
        view.layer.borderWidth = 1
        view.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        return view
    }()
    
    fileprivate let bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = kGATabbarBackgroundColor
        return view
    }()
    
    fileprivate let totalBettingTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "共选"
        
        return label
    }()
    
    let bettingCount: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "0"
        return label
    }()
    
    fileprivate let bettingTipsWord: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "注，"
        
        return label
    }()
    
    let amountLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontRedColor
        label.text = "0.00"
        return label
    }()
    
    let yuanAmontLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.white
        label.text = "元"
        
        return label
    }()
    
    fileprivate let balanceTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "余额："
        
        return label
    }()
    
    let balanceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "0.00"
        
        return label
    }()
    
    let yuanBalanceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.text = "元"
        
        return label
    }()
    
    let confirmBettingBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("确定投注", for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.backgroundColor = kGAFontRedColor
        
        return button
    }()
    
    let modeView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.borderWidth = 1
        view.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        
        return view
    }()
    
    let modeTips: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        
        label.text = "模式"
        
        return label
    }()
    
    let twoYuanBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("2元", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.selected)
        button.setBackgroundImage(UIImage(named: "modeNormal"), for: UIControlState.normal)
        button.setBackgroundImage(UIImage(named: "modeSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        
        return button
    }()
    
    let oneYuanBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("1元", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.selected)
        button.setBackgroundImage(UIImage(named: "modeNormal"), for: UIControlState.normal)
        button.setBackgroundImage(UIImage(named: "modeSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        
        return button
    }()
    
    let twoJiaoBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("2角", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.selected)
        button.setBackgroundImage(UIImage(named: "modeNormal"), for: UIControlState.normal)
        button.setBackgroundImage(UIImage(named: "modeSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        
        return button
    }()
    
    let oneJiaoBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("1角", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.selected)
        button.setBackgroundImage(UIImage(named: "modeNormal"), for: UIControlState.normal)
        button.setBackgroundImage(UIImage(named: "modeSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        
        return button
    }()
    
    let twoFenBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("2分", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.selected)
        button.setBackgroundImage(UIImage(named: "modeNormal"), for: UIControlState.normal)
        button.setBackgroundImage(UIImage(named: "modeSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        
        return button
    }()
    
    let twoLiBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setTitle("2厘", for: UIControlState.normal)
        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
        button.setTitleColor(UIColor.white, for: UIControlState.selected)
        button.setBackgroundImage(UIImage(named: "modeNormal"), for: UIControlState.normal)
        button.setBackgroundImage(UIImage(named: "modeSelected"), for: UIControlState.selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        
        return button
    }()
    
    /// 赔率label
    let rebateLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        
        label.text = "0%"
        
        return label
    }()
    
    /// 奖金组slider
    let priceGroupSlider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 0
        
        return slider
    }()
    
    /// 赔率值label
    let priceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.text = "0"
        
        return label
    }()
    
//    let traceWinStopBtn: UIButton = {
//        let button = UIButton(type: UIButtonType.custom)
//        button.setTitle("追中即停", for: UIControlState.normal)
//        button.setTitleColor(kGAFontGrayColor, for: UIControlState.normal)
//        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
//        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
//        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
//
//        return button
//    }()
    
    var moneyUnitClosures: ((_ moneyUnit: Double) -> Void)?
    
    fileprivate weak var curMoneyUnitBtn: UIButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.topView)
        self.topView.addSubview(self.awardPeriodLabel)
        self.topView.addSubview(self.periodTipsLabel)
        self.topView.addSubview(self.coutdownLabel)
        self.topView.addSubview(self.onceAgainBtn)
        
        self.addSubview(self.tableView)
        
        self.addSubview(self.toolbarView)
        self.toolbarView.addSubview(self.toolbarSeperatorLine)
        self.toolbarView.addSubview(self.bettingTitleLabel)
        self.toolbarView.addSubview(self.mutipleFiled)
        self.toolbarView.addSubview(self.mutipleTitleLabel)
        
        self.toolbarView.addSubview(self.chasingButton)
        self.toolbarView.addSubview(self.label_moshi)
        
        self.toolbarView.addSubview(self.aiPeriodBtn)
        
        self.addSubview(self.bottomView)
        self.bottomView.addSubview(self.totalBettingTips)
        self.bottomView.addSubview(self.bettingCount)
        self.bottomView.addSubview(self.bettingTipsWord)
        self.bottomView.addSubview(self.amountLabel)
        self.bottomView.addSubview(self.yuanAmontLabel)
        self.bottomView.addSubview(self.balanceTitleLabel)
        self.bottomView.addSubview(self.balanceLabel)
        self.bottomView.addSubview(self.yuanBalanceLabel)
        self.bottomView.addSubview(self.confirmBettingBtn)
        
        self.addSubview(self.modeView)
        self.modeView.addSubview(self.modeTips)
        self.modeView.addSubview(self.twoYuanBtn)
        self.modeView.addSubview(self.oneYuanBtn)
        self.modeView.addSubview(self.twoJiaoBtn)
        self.modeView.addSubview(self.oneJiaoBtn)
        self.modeView.addSubview(self.twoFenBtn)
        self.modeView.addSubview(self.twoLiBtn)
        self.modeView.addSubview(self.rebateLabel)
        self.modeView.addSubview(self.priceGroupSlider)
        self.modeView.addSubview(self.priceLabel)
//        self.modeView.addSubview(self.traceWinStopBtn)
        
        self.makeConstraintsForSubviews()
        
        self.modeView.isHidden = true
//        self.traceWinStopBtn.isSelected = true
        self.twoYuanBtn.addTarget(self, action: #selector(switchMoneyUnit(_:)), for: .touchUpInside)
        self.oneYuanBtn.addTarget(self, action: #selector(switchMoneyUnit(_:)), for: .touchUpInside)
        self.twoJiaoBtn.addTarget(self, action: #selector(switchMoneyUnit(_:)), for: .touchUpInside)
        self.oneJiaoBtn.addTarget(self, action: #selector(switchMoneyUnit(_:)), for: .touchUpInside)
        self.twoFenBtn.addTarget(self, action: #selector(switchMoneyUnit(_:)), for: .touchUpInside)
        self.twoLiBtn.addTarget(self, action: #selector(switchMoneyUnit(_:)), for: .touchUpInside)
//        self.traceWinStopBtn.addTarget(self, action: #selector(traceWinStopBtnClick(_:)), for: .touchUpInside)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
//        if !self.modeView.isHidden {
//            self.modeView.isHidden = true
//        }
        
        self.endEditing(true)
    }
    
    func switchMoneyUnit(_ button: UIButton) {
        
        if button == self.curMoneyUnitBtn {
            return
        }
        
        let bSelected = button.isSelected
        button.isSelected = !bSelected
        if self.curMoneyUnitBtn != nil {
            self.curMoneyUnitBtn.isSelected = bSelected
        }
        self.curMoneyUnitBtn = button
        
        var moneyUnit = 1.0
        
        switch button {
        case self.twoYuanBtn:
            moneyUnit = 1.0
        case self.oneYuanBtn:
            moneyUnit = 0.5
        case self.twoJiaoBtn:
            moneyUnit = 0.1
        case self.oneJiaoBtn:
            moneyUnit = 0.05
        case self.twoFenBtn:
            moneyUnit = 0.01
        case self.twoLiBtn:
            moneyUnit = 0.001
        default:
            moneyUnit = 1.0
        }
        
        if self.moneyUnitClosures != nil {
            self.moneyUnitClosures!(moneyUnit)
        }
        
    }
    
//    func traceWinStopBtnClick(_ button: UIButton) {
//        button.isSelected = !button.isSelected
//    }
    
    //MARK: - Private methods
    
    @objc fileprivate func keyboardWillShow(_ notice: Notification) {
        self.tableView.isUserInteractionEnabled = false
        
        let endRect = (notice.userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let duration = (notice.userInfo![UIKeyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        
        let offsetY = self.bottomView.frame.height -  endRect.height
        if offsetY != 0 {
            UIView.animate(withDuration: duration, animations: {
                self.toolbarView.transform = CGAffineTransform(translationX: 0, y: offsetY)
            })
        }
    }
    
    @objc fileprivate func keyboardWillHide(_ notice: Notification) {
        self.tableView.isUserInteractionEnabled = true
        
        let duration = (notice.userInfo![UIKeyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        UIView.animate(withDuration: duration) {
            self.toolbarView.transform = CGAffineTransform.identity
        }
        
    }
    
    fileprivate func makeConstraintsForSubviews() {
        
        self.topView.snp.makeConstraints { (make) in
            make.left.top.right.equalTo(self)
            make.height.equalTo(110)
        }
        self.awardPeriodLabel.snp.makeConstraints { (make) in
            make.top.equalTo(self.periodTipsLabel)
            make.right.equalTo(self.periodTipsLabel.snp.left)
        }
        self.periodTipsLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(20)
            make.right.lessThanOrEqualTo(self.topView.snp.centerX)
        }
        self.coutdownLabel.snp.makeConstraints { (make) in
            make.top.equalTo(self.periodTipsLabel)
            make.left.equalTo(self.periodTipsLabel.snp.right).offset(10)
        }

        self.onceAgainBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-20)
            make.width.equalTo(105)
            make.height.equalTo(45)
        }
        
        self.tableView.snp.makeConstraints { (make) in
            make.top.equalTo(self.topView.snp.bottom).offset(10)
            make.left.right.equalToSuperview()
            make.bottom.equalTo(self.toolbarView.snp.top)
        }
        
        self.toolbarView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(self.bottomView.snp.top)
            make.height.equalTo(47.5)
        }
        self.toolbarSeperatorLine.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(1)
        }
        self.bettingTitleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.centerY.equalToSuperview()
        }
        self.mutipleFiled.snp.makeConstraints { (make) in
            make.left.equalTo(self.bettingTitleLabel.snp.right).offset(5)
            make.centerY.equalToSuperview()
            make.height.equalTo(27.5)
            make.width.equalTo(40)
        }
        self.mutipleTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.mutipleFiled.snp.right).offset(5)
            make.centerY.equalToSuperview()
        }
        self.aiPeriodBtn.snp.makeConstraints { (make) in
            make.left.equalTo(mutipleTitleLabel.snp.right).offset(15)
            make.centerY.equalTo(mutipleFiled)
            make.width.equalTo(70)
            make.height.equalTo(mutipleFiled)
        }
        
        self.chasingButton.snp.makeConstraints { (make) in
            make.height.equalTo(27.5)
            make.width.equalTo(self.toolbarView.snp.height)
            make.right.equalToSuperview().offset(-15)
            make.centerY.equalToSuperview()
        }
        
        self.label_moshi.snp.makeConstraints { (make) in
            make.right.equalTo(self.chasingButton.snp.left)
            make.centerY.equalToSuperview()
        }
        
        self.bottomView.snp.makeConstraints { (make) in
            make.left.bottom.right.equalToSuperview()
            make.height.equalTo(49)
        }
        self.totalBettingTips.snp.makeConstraints { (make) in
            make.left.equalTo(15)
            make.top.equalToSuperview().offset(5)
        }
        self.bettingCount.snp.makeConstraints { (make) in
            make.left.equalTo(self.totalBettingTips.snp.right)
            make.centerY.equalTo(self.totalBettingTips)
        }
        self.bettingTipsWord.snp.makeConstraints { (make) in
            make.left.equalTo(self.bettingCount.snp.right)
            make.centerY.equalTo(self.totalBettingTips)
        }
        self.amountLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.bettingTipsWord.snp.right)
            make.centerY.equalTo(self.totalBettingTips)
        }
        self.yuanAmontLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.amountLabel.snp.right)
            make.centerY.equalTo(self.totalBettingTips)
        }
        self.balanceTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.totalBettingTips)
            make.top.equalTo(self.totalBettingTips.snp.bottom).offset(5)
        }
        self.balanceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.balanceTitleLabel.snp.right)
            make.centerY.equalTo(self.balanceTitleLabel)
        }
        self.yuanBalanceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.balanceLabel.snp.right)
            make.centerY.equalTo(self.balanceTitleLabel)
        }
        self.confirmBettingBtn.snp.makeConstraints { (make) in
            make.top.right.bottom.equalToSuperview()
            make.width.equalTo(115)
        }
        
        self.modeView.snp.makeConstraints { (make) in
            make.bottom.equalTo(self.toolbarView.snp.top)
            make.right.equalToSuperview().offset(-15)
            make.left.equalToSuperview().offset(15)
            make.height.equalTo(100)
        }
        self.modeTips.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(10)
            make.centerY.equalTo(self.twoYuanBtn)
        }
        self.twoYuanBtn.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(15)
            make.left.equalTo(self.modeTips.snp.right).offset(15)
            make.width.equalTo(30)
            make.height.equalTo(32.5)
        }
        self.oneYuanBtn.snp.makeConstraints { (make) in
            make.top.width.height.equalTo(self.twoYuanBtn)
            make.left.equalTo(self.twoYuanBtn.snp.right).offset(5)
        }
        self.twoJiaoBtn.snp.makeConstraints { (make) in
            make.top.width.height.equalTo(self.twoYuanBtn)
            make.left.equalTo(self.oneYuanBtn.snp.right).offset(5)
        }
        self.oneJiaoBtn.snp.makeConstraints { (make) in
            make.top.width.height.equalTo(self.twoYuanBtn)
            make.left.equalTo(self.twoJiaoBtn.snp.right).offset(5)
        }
        self.twoFenBtn.snp.makeConstraints { (make) in
            make.top.width.height.equalTo(self.twoYuanBtn)
            make.left.equalTo(self.oneJiaoBtn.snp.right).offset(5)
        }
        self.twoLiBtn.snp.makeConstraints { (make) in
            make.top.width.height.equalTo(self.twoYuanBtn)
            make.left.equalTo(self.twoFenBtn.snp.right).offset(5)
        }
        self.rebateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.modeTips)
            make.top.equalTo(self.modeTips.snp.bottom).offset(20)
            make.width.equalTo(50)
        }
        self.priceGroupSlider.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.rebateLabel)
            make.left.equalTo(self.rebateLabel.snp.right).offset(5)
            make.width.equalTo(115)
        }
        self.priceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self.priceGroupSlider.snp.right).offset(5)
            make.centerY.equalTo(self.priceGroupSlider)
        }
//        self.traceWinStopBtn.snp.makeConstraints { (make) in
//            make.right.equalToSuperview().offset(-5)
//            make.centerY.equalTo(self.priceLabel)
//            make.height.equalTo(30)
//            make.width.equalTo(75)
//        }
    }
    
}
