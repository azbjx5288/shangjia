//
//  LotteryAIPeriodBettingConfirmViewController.swift
//  GoldenApple
//
//  Created by El Capitan on 24/08/2018.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class LotteryAIPeriodBettingConfirmViewController: UIViewController {
    
    fileprivate let logoIV: UIImageView = {
        let iv = UIImageView()
        
        return iv;
    }()
    
    fileprivate let nameLbl: UILabel = {
        let lbl = UILabel()
        lbl.textColor = .black
        lbl.font = UIFont.systemFont(ofSize: 15)
        
        return lbl
    }()
    
    fileprivate let startLbl: UILabel = {
        let lbl = UILabel()
        lbl.textColor = .black
        lbl.font = UIFont.systemFont(ofSize: 15)
        
        return lbl
    }()
    
    fileprivate let detailLbl: UILabel = {
        let lbl = UILabel()
        lbl.numberOfLines = 0
        lbl.textColor = .black
        lbl.font = UIFont.systemFont(ofSize: 15)
        lbl.contentMode = .topLeft
        
        return lbl
    }()
    
    var submitClosure: (() -> Void)?
    
    var dataDic: NSDictionary?
    
    deinit {
        print("LotteryAIPeriodBettingConfirmViewController deinit!!!")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        configUI()
        configData()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        detailLbl.sizeToFit()
    }
    

// MARK: - private method
    fileprivate func configUI() {
        view.backgroundColor = .white
        view.layer.cornerRadius = 6
        view.clipsToBounds = true
        
        let lbl = UILabel()
        view.addSubview(lbl)
        lbl.backgroundColor = RGBCOLOR(240, 240, 240)
        lbl.text = "投注确认"
        lbl.font = UIFont.systemFont(ofSize: 18)
        lbl.textAlignment = .center
        lbl.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(44)
        }
        
        var sepLine = UIView()
        sepLine.backgroundColor = UIColor.lightGray
        view.addSubview(sepLine)
        sepLine.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.height.equalTo(1)
            make.top.equalTo(lbl.snp.bottom)
        }
        
        let startX = 40
        view.addSubview(logoIV)
        logoIV.snp.makeConstraints { (make) in
            make.left.equalTo(startX)
            make.top.equalTo(sepLine.snp.bottom).offset(20)
            make.width.height.equalTo(50)
        }
        
        view.addSubview(nameLbl)
        nameLbl.snp.makeConstraints { (make) in
            make.left.equalTo(logoIV.snp.right).offset(15)
            make.top.equalTo(logoIV)
        }
        
        view.addSubview(startLbl)
        startLbl.snp.makeConstraints { (make) in
            make.left.equalTo(nameLbl)
            make.bottom.equalTo(logoIV)
        }
        
        sepLine = UIView()
        sepLine.backgroundColor = UIColor.lightGray
        view.addSubview(sepLine)
        sepLine.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.height.equalTo(1)
            make.top.equalTo(startLbl.snp.bottom).offset(10)
        }
        
        view.addSubview(detailLbl)
        detailLbl.snp.makeConstraints { (make) in
            make.left.equalTo(startX)
            make.right.equalTo(-startX)
            make.top.equalTo(sepLine.snp.bottom).offset(20)
            
        }
        
        sepLine = UIView()
        sepLine.backgroundColor = UIColor.lightGray
        view.addSubview(sepLine)
        sepLine.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.height.equalTo(1)
            make.top.equalTo(detailLbl.snp.bottom).offset(20)
        }
        
        let cancelBtn = UIButton(type: .custom)
        cancelBtn.setTitle("取消", for: .normal)
        view.addSubview(cancelBtn)
        cancelBtn.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        cancelBtn.snp.makeConstraints { (make) in
            make.left.bottom.equalToSuperview()
            make.top.equalTo(sepLine.snp.bottom)
            make.height.equalTo(44)
            make.width.equalToSuperview().multipliedBy(0.5)
        }
        cancelBtn.setTitleColor(.black, for: .normal)
        cancelBtn.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        let okBtn = UIButton(type: .custom)
        okBtn.setTitle("确认投注", for: .normal)
        okBtn.setTitleColor(.black, for: .normal)
        view.addSubview(okBtn)
        okBtn.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        okBtn.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview()
            make.top.equalTo(cancelBtn)
            make.width.equalToSuperview().multipliedBy(0.5)
        }
        okBtn.addTarget(self, action: #selector(submitBetting), for: .touchUpInside)
        
        sepLine = UIView()
        sepLine.backgroundColor = UIColor.lightGray
        view.addSubview(sepLine)
        sepLine.snp.makeConstraints { (make) in
            make.left.equalTo(cancelBtn.snp.right)
            make.width.equalTo(1)
            make.top.bottom.equalTo(cancelBtn)
        }
    }
    
    func configData() {
        let lotteryId = GACacheManager.default.getCurrentLotteryId()
        let icon = GACacheManager.default.getLotteryIcon(lotteryId:lotteryId)
        let lotteryDic = GACacheManager.default.getLotteryDictionary(lotteryId: lotteryId)
        
        logoIV.image = UIImage.init(named: icon!)
        nameLbl.text = lotteryDic?.object(forKey: LotteryListAPIManager.DataKey.kName) as? String
        startLbl.text = "起始期号:\(dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kLotteryNumber) as! String)"
        
        var modeStr = ""
        let moneyUnit = dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMoneyunit) as! NSNumber
        switch moneyUnit.floatValue {
        case 1:
            modeStr = "2元"
        case 0.5:
            modeStr = "1元"
        case 0.1:
            modeStr = "2角"
        case 0.05:
            modeStr = "1角"
        case 0.01:
            modeStr = "分"
        case 0.001:
            modeStr = "厘"
        default:
            break
        }
        let isTrace = dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kIsTrace) as! Bool
        let isTraceStr = isTrace ? "是" : "否"
        detailLbl.text =
            "请确认以下投注内容：\n" +
            "***********************\n" +
            "追中即停：\(isTraceStr)\n" +
            "起始期号：\(dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kLotteryNumber) as! String)\n" +
            "单倍注数：\(dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kNum) as! NSNumber)注\n" +
            "模 式：\(modeStr)模式\n" +
            "倍 数：\(dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple) as! String)倍\n" +
            "追号期数：\(dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kTotalPeriod) as! NSNumber)\n" +
            "总金额：¥\(dataDic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kAmount) as! String)\n" +
        "***********************"
    }
    
    @objc
    fileprivate func back() {
        dismiss(animated: false, completion: nil)
    }
    
    @objc
    fileprivate func submitBetting() {
        if let closure = submitClosure {
            closure()
        }
        dismiss(animated: false, completion: nil)
    }

}
