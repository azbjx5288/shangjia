//
//  LotteryAIPeriodBettingConfirmView.swift
//  GoldenApple
//
//  Created by El Capitan on 24/08/2018.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class LotteryAIPeriodBettingConfirmView: UIView {

    fileprivate let logoIV: UIImageView = {
        let iv = UIImageView()
        
        return iv;
    }()
    
    fileprivate let nameLbl: UILabel = {
        let lbl = UILabel()
        
        return lbl
    }()
    
    fileprivate let startLbl: UILabel = {
        let lbl = UILabel()
        
        return lbl
    }()

    fileprivate func configUI() {
    
    }
}
