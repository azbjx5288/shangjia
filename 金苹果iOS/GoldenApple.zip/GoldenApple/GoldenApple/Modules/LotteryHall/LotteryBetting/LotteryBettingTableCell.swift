//
//  LotteryBettingTableCell.swift
//  GoldenApple
//
//  Created by User on 06/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryBettingTableCell: UITableViewCell {
    
    let methodTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = "XX"
        
        return label
    }()
    
    let numberLabel: UITextView = {
        let label = UITextView()
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = "00"
        label.textAlignment = .left
        label.textColor = kGAFontGrayColor
        label.isUserInteractionEnabled = false
        return label
    }()
    
    let bettingCountLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = "0"
        
        return label
    }()
    
    fileprivate let bettingCountTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = "注"
        
        return label
    }()
    
    let deleteRowBtn: UIButton = {
        let button = UIButton(type: UIButtonType.custom)
        button.setBackgroundImage(UIImage(named: "cancel-button"), for: UIControlState.normal)
        return button
    }()
    
    fileprivate let seperatorLine: UIView = {
        let view = UIView()
        view.backgroundColor = kGASerperatorLineGrayColor
        
        return view
    }()
    
    var deleteItemBlock: (() -> Void)?
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.contentView.backgroundColor = UIColor.white
        
        self.contentView.addSubview(self.methodTitleLabel)
        self.contentView.addSubview(self.numberLabel)
        self.contentView.addSubview(self.bettingCountLabel)
        self.contentView.addSubview(self.bettingCountTitleLabel)
        self.contentView.addSubview(self.deleteRowBtn)
        self.contentView.addSubview(self.seperatorLine)
        
        self.deleteRowBtn.addTarget(self, action: #selector(deleteRowBtnClick), for: UIControlEvents.touchUpInside)
        
        self.methodTitleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.top.equalToSuperview().offset(10)
            make.height.equalTo(30)
        }
        self.numberLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.numberLabel.superview!)
            make.top.equalTo(self.methodTitleLabel.snp.bottom).offset(5)
            make.width.equalTo(UIScreen.main.bounds.size.width - 30)
            make.height.equalTo(20)
            make.bottom.equalToSuperview().offset(-10)
        }
        self.bettingCountLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.methodTitleLabel)
            make.right.equalTo(self.bettingCountTitleLabel.snp.left)
        }
        self.bettingCountTitleLabel.snp.makeConstraints { (make) in
            make.right.equalTo(self.deleteRowBtn.snp.left).offset(-15)
            make.centerY.equalTo(self.bettingCountLabel)
        }
        self.deleteRowBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.methodTitleLabel)
            make.right.equalToSuperview().offset(-15)
            make.width.height.equalTo(22.5)
        }
        
        self.seperatorLine.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func setBettingDict(_ bettingDict: NSDictionary) {
        
        let titleName = bettingDict[LotteryBettingViewController.DataKey.kTitleName] as? String
        let bettingCount = bettingDict[LotteryBettingViewController.DataKey.kNum] as! Int
        let bettingNumber = bettingDict[LotteryBettingViewController.DataKey.kBall] as? String
        
        self.methodTitleLabel.text = titleName
        self.bettingCountLabel.text = String(format: "%ld", bettingCount)
        self.numberLabel.text = bettingNumber
        let size = self.numberLabel.sizeThatFits(CGSize.init(width: UIScreen.main.bounds.size.width - 30, height: CGFloat.greatestFiniteMagnitude))
        self.numberLabel.snp.updateConstraints { (make) in
            make.height.equalTo(size.height + 2)
        }
    }
    
    func deleteRowBtnClick() {
        
        if self.deleteItemBlock != nil {
            self.deleteItemBlock!()
        }
    }
}
