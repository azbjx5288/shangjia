//
//  ProfitTraceTableViewCell.swift
//  GoldenApple
//
//  Created by El Capitan on 06/08/2018.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class ProfitTraceTableViewCell: UITableViewCell {
    static let cellIdentifier = "ProfitTraceTableViewCell"
    
    static let itemWidth: CGFloat = 100
    static let itemPadding: CGFloat = 10
    
    static let profitSelectBtnStartTag = 100000
    static let profitMultiFieldStartTag = 200000
    
    fileprivate var _dic: NSMutableDictionary?
    var dic: NSMutableDictionary? {
        set {
            _dic = newValue
            updateUI()
        }
        get {
            return _dic
        }
    }
    
    let selectButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        
        return button
    }()
    
    let periodLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = ""
        
        return label
    }()
    
    let mutipleFiled: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "1"
        field.font = UIFont.systemFont(ofSize: 14)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    let amountLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.textAlignment = .center
        label.text = "¥ 1234567.00元"
        label.numberOfLines = 2
        
        return label
    }()
    
    let rewardLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.textAlignment = .center
        label.text = "¥ 1234567.00元"
        label.numberOfLines = 2
        
        return label
    }()
    
    let expectedRewardLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.textAlignment = .center
        label.text = "¥ 12567.00元"
        label.numberOfLines = 2
        
        return label
    }()
    
    let expectedRateLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.textAlignment = .center
        label.text = "90.00%"
        
        return label
    }()
    
    let sepLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = kGASerperatorLineGrayColor
        
        return label
    }()
    
    var totalCount = 0
    var price = 0
    var moneyUnit = 0.0
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        contentView.addSubview(selectButton)
        contentView.addSubview(periodLabel)
        contentView.addSubview(mutipleFiled)
        contentView.addSubview(amountLabel)
        contentView.addSubview(rewardLabel)
        contentView.addSubview(expectedRewardLabel)
        contentView.addSubview(expectedRateLabel)
        contentView.addSubview(sepLabel)
        
        selectButton.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
        }
        
        periodLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(50)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        
        mutipleFiled.snp.makeConstraints { (make) in
            make.left.equalTo(periodLabel.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(60)
            make.height.equalTo(30)
        }
        
        amountLabel.snp.makeConstraints { (make) in
            make.left.equalTo(mutipleFiled.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        
        rewardLabel.snp.makeConstraints { (make) in
            make.left.equalTo(amountLabel.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        
        expectedRewardLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rewardLabel.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
        }
        
        expectedRateLabel.snp.makeConstraints { (make) in
            make.left.equalTo(expectedRewardLabel.snp.right).offset(ProfitTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-15)
            make.width.equalTo(ProfitTraceTableViewCell.itemWidth)
            
        }
        
        sepLabel.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
        
        selectionStyle = .none
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    fileprivate func updateUI() {
        periodLabel.text =  (dic?.object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String)
        mutipleFiled.text = (dic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
            as! String)
        let multi = (mutipleFiled.text! as NSString).doubleValue
        let total = Double(totalCount) * Double(price) * moneyUnit * multi
        amountLabel.text = String(format: "¥ %.3lf元", total)
        selectButton.isSelected = dic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool

        rewardLabel.text = String(format: "¥ %.3lf元", dic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kProfitSingleReward) as! Double)
        
        expectedRewardLabel.text = String(format: "¥ %.3lf元", dic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kProfitExpectedReward) as! Double)
        
        expectedRateLabel.text = String(format: "%.02f%%", dic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kProfitExpectedRate) as! Double * 100)
        
    }

}
