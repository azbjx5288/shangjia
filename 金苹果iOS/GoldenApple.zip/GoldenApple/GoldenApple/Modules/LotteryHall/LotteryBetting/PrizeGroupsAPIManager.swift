//
//  PrizeGroupsAPIManager.swift
//  GoldenApple
//
//  Created by User on 21/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class PrizeGroupsAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        
        /// 奖金组数量
        static let kCount = "count"
        
        /// 奖金组列表，正序排列
        static let kGroups = "groups"
    }
    
}

extension PrizeGroupsAPIManager: LYAPIManager {
    
    public func methodName() -> NSString {
        return "service?packet=Game&action=getAvailablePrizeGroups"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return true
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
}

extension PrizeGroupsAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        guard let prizeGoupsDict = data.object(forKey: "data") as? NSDictionary else { return nil }
        
        return prizeGoupsDict
    }
    
    
    
}

