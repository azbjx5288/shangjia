//
//  BettingAPIManager.swift
//  GoldenApple
//
//  Created by User on 20/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class BettingAPIManager: GAAPIBaseManager {

}

extension BettingAPIManager: LYAPIManager {
    
    public func methodName() -> NSString {
        return "service?packet=Game&action=bet"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .post
    }
    
    public func shouldCache() -> Bool {
        return true
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
}

extension BettingAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        guard let bettingIdDict = data.object(forKey: "data") as? NSDictionary else { return nil }
        
        return bettingIdDict
    }
    
}
