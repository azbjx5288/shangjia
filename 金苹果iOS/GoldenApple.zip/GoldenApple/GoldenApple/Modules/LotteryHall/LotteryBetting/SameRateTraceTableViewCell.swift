//
//  SameRateTraceTableViewCell.swift
//  GoldenApple
//
//  Created by El Capitan on 03/08/2018.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class SameRateTraceTableViewCell: UITableViewCell {
    
    static let cellIdentifier = "SameRateTraceTableViewCell"
    
    static let sameSelectBtnStartTag = 100000
    static let sameMultiFieldStartTag = 200000
    static let doubleSelectBtnStartTag = 300000
    static let doubleMultiFieldStartTag = 400000
    
    static let itemWidth: CGFloat = 100
    static let itemPadding: CGFloat = 10
    
    let selectButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(named: "traceWinStopNormal"), for: UIControlState.normal)
        button.setImage(UIImage(named: "traceWinStopSelected"), for: UIControlState.selected)
        
        return button
    }()
    
    let periodLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.text = ""
        
        return label
    }()
    
    let mutipleFiled: UITextField = {
        let field = UITextField()
        field.keyboardType = .numberPad
        field.text = "1"
        field.font = UIFont.systemFont(ofSize: 14)
        field.textAlignment = .center
        field.layer.borderWidth = 1
        field.layer.borderColor = kGASerperatorLineGrayColor.cgColor
        field.layer.masksToBounds = true
        
        return field
    }()
    
    let amountLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = kGAFontBlackColor
        label.textAlignment = .right
        label.text = "¥ 1234567.00元"
        
        return label
    }()
    
    let sepLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = kGASerperatorLineGrayColor
        
        return label
    }()
    
    fileprivate var _dic: NSMutableDictionary?
    
    var dic: NSMutableDictionary? {
        set {
            _dic = newValue
            updateUI()
        }
        get {
            return _dic
        }
    }
    
    var totalCount = 0
    var price = 0
    var moneyUnit = 0.0

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        contentView.backgroundColor = .white
        
        contentView.addSubview(selectButton)
        contentView.addSubview(periodLabel)
        contentView.addSubview(mutipleFiled)
        contentView.addSubview(amountLabel)
        contentView.addSubview(sepLabel)
        
        selectButton.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
        }
        
        periodLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(50)
            make.centerY.equalToSuperview()
            make.width.equalTo(SameRateTraceTableViewCell.itemWidth)
        }
        
        mutipleFiled.snp.makeConstraints { (make) in
            make.left.equalTo(periodLabel.snp.right).offset(SameRateTraceTableViewCell.itemPadding)
            make.centerY.equalToSuperview()
            make.width.equalTo(60)
            make.height.equalTo(30)
        }
        
        amountLabel.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalToSuperview()
            make.leading.equalTo(mutipleFiled.snp.trailing).offset(SameRateTraceTableViewCell.itemPadding)
            
        }
        
        sepLabel.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
        
        selectionStyle = .none
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate func updateUI() {
        periodLabel.text =  (dic?.object(forKey: TraceIssueAPIManager.DataKey.kNumber) as! String)
        mutipleFiled.text = (dic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kMultiple as NSCopying)
            as! String)
        let multi = (mutipleFiled.text! as NSString).doubleValue
        let total = Double(totalCount) * Double(price) * moneyUnit * multi
        amountLabel.text = String(format: "¥ %.3lf元", total)
        selectButton.isSelected = dic?.object(forKey: LotteryAIPeriodBettingViewController.DataKey.kSelectStatus as NSCopying) as! Bool
    
    }

}
