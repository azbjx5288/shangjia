//
//  LotteryMethodViewController.swift
//  GoldenApple
//
//  Created by User on 08/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryMethodViewController: UIViewController {
    
    static let cellIdentifier = "LotteryMethodCell"
    static let headerIdentifer = "LotteryMethodSectionHeader"
    
    var methodInfoList: [NSDictionary]? {
        didSet {
            self.collectionView.reloadData()
        }
    }
    
    let collectionView: UICollectionView = {
        
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.minimumLineSpacing = 10
        flowLayout.minimumInteritemSpacing = 10
        
        flowLayout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        flowLayout.headerReferenceSize = CGSize(width: 100, height: 35)
        
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: flowLayout)
        return collection
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = UIColor.blue
        self.view.addSubview(self.collectionView)
        self.collectionView.backgroundColor = UIColor.white
        
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.collectionView.register(LotteryMethodCell.classForCoder(), forCellWithReuseIdentifier: LotteryMethodViewController.cellIdentifier)
        self.collectionView.register(LotteryMethodSectionHeader.classForCoder(), forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: LotteryMethodViewController.headerIdentifer)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
//        self.collectionView.reloadData()
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        self.collectionView.frame = self.view.bounds
    }

}

extension LotteryMethodViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return self.methodInfoList != nil ? self.methodInfoList!.count : 0
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if self.methodInfoList == nil {
            return 0
        }
        
        let methodGroupDict = self.methodInfoList![section]
        let methodInfo = methodGroupDict.object(forKey: MethodListAPIManager.DataKey.kMehtodDetail) as! [NSDictionary]
        
        return methodInfo.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LotteryMethodViewController.cellIdentifier, for: indexPath) as! LotteryMethodCell
        
        let methodGroupDict = self.methodInfoList![indexPath.section]
        let methodInfo = methodGroupDict.object(forKey: MethodListAPIManager.DataKey.kMehtodDetail) as! [NSDictionary]
        cell.methodLabel.text = (methodInfo[indexPath.item].object(forKey: MethodListAPIManager.DataKey.kNameCn) as! String)
        
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        if kind == UICollectionElementKindSectionHeader {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: LotteryMethodViewController.headerIdentifer, for: indexPath) as! LotteryMethodSectionHeader
            
            let methodGroupDict = self.methodInfoList![indexPath.section]
            header.titleLabel.text = (methodGroupDict.object(forKey: MethodListAPIManager.DataKey.kNameCn) as! String)
            
            return header
            
        }
        
        return UICollectionReusableView()
    }
    
}

extension LotteryMethodViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let methodGroupDict = self.methodInfoList![indexPath.section]
        let methodInfoList = methodGroupDict.object(forKey: MethodListAPIManager.DataKey.kMehtodDetail) as! [NSDictionary]
        
        let name = methodGroupDict.object(forKey: MethodListAPIManager.DataKey.kNameCn) as! String
        LotteryRulesOfPlay.default.setLotteryMethodDict(dict: methodInfoList[indexPath.item], mainGroupName: name)
        
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension LotteryMethodViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let methodGroupDict = self.methodInfoList![indexPath.section]
        let methodInfo = methodGroupDict.object(forKey: MethodListAPIManager.DataKey.kMehtodDetail) as! [NSDictionary]
        
        let title = (methodInfo[indexPath.item].object(forKey: MethodListAPIManager.DataKey.kNameCn) as! NSString)
        
        return title.size(attributes: [NSFontAttributeName : UIFont.systemFont(ofSize: LotteryMethodCell.methodFontSize + 5)])
    }
    
}
