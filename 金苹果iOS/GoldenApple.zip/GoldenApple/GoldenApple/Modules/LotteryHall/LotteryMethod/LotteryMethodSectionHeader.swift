//
//  LotteryMethodSectionHeader.swift
//  GoldenApple
//
//  Created by User on 07/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryMethodSectionHeader: UICollectionReusableView {
    
    let titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.textColor = kGAFontBlackColor
        
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.titleLabel)
        self.titleLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(20)
        }
        self.backgroundColor = kGABallGrayColor
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
    
}
