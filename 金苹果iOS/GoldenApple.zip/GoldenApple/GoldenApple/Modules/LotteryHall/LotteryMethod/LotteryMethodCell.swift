//
//  LotteryMethodCell.swift
//  GoldenApple
//
//  Created by User on 07/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryMethodCell: UICollectionViewCell {
    
    static let methodFontSize: CGFloat = 13.0
    
    let methodLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: LotteryMethodCell.methodFontSize)
        label.textColor = kGAFontGrayColor
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(self.methodLabel)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.methodLabel.frame = self.bounds
    }
    
    override var isSelected: Bool {
        didSet {
            if isSelected {
                self.methodLabel.textColor = kGAFontRedColor
            } else {
                self.methodLabel.textColor = kGAFontGrayColor
            }
        }
    }
    
}
