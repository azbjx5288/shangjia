//
//  GAGameViewController.swift
//  GoldenApple
//
//  Created by User on 29/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import WebKit

class GAGameViewController: GAWKWebViewController {
    
    /// 是否是试玩模式
    var isTryMode = false
    
    fileprivate var apiManager = GAGameAPIManager()
    
    fileprivate var lotteryIdentifier: String
    
    fileprivate var isAddSMH = false

    required init(lotteryIdentifier: String) {
        
        self.lotteryIdentifier = lotteryIdentifier
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.lotteryIdentifier = ""
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        if self.isAddSMH {
            self.webView.configuration.userContentController.removeScriptMessageHandler(forName: "exitWKWebViewController")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.webView.configuration.userContentController.add(self, name: "exitWKWebViewController")
        self.isAddSMH = true
        self.apiManager.delegate = self
        self.apiManager.paramSource = self

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.apiManager.loadData()
    }

    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        
        return .landscapeLeft
    }
    
    fileprivate func exitWKWebViewController() {
        
        if self.navigationController != nil {
            self.navigationController!.popViewController(animated: true)
        } else {
            self.webView.reload()
            self.dismiss(animated: true, completion: nil)
        }
    }

}

extension GAGameViewController: LYAPIManagerCallBackDelegate {
    
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        
        if manager == self.apiManager {
            guard let resultDict = manager.fetchData(self.apiManager) as? NSDictionary else { return }
            
            if self.isTryMode {
                let freeUrl = resultDict[GAGameAPIManager.DataKey.kFreePlayUrl] as! String
                let urlRequest = URLRequest(url: URL(string: freeUrl)!)
                self.webView.load(urlRequest)
            } else {
                let requestUrl = resultDict[GAGameAPIManager.DataKey.kRequestUrl] as! String
                let urlRequest = URLRequest(url: URL(string: requestUrl)!)
                self.webView.load(urlRequest)
            }
            
//            print("GAGameViewController----\(requestUrl)")
        }
        
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        
        let errorDict = manager.fetchFailedRequestMsg(nil) as? NSDictionary
        if errorDict != nil {
            let errorString = errorDict!.object(forKey: "error") as! String
            GAProgressHUD.showError(message: errorString)
        }
        
    }
    
    
}

extension GAGameViewController: LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        return ["lottery": self.lotteryIdentifier]
    }
    
    
}

extension GAGameViewController: WKScriptMessageHandler {
    
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        
        if message.name == "exitWKWebViewController" {
            self.exitWKWebViewController()
        }
        
        
    }
    
    
}
