//
//  GAGameAPIManager.swift
//  GoldenApple
//
//  Created by User on 29/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class GAGameAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        
        /// 外接彩种的大厅地址
        static let kRequestUrl = "request_url"
        /// 外接彩种的大厅试玩地址
        static let kFreePlayUrl = "free_play_url"
    }

}

extension GAGameAPIManager: LYAPIManager {
    
    public func methodName() -> NSString {
        return "service?packet=Game&action=getThirdLotteryLink"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
    
}

extension GAGameAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let resultDict = data.object(forKey: "data") as? NSDictionary else { return nil }
        
        return resultDict
    }
}
