//
//  LotteryMenuSectionFooter.swift
//  GoldenApple
//
//  Created by El Capitan on 2018/3/8.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

class LotteryMenuSectionFooter: UICollectionReusableView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = kGASerperatorLineGrayColor
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    }
}
