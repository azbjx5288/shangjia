//
//  MessageAPIManager.swift
//  GoldenApple
//
//  Created by User on 2018/8/17.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import Foundation

class MessageAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        static let is_show = "is_show"
    }
    
}

extension MessageAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Message&action=GetLetterInfo"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return false
    }
    
}


extension MessageAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        guard let bannerDictList = data.object(forKey: "data") as? NSDictionary else { return nil }
        
        return bannerDictList
    }
}
