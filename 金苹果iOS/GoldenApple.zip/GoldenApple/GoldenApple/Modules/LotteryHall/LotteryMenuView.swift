//
//  LotteryMenuView.swift
//  GoldenApple
//
//  Created by El Capitan on 2018/3/7.
//  Copyright © 2018年 GoldenMango. All rights reserved.
//

import UIKit

let indicatorWidth : CGFloat = 5.0

protocol LotteryMenuViewDelegate {
    func selectedItem(index : Int)
    func childMenuStatusChanges(isOpen : Bool)
}

class LotteryMenuView: UIView {

    private var _index = 0
    var index : Int {
        set {
            _index = newValue
            self.indexChanged()
        }
        get {
            return _index
        }
    }
    
    private var _isOpenChildMenu = false
    var isOpenChildMenu : Bool {
        set {
            _isOpenChildMenu = newValue
            self.isOpenChildMenuChanged()
        }
        get {
            return _isOpenChildMenu
        }
    }
    
    var delegate : LotteryMenuViewDelegate?
    
    private let itemSettingArray = [["rightIcon" : "lottery", "title" : "购彩大厅"],
                             ["rightIcon" : "gagame", "title" : "GA游戏"]
                            ]
    
    private let indicatorView : UIView = {
        let view = UIView()
        view.backgroundColor = kGANavigationBackgroundColor
        view.layer.cornerRadius = indicatorWidth * 0.5
        return view
    }()
    private let bottomLine : UIView = {
        let view = UIView()
        view.backgroundColor = kGASerperatorLineGrayColor
        return view
    }()
    
    private let arrowImageView : UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage.init(named: "allow_down_sel")
        return imageView
    }()
    
    private var items : NSMutableArray = NSMutableArray()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        for i in 0...itemSettingArray.count - 1 {
            let btn = UIButton()
            btn.index = i
            let rightIcon = (itemSettingArray[i] as NSDictionary).value(forKey: "rightIcon") as! String
            let rightSelectIcon = rightIcon + "press"
            let title = (itemSettingArray[i] as NSDictionary).value(forKey: "title") as! String
            btn.setImage(UIImage.init(named: rightIcon), for: .normal)
            btn.setImage(UIImage.init(named: rightSelectIcon), for: .selected)
            btn.setTitle(title, for: .normal)
            btn.setTitleColor(kGAFontGrayColor, for: .normal)
            btn.setTitleColor(kGAFontRedColor, for: .selected)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 17)
            btn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0)
            btn.addTarget(self, action: #selector(selectedItem(_ :)), for: .touchUpInside)
            self.addSubview(btn)
            self.items.add(btn)
        }
        self.addSubview(self.bottomLine)
        self.addSubview(self.indicatorView)
        self.addSubview(self.arrowImageView)
        
        self.setSubViewConstraints()
        
        (self.items.firstObject as! UIButton).isSelected = true
    }
    
   @objc private func selectedItem(_ sender : UIButton) {
        if sender.index == self.index {
            if sender.index == 0 {
                self.isOpenChildMenu = !self.isOpenChildMenu
            }
            return
        }
        if sender.index != 0 {
            self.isOpenChildMenu = false
        }
        for i in 0...items.count - 1 {
            let btn = items[i] as! UIButton
            btn.isSelected = false
        }
        sender.isSelected = true
        self.index = sender.index
    }
    
    private func indexChanged() {
        let width = UIScreen.main.bounds.size.width / CGFloat(self.items.count)
        self.indicatorView.snp.updateConstraints { (make) in
            make.centerX.equalTo(self.items.firstObject as! UIButton).offset(CGFloat(self.index) * width)
        }
        UIView.animate(withDuration: 0.3) {
            self.indicatorView.superview?.layoutIfNeeded()
        }
        
        if self.delegate != nil {
            self.delegate?.selectedItem(index: self.index)
        }
        if index != 0 {
            self.arrowImageView.isHidden = true
        } else {
            self.arrowImageView.isHidden = false
        }
    }
    
    private func isOpenChildMenuChanged() {
        if self.isOpenChildMenu {
            self.transformImageView(imageView: self.arrowImageView, rotationAngle: Double.pi)
        } else {
            self.transformImageView(imageView: self.arrowImageView, rotationAngle: Double.pi * 2)
        }
        if self.delegate != nil {
            self.delegate?.childMenuStatusChanges(isOpen: self.isOpenChildMenu)
        }
    }
    
    func setSubViewConstraints() {
        let width = UIScreen.main.bounds.width/CGFloat(items.count)
        for i in 0...items.count - 1 {
            let btn = items[i] as! UIButton
            btn.snp.makeConstraints({ (make) in
                make.width.equalTo(width)
                make.height.equalTo(self)
                make.top.equalTo(self)
                make.left.equalTo(self).offset(width * CGFloat(i))
            })
        }
        self.bottomLine.snp.makeConstraints { (make) in
            make.height.equalTo(1)
            make.left.right.equalTo(self)
            make.bottom.equalTo(self)
        }
        self.indicatorView.snp.makeConstraints { (make) in
            make.width.equalTo(indicatorWidth)
            make.height.equalTo(indicatorWidth)
            make.bottom.equalTo(self).offset(-8)
            make.centerX.equalTo(self.items.firstObject as! UIButton).offset(0)
        }
        self.arrowImageView.snp.makeConstraints { (make) in
            make.centerY.equalTo(self);
            make.width.height.equalTo(15);
            make.left.equalTo((self.items.firstObject as! UIButton).titleLabel!.snp.right).offset(2)
        }
    }
    
    private func transformImageView(imageView : UIImageView ,rotationAngle : Double) {
        let transform = CGAffineTransform(rotationAngle: CGFloat(rotationAngle))
        UIView.animate(withDuration: 0.3) {
            imageView.transform = transform
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        fatalError("init(coder:) has not been implemented")
    }

}
