//
//  LotteryListAPIManager.swift
//  GoldenApple
//
//  Created by User on 20/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class LotteryListAPIManager: GAAPIBaseManager {
    
    struct DataKey {
        
        /// 自定义普通彩种
        static let kLotteryList = "lotteryList"
        
        /// 自定义GA游戏彩种
        static let kGAGameList = "gaGameList"
        
        static let kGameType = "game_type"
        static let kId = "id"
        static let kIdentifier = "identifier"
        static let kIsInstant = "is_instant"
        static let kName = "name"
        static let kRequestUrl = "request_url"
        static let kSeriesId = "series_id"
        static let kStatus = "status"
        static let kTypeId = "type_id"
    }

}

extension LotteryListAPIManager : LYAPIManager {
    public func methodName() -> NSString {
        return "service?packet=Game&action=getAllGames"
    }
    
    public func serviceType() -> NSString {
        return ServiceType.goldenApple.rawValue as NSString
    }
    
    public func requestType() -> LYAPIManagerRequestType {
        return .get
    }
    
    public func shouldCache() -> Bool {
        return true
    }
    
    func reform(_ params: NSDictionary?) -> NSDictionary? {
        
        let resultParams: NSMutableDictionary
        if params != nil {
            resultParams = NSMutableDictionary(dictionary: params! as NSDictionary)
        } else {
            resultParams = NSMutableDictionary()
        }
        
//        resultParams["game_type"] = "gagame"
        resultParams[GASessionManager.UserInfoKey.kToken] = GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken]
        
        return resultParams as NSDictionary
        
    }
    
}

extension LotteryListAPIManager: LYAPIManagerDataReformer {
    
    func reformData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Any? {
        
        guard let lotteryList = data.object(forKey: "data") as? [NSDictionary] else { return nil }
        GACacheManager.default.lotteryList = lotteryList
        
        let lotteryOtherList = NSMutableArray()
        let gaGameList = NSMutableArray()
        
        for item in lotteryList {
            guard let seriersId = (item[LotteryListAPIManager.DataKey.kSeriesId] as? Int) else {
                return nil
            }
            
            if seriersId == eLotterySeriesType.eGaGame.rawValue {
                gaGameList.add(item)
            } else {
                lotteryOtherList.add(item)
            }
        }
        
//        let lotteryListDict = [ LotteryListAPIManager.DataKey.kLotteryList: lotteryOtherList,
//                                LotteryListAPIManager.DataKey.kGAGameList: gaGameList]
        
        return [lotteryOtherList, gaGameList]
    }
}
