//
//  LotteryHallViewController.swift
//  GoldenApple
//
//  Created by User on 29/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import FSPagerView
import SDWebImage

class LotteryHallViewController: UIViewController {

    static let bannerCellIdentifier = "bannerCellIdentifier"
    static let lotteryCellIdentifer = "lotteryCellIdentifer"
    static let lotteryMenuIdentifer = "lotteryMenuIdentifer"
    static let lotteryMenuFooterIdentifer = "lotteryMenuFooterIdentifer"
    static var is_show_msg = false
    //所有彩票列表
    fileprivate var lotteryDictList:[NSDictionary]?
    fileprivate var bannerDictList: [NSDictionary]?
    //所以彩票和GA游戏
    fileprivate var lotteryAllList: NSArray?
    
    /// banner管理器
    let bannerAPIManager = BannerAPIManager()
    
    /// 彩票列表管理器
    let lotteryListAPIManager = LotteryListAPIManager()
    
    /// 消息g红点
    let messageAPImanager = MessageAPIManager()

    fileprivate let contentView: LotteryHallView = {
        return LotteryHallView()
    }()
    
    fileprivate var isOpenedChildMenu : Bool = false
    
    let childMenuDatas = [
                              ["title" : "全部彩种","series_id" : eLotterySeriesType.eAll.rawValue],
                              ["title" : "常用彩种","series_id" : eLotterySeriesType.eOften.rawValue],
                              ["title" : "时时彩","series_id" : eLotterySeriesType.eTime.rawValue],
                              ["title" : "11选5","series_id" : eLotterySeriesType.e11X5.rawValue],
                              ["title" : "3D","series_id" : eLotterySeriesType.e3D.rawValue],
                              ["title" : "快三","series_id" : eLotterySeriesType.eK3.rawValue],
                              ["title" : "PK10","series_id" : eLotterySeriesType.ePk10.rawValue],
                              ["title" : "快乐十二","series_id" : eLotterySeriesType.eKL12.rawValue],
                              ["title" : "快乐十分","series_id" : eLotterySeriesType.eKL10.rawValue],
                              ["title" : "快乐彩", "series_id" : eLotterySeriesType.eKL.rawValue],
                         ]
    /// 当前选中的彩票分类
    var selectedChildMenuIndex = 0

    override func loadView() {
        super.loadView()
        
        self.view = self.contentView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationItem.title = "金苹果"
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationItem.setLeftBarButton(UIBarButtonItem(image: UIImage(named: "customerservice"), style: .done, target: self, action: #selector(customerCareBtnClick)), animated: true)
        self.navigationItem.setRightBarButton(UIBarButtonItem(image: UIImage(named: "report"), style: .done, target: self, action: #selector(reportBtnClick)), animated: true)
        
        self.bannerAPIManager.delegate = self
        self.bannerAPIManager.paramSource = self
        self.lotteryListAPIManager.delegate = self
        self.lotteryListAPIManager.paramSource = self
        self.messageAPImanager.delegate = self
        self.messageAPImanager.paramSource = self
        
        self.contentView.bannerView.register(FSPagerViewCell.self, forCellWithReuseIdentifier: LotteryHallViewController.bannerCellIdentifier)
        self.contentView.bannerView.dataSource = self
        self.contentView.bannerView.delegate = self
        
        self.contentView.collectionView.dataSource = self
        self.contentView.collectionView.delegate = self
        self.contentView.collectionView.register(LotteryListCollectionCell.self, forCellWithReuseIdentifier: LotteryHallViewController.lotteryCellIdentifer)
        self.contentView.collectionView.register(LotteryMenuCollectionViewCell.self, forCellWithReuseIdentifier: LotteryHallViewController.lotteryMenuIdentifer)
        self.contentView.collectionView.register(LotteryMenuSectionFooter.classForCoder(), forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: LotteryHallViewController.lotteryMenuFooterIdentifer)
        self.navigationController!.isNavigationBarHidden = false
        self.navigationController!.navigationBar.isTranslucent = false
        self.view.backgroundColor = UIColor.white
        
        self.contentView.lotterySegmentedControl.delegate = self
        
        self.bannerAPIManager.loadData()
        self.lotteryListAPIManager.loadData()
        self.messageAPImanager.loadData()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if self.isOpenedChildMenu {
            let selectedChildMenuIndexPath = NSIndexPath.init(row: self.selectedChildMenuIndex, section: 0)
            let selectedChildMenuCell = self.contentView.collectionView.cellForItem(at: selectedChildMenuIndexPath as IndexPath)
            if selectedChildMenuCell != nil {
                selectedChildMenuCell?.isSelected = true
            }
        }
        if LotteryHallViewController.is_show_msg {
            let tabbars = self.navigationController?.tabBarController?.tabBar.items
            let tabbar = tabbars?[3]
            tabbar?.badgeValue = " "
        }else{
            let tabbars = self.navigationController?.tabBarController?.tabBar.items
            let tabbar = tabbars?[3]
            tabbar?.badgeValue = nil
        }
    }
    
    func customerCareBtnClick() {
        
        let customerVC = CustomerServiceViewController()
        customerVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(customerVC, animated: true)
    }
    
    func reportBtnClick() {
        
        let noticeVC = NoticeListViewController()
        noticeVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(noticeVC, animated: true)
    }
}

extension LotteryHallViewController: LotteryMenuViewDelegate {
    func selectedItem(index: Int) {
        self.selectedChildMenuIndex = 0
        let segmentedIndex = self.contentView.lotterySegmentedControl.index
        if self.lotteryAllList != nil && segmentedIndex < self.lotteryAllList!.count {
            self.lotteryDictList = self.lotteryAllList![Int(segmentedIndex)] as? [NSDictionary]
            self.contentView.collectionView.reloadData()
        }
    }
    func childMenuStatusChanges(isOpen: Bool) {
        self.isOpenedChildMenu = isOpen
        self.contentView.collectionView.reloadData()
    }
}

// MARK: - LYAPIManagerParamSource

extension LotteryHallViewController: LYAPIManagerParamSource {
    
    func paramsForApi(_ manager: LYAPIBaseAPIManager) -> NSDictionary? {
        
        if manager == self.bannerAPIManager {
            return [GASessionManager.UserInfoKey.kToken : GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken] as! String]
        }
        else if manager == self.lotteryListAPIManager {
            GAProgressHUD.showLoading(message: "正在加载...")
        }
        else if manager == self.messageAPImanager {
            return [GASessionManager.UserInfoKey.kToken : GASessionManager.default.userinformation![GASessionManager.UserInfoKey.kToken] as! String]
        }
        
        return nil
    }
}

// MARK: - LYAPIManagerCallBackDelegate

extension LotteryHallViewController: LYAPIManagerCallBackDelegate {
    
    func managerCallAPIDidSuccess(_ manager: LYAPIBaseAPIManager, _ isEndCall: Bool) {
        
        if manager == self.bannerAPIManager {
            
            self.bannerDictList = manager.fetchData(self.bannerAPIManager) as? [NSDictionary]
            self.contentView.bannerView.reloadData()
            //            NSLog("LotteryHallViewController-----managerCallAPIDidSuccess---%@", manager.fetchData(nil) as! NSDictionary)
            
        } else if manager == self.lotteryListAPIManager {
            
            GAProgressHUD.hidHUD()
            guard let lotteryList = manager.fetchData(self.lotteryListAPIManager) as? NSArray else { return }
            
            let index = self.contentView.lotterySegmentedControl.index
            self.lotteryDictList = lotteryList[Int(index)] as? [NSDictionary]
            self.lotteryAllList = lotteryList
            
            self.contentView.collectionView.reloadData()
        }else if manager == self.messageAPImanager {
            let data = manager.fetchData(self.messageAPImanager) as? NSDictionary
            if let is_show = data?["is_show"] as? Bool {
                LotteryHallViewController.is_show_msg = is_show
            }
            
            if LotteryHallViewController.is_show_msg {
                let tabbars = self.navigationController?.tabBarController?.tabBar.items
                let tabbar = tabbars?[3]
                tabbar?.badgeValue = " "
            }else{
                let tabbars = self.navigationController?.tabBarController?.tabBar.items
                let tabbar = tabbars?[3]
                tabbar?.badgeValue = nil
            }
            
        }
        
    }
    
    func managerCallAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        GAProgressHUD.hidHUD()
        let errorDict = manager.fetchFailedRequestMsg(nil) as? NSDictionary
        if errorDict != nil {
            let errorString = errorDict!.object(forKey: "error") as! String
            GAProgressHUD.showError(message: errorString)
        }
    }
}

// MARK: - FSPagerViewDataSource

extension LotteryHallViewController: FSPagerViewDataSource {
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        self.contentView.pageControl.numberOfPages = self.bannerDictList != nil ? self.bannerDictList!.count : 1
        return self.bannerDictList != nil ? self.bannerDictList!.count : 1
    }
    
    func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: LotteryHallViewController.bannerCellIdentifier, at: index)

        var url: URL?
        if self.bannerDictList != nil {
            let bannerDict = self.bannerDictList![index]
            url = URL(string: bannerDict.object(forKey: BannerAPIManager.DataKey.kPath) as! String)
        }
        cell.imageView?.sd_setImage(with: url, placeholderImage: UIImage(named: "banner"), options: SDWebImageOptions.allowInvalidSSLCertificates, completed: nil)
        
        return cell
    }
    
}

// MARK: - FSPagerViewDelegate

extension LotteryHallViewController: FSPagerViewDelegate {
    
    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
        pagerView.deselectItem(at: index, animated: true)
        pagerView.scrollToItem(at: index, animated: true)
        self.contentView.pageControl.currentPage = index
        
        if bannerDictList != nil {
            let noticeUrlStr = self.bannerDictList![index].object(forKey: BannerAPIManager.DataKey.kUrl) as? String
            if noticeUrlStr != nil {
                guard let url = URL(string: noticeUrlStr!) else {return}
                UIApplication.shared.openURL(url)
            } else if let noticeId = self.bannerDictList![index].object(forKey: BannerAPIManager.DataKey.kNoticeId) as? Int {
                let noticeDetailVC = NoticeDetailViewController()
                noticeDetailVC.noticeId = noticeId
                self.navigationController?.pushViewController(noticeDetailVC, animated: true)
            }
        }
        
        
    }
    
    func pagerViewDidScroll(_ pagerView: FSPagerView) {
        guard self.contentView.pageControl.currentPage != pagerView.currentIndex else {
            return
        }
        self.contentView.pageControl.currentPage = pagerView.currentIndex // Or Use KVO with property "currentIndex"
    }
}

// MARK: - UICollectionViewDataSource

extension LotteryHallViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        if self.lotteryDictList == nil {
            return 0
        }
        if self.isOpenedChildMenu {
            return 2
        } else {
            return 1
        }
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.lotteryDictList == nil {
            return 0
        }
        if self.isOpenedChildMenu && section == 0 {
            return self.childMenuDatas.count
        } else {
            return self.lotteryDictList!.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if self.isOpenedChildMenu && indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LotteryHallViewController.lotteryMenuIdentifer, for: indexPath) as! LotteryMenuCollectionViewCell
            let menuDict = self.childMenuDatas[indexPath.row] as NSDictionary
            let title = menuDict.value(forKey: "title") as! String
            cell.categoryLabel.text = title
            if self.selectedChildMenuIndex == indexPath.row {
                cell.isSelected = true
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LotteryHallViewController.lotteryCellIdentifer, for: indexPath) as! LotteryListCollectionCell
            
            let lotteryDict = self.lotteryDictList![indexPath.item]
            cell.setLotteryDict(lotteryDict)
            
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if self.isOpenedChildMenu && indexPath.section == 0 {
            if kind == UICollectionElementKindSectionFooter {
                let footer = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: LotteryHallViewController.lotteryMenuFooterIdentifer, for: indexPath) as! LotteryMenuSectionFooter
                return footer
                
            }
        }
        
        return UICollectionReusableView()
    }
}

extension LotteryHallViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if self.isOpenedChildMenu && indexPath.section == 0 {
            
            let lastSelectedIndexPath = NSIndexPath.init(row: self.selectedChildMenuIndex, section: indexPath.section)
            let lastSelectedCell = collectionView.cellForItem(at: lastSelectedIndexPath as IndexPath)
            lastSelectedCell?.isSelected = false
            
            self.selectedChildMenuIndex = indexPath.row
            
            let menuDict = self.childMenuDatas[indexPath.row] as NSDictionary
            let series_id = menuDict.value(forKey: "series_id") as! Int
            let predicate = NSPredicate.init(format: "series_id == %d", series_id)
            self.lotteryDictList = self.lotteryAllList![0] as? [NSDictionary]
            if series_id == eLotterySeriesType.eOften.rawValue {
                self.lotteryDictList = GACacheManager.default.getOftenLotteryList()
            } else if  series_id == eLotterySeriesType.eAll.rawValue {
                
            } else {
                self.lotteryDictList = (self.lotteryDictList! as NSArray).filtered(using: predicate) as? [NSDictionary]
            }
            let indexSet = NSIndexSet.init(index: 1) as IndexSet
            collectionView.reloadSections(indexSet)
        } else {

            guard let lotteryDict = self.lotteryDictList?[indexPath.item] else { return }
            
            guard let lotteryType = lotteryDict[LotteryListAPIManager.DataKey.kSeriesId] as? Int else { return }
            if lotteryType == eLotterySeriesType.eGaGame.rawValue {
                guard let lotteryIdenti = lotteryDict[LotteryListAPIManager.DataKey.kIdentifier] as? String else { return }
                
                let alertController = UIAlertController(title: nil, message: "您可以选择:", preferredStyle: .alert)
                let startAction = UIAlertAction(title: "开始游戏", style: .default) { (start) in
                    let gaGameVC = GAGameViewController(lotteryIdentifier: lotteryIdenti)
                    gaGameVC.isTryMode = false
                    self.present(gaGameVC, animated: true, completion: nil)
                }
                let tryAction = UIAlertAction(title: "免费试玩", style: .default) { (try) in
                    let gaGameVC = GAGameViewController(lotteryIdentifier: lotteryIdenti)
                    gaGameVC.isTryMode = true
                    self.present(gaGameVC, animated: true, completion: nil)
                }
                let cancelAction = UIAlertAction(title: "取消", style: .cancel) { (cancelAction) in
                }
                alertController.addAction(startAction)
                alertController.addAction(tryAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            } else {
                
                let lotteryPlaying = LotteryPlayingViewController(lotteryDict: self.lotteryDictList![indexPath.item])
                lotteryPlaying.hidesBottomBarWhenPushed = true
                
                self.navigationController?.pushViewController(lotteryPlaying, animated: true)
                GACacheManager.default.addOftenLotteryId(id: lotteryDict.value(forKey: LotteryListAPIManager.DataKey.kId) as! Int)
            }
        }
    }

}

extension LotteryHallViewController: UICollectionViewDelegateFlowLayout {
    
    //每个item尺寸
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if self.isOpenedChildMenu && indexPath.section == 0 {
            let menuDict = self.childMenuDatas[indexPath.row] as NSDictionary
            let title = menuDict.value(forKey: "title") as! String
            var size = title.size(attributes: [NSFontAttributeName : UIFont.systemFont(ofSize: LotteryMenuCollectionViewCell.childMenuFontSize)])
            size = CGSize.init(width: max(size.width + 10, 50) , height: size.height + 15)
            return size
        } else {
            return CGSize(width: 80, height: 100)
        }
    }
    //每个section的内边距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if self.isOpenedChildMenu && section == 0 {
            return UIEdgeInsetsMake(20, 10, 10, 10)
        } else {
            return UIEdgeInsetsMake(20, 20, 20, 20)
        }
    }
    //item的垂直间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if self.isOpenedChildMenu && section == 0 {
            return 15
        } else {
            return 20
        }
    }
    //item的水平间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if self.isOpenedChildMenu && section == 0 {
            return 10
        } else {
            return 20
        }
    }
    //设置footer的size
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if self.isOpenedChildMenu && section == 0 {
            return CGSize(width: 10, height: 1)
        }
        return CGSize(width: 0, height: 0)
    }
}

extension LotteryHallViewController:UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        var bannerFrame : CGRect = self.contentView.bannerView.frame
        var segmentFrame : CGRect = self.contentView.lotterySegmentedControl.frame
        let offsetY : CGFloat = self.contentView.collectionView.contentOffset.y + self.contentView.collectionView.contentInset.top

        //先回到初始状态
        bannerFrame.origin.y = -self.contentView.collectionView.contentInset.top
        segmentFrame.origin.y = bannerFrame.maxY
        bannerFrame.size.height =  self.contentView.bannerHeight
        // 向下拉
        if offsetY < 0 {
            //bannerview跟随弹簧移动,防止顶部空白
            bannerFrame.origin.y = self.contentView.collectionView.contentOffset.y
            // 修改bannerview的高度,图片放大
//            bannerFrame.size.height =  self.contentView.bannerHeight - offsetY
            segmentFrame.origin.y = bannerFrame.maxY
        // 向上拉
        } else {
            //segmentedControll悬停
            if -self.contentView.collectionView.contentOffset.y < self.contentView.segmentedBarHeight {
                bannerFrame.origin.y = self.contentView.collectionView.contentOffset.y - self.contentView.bannerHeight
                segmentFrame.origin.y = bannerFrame.maxY
            }
        }
        self.contentView.bannerView.frame = bannerFrame
        self.contentView.lotterySegmentedControl.frame = segmentFrame
    }
}




