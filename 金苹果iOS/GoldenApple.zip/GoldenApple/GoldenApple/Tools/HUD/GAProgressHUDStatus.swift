//
//  GAProgressHUDStatus.swift
//  GAProgressHUD
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 El Capitan. All rights reserved.
//

import UIKit

public enum GAProgressHUDStatus {
    case none
    case loading
    case error
    case success
    case warning
}
