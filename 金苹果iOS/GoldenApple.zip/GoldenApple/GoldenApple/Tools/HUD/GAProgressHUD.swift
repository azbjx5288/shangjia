//
//  GAProgressHUD.swift
//  GAProgressHUD
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 El Capitan. All rights reserved.
//

import UIKit

class GAProgressHUD: NSObject {
    
    
    /// 显示HUD
    ///
    /// - Parameters:
    ///   - message: 提示信息
    ///   - status: 状态 .none:没有图标, .loading:加载图标, .success：加载成功, .warning：警告, .error：失败
    static func showHUD(message : String,status : GAProgressHUDStatus) {
        
        let rootView = UIApplication.shared.keyWindow?.rootViewController?.view
        
        self.hidHUD()
        
        let hud = GAProgressHUDView()
        
        var frame = rootView?.frame
        
        frame?.origin.y = 64
        
        frame!.size.height = (frame?.size.height)! - 118
        hud.frame = frame!
        rootView?.addSubview(hud)
        rootView?.bringSubview(toFront: hud)
        hud.showHUD(message: message, status: status)
    }
    
    
    /// 显示HUD，并自动隐藏
    ///
    /// - Parameters:
    ///   - message: 提示信息
    ///   - status: 状态 .none:没有图标, .loading:加载图标, .success：加载成功, .warning：警告, .error：失败
    ///   - duration: 显示时间
    static func showHUD(message : String,status : GAProgressHUDStatus,duration : CFTimeInterval) {
        self.showHUD(message: message, status: status)
        DispatchQueue.main.asyncAfter(deadline: .now() + duration, execute:
            {
                self.hidHUD()
        })
    }
    
    
    /// 显示加载中HUD
    ///
    /// - Parameter message: 提示信息
    static func showLoading(message : String) {
        self.showHUD(message: message, status: .loading)
    }
    
    /// 显示成功HUD
    ///
    /// - Parameter message: 提示信息
    static func showSuccess(message : String) {
        self.showHUD(message: message, status: .success, duration: 3)
    }
    
    /// 显示失败HUD
    ///
    /// - Parameter message: 提示信息
    static func showError(message : String, duration: CFTimeInterval = 3) {
        self.showHUD(message: message, status: .error, duration: duration)
    }
    
    /// 显示警告HUD
    ///
    /// - Parameter message: 提示信息
    static func showWarning(message : String) {
        self.showHUD(message: message,status: .warning, duration: 3)
    }
    
    
    /// 隐藏HUD
    static func hidHUD() {
        
        let rootView = UIApplication.shared.keyWindow?.rootViewController?.view

        for view in (rootView?.subviews)! {
            if view.isKind(of: GAProgressHUDView.self) {
                UIView.animate(withDuration: 0.5, animations: {
                    view.alpha = 0
                }, completion: { (finished) in
                    view.removeFromSuperview()
                })
            }
        }
    }
    
    
    /// 隐藏HUD，并处理完成回调
    ///
    /// - Parameter completion: 完成隐藏回调
    static func hidHUD(completion: ((Bool) -> Swift.Void)? = nil) {
        
        let rootView = UIApplication.shared.keyWindow?.rootViewController?.view
        
        for view in (rootView?.subviews)! {
            if view.isKind(of: GAProgressHUDView.self) {
                UIView.animate(withDuration: 0.5, animations: {
                    view.alpha = 0
                }, completion: { (finished) in
                    view.removeFromSuperview()
                    completion!(finished)
                })
            }
        }
        
    }
}
