//
//  GAProgressHUDView.swift
//  GAProgressHUD
//
//  Created by El Capitan on 2017/11/14.
//  Copyright © 2017年 El Capitan. All rights reserved.
//

import UIKit

class GAProgressHUDView: UIView {
    private let messageLabel = UILabel()
    private let imageView = UIImageView()
    fileprivate let contentView = UIView()
    
    override init(frame: CGRect) {
        super.init(frame: CGRect.zero)
  
        self.contentView.backgroundColor = UIColor.init(red: 0.0 / 255, green:  0.0 / 255, blue:  0.0 / 255, alpha: 0.7)
        self.contentView.layer.cornerRadius = 3
        self.addSubview(self.contentView)
        
        self.messageLabel.textColor = .white
        self.messageLabel.font = UIFont.systemFont(ofSize: 16)
        self.messageLabel.numberOfLines = 0
        self.contentView.addSubview(self.messageLabel)
        
        self.contentView.addSubview(self.imageView)

    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func showHUD(message : String,status : GAProgressHUDStatus) {
        switch status {
        case .none:
            self.setFrame(message:message)
            break
        case .loading:
            self.imageView.image = UIImage.init(named: "GAProgressHUD_loading")
            self.setFrame(message:message)
            
            let rotationAnimation = CABasicAnimation.init(keyPath: "transform.rotation.z")
            rotationAnimation.toValue = NSNumber.init(value:  .pi * 2.0)
            rotationAnimation.duration = 2.5
            rotationAnimation.isCumulative = true
            rotationAnimation.repeatCount = 999999999999
            rotationAnimation.autoreverses = true
            rotationAnimation.isRemovedOnCompletion = false
            self.imageView.layer.add(rotationAnimation, forKey: "rotationAnimation")
          
            break
        case .error:
            self.imageView.image = UIImage.init(named: "GAProgressHUD_warning")
            self.setFrame(message:message)
            break
        case .success:
            self.imageView.image = UIImage.init(named: "GAProgressHUD_success")
            self.setFrame(message:message)
            break
        case .warning:
            self.imageView.image = UIImage.init(named: "GAProgressHUD_warning")
            self.setFrame(message:message)
            break

        }
    }
    private func setFrame(message : String) {
        let margin : CGFloat = 15.0
        
        let attStr = NSAttributedString.init(string: message, attributes: [NSFontAttributeName : self.messageLabel.font])
        let messageSize = attStr.boundingRect(with: CGSize.init(width: 200, height: Double(MAXFLOAT)), options: [.usesLineFragmentOrigin,.usesFontLeading], context: nil).size
        self.messageLabel.text = message
        
        let image = self.imageView.image
        
        var contentWidth : CGFloat = 0.0
        var messageX : CGFloat = 0.0
        if image == nil {
            contentWidth = ceil(messageSize.width) + 2 * margin
            messageX = margin
        } else {
            contentWidth = (image?.size.width)! + ceil(messageSize.width) + 3 * margin
            messageX = (image?.size.width)! + margin + margin / 2
        }
       
        let contentHeight = ceil(messageSize.height) + 2 * margin
        let contentX = self.frame.midX - contentWidth / 2
        let contentY = self.frame.midY - self.frame.minY - contentHeight / 2
        self.contentView.frame = CGRect.init(x: contentX , y: contentY, width: contentWidth, height: contentHeight)
        
        let messageY = (self.contentView.frame.height - ceil(messageSize.height)) / 2
        self.messageLabel.frame = CGRect.init(x: messageX, y: messageY, width: ceil(messageSize.width), height: ceil(messageSize.height))
        
        if image != nil {
            let imageY = self.messageLabel.frame.midY - (image?.size.height)! / 2
            self.imageView.frame = CGRect.init(x: margin, y: imageY, width: (image?.size.width)!, height: (image?.size.height)!)
        }
        
    }
}
