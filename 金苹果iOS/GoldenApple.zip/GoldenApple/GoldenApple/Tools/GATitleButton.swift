//
//  GATitleButton.swift
//  GoldenApple
//
//  Created by User on 07/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class GATitleButton: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.imageView?.contentMode = .center
        self.titleLabel?.textAlignment = .right
        self.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        self.setTitleColor(UIColor.white, for: UIControlState.normal)
        
        self.adjustsImageWhenHighlighted = false
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    override func imageRect(forContentRect contentRect: CGRect) -> CGRect {
        
        let imageW = self.frame.height
        let imageH = imageW
        let imageX = self.frame.width - imageW
        
        return CGRect(x: imageX, y: 0, width: imageW, height: imageH)
    }
    
    override func titleRect(forContentRect contentRect: CGRect) -> CGRect {
        
        let titleH = self.frame.height
        let titleW = self.frame.width - self.frame.height
        
        return CGRect(x: 0, y: 0, width: titleW, height: titleH)
    }
    
    override func setTitle(_ title: String?, for state: UIControlState) {
        
        super.setTitle(title, for: state)
        
        if title == nil {
            return
        }
        
        let titleSize = (title! as NSString).size(attributes: [NSFontAttributeName : self.titleLabel!.font])
        
        var bFrame = self.frame
        bFrame.size.height = titleSize.height
        bFrame.size.width = titleSize.width + bFrame.height + 10
        self.frame = bFrame
        
    }
    
}
