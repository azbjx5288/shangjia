//
//  GAWKWebViewController.swift
//  GoldenApple
//
//  Created by User on 29/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit
import WebKit

class GAWKWebViewController: UIViewController,WKUIDelegate {
    
    fileprivate var isAddEstimated = false
    
    lazy var webView: WKWebView = {
        let config:WKWebViewConfiguration = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true;
        config.mediaPlaybackRequiresUserAction = false;
        let webView = WKWebView.init(frame: CGRect.zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.scrollView.bounces = false
        
        webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: nil)
        self.isAddEstimated = true
        
        return webView
    }()
    
    fileprivate lazy var progressView: UIProgressView = {
        let view = UIProgressView(progressViewStyle: UIProgressViewStyle.default)
        view.trackTintColor = RGBCOLOR(240, 240, 240)
        view.progressTintColor = UIColor.green
        
        return view
    }()
    
    deinit {
        if self.isAddEstimated{
            self.webView.removeObserver(self, forKeyPath: "estimatedProgress")
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.addSubview(self.webView)
        self.view.addSubview(self.progressView)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.webView.frame = self.view.bounds
        
        if self.navigationController != nil && self.navigationController!.navigationBar.isTranslucent {
            let originY = self.navigationController!.navigationBar.frame.maxY
            self.progressView.frame = CGRect(x: 0, y: originY, width: self.view.bounds.size.width, height: 3)
        } else {
            self.progressView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: 3)
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        if keyPath == "estimatedProgress" {
            self.progressView.alpha = 1.0
            let animated = self.webView.estimatedProgress > Double(self.progressView.progress)
            self.progressView.setProgress(Float(self.webView.estimatedProgress), animated: animated)
            
            if self.webView.estimatedProgress >= 1.0 {
                UIView.animate(withDuration: 0.3, delay: 0.3, options: UIViewAnimationOptions.curveEaseOut, animations: {
                    self.progressView.alpha = 0.0
                }, completion: { (_) in
                    self.progressView.setProgress(0.0, animated: false)
                })
            }
        } else {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
        }
        
    }
    
    func setCookies() {
        let cookies = HTTPCookieStorage.shared.cookies
        if cookies != nil {
            HTTPCookie.requestHeaderFields(with: cookies!)
        }
    }
}

extension GAWKWebViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        GAProgressHUD.showLoading(message: "正在加载...")
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        GAProgressHUD.hidHUD()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        GAProgressHUD.hidHUD()
        
        let alertVC = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertVC.addAction(okAction)
        
        self.present(alertVC, animated: false, completion: nil)
    }
}

