//
//  GAAlertView.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/15.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import XFDialogBuilder

class GAAlertView: XFDialogNotice {

    private let titleLine : UIView = UIView()
    
    override func addContentView() {
        super.addContentView()
        self.titleLine.backgroundColor = UIColor.init(red: 220.0/255, green: 220.0/255, blue: 220.0/255, alpha: 1)
        self.addSubview(self.titleLine)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.titleLine.frame = CGRect.init(x: 0, y: self.titleLabel.frame.height, width: self.titleLabel.frame.width, height: 1)
    }
    
    static func showAlert(title : String,attrs : NSDictionary,commitCallBack : @escaping CommitClickBlock)->XFDialogNotice {
        for view in (UIApplication.shared.keyWindow?.subviews)! {
            if view.isKind(of: GAAlertView.self) {
                if (view as! GAAlertView).attrs[XFDialogNoticeText] as! String == attrs[XFDialogNoticeText] as! String {
                    view.removeFromSuperview()
                    (view as! GAAlertView).mask.removeFromSuperview()
                }
            }
        }
        let dialogFrameView = super.dialog(withTitle: title, attrs: attrs as! [AnyHashable : Any], commitCallBack: commitCallBack)
        let panelView = dialogFrameView?.value(forKey: "panelView") as! UIView
        panelView.removeFromSuperview()
        
        for gesture in (dialogFrameView?.mask.gestureRecognizers)! {
            dialogFrameView?.mask.removeGestureRecognizer(gesture)
        }
        
        return dialogFrameView!
    }
    
}

