//
//  GAAlertDelegate.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/15.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

protocol GAAlertDelegate {
    func alertCancelButtonClicked()
    func alertCommitButtonClicked()
}
