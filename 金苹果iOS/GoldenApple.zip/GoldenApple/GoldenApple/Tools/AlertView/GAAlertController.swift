//
//  GAAlertController.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/15.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit
import XFDialogBuilder

class GAAlertController: NSObject {
    
    static func showAlert(title : String,message : String,delegate : GAAlertDelegate?,cancelButtonTitle : String? ,commitButtonTitle : String) {
        let titleViewBackgroundColor = UIColor.init(red: 240.0/255, green: 240.0/255, blue: 240.0/255, alpha: 1)
        let noticeTextColor = kGANavigationBackgroundColor
        let lineColor = UIColor.init(red: 220.0/255, green: 220.0/255, blue: 220.0/255, alpha: 1)
        let cancelButtonTitleColor = UIColor.init(red: 0.0/255, green: 0.0/255, blue: 253.0/255, alpha: 1)
        let commitButtonTitleColor = kGANavigationBackgroundColor
        
        var showCancelBtn = true
        
        if (cancelButtonTitle == nil) {
            showCancelBtn = false
        }
        
        let cancelButtonTitle = showCancelBtn ? cancelButtonTitle : ""
  
        var alertView : GAAlertView?
        alertView = GAAlertView.showAlert(title: title,
                                    attrs: [
                                        XFDialogMaskViewAlpha : 0.3,
                                        XFDialogEnableBlurEffect:false,
                                        XFDialogTitleViewBackgroundColor :titleViewBackgroundColor,
                                        XFDialogTitleColor: UIColor.black,
                                        XFDialogCommitButtonCancelDisable:!showCancelBtn, // 禁用取消按钮
                                        XFDialogNoticeText: message,
                                        XFDialogNoticeTextColor : noticeTextColor,
                                        XFDialogLineColor: lineColor,
                                        XFDialogLineWidth: 1,
                                        XFDialogCancelButtonTitleColor: cancelButtonTitleColor,
                                        XFDialogCommitButtonTitleColor: commitButtonTitleColor,
                                        XFDialogCancelButtonTitle : cancelButtonTitle!,
                                        XFDialogCommitButtonTitle : commitButtonTitle,
                                        
                                        ],
                                    commitCallBack: {(inputText) -> ()  in
                                            alertView?.hide(animationBlock: { (view) -> Float in
                                                if delegate != nil {
                                                    delegate?.alertCommitButtonClicked()
                                                }
                                                alertView = nil
                                                return 0.0
                                            })
                                    }
        )
        .show(animationBlock: nil)
        .setCancelCallBack({
                alertView = nil
                if delegate != nil {
                    delegate?.alertCancelButtonClicked()
                }
        }) as? GAAlertView
    
    }
    
    static func showAlert(_ title : String, _ message : String, _ cancelBtnTitle : String? , _ commitBtnTitle : String, cancelCallBack: (() -> ())?, commitCallBack: @escaping (() -> ())) {
        let titleViewBackgroundColor = UIColor.init(red: 240.0/255, green: 240.0/255, blue: 240.0/255, alpha: 1)
        let noticeTextColor = kGANavigationBackgroundColor
        let lineColor = UIColor.init(red: 220.0/255, green: 220.0/255, blue: 220.0/255, alpha: 1)
        let cancelButtonTitleColor = UIColor.init(red: 0.0/255, green: 0.0/255, blue: 253.0/255, alpha: 1)
        let commitButtonTitleColor = kGANavigationBackgroundColor
        
        var showCancelBtn = true
        
        if (cancelBtnTitle == nil) {
            showCancelBtn = false
        }
        
        let cancelButtonTitle = showCancelBtn ? cancelBtnTitle : ""
        
        var alertView : GAAlertView?
        alertView = GAAlertView.showAlert(title: title,
                                          attrs: [
                                            XFDialogMaskViewAlpha : 0.3,
                                            XFDialogEnableBlurEffect:false,
                                            XFDialogTitleViewBackgroundColor :titleViewBackgroundColor,
                                            XFDialogTitleColor: UIColor.black,
                                            XFDialogCommitButtonCancelDisable:!showCancelBtn, // 禁用取消按钮
                                            XFDialogNoticeText: message,
                                            XFDialogNoticeTextColor : noticeTextColor,
                                            XFDialogLineColor: lineColor,
                                            XFDialogLineWidth: 1,
                                            XFDialogCancelButtonTitleColor: cancelButtonTitleColor,
                                            XFDialogCommitButtonTitleColor: commitButtonTitleColor,
                                            XFDialogCancelButtonTitle : cancelButtonTitle!,
                                            XFDialogCommitButtonTitle : commitBtnTitle,
                                            
                                            ],
                                          commitCallBack: {(inputText) -> ()  in
                                            alertView?.hide(animationBlock: { (view) -> Float in
                                                commitCallBack()
                                                alertView = nil
                                                return 0.0
                                            })
        }
            )
            .show(animationBlock: nil)
            .setCancelCallBack({
                alertView = nil
                
                if cancelCallBack != nil {
                    cancelCallBack!()
                }
            }) as? GAAlertView
        
    }
}
