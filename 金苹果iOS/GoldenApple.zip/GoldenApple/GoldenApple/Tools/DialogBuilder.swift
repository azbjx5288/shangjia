//
//  DialogBuilder.swift
//  LottryReact
//
//  Created by 小辉 on 2017/11/10.
//  Copyright © 2017年 小辉. All rights reserved.
//

import Foundation
import PopupDialog

protocol DialogBuilder {
    func build() -> PopupDialog
}

class SimpleDialogBuilder: DialogBuilder {
    
    private var title = "提示"
    private var message = ""
    private var messageColor = UIColor.red
    private var messageTextAlignment: NSTextAlignment = .center
    
    private var buttonAlignment: UILayoutConstraintAxis = .horizontal
    private var isDismissOnButtonTap: Bool = true
    private var isGestureDismissal: Bool = true
    private var transitionStyle: PopupDialogTransitionStyle = .fadeIn
    
    private var hasPositive = true
    private var hasNagative = true
    private var titlePositive = "确定"
    private var titleNagative = "取消"
    private var positive: () -> Void = {}
    private var nagative: () -> Void = {}
    
    private var completion: () -> Void = {}
    
    func title(_ title: String) -> SimpleDialogBuilder {
        self.title = title
        return self
    }
    
    func message(_ message: String,_ messageColor: UIColor = .red) -> SimpleDialogBuilder {
        self.message = message
        self.messageColor = messageColor
        return self
    }
    
    func messageTextAlignment(_ messageTextAlignment: NSTextAlignment) -> SimpleDialogBuilder {
        self.messageTextAlignment = messageTextAlignment
        return self
    }
    
    func buttonAlignment(_ buttonAlignment: UILayoutConstraintAxis) -> SimpleDialogBuilder {
        self.buttonAlignment = buttonAlignment
        return self
    }
    
    func isDismissOnButtonTap(_ isDismissOnButtonTap: Bool) -> SimpleDialogBuilder {
        self.isDismissOnButtonTap = isDismissOnButtonTap
        return self
    }
    
    func isGestureDismissal(_ isGestureDismissal: Bool) -> SimpleDialogBuilder {
        self.isGestureDismissal = isGestureDismissal
        return self
    }
    
    func transitionStyle(_ transitionStyle: PopupDialogTransitionStyle) -> SimpleDialogBuilder {
        self.transitionStyle = transitionStyle
        return self
    }
    
    func completion(_ completion: @escaping() -> Void) -> SimpleDialogBuilder {
        self.completion = completion
        return self
    }
    
    func hasPositiveTap(_ hasPositive:Bool = true, _ titlePositive: String = "确定", positive: @escaping() -> Void = {}) -> SimpleDialogBuilder {
        self.hasPositive = hasPositive
        self.titlePositive = titlePositive
        self.positive = positive
        return self
    }
    
    func hasNagativeTap(_ hasNagative:Bool = true, _ titleNagative: String = "取消", nagative: @escaping() -> Void = {}) -> SimpleDialogBuilder {
        self.hasNagative = hasNagative
        self.titleNagative = titleNagative
        self.nagative = nagative
        return self
    }
    
    func build() -> PopupDialog {
        let popup = PopupDialog(title:self.title ,message: self.message,gestureDismissal:self.isGestureDismissal,completion: self.completion)
        
        popup.buttonAlignment = self.buttonAlignment
        popup.transitionStyle = self.transitionStyle
        
        if hasNagative {
            popup.addButton(PopupDialogButton(title: self.titleNagative, height: 44, dismissOnTap: isDismissOnButtonTap, action: {self.nagative()}))
        }
        
        if hasPositive {
            popup.addButton(PopupDialogButton(title: self.titlePositive, height: 44, dismissOnTap: isDismissOnButtonTap, action: {self.positive()}))
        }
        
        let vc = popup.viewController as! PopupDialogDefaultViewController
        vc.messageColor = self.messageColor
        vc.messageTextAlignment = self.messageTextAlignment
        return popup
    }
    
    
}

class CustomerDialogBuilder: DialogBuilder {

    private var customerVc: UIViewController
    
    private var buttonAlignment: UILayoutConstraintAxis = .horizontal
    private var isDismissOnButtonTap: Bool = true
    private var isGestureDismissal: Bool = true
    private var transitionStyle: PopupDialogTransitionStyle = .fadeIn
    
    private var hasPositive = true
    private var hasNagative = true
    private var titlePositive = "确定"
    private var titleNagative = "取消"
    private var positive: () -> Void = {}
    private var nagative: () -> Void = {}
    
    private var completion: () -> Void = {}
    
    required init(customerVc: UIViewController) {
        self.customerVc = customerVc
    }
    
    func buttonAlignment(_ buttonAlignment: UILayoutConstraintAxis) -> CustomerDialogBuilder {
        self.buttonAlignment = buttonAlignment
        return self
    }
    
    func isDismissOnButtonTap(_ isDismissOnButtonTap: Bool) -> CustomerDialogBuilder {
        self.isDismissOnButtonTap = isDismissOnButtonTap
        return self
    }
    
    func isGestureDismissal(_ isGestureDismissal: Bool) -> CustomerDialogBuilder {
        self.isGestureDismissal = isGestureDismissal
        return self
    }
    
    func transitionStyle(_ transitionStyle: PopupDialogTransitionStyle) -> CustomerDialogBuilder {
        self.transitionStyle = transitionStyle
        return self
    }
    
    func completion(_ completion: @escaping() -> Void) -> CustomerDialogBuilder {
        self.completion = completion
        return self
    }
    
    func hasPositiveTap(_ hasPositive:Bool = true, _ titlePositive: String = "确定", positive: @escaping() -> Void = {}) -> CustomerDialogBuilder {
        self.hasPositive = hasPositive
        self.titlePositive = titlePositive
        self.positive = positive
        return self
    }
    
    func hasNagativeTap(_ hasNagative:Bool = true, _ titleNagative: String = "取消", nagative: @escaping() -> Void = {}) -> CustomerDialogBuilder {
        self.hasNagative = hasNagative
        self.titleNagative = titleNagative
        self.nagative = nagative
        return self
    }
    

    func build() -> PopupDialog {
        let popup =  PopupDialog(viewController: self.customerVc,
                                 buttonAlignment: self.buttonAlignment,
                                 transitionStyle: self.transitionStyle,
                                 gestureDismissal: self.isGestureDismissal,
                                 completion: self.completion)
        if self.hasNagative {
            popup.addButton(PopupDialogButton(title: self.titleNagative, height: 44, dismissOnTap: self.isDismissOnButtonTap, action: {self.nagative()}))
        }
        if self.hasPositive {
            popup.addButton(PopupDialogButton(title: self.titlePositive, height: 44, dismissOnTap: self.isDismissOnButtonTap, action: {self.positive()}))
        }
        return popup
    }
    
}
