//
//  WOWDropMenuView.swift
//  Wow
//
//  Created by 王云鹏 on 16/4/8.
//  Copyright © 2016年 wowdsgn. All rights reserved.
//

import Foundation
import UIKit
import SnapKit

let screenWidth = UIScreen.main.bounds.size.width
let screenHeight = UIScreen.main.bounds.size.height


struct WOWDropMenuSetting {
    
    var columnTitles: Array<String> = []
    
    var rowTitles: Array<Array<String>> =  []
    var columnTitleFont:UIFont = UIFont.init(name:"HelveticaNeue-Medium", size:13)!
    
    var cellHeight:CGFloat = 48
    
    /// 每列的title是否等宽
    var columnEqualWidth:Bool = true
    
    var maxShowCellNumber:Int = 15
    
    var cellTextLabelColor:UIColor = UIColor.black
    
    var cellTextLabelSelectColoror:UIColor = UIColor.red
    
    var tableViewBackgroundColor:UIColor = UIColor.white
    
    var markImage:UIImage? = UIImage(named:"duihao")
    
    var showDuration:TimeInterval = 0.3
    
    var cellSelectionColor:UIColor = UIColor(colorLiteralRed: 255/255.0, green: 230/255.0, blue: 0/255.0, alpha: 1)
    
    //列数
    var columnNumber:Int = 0
}


protocol DropMenuViewDelegate:class{
    func dropMenuClick(column:Int,row:Int)
}



class WOWDropMenuView: UIView {
    private var headerView: UIView!
    private var backView:UIView!
    private var bottomButton:UIButton!
    fileprivate var currentColumn:Int = 0
    private var show:Bool = false
    fileprivate var columItemArr = [WOWDropMenuColumn]()
    private var showSubViews = [UIView]()
    //存放的是每一列正在选择的title  row = value
    fileprivate var columnShowingDict = [Int:String]()
    fileprivate var setting: WOWDropMenuSetting
    
    weak var delegate:DropMenuViewDelegate?
    
    private var expandTableViewHeight: CGFloat

    private lazy var tableView:UITableView = {
        let v = UITableView(frame:CGRect(x:0, y: self.frame.size.height, width: self.frame.size.width, height: 0), style:.plain)
        v.delegate = self
        v.dataSource = self
        return v
    }()
    
    
    init(frame: CGRect, setting: WOWDropMenuSetting) {
        self.setting = setting
        self.expandTableViewHeight = CGFloat(setting.maxShowCellNumber) * setting.cellHeight
        super.init(frame: frame)
        initData()
        configSubView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.setting = WOWDropMenuSetting()
        self.expandTableViewHeight = CGFloat(setting.maxShowCellNumber) * setting.cellHeight
        super.init(coder: aDecoder)
    }
    
    private func initData(){
        assert(setting.columnTitles.count == setting.rowTitles.count,"其中一列的list数据为空")
        setting.columnNumber = setting.columnTitles.count
        for (index,title) in setting.columnTitles.enumerated() {
            columnShowingDict[index] = title
        }
    }
    
    private func configSubView(){
        backgroundColor = UIColor.white
        configHeaderView()
        //添加下方阴影线
        let line = UIView()
        line.backgroundColor = UIColor(red: 200/255.0, green: 199/255.0, blue: 204/255.0, alpha: 1)
        addSubview(line)
        line.snp.makeConstraints { [weak self](make) in
            if let strongSelf = self{
                make.left.right.bottom.equalTo(strongSelf).offset(0)
                make.height.equalTo(0.5)
            }
        }
        bottomButton = UIButton(type:.system)
        bottomButton.frame = CGRect(x:0, y: frame.height-2, width: frame.width, height:21)
        bottomButton.setBackgroundImage(UIImage(named: "icon_chose_bottom"), for: .normal)
        bottomButton.addTarget(self, action:#selector(bottomButtonClick(sender:)), for:.touchUpInside)
        bottomButton.isHidden = true
        
        
        backView = UIView(frame:CGRect(x:0, y:frame.height, width:frame.width, height:UIScreen.main.bounds.size.height))
        backView.isHidden = false
        backView.alpha = 0
        //添加背景毛玻璃效果
        let blurEffect = UIBlurEffect(style: .light)
        let blurView = UIVisualEffectView(effect: blurEffect)
        blurView.frame = CGRect(x:0, y: 0, width: backView.frame.size.width, height: backView.frame.size.height)
        backView.addSubview(blurView)
        //添加点击手势
        let tap = UITapGestureRecognizer(target: self, action:#selector(backTap))
        backView.addGestureRecognizer(tap)
        showSubViews = [bottomButton,backView,tableView]
    }
    
    private func configHeaderView(){
        headerView = UIView(frame: CGRect(x:0, y:0, width:frame.size.width, height:frame.size.height))
        for (index,title) in setting.columnTitles.enumerated() {
            let columnItem = Bundle.loadResourceName(name: "WOWDropMenuColumn") as! WOWDropMenuColumn
            columnItem.titleButton.setTitle(title, for: .normal)
            columnItem.titleButton.addTarget(self, action:#selector(columnTitleClick(btn:)), for: .touchUpInside)
            columnItem.titleButton.tag = index
            headerView.addSubview(columnItem)
            if setting.columnEqualWidth {
                let columnWidth = (UIScreen.main.bounds.size.width - 5 * CGFloat(setting.columnTitles.count)) / CGFloat(setting.columnTitles.count)
                if index == 0 {
                    columnItem.snp.makeConstraints({ (make) in
                        make.left.top.bottom.equalTo(headerView).offset(0)
                        make.width.equalTo(columnWidth)
                    })
                }else{
                    columnItem.snp.makeConstraints({ (make) in
                        make.left.equalTo(columItemArr[index - 1].snp.right).offset(5)
                        make.top.bottom.equalTo(headerView).offset(0)
                        make.width.equalTo(columnWidth)
                        make.centerY.equalTo(headerView)
                    })
                }
            }else{
                if index == 0 {
                    columnItem.snp.makeConstraints({ (make) in
                        make.left.top.bottom.equalTo(headerView).offset(0)
                    })
                }else{
                    columnItem.snp.makeConstraints({ (make) in
                        make.left.equalTo(columItemArr[index - 1].snp.right).offset(5)
                        make.top.bottom.equalTo(headerView).offset(0)
                        make.centerY.equalTo(headerView)
                    })
                }
            }
            
            columItemArr.append(columnItem)
            if index != setting.columnTitles.count - 1{
                let view = UIView()
                view.backgroundColor = RGBCOLOR(242, 242, 242)
                headerView.addSubview(view)
                view.snp.makeConstraints { (make) in
                    make.top.bottom.equalToSuperview()
                    make.width.equalTo(1)
                    make.left.equalTo(columItemArr[index].snp.right).offset(4)
                }
            }
        }
        self.addSubview(headerView)
        headerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    func  backTap(){
        hide()
    }
    
    func bottomButtonClick(sender:UIButton) {
        hide()
    }
    
    func columnTitleClick(btn:UIButton){
        show = !show
        if currentColumn != btn.tag {
            show = true
            UIView.animate(withDuration: setting.showDuration, animations: {[weak self] () -> () in
                if let strongSelf = self {
                    strongSelf.columItemArr[strongSelf.currentColumn].arrowImageView.transform = CGAffineTransform.identity
                }
            })
        }else{
            
        }
        currentColumn = btn.tag
        if show {
            //            showSubViews.forEach({ (view) in
            //                view.removeFromSuperview()
            //            })可以不这样做
            rotateArrow()
            tableView.isHidden = false
            backView.isHidden  = false
            bottomButton.isHidden = false
            tableView.frame = CGRect(x:0, y: self.y + self.height, width:screenWidth, height: 0)
            bottomButton.frame = CGRect(x:0, y:self.y + self.height, width:screenWidth, height:21)
            backView.frame = CGRect(x:0, y: self.y + self.height, width: screenWidth, height: screenHeight)
            self.superview?.addSubview(tableView)
            self.superview?.addSubview(bottomButton)
            self.superview?.addSubview(backView)
            self.superview?.insertSubview(backView, belowSubview: tableView)
            
            UIView.animate(withDuration: setting.showDuration, animations: {
                self.tableView.height = CGFloat(self.setting.maxShowCellNumber) * self.setting.cellHeight
                
                self.bottomButton.y = self.tableView.frame.maxY - 1
                
                self.backView.alpha = 0.8
            })
        }else{
            hide()
        }
        tableView.reloadData()
    }
    
    private func rotateArrow() {
        UIView.animate(withDuration: setting.showDuration, animations: {[weak self] () -> () in
            if let strongSelf = self {
                strongSelf.columItemArr[strongSelf.currentColumn].arrowImageView.transform =
                    CGAffineTransform.init(rotationAngle: 180 * CGFloat(Double.pi/180))
            }
        })
    }
    
    fileprivate func hide(){
        show = false
        UIView.animate(withDuration: setting.showDuration, animations: {
            self.tableView.height = 0
            self.bottomButton.y -= CGFloat(self.setting.maxShowCellNumber) * self.setting.cellHeight
            self.columItemArr[self.currentColumn].arrowImageView.transform = CGAffineTransform.identity
            self.backView.alpha = 0
        }, completion: { (ret) in
            self.tableView.isHidden = true
            self.bottomButton.isHidden = true
            self.backView.isHidden = true
            self.tableView.removeFromSuperview()
            self.bottomButton.removeFromSuperview()
            self.backView.removeFromSuperview()
        })
    }
    
}


extension WOWDropMenuView:UITableViewDelegate,UITableViewDataSource{
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return setting.rowTitles[currentColumn].count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return setting.cellHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellID = "MenuCell"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellID)
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier:cellID)
            cell?.textLabel?.font = UIFont.systemFont(ofSize: 15)
            cell?.textLabel?.textColor = UIColor.black
            let image = UIImage(named: "duihao")
            let markImageView = UIImageView(frame:CGRect(x:frame.width - (image?.size.width)! - 15, y:0, width:(image?.size.width)!, height: (image?.size.height)!))
            markImageView.centerY = (cell?.contentView.centerY)!
            markImageView.tag = 10001
            markImageView.image = image
            cell?.contentView.addSubview(markImageView)
        }
        let titles = setting.rowTitles[currentColumn]
        cell?.textLabel?.text = titles[indexPath.row]
        cell?.textLabel?.textColor = columnShowingDict[currentColumn] == titles[indexPath.row] ? setting.cellTextLabelSelectColoror : setting.cellTextLabelColor
        if columnShowingDict[currentColumn] == titles[indexPath.row] {
            tableView.scrollToRow(at: indexPath, at:.none, animated: true)
        }
        cell?.contentView.viewWithTag(10001)?.isHidden = !(columnShowingDict[currentColumn] == titles[indexPath.row])
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let title = setting.rowTitles[currentColumn][indexPath.row]
        columItemArr[currentColumn].titleButton.setTitle(title, for: .normal)
        columnShowingDict[currentColumn] = title
        hide()
        if let del = self.delegate {
            del.dropMenuClick(column: currentColumn, row: indexPath.row)
        }
    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let title = WOWDropMenuSetting.rowTitles[currentColumn][indexPath.row]
//        columItemArr[currentColumn].titleButton.setTitle(title, for: .normal)
//        columnShowingDict[currentColumn] = title
//        hide()
//        if let del = self.delegate {
//            del.dropMenuClick(column: currentColumn, row: indexPath.row)
//        }
//    }
    
    //    //因为有view在父试图之外，所以要加入响应  但是会阻碍外侧tableView的响应事件
    //    override func hitTest(point: CGPoint, withEvent event: UIEvent?) -> UIView? {
    //        var view = super.hitTest(point, withEvent: event)
    //        if view == nil {
    //            for v in self.subviews {
    //                let p = v.convertPoint(point, fromView: self)
    //                if  CGRectContainsPoint(v.bounds, p) {
    //                    view = v
    //                }
    //            }
    //        }
    //        return view
    //    }
    
}


public extension Bundle{
    static func loadResourceName(name:String!) -> AnyObject?{
        return  Bundle.main.loadNibNamed(name, owner: self, options: nil)?.last as AnyObject
    }
}
