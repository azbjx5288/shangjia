//
//  WOWDropMenuColumn.swift
//  Wow
//
//  Created by 王云鹏 on 16/4/8.
//  Copyright © 2016年 wowdsgn. All rights reserved.
//

import UIKit

class WOWDropMenuColumn: UIView {

    @IBOutlet weak var titleButton: UIButton!
        
    @IBOutlet weak var arrowImageView: UIImageView!
}
