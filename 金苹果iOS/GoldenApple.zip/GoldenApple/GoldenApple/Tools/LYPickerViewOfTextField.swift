//
//  LYPickerViewOfTextField.swift
//  GoldenApple
//
//  Created by User on 2018/6/4.
//  Copyright © 2018 GoldenMango. All rights reserved.
//

import UIKit

class LYPickerViewOfTextField: UITextField {

    let pickerView = UIPickerView()
    
    var dataArray: NSArray = []
    
    let inputAccessoryTool: UIToolbar? = {
        if UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.pad {
            return nil
        }
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.blackTranslucent
        toolBar.autoresizingMask = UIViewAutoresizing.flexibleHeight
        toolBar.sizeToFit()
        var frame = toolBar.frame
        frame.size.height = 30
        toolBar.frame = frame
        
        return toolBar
    }()
    
    override func draw(_ rect: CGRect) {
        super.drawText(in: rect)
        
        pickerView.dataSource = self
        pickerView.delegate = self
        inputView = pickerView
        inputAccessoryView = inputAccessoryTool
        let doneBtn = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action: #selector(doneBtnClick))
        let flexibleSpaceLeft = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        inputAccessoryTool?.setItems([flexibleSpaceLeft, doneBtn], animated: true)
    }
    
    
    func doneBtnClick() {
        let row = pickerView.selectedRow(inComponent: 0)
        if dataArray.count > 0 {
            text = dataArray.object(at: row) as? String
        }
        
        
        self.resignFirstResponder()
        super.resignFirstResponder()
    }
    
    override var canBecomeFirstResponder: Bool {
        
        return true
    }
    
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        //禁用复制粘贴功能
        super.canPerformAction(action, withSender: sender)
        
        UIMenuController.shared.isMenuVisible = false
        
        return false
    }
}

extension LYPickerViewOfTextField: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return dataArray.count
    }
}

extension LYPickerViewOfTextField: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dataArray.object(at: row) as? String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        text = dataArray.object(at: row) as? String
    }
    
}
