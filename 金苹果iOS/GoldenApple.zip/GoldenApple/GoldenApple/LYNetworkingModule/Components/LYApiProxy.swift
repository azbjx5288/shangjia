//
//  LYApiProxy.swift
//  LYNetworkingModule
//
//  Created by User on 01/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import Alamofire
import UIKit

public class LYApiProxy: NSObject {

    static let `default` = LYApiProxy.init()
    
    private var dispatchTable = [Int : URLSessionTask]()
    
    fileprivate var base64DecodedResponse = false
    
    private override init() {}
    
    func callGETMethod(_ params: NSDictionary, serviceIdentifier: NSString, methodName: NSString, success: @escaping (_ response: LYURLResponse) -> (), fail: @escaping (_ response: LYURLResponse) -> ()) -> Int {
        
        let request = self.generateRequest(serviceIdentifier, requestParams: params, methodName: methodName, requestWithMethod: .get)
        let requestId = self.callApi(request, successCallBack: success, failCallBack: fail)
        
        return requestId
    }
    
    func callPOSTMethod(_ params: NSDictionary, serviceIdentifier: NSString, methodName: NSString, success: @escaping (_ response: LYURLResponse) -> (), fail: @escaping (_ response: LYURLResponse) -> ()) -> Int {
        
        let request = self.generateRequest(serviceIdentifier, requestParams: params, methodName: methodName, requestWithMethod: .post)
        let requestId = self.callApi(request, successCallBack: success, failCallBack: fail)
        
        return requestId
    }
    
    func callPUTMethod(_ params: NSDictionary, serviceIdentifier: NSString, methodName: NSString, success: @escaping (_ response: LYURLResponse) -> (), fail: @escaping (_ response: LYURLResponse) -> ()) -> Int {
        
        let request = self.generateRequest(serviceIdentifier, requestParams: params, methodName: methodName, requestWithMethod: .put)
        let requestId = self.callApi(request, successCallBack: success, failCallBack: fail)
        
        return requestId
    }
    
    func callDELETEMethod(_ params: NSDictionary, serviceIdentifier: NSString, methodName: NSString, success: @escaping (_ response: LYURLResponse) -> (), fail: @escaping (_ response: LYURLResponse) -> ()) -> Int {
        
        let request = self.generateRequest(serviceIdentifier, requestParams: params, methodName: methodName, requestWithMethod: .delete)
        let requestId = self.callApi(request, successCallBack: success, failCallBack: fail)
        
        return requestId
    }
    
    func callHTTPMethod(_ requestWithMethod: HTTPMethod, params: NSDictionary?, serviceIdentifier: NSString, methodName: NSString, success: @escaping (_ response: LYURLResponse) -> (), fail: @escaping (_ response: LYURLResponse) -> ()) -> Int {
        let request = self.generateRequest(serviceIdentifier, requestParams: params, methodName: methodName, requestWithMethod: requestWithMethod)
        let requestId = self.callApi(request, successCallBack: success, failCallBack: fail)
        
        return requestId
    }
    
    /// 取消某个request请求
    ///
    /// - Parameter requestID: requestID
    func cancelRequest(requestID: Int) -> Void {
        let requestOperation = self.dispatchTable[requestID]
        requestOperation?.cancel()
        
        self.dispatchTable.removeValue(forKey: requestID)
    }
    
    /// 取消一些request请求
    ///
    /// - Parameter requestIDList: <#requestIDList description#>
    func cancelRequest(requestIDList: [Int]) -> Void {
        for requestID in requestIDList {
            self.cancelRequest(requestID: requestID)
        }
    }
    
    
    func callApi(_ request: DataRequest, successCallBack: @escaping (_ response: LYURLResponse) -> (), failCallBack: @escaping (_ response: LYURLResponse) -> ()) -> Int {
        
        request.responseData { (dataResponse) in
            let requestId = request.task!.taskIdentifier
            self.dispatchTable.removeValue(forKey: requestId)
            
            var encodingData = dataResponse.data
            
            if self.base64DecodedResponse && dataResponse.data != nil {
                encodingData = Data(base64Encoded: dataResponse.data!, options: Data.Base64DecodingOptions.ignoreUnknownCharacters)
            }
            
            var responseString: String?
            if encodingData != nil {
                responseString = String(data: encodingData!, encoding: .utf8)
            }
            
            #if DEBUG
//                print("\(String(describing: request.request?.url))")
                if encodingData != nil {
                    do {
                        let obj = try JSONSerialization.jsonObject(with: encodingData!, options: .allowFragments)
//                        print("\(String(describing: obj))")
                    } catch {
                        
                    }
                } else {
                    let errorStr = String.init(data: dataResponse.data!, encoding: .utf8)
//                    print(errorStr as Any)
                }

            #endif

            
            switch dataResponse.result{
            case .success( _):
                // TODO: to do
                // 检查http response是否成立。
//                [CTLogger logDebugInfoWithResponse:httpResponse
//                responseString:responseString
//                request:request
//                error:NULL];

                let LYResponse = LYURLResponse.init(responseString: responseString, requestId: requestId, request: request, responseData: encodingData, status: .success)
                successCallBack(LYResponse)
            case .failure(let error):
//                [CTLogger logDebugInfoWithResponse:httpResponse
//                                    responseString:responseString
//                                    request:request
//                                    error:error];
                let LYResponse = LYURLResponse.init(responseString: responseString, requestId: requestId, request: request, responseData: encodingData, error: error as NSError)
                failCallBack(LYResponse)
            }
        }
        
        let requestId = request.task!.taskIdentifier
        
        self.dispatchTable[requestId] = request.task
        return requestId
    }
    
}

extension LYApiProxy {
    
    fileprivate func generateRequest(_ serviceIdentifier: NSString, requestParams: NSDictionary?, methodName: NSString, requestWithMethod: HTTPMethod) -> DataRequest {
        let service = try? LYServiceFactory.default.service(serviceIdentifier)
        let urlString = service!.urlGeneratingRule(methodName)
        if service!.child != nil {
            self.base64DecodedResponse = service!.child!.base64DecodedResponse
        }
        
        let totoalRequestParams = self.totoalRequestParams(service!, methodName: methodName, requestParams: requestParams)
        
        let header: NSDictionary? = nil
        let  dict = service!.child?.extraHttpHeadParams(methodName)
        if dict != nil {
            for (key, value) in dict! {
                header?.setValue(value, forKey: key as! String)
            }
        }
        
        let result = Alamofire.request(urlString, method: requestWithMethod, parameters: (totoalRequestParams as? [String:Any]), encoding: URLEncoding.default, headers: header as? HTTPHeaders)
        
        //这里很重要
        if requestParams != nil {
            result.requestParams = requestParams!
        }
        
        #if DEBUG
//            print("\(String(describing: result.request?.url))")
//            print("\(String(describing: totoalRequestParams))")
        #endif

    
        return result
    }
    
    fileprivate func totoalRequestParams(_ service: LYService, methodName: NSString, requestParams: NSDictionary?) -> NSDictionary? {
        
        if requestParams == nil {
            return nil
        }
        
        let totoalRequestParams = NSMutableDictionary(dictionary: requestParams!)
        
        let extraParams = service.child?.extraParams(methodName: methodName, requestParams: requestParams)
        if extraParams != nil {
            for (key, value) in extraParams! {
                totoalRequestParams.setObject(value, forKey: key as! NSCopying)
            }
        }
        
        return totoalRequestParams.copy() as? NSDictionary
    }
    
}
