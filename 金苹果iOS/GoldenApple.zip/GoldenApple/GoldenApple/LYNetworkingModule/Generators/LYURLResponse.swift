//
//  LYURLResponse.swift
//  LYNetworkingModule
//
//  Created by User on 01/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import Foundation
import Alamofire

public struct LYURLResponse {

    public let status: LYAPIManagerErrorType

    public let contentString: NSString?
    
    public let content: Any?
    
    public let requestId: Int?
    
    public let request: Request?
    
    public let responseData: NSData?
    
    public var requestParams: NSDictionary? = [:]
    
    public let error: NSError?
    
    public let isCache: Bool
    
    public init(responseString: String?, requestId: Int, request: Request, responseData: Data?, status: LYAPIManagerErrorType) {
        self.contentString = responseString as NSString?
        if responseData != nil {
            self.content = try? JSONSerialization.jsonObject(with: responseData!, options: JSONSerialization.ReadingOptions.allowFragments)
        } else {
            self.content = nil
        }
        self.status = status
        self.requestId = requestId
        self.request = request
        self.responseData = responseData as NSData?
        self.requestParams = request.requestParams
        self.isCache = false
        self.error = nil
    }
    
    public init(responseString: String?, requestId: Int, request: Request, responseData: Data?, error: NSError?) {
        self.contentString = responseString as NSString?
        self.requestId = requestId
        self.request = request
        self.responseData = responseData as NSData?
        self.requestParams = request.requestParams
        self.isCache = false
        self.error = error
        if responseData != nil {
            self.content = try? JSONSerialization.jsonObject(with: responseData! as Data, options: JSONSerialization.ReadingOptions.allowFragments)
        } else {
            self.content = nil
        }
        
        if (error != nil) {
            if error?.code == NSURLErrorTimedOut {
                self.status = .timeout
            } else {
                self.status = .noNetWork
            }
        } else {
            self.status = .success
        }
        
    }

    /// 使用initWithData的response，它的isCache是YES，上面两个函数生成的response的isCache是NO
    init(data: Data?) {
        if data != nil {
            self.contentString = NSString.init(data: data!, encoding: String.Encoding.utf8.rawValue)
        } else {
            self.contentString = nil
        }
        
        self.status = .success
        self.requestId = nil
        self.request = nil
        self.responseData = data as NSData?
        self.content = try? JSONSerialization.jsonObject(with: responseData! as Data, options: JSONSerialization.ReadingOptions.allowFragments)
        self.isCache = true
        self.error = nil
    }
    
//    private func responseStatusWithError(_ error: NSError?) ->LYURLResponseStatus {
//        if (error != nil) {
//            let result = LYURLResponseStatus.LYURLResponseStatusErrorNoNetwork
//            if error?.code == NSURLErrorTimedOut {
//                return LYURLResponseStatus.LYURLResponseStatusErrorTimeout
//            } else {
//                return result
//            }
//        }
//        
//        return LYURLResponseStatus.LYURLResponseStatusSuccess
//    }
    
}
