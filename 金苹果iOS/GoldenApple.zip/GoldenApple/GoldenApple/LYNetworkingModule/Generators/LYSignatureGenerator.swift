//
//  LYSignatureGenerator.swift
//  LYNetworkingModule
//
//  Created by User on 26/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

struct LYSignatureGenerator {
    
//    func signGetMethod(_ allParams: NSDictionary, methodName: NSString, apiVersion: NSString) -> NSString {
//        let signStr = allParams.urlParamsString(true)
//        return NSString(
//    }
}
