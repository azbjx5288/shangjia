//
//  GACacheManager.swift
//  GoldenApple
//
//  Created by El Capitan on 2017/11/16.
//  Copyright © 2017年 GoldenMango. All rights reserved.
//

import UIKit

class GACacheManager: NSObject {
    open static let `default`: GACacheManager = {
        return GACacheManager()
    }()
    
    public var lotteryList : [NSDictionary]?
    
    public func getLotteryDictionary(lotteryId : Int) -> NSDictionary? {
        if self.lotteryList == nil {
            return nil
        }
        
        for dict  in self.lotteryList! {
            if dict.object(forKey: "id") as! Int == lotteryId {
                return dict
            }
        }
        return nil
    }
    
    public func getLotteryDictionary(name : String) -> NSDictionary? {
        if self.lotteryList == nil {
            return nil
        }
        
        for dict  in self.lotteryList! {
            if (dict.object(forKey: "name") as! String) == name {
                return dict
            }
        }
        return nil
    }
    //缓存常用彩种ID
    public func addOftenLotteryId(id : Int) {
        let tempArray = NSMutableArray()
        var oftenLotteryIds = UserDefaults.standard.value(forKey: kGAOftenLotteryCacheKey) as? [Int]
        if oftenLotteryIds == nil {
            oftenLotteryIds = NSArray() as? [Int]
        }
        tempArray.addObjects(from: oftenLotteryIds!)
        tempArray.insert(id, at: 0)
        if tempArray.count > 6 {tempArray.remove(tempArray.lastObject as Any)}
        UserDefaults.standard.set((tempArray.copy() as? [Int]), forKey: kGAOftenLotteryCacheKey)
        UserDefaults.standard.synchronize()
    }
    public func getCurrentLotteryId()->Int {
        var oftenLotteryIds = UserDefaults.standard.value(forKey: kGAOftenLotteryCacheKey) as? [Int]
        let id: Int? = oftenLotteryIds?[0]
        if let id = id {
            return id
        } else {
            return 0;
        }
    }
    
    //获取常用彩种
    public func getOftenLotteryList()->[NSDictionary]? {
        let tempArray = NSMutableArray()
        var oftenLotteryIds = UserDefaults.standard.value(forKey: kGAOftenLotteryCacheKey) as? [Int]
        if oftenLotteryIds == nil {
            oftenLotteryIds = NSArray() as? [Int]
        }
        for id in oftenLotteryIds! {
            let predicate = NSPredicate.init(format: "id == %d", id)
            let lottery = (self.lotteryList! as NSArray).filtered(using: predicate) as? [NSDictionary]
            if lottery != nil {
                tempArray.addObjects(from: lottery!)
            }
        }
        return tempArray.copy() as? [NSDictionary]
    }
    
    public func getLotteryIcon(lotteryId : Int) -> String? {
        switch lotteryId {
        case 1:
            return "cqssc" //重庆时时彩
        case 2:
            return "sd11x5" //山东11选5
        case 3:
            return "hljssc" //黑龙江时时彩
        case 4:
            return "shssl" //上海时时乐
        case 6:
            return "xjssc" //新疆时时彩
        case 7:
            return "tjssc" //天津时时彩
        case 8:
            return "jx115" //江西11选5
        case 9:
            return "gd115" //广东11选5
        case 10:
            return "bjpk10" //北京PK拾
        case 11:
            return "3d"   //F3D  3D
        case 12:
            return "plw" //排列三/五
        case 13:
            return "pgffc" // 苹果分分彩
        case 14:
            return "pg115" // 苹果11选5
        case 15:
            return "jsks" // 江苏快三
        case 16:
            return "pg3fc" // 苹果三分彩
        case 17:
            return "pgksffc" // 苹果快三分分彩
        case 18:
            return "gsks" // 甘肃快三
        case 19:
            return "pgjspk10" // 苹果极速PK10
        case 20:
            return "pgjs3d" // 苹果极速3D
        case 21:
            return"gxks" // 广西快三
        case 22:
            return"bj11x5" // 北京11选5
        case 24:
            return "ah115"   //安徽11选5
        case 25:
            return "ln115"   //辽宁11选5
        case 27:
            return"fj115" // 福建11选5
        case 28:
            return"pg5fc" // 苹果五分彩
        case 29:
            return "gz115"   //贵州11选5
        case 30:
            return"ahks" // 安徽快三
        case 32:
            return"sx11x5" // 山西11选5
        case 33:
            return"hbks" // 河北快三
        case 34:
            return "nmg115"   //内蒙古11选5
        case 37:
            return "bjkl8"   //北京快乐8
        case 39:
            return"scklse"   //四川快乐十二
        case 41:
            return"cqsxklsf"   //重庆快乐十分
        case 42:
            return"zjklse"   //浙江快乐十二
        case 44:
            return"pg11x5sfc" // 11选5三分彩
        case 47:
            return "sj115"  //江苏11选5
        case 48:
            return"fjks" // 福建快三
        case 49:
            return"mdbmc" // 缅甸百秒彩
        case 51:
            return "pgkl8ffc"   //苹果快乐8分分彩
        case 52:
            return"sh11x5" // 上海11选5
        case 53:
            return "hb115"   //河北11选5
        case 55:
            return"hnks" // 河南快三
        case 56:
            return "tj115"//天津11选5
        case 57:
            return"gdsxklsf"   //广东快乐十分
        case 59:
            return"lnklse"   //辽宁快乐十二
        case 92:
            return "zj115"   //浙江11选5
        case 93:
            return "twbg"   //台湾宾果
        case 94:
            return"ic_Baccarat" // GA百家乐
        case 95:
            return"ic_ga-xydzp" // GA幸运大转盘
        case 96:
            return"ico_Longhu-bucket" // GA龙虎
        case 97:
            return"ico_speed" // GA骰宝
        case 98:
            return"ic_ga-21dian" // GA二十一点
        case 99:
            return"ico_Win-three" // GA赢三张
        case 100:
            return"ic_xszc" // GA西施早餐
        case 101:
            return"ic_sgj" // GA水果机
        case 110:
            return"ic_ga-brnn" // GA百人牛牛
        case 112:
            return"ic_qwnn" // GA趣味牛牛
        case 113:
            return"ic_ga_jstb" // GA江苏骰宝
        case 114:
            return"ic_ga_sgsgj" // GA三国水果机
        case 115:
            return "ic_ga_elslp"   //俄罗斯轮盘
        case 116:
            return "ic_ga_dzpk"   //德州扑克
        case 117:
            return "ic_ga_sqdz"   //神奇弹珠
        case 118:
            return "ic_ga_jlbpk"   //加勒比扑克
        case 119:
            return "ic_ga_dys"  //打鼹鼠
        case 120:
            return "ic_ga_dfw"  //大富翁
        case 121:
            return "ic_ga_stjdb"  //石头剪刀布
        case 122:
            return "ic_ga_xbjl"  //新百家乐
        case 123:
            return "ic_ga_sg"  //三公
        case 124:
            return "ic_ga_br3g" //百人三公
        case 125:
            return "ic_ga_cjlhd" //超级龙虎斗
        default:
            return"jpgcz"
        }
     
    }
    
    public func getBankIcon(bankId : Int) -> String? {
        switch bankId {
        case 1:
            return "icon_ICBC"     //中国工商银行
        case 2:
            return "icon_CCB"     //中国建设银行
        case 3:
            return "icon_ABC"     //中国农业银行
        case 4:
            return "icon_BC"     //中国银行
        case 5:
            return "icon_CMB"     //招商银行
        case 6:
            return "icon_BOCOM"     //交通银行
        case 7:
            return "icon_CMBms"     //中国民生银行
        case 8:
            return "icon_CCBzx"     //中信银行
        case 9:
            return "icon_SPDB"     //上海浦东发展银行
        case 10:
            return "icon_GDB"     //广东发展银行
        case 11:
            return "icon_PAB"     //平安银行
        case 13:
            return "icon_CIB"     //兴业银行
        case 14:
            return "icon_HB"     //华夏银行
        case 15:
            return "icon_CEB"     //光大银行
        case 16:
            return "icon_PSBC"     //中国邮政
        case 17:
            return "jpgcz"         //城市商业银行
        case 18:
            return "jpgcz"         //农村商业银行
        case 19:
            return "jpgcz"         //恒丰银行
        case 20:
            return "jpgcz"     //浙商银行
        case 21:
            return "jpgcz"     //农村合作银行
        case 22:
            return "jpgcz"     //渤海银行
        case 23:
            return "jpgcz"     //徽商银行
        case 24:
            return "jpgcz"     //村镇银行
        case 25:
            return "jpgcz"     //上海农村商业银行
        case 26:
            return "jpgcz"     //农村信用合作社
        case 27:
            return "jpgcz"     //韩国外换银行
        case 28:
            return "jpgcz"     //友利银行
        case 29:
            return "jpgcz"     //新韩银行
        case 31:
            return "jpgcz"     //韩亚银行
        case 32:
            return "icon_SB"     //上海银行
        case 33:
            return "icon_BOB"     //北京银行
        case 34:
            return "icon_BRCB"     //北京农商银行
        case 35:
            return "jpgcz"     //上海市农村商业银行
        case 36:
            return "icon_HZB"     //杭州银行
        case 37:
            return "icon_BG"     //广州银行
        default:
            return "jpgcz"
        }
     
    }
}
