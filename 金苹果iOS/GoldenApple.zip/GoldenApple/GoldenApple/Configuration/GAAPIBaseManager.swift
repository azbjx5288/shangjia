//
//  GAAPIBaseManager.swift
//  GoldenApple
//
//  Created by User on 16/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class GAAPIBaseManager: LYAPIBaseAPIManager {

    override init() {
        super.init()
        self.validator = self
    }
}

extension GAAPIBaseManager : LYAPIManagerValidator {

    public func isCorrectWithParamsData(_ manager: LYAPIBaseAPIManager, data: NSDictionary?) -> Bool {
        return true
    }

    public func isCorrectWithCallBackData(_ manager: LYAPIBaseAPIManager, data: NSDictionary) -> Bool {
//        GAProgressHUD.hidHUD()
        let errno = data["errno"] as! Int
        if (errno == 0)  {
            return true
        }

        if errno == GAError.ServiceError.forcedExit.rawValue {
            self.cancelAllRequests()
            NotificationCenter.default.post(name: Notification.Name.Logout, object: errno)
            return false
        }

        return false
    }

}


