//
//  GASessionManager.swift
//  GoldenApple
//
//  Created by User on 19/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

open class GASessionManager: NSObject {
    
    open static let `default`: GASessionManager = {
        return GASessionManager()
    }()
    
    struct UserInfoKey {
        static let kAbalance = "abalance"
        static let kNickname = "nickname"
        static let kUsername = "username"
        static let kToken = "token"
    }
    
    var userinformation: NSDictionary!
    

}

