//
//  Notifications.swift
//  GoldenApple
//
//  Created by User on 17/10/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import Foundation

extension Notification.Name {
    
    public static let Logout = Notification.Name("com.GoldenMango.GoldenApple.notification.name.logout")
    
}
