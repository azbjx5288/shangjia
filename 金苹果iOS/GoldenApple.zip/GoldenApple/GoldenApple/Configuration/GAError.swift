//
//  GAError.swift
//  GoldenApple
//
//  Created by User on 16/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class GAError: Error {

    public enum ServiceError: Int {
        case forcedExit = 3004
    }
    
}

