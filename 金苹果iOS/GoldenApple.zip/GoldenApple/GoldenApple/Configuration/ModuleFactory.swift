//
//  ModuleFactory.swift
//  GoldenApple
//
//  Created by User on 27/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

enum MoudleType : String {
    case login = "kGAServiceLoginUser"
}

enum ServiceType : String {
    case goldenApple = "GoldenAppleService"
}

public class ModuleFactory {
    
    class func createModule(_ moduleType: MoudleType) -> UIViewController {
        var module: UIViewController!
        switch moduleType {
        case .login:
            module = LoginViewController()

        }
        
        return module
    }
    
}
