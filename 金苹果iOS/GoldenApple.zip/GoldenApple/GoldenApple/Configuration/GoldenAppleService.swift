//
//  GoldenAppleService.swift
//  GoldenApple
//
//  Created by User on 27/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

class GoldenAppleService: LYService {

}

extension GoldenAppleService: LYServiceProtocol {
    var isOnline: Bool {
        return false
    }
    
    var offlineApiBaseUrl: NSString {
        return "http://jpgapi4.4385nt.com"
//        return "http://jpgapi.4385nt.com"
    }
    
    var onlineApiBaseUrl: NSString {
        return "http://jpg888.org"
    }
    
    var offlineApiVersion: NSString {
        return ""
    }
    
    var onlineApiVersion: NSString {
        return ""
    }
    
    var offlinePublicKey: NSString {
//        return "505b2c0b58fff48635c6c955ced91a2b" //android测试服key
        return "df340af70e8541882701b344d29fa101"   //iOS测试服key
    }
    
    var onlinePublicKey: NSString {
//        return "dad4dd6edf43146881a3da6ed84bf029" //android正式服key
        return "4e6cd604d31901b6de5d134673875f66"   //iOS正式服key
    }
    
    var offlinePrivateKey: NSString {
        return ""
    }
    
    var onlinePrivateKey: NSString {
        return ""
    }
    
    var base64DecodedResponse: Bool {
        return true
    }
    
    func extraParams(methodName: NSString, requestParams: NSDictionary?) -> NSDictionary? {
        
        if requestParams != nil {
        //对参数进行加密签名
            var metodStr = ""
            if methodName.range(of: "?").location != NSNotFound {
                metodStr = methodName.substring(from: methodName.range(of: "?").upperBound)
            }
            
            let signStr = metodStr + (requestParams!.urlParamsString(false) as String) + (self.publicKey as String)
            return ["sign" : signStr.md5()]
        }

        return nil
    }
    
    
    func extraHttpHeadParams(_ methodName: NSString) -> NSDictionary? {
        return [ "sessionID" : NSUUID().uuidString]
    }
    
    func callAPIDidFailed(_ manager: LYAPIBaseAPIManager) {
        
        GAProgressHUD.hidHUD()
        let errDict = manager.fetchData(nil) as? NSDictionary
        if errDict != nil {
            let errInfo = errDict!.object(forKey: "error") as! String
            GAProgressHUD.showWarning(message: errInfo)
        } else {
            switch manager.errorType {
            case .noContent:
                GAAlertController.showAlert("提示", "请求失败,网络故障!", "取消", "重试", cancelCallBack: nil, commitCallBack: {
                    manager.loadData()
                })
            case .noNetWork:
                GAAlertController.showAlert("提示", "返回数据不正确!", "取消", "重试", cancelCallBack: nil, commitCallBack: {
                    manager.loadData()
                })
            case .timeout:
                GAAlertController.showAlert("提示", "请求超时!", "取消", "重试", cancelCallBack: nil, commitCallBack: {
                    manager.loadData()
                })
            case .paramsError:
                GAAlertController.showAlert("提示", "参数错误!", "取消", "重试", cancelCallBack: nil, commitCallBack: {
                    manager.loadData()
                })
            default: GAAlertController.showAlert("提示", "程序出错!", "取消", "重试", cancelCallBack: nil, commitCallBack: { manager.loadData() })
            }
        }
        
    }
    
}

