//
//  GoldenAppleConst.swift
//  GoldenApple
//
//  Created by User on 02/11/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

import UIKit

func RGBCOLOR(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> UIColor {
    return UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: a)
}

let kGANavigationBackgroundColor = RGBCOLOR(207, 82, 78)

/// color 39,40,44
let kGATabbarBackgroundColor = RGBCOLOR(39, 40, 44)

/// color
let kGATabbarUnSelectedFontColor = RGBCOLOR(169, 169, 170)

let kGAViewGrayBackgoundColor = RGBCOLOR(232, 232, 233)

let kGAFontGrayColor = RGBCOLOR(153, 153, 153)

let kGAFontLightGrayColor = RGBCOLOR(220, 220, 220)

let kGAFontRedColor = RGBCOLOR(207, 78, 75)

let kGAFontBlackColor = RGBCOLOR(51, 51, 51)

let kGABallGrayColor = RGBCOLOR(214, 214, 214)

let kGABackgroundColor = RGBCOLOR(240, 240, 240)

let kGASerperatorLineGrayColor = RGBCOLOR(153, 153, 153, 0.3)

let kGACustomerServiceUrlString = "http://s3.myapple888.com/index/app?companyId=70722524&style=default&mode=4"

let kGAOftenLotteryCacheKey = "kGAOftenLotteryCacheKey"


let kGAlotteryIdDatas = [
    "全部彩种" : "-1",
    "重庆时时彩" : "1",
    "山东11选5" : "2",
    "黑龙江时时彩" : "3",
    "上海时时乐" : "4",
    "新疆时时彩" : "6",
    "天津时时彩" : "7",
    "江西11选5" : "8",
    "广东11选5" : "9",
    "北京PK拾" : "10",
    "3D" : "11",
    "排列三/五" : "12",
    "苹果分分彩" : "13",
    "苹果11选5" : "14",
    "江苏快三" : "15",
    "苹果三分彩" : "16",
    "苹果快三分分彩" : "17",
    "甘肃快三" : "18",
    "苹果极速PK10" : "19",
    "苹果极速3D" : "20",
    "广西快三" : "21",
    "北京11选5" : "22",
    "安徽11选5" : "24",
    "辽宁11选5" : "25",
    "福建11选5" : "27",
    "苹果五分彩" : "28",
    "贵州11选5" : "29",
    "安徽快三" : "30",
    "山西11选5" : "32",
    "河北快三" : "33",
    "内蒙古11选5" : "34",
    "北京快乐8" : "37",
    "四川快乐十二" : "39",
    "重庆快乐十分" : "41",
    "浙江快乐十二" : "42",
    "11选5三分彩" : "44",
    "江苏11选5" : "47",
    "福建快三" : "48",
    "缅甸百秒彩" : "49",
    "苹果快乐8分分彩" : "51",
    "上海11选5" : "52",
    "河北11选5" : "53",
    "河南快三" : "55",
    "天津11选5" : "56",
    "广东快乐十分" : "57",
    "辽宁快乐十二" : "59",
    "浙江11选5" : "92",
    "台湾宾果" : "93"
]
let kGAlotteryNameDatas = [
    "全部彩种",
    "重庆时时彩",
    "山东11选5",
    "黑龙江时时彩",
    "上海时时乐",
    "新疆时时彩",
    "天津时时彩",
    "江西11选5",
    "广东11选5",
    "北京PK拾",
    "3D",
    "排列三/五",
    "苹果分分彩",
    "苹果11选5",
    "江苏快三",
    "苹果三分彩",
    "苹果快三分分彩",
    "甘肃快三",
    "苹果极速PK10",
    "苹果极速3D",
    "广西快三",
    "北京11选5",
    "安徽11选5",
    "辽宁11选5",
    "福建11选5",
    "苹果五分彩",
    "贵州11选5",
    "安徽快三",
    "山西11选5",
    "河北快三",
    "内蒙古11选5",
    "北京快乐8",
    "四川快乐十二",
    "重庆快乐十分",
    "浙江快乐十二",
    "11选5三分彩",
    "江苏11选5",
    "福建快三",
    "缅甸百秒彩",
    "苹果快乐8分分彩",
    "上海11选5",
    "河北11选5",
    "河南快三",
    "天津11选5",
    "广东快乐十分",
    "辽宁快乐十二",
    "浙江11选5",
    "台湾宾果"
]

let KGAQueryTimeList = ["今天","昨天","近7天","当月"]
let KGAQueryBettingStatusNames = ["全部状态","待开奖","已开奖","未中奖","已撤单"]
let KGALotteryBettingStatus = ["全部状态":"-1","待开奖":"0","已开奖":"4","未中奖":"2","已撤单":"1"]
let KGAQueryChasingStatusNames = ["全部状态", "已完成", "进行中", "用户终止", "系统终止", "管理员终止"]
let KGAQueryChasingStatusList = ["全部状态":"-1","进行中":"0", "已完成":"1", "用户终止":"2",  "管理员终止":"3", "系统终止":"4"]
