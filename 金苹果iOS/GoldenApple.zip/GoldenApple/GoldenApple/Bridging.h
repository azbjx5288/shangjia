//
//  Bridging.h
//  GoldenApple
//
//  Created by User on 28/09/2017.
//  Copyright © 2017 GoldenMango. All rights reserved.
//

#ifndef Bridging_h
#define Bridging_h

#import <CommonCrypto/CommonCrypto.h>
#if Release
#import "UMMobClick/MobClick.h"
#endif
#endif /* Bridging_h */
